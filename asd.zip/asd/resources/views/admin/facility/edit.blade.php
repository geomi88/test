@extends('admin.layouts.master')
@section('styles')
@parent
<style>

</style>
@stop
@section('content')
  @section('bodyClass')
    @parent
    hold-transition skin-blue sidebar-mini
  @stop
 <div class="container-fluid dashboard-content">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Update Facility  - {{ $facilityDetails->facility_title }}
					<a class="float-sm-right" href="{{ apa('facility_manager') }}"><button class="btn btn-outline-dark btn-flat">Back</button></a></h2>
            </div>
        </div>
    </div>  
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <div class="col-sm-12 card-header form-header">
                    <div class="row align-items-center">
                        <h5>Fields marked (<em>*</em> ) are mandatory</h5> 
                    </div>
                </div>
                
				{!! Form::open(array('url' => apa('facility_manager/update/'.$facilityDetails->facility_id ) , 'id'=>'post-form','files'=>true)) !!}
                    <div class="card-body">
                        <div class="col-sm-12">
                            @include('admin.common.user_message')
							<div class="clearfix"></div>
								<div class="row">
									<div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="facility_title" class="col-form-label">Facility  Title<em>*</em></label>
                                            <input id="facility_title" name="facility_title" type="text" value="{{ $facilityDetails->facility_title }}" class="form-control" required>
                                        </div>
                                    </div>
                                     
                                </div>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="facility_image" class="col-form-label">Facility  Image<em>*</em></label><br/>
											@if(Storage::exists('public/uploads/facility/image/'.$facilityDetails->facility_image))
												<img src="{{ asset('storage/uploads/facility/image/'.$facilityDetails->facility_image) }}" style="width:60px"/>
											@endif
                                            <input  name="facility_image" type="file" class="form-control" >
                                        </div>
                                    </div>
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="facility_icon" class="col-form-label">Facility  Icon, (If any)<em>*</em></label><br/>
											@if(Storage::exists('public/uploads/facility/icon/'.$facilityDetails->facility_icon))
												<img src="{{ asset('storage/uploads/facility/icon/'.$facilityDetails->facility_icon) }}" style="width:60px"/>
											@endif
                                            <input id="facility_icon" name="facility_icon" type="file" class="form-control" >
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="facility_excerpt" class="col-form-label">Facility  Excerpt<em>*</em></label>
                                            <textarea  name="facility_excerpt" type="file" class="form-control editorLTR" required>{{ $facilityDetails->facility_exceprt }}</textarea>
                                        </div>
                                    </div>
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="facility_description" class="col-form-label">Facility  Description<em>*</em></label>
                                            <textarea id="facility_description" name="facility_description"class="form-control editorLTR" required>{{ $facilityDetails->facility_description }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                        <label for="facility_status" class="col-form-label">Facility  Status<em>*</em></label>
                                            <select id="facility_status" name="facility_status" class="form-control">
                                                
                                                <option {{($facilityDetails->facility_status==1) ? "selected" : "" }} value="1">Active</option>
                                                <option {{($facilityDetails->facility_status==2) ? "selected" : "" }} value="2">Inactive</option>
                                            </select>
                                        </div>
                                    </div> 
                                </div>
						</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="button-control-wrapper">
                                <div class="form-group">
                                    <input class="btn btn-primary" type="submit" name="updatebtnsubmit" value="Update"  />
                                    <a href="{{ apa('facility_manager') }}" class="btn btn-danger">Close</a>
                                </div>
                            </div>
                        </div>           
					</div>           
                {{ Form::close() }}
            </div>
        </div>
    </div>
 </div>  
@stop

@section('scripts')
@parent
<script>
 $(document).ready(function(){
     $('#post-form').validate();

 });
</script>

@stop