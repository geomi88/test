@extends('admin.layouts.master')
@section('styles')
@parent
<style>

</style>
@stop
@section('content')
  @section('bodyClass')
    @parent
    hold-transition skin-blue sidebar-mini
  @stop
 <div class="container-fluid dashboard-content">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Add Facility
					<a class="float-sm-right" href="{{ apa('facility_manager') }}"><button class="btn btn-outline-dark btn-flat">Back</button></a></h2>
            </div>
        </div>
    </div>  
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <div class="col-sm-12 card-header form-header">
                    <div class="row align-items-center">
                        <h5>Fields marked (<em>*</em> ) are mandatory</h5> 
                    </div>
                </div>
                
                 {!! Form::open(['method' => 'POST', 'url' => apa('facility_manager/create' ), 'id'=>'post-form','files'=>true] ) !!}
				
                    <div class="card-body">
                        <div class="col-sm-12">
                            @include('admin.common.user_message')
                            <div class="clearfix"></div>
                            
                                
								<div class="row">
									<div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="facility_title" class="col-form-label">Facility  Title<em>*</em></label>
                                            <input id="facility_title" name="facility_title" type="text" value="{{ Input::old('facility_title') }}" class="form-control" required>
                                        </div>
                                    </div>
                                     
                                </div>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="facility_image" class="col-form-label">Facility  Image<em>*</em></label>
                                            <input  name="facility_image" type="file" class="form-control" required>
                                        </div>
                                    </div>
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="facility_icon" class="col-form-label">Facility  Icon, (If any)<em>*</em></label>
                                            <input id="facility_icon" name="facility_icon" type="file" class="form-control" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="facility_excerpt" class="col-form-label">Facility  Excerpt<em>*</em></label>
                                            <textarea  name="facility_excerpt" type="file" class="form-control editorLTR" required>{{ Input::old('facility_excerpt') }}</textarea>
                                        </div>
                                    </div>
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="facility_description" class="col-form-label">Facility  Description<em>*</em></label>
                                            <textarea id="facility_description" name="facility_description"class="form-control editorLTR" required>{{ Input::old('facility_description') }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                        <label for="facility_status" class="col-form-label">Facility  Status<em>*</em></label>
                                            <select id="facility_status" name="facility_status" class="form-control">
                                                <option value="1">Active</option>
                                                <option value="2">Inactive</option>
                                            </select>
                                        </div>
                                    </div> 
                                </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="button-control-wrapper">
                                <div class="form-group">
                                    <input class="btn btn-primary" type="submit" name="savebtnsubmit" value="Save"  />
                                    <a href="{{ apa('facility_manager') }}" class="btn btn-danger">Close</a>
                                </div>
                            </div>
                        </div>
                    </div>
                {{ Form::close() }}
            </div>
        </div>
    </div>
 </div>  
@stop

@section('scripts')
@parent
<script>
 $(document).ready(function(){
     $('#post-form').validate();

 });
</script>

@stop