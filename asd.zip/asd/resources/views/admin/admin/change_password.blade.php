@extends('admin.layouts.master')
@section('styles')
@parent
<style>

</style>
@stop
@section('content')
  @section('bodyClass')
    @parent
    hold-transition skin-blue sidebar-mini
  @stop
 <div class="container-fluid dashboard-content">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Change Password
					<a class="float-sm-right" href="{{ apa('soil') }}"><button class="btn btn-outline-dark btn-flat">Back</button></a></h2>
            </div>
        </div>
    </div>  
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                
                 {!! Form::open(['method' => 'POST', 'url' => apa('change_password' ), 'id'=>'changepwd-form'] ) !!}
				
                    <div class="card-body">
                        <div class="col-sm-12">
                            @include('admin.common.user_message')
                            <div class="clearfix"></div>
                            
                                
								<div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="current_password" class="col-form-label">Current Password</label>
                                            <input id="current_password" name="current_password" type="password" value="" class="form-control" required>
                                        </div>
                                    </div>
                                     
                                </div>

                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="new_password" class="col-form-label">Current Password</label>
                                            <input id="new_password" name="new_password" type="password" value="" class="form-control" required>
                                        </div>
                                    </div>
                                     
                                </div>
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="confirm_password" class="col-form-label">Confirm Password</label>
                                            <input id="confirm_password" name="confirm_password" type="password" value="" class="form-control" required>
                                        </div>
                                    </div>
                                     
                                </div>
                                
                                
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="button-control-wrapper">
                                <div class="form-group">
                                    <input class="btn btn-primary" type="submit" name="savebtnsubmit" value="Save"  />
                                </div>
                            </div>
                        </div>
                    </div>
                {{ Form::close() }}
            </div>
        </div>
    </div>
 </div>  
@stop

@section('scripts')
@parent
<script>
 $(document).ready(function(){
     $('#changepwd-form').validate({
            errorElement: 'label',
            ignore: [],
            rules: {
                'current_password': {
                    required: true
                },
                'new_password': {
                    required: true,
                    minlength : 8,
                },
                'confirm_password': {
                    required: true,
                    equalTo: "#new_password",
                    minlength : 8,
                },
            },
            messages: {

            },
            submitHandler: function(form) {
                
                form.submit();
            }

        });

 });
</script>

@stop