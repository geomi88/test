<script>
   $('body').on('change','#hubId', function(e) {
	    e.preventDefault();
		var id=$(this).val();
	    var url_="{{apa('ajax/get-space')}}/"+id;
		
		var dataToSend = {};
		
		sendAjax(url_,'get',dataToSend,function(data){
			if(data.status){
				var options='<option value="">Select One</option>';
				$.each(data.spaceList,function(i,v){
				  options+='<option value="'+v.space_id+'">'+v.space_title+'</option>';
				});
				$('#alottedSpace').html(options);
			}
		});
    });
</script>