@extends('admin.layouts.master')
@section('content')
@section('bodyClass')
@parent 
hold-transition skin-blue sidebar-mini
@stop
<div class="container-fluid dashboard-content">
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="page-header">
				<h2 class="pageheader-title">Category Manager
					<a class="float-sm-right" href="{{ apa('category_manager/create') }}">
						<button class="btn btn-success btn-flat">Create New</button>
					</a>
				</h2>
			</div>
		</div>
	</div> 
	
	<div class="row">
		<div class="col-sm-12">
			@include('admin.common.user_message')
		</div>
		<!-- ============================================================== -->
		<!-- striped table -->
		<!-- ============================================================== -->
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="card">
				<div class="col-sm-12 card-header my-table-header">
					<div class="row align-items-center">
						<div class="col-sm-6"><h5 class="">{{ $categoryList->count() }} results found.</h5></div>
						<?php /*<div class="col-sm-6"><h5 class="text-right">Showing {{ $hubList->currentPage() }} of {{  $hubList->total() }} pages</h5></div> */ ?>
					</div>
				</div>
				<div class="card-body">
					<div class="table-responsive-md">
						<?php  if(!empty($categoryList) && $categoryList->count() > 0){ ?>

							<table id="example1" class="table table-bordered table-hover">

							 <thead>

								<tr>

									<th>Sl.no</th>

									<th>Category English Title</th>

									<th>Parent Category</th>
									
									

									<th>Status</th>
									<th>Options</th>

								</tr></thead>

								<tbody>

								<?php
									$inc=getPaginationSerial($categoryList);
									foreach ($categoryList as $category){
										
								?>

										<tr>

											<td class="slno"><span class="centered"><?php echo $inc++; ?></span></td>
											<td>
												<div class="col-sm-12" style="max-width:350px">
													<div class="col-sm-12" >{{ $category->category_title }}</div>
												</div>
											</td>
											<td>
												<div  class="col-sm-12" dir="rtl" > 
													@if(isset($category->parentCategory))
														{{ $category->parentCategory->category_title }}
													@else
														NILL
													@endif
												</div>
											</td>
											
											<td class="status">
                                                    <?php 
                                                        echo ($category->category_status==1)
                                                        ?"<a href='".apa('category_manager/changestatus/'.$category->category_id)."' ><i class='fa fa-check-circle'></i></a>"
                                                        :"<a href='".apa('category_manager/changestatus/'.$category->category_id)."' ><i class='fa fa-times-circle'></i></a>"; 
                                                    ?>
                                            </td>

											<td  class="manage">
												<ul>
												<li>
                                                    <a href="{{ apa('category_manager/update/'.$category->category_id) }}" title="edit"><i class="far fa-edit"></i></a>
												</li>
												<?php /*
												<li>
                                                    <a href="{{apa('category_manager/delete/'.$category->category_id) }}" class="btn btn-danger btn-sm" title="delete" onclick="return confirm('Are you sure want to delete?');"><i class="fa fa-trash-o"></i></a>
												</li>
												*/ ?>
												</ul>
											</td>


										</tr>

										<?php } ?>
                                        <tr>
                                            <td colspan="6" >{!! $categoryList->links() !!}</td>
                                        </tr>
								   </tbody>

							</table>
							</div>
							<?php }else{ ?>


									<div class="col-sm-12">

										<div class="alert alert-danger alert-dismissable">

											<i class="fa fa-ban"></i>

											<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

											<b>Alert!</b> No Records Found!.

										</div>

									</div>

							<?php } ?>
</div>
				</div>
			</div>
		</div>
	</div>
</div>
@stop