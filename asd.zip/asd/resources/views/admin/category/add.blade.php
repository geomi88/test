@extends('admin.layouts.master')
@section('content')
@section('bodyClass')
@parent 
hold-transition skin-blue sidebar-mini
@stop
<div class="container-fluid dashboard-content">
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="page-header">
				<h2 class="pageheader-title">Category Manager
					<a class="float-sm-right" href="{{ apa('category_manager/create') }}">
						<button class="btn btn-success btn-flat">Create New</button>
					</a>
				</h2>
			</div>
		</div>
	</div> 
	
	<div class="row">
		<div class="col-sm-12">
			@include('admin.common.user_message')
		</div>
		<!-- ============================================================== -->
		<!-- striped table -->
		<!-- ============================================================== -->
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="card">
				<div class="col-sm-12 card-header my-table-header">
					<div class="row align-items-center">
						<div class="col-sm-6"><h5 class="">Add category</h5></div>
						<?php /*<div class="col-sm-6"><h5 class="text-right">Showing {{ $hubList->currentPage() }} of {{  $hubList->total() }} pages</h5></div> */ ?>
					</div>
				</div>
				<div class="card-body">
  						{{ Form::open(array('url' => apa('category_manager/create'),'files' => true,'role'=>'form','name'=>'CategoryCreate')) }}


	        				<div class="row">
								<div class="col-sm-6">
	        						<label>Parent Category</label>		
                                    
	        						<select name="category_parent_id" class="form-control">
                                    <option value="">Select Parent Category</option>
        								@if(!empty($categoryList))
                                            @foreach($categoryList as $category)
                                                <option value="{{ $category->category_id }}">{{ $category->category_title }}</option>
                                            @endforeach
                                        @endif
        							</select>
	        					</div>


	        					<div class="col-sm-6">

	        						<label>Category Title</label>

	        						<input type="text" name="category_title"  value= "{{ Input::old('category_title') }}" class="form-control" placeholder=""   required />

	        					</div>

	        					
	        				</div>
                            <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="agriculture_image" class="col-form-label">Category Image<em>*</em></label>
                                            <input  name="category_image" type="file" class="form-control" required>
                                        </div>
                                    </div>
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="agriculture_icon" class="col-form-label">Category Icon, (If any)<em>*</em></label>
                                            <input id="category_icon" name="category_icon" type="file" class="form-control" required>
                                        </div>
                                    </div>
                            </div>
                            
        					<div class="row">
        						<div class="col-sm-4">
        							<label>Status</label>
        							<select name="category_status" class="form-control">
        								<option value="1">Activate</option>
        								<option value="2">Deactivate</option>
        							</select>
        						</div>
        					</div>

        					<div class="row">
        						<div class="col-sm-6">
        							<div class="form-group"></div>
        							<div class="form-group">
        								<input type="submit" name="createbtnsubmit" value="Submit"  class="btn btn-success  btn-flat">
        								<a href="<?php echo apa('category'); ?>" class="btn btn-danger  btn-flat">Close</a>
        							</div>
        						</div>
        					</div>
        			{{ Form::close() }}
  					</div>
			</div>
		</div>
	</div>
</div>
@stop