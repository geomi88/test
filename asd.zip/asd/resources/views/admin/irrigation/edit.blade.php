@extends('admin.layouts.master')
@section('styles')
@parent
<style>

</style>
@stop
@section('content')
  @section('bodyClass')
    @parent
    hold-transition skin-blue sidebar-mini
  @stop
 <div class="container-fluid dashboard-content">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Update Irrigation  - {{ $irrigationDetails->irrigation_title }}
					<a class="float-sm-right" href="{{ apa('irrigation') }}"><button class="btn btn-outline-dark btn-flat">Back</button></a></h2>
            </div>
        </div>
    </div>  
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <div class="col-sm-12 card-header form-header">
                    <div class="row align-items-center">
                        <h5>Fields marked (<em>*</em> ) are mandatory</h5> 
                    </div>
                </div>
                
				{!! Form::open(array('url' => apa('irrigation/update/'.$irrigationDetails->irrigation_id ) , 'id'=>'post-form','files'=>true)) !!}
                    <div class="card-body">
                        <div class="col-sm-12">
                            @include('admin.common.user_message')
							<div class="clearfix"></div>
								<div class="row">
									<div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="irrigation_title" class="col-form-label">Irrigation  Title<em>*</em></label>
                                            <input id="irrigation_title" name="irrigation_title" type="text" value="{{ $irrigationDetails->irrigation_title }}" class="form-control" required>
                                        </div>
                                    </div>
                                     
                                </div>
                                
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                        <label for="irrigation_status" class="col-form-label">Irrigation  Status<em>*</em></label>
                                            <select id="irrigation_status" name="irrigation_status" class="form-control">
                                                <option {{($irrigationDetails->irrigation_status==1) ? "selected" : "" }} value="1">Active</option>
                                                <option {{($irrigationDetails->irrigation_status==2) ? "selected" : "" }} value="2">Inactive</option>
                                            </select>
                                        </div>
                                    </div> 
                                </div>
						</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="button-control-wrapper">
                                <div class="form-group">
                                    <input class="btn btn-primary" type="submit" name="updatebtnsubmit" value="Update"  />
                                    <a href="{{ apa('irrigation') }}" class="btn btn-danger">Close</a>
                                </div>
                            </div>
                        </div>           
					</div>           
                {{ Form::close() }}
            </div>
        </div>
    </div>
 </div>  
@stop

@section('scripts')
@parent
<script>
 $(document).ready(function(){
     $('#post-form').validate();

 });
</script>

@stop