@extends('admin.layouts.master')
@section('content')
@section('bodyClass')
@parent 
hold-transition skin-blue sidebar-mini
@stop
<div class="container-fluid dashboard-content">
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="page-header">
				<h2 class="pageheader-title">Farm Subscriptions					
				</h2>
			</div>
		</div>
	</div> 
	<div>
			@include('admin.farm_subscription.list_filters')
	</div>
	<div class="row">
		<div class="col-sm-12">
			@include('admin.common.user_message')
		</div>
		<!-- ============================================================== -->
		<!-- striped table -->
		<!-- ============================================================== -->
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="card">
				<div class="col-sm-12 card-header my-table-header">
					<div class="row align-items-center">
						<div class="col-sm-6"><h5 class="">{{ $subscriptionList->total() }} results found.</h5></div>
						<?php /*<div class="col-sm-6"><h5 class="text-right">Showing {{ $hubList->currentPage() }} of {{  $hubList->total() }} pages</h5></div> */ ?>
					</div>
				</div>
				<div class="card-body">
					<div class="table-responsive-md">
						<table class="table table-striped table-bordered">
							<thead>
								<tr>
									
									<th scope="col">#</th>
									
									<th scope="col">Farm Name</th>
									
									<th scope="col">Owner</th>
									
									<th scope="col">Subscriber</th>
									
									<th scope="col">Option</th>
									
									
								</tr>
							</thead>
							<tbody>
								@if (count($subscriptionList) > 0)
									<?php $inc = getPaginationSerial($subscriptionList); 	?>
								
									@foreach ($subscriptionList as $subscription)
									
									<tr>
										<td>{{ $inc++ }}</td>
										<td>
											{{$subscription->getFarmDetails->fm_title}}
										</td>
                                        <td>{{$subscription->getFarmDetails->owner->user_full_name}}</td>
                                        <td>{{$subscription->subscriber_details->user_full_name}}</td> 										
										<td>
											<a href="{{ apa('farm_subscriptions/view/'.$subscription->fs_id) }}" class="btn btn-xs btn-info">View</a>											
										</td>
										
									</tr>
									@endforeach
								@else
									<tr>
										<td colspan="5">@lang('global.app_no_entries_in_table')</td>
                                    </tr>
                                    
                                @endif
                                    <tr>
                                        <td colspan="5">{{$subscriptionList->links()}}</td>
                                    </tr>
                                
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@stop