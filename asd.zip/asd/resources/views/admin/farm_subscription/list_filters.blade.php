<div id="filterOptions" style="{{empty(Input::get('filterNow')) ? '' : ''}}">
    {{ Form::open(array('name'=>'filter-farms','url'=>Config::get('app.admin_prefix').'/farm_subscriptions','method'=>'get' )) }}
        <div class="row">                                            
            <div class="col-md-4 form-group">
                <input type="text" name="name" class="dirChange form-control border {{ !empty(Input::get('name')) ? 'border-green' : '' }}" value="{{Input::get('name')}}" placeholder="Search by Farm Name" /> 
            </div>  
                        
            <input type="hidden" name="sortCol" id="sortCol" value ="" />
            <input type="hidden" name="sortOrd" id="sortOrd" value ="" />
            <div class="clearfix"></div>
            <div class="col-md-4 form-group">
                <input type="submit" name="filterNow" id="filterNow" class=" btn btn-success" value="Search" /> 
                <a href="{{ asset(Config::get('app.admin_prefix').'/farm_subscriptions') }}"><input type="button" name="filterNow" class=" btn btn-primary" value="Reset" /></a> 
            </div>
        </div>
    {{ Form::close() }}
    
</div>