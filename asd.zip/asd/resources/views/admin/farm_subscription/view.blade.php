@extends('admin.layouts.master')
@section('content')
@section('bodyClass')
@parent 
hold-transition skin-blue sidebar-mini
@stop
<div class="container-fluid dashboard-content">
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="page-header">
				<h2 class="pageheader-title">Subscription Details					
				</h2>
			</div>
		</div>
	</div> 
	
	<div class="row">
		<div class="col-sm-12">
			@include('admin.common.user_message')
		</div>
		<!-- ============================================================== -->
		<!-- striped table -->
		<!-- ============================================================== -->
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="card">
				
				<div class="card-body">
					<div class="table-responsive-md">
						<table class="table table-striped table-bordered">
							<tbody>
								<tr>																		
									<td><b>Farm Name</b></td>									
									<td>{{$subscriptionDetails->getFarmDetails->fm_title}}</td>																																				
                                </tr>
                                <tr>																		
									<td><b>Owner Name</b></td>									
									<td>{{$subscriptionDetails->getFarmDetails->owner->user_full_name}}</td>																																				
                                </tr>
                                <tr>																		
									<td><b>Subsciber Name</b></td>									
									<td>{{$subscriptionDetails->subscriber_details->user_full_name}}</td>																																				
                                </tr>
                                <tr>																		
									<td><b>Start Date</b></td>									
									<td>{{date_convert($subscriptionDetails->fs_start_date)}}</td>																																				
                                </tr>
                                <tr>																		
                                    <td><b>End Date</b></td>
                                    @php $expiry_date = date('Y-m-d', strtotime("+$subscriptionDetails->fs_duration_months months", strtotime($subscriptionDetails->fs_start_date))); @endphp									
									<td>{{date_convert($expiry_date)}}</td>																																				
                                </tr>
                                <tr>																		
									<td><b>Total Duration</b></td>									
									<td>{{$subscriptionDetails->fs_duration_months}} Months</td>																																				
                                </tr>
                                <tr>																		
									<td><b>Number of Plots</b></td>									
									<td>{{$subscriptionDetails->fs_number_of_plots}}</td>																																				
                                </tr>
								<tr>																		
									<td><b>Price</b></td>									
									<td>${{ $subscriptionDetails->getFarmDetails->fm_price }} per month</td>																																				
                                </tr>
                                <tr>																		
									<td><b>Total Price</b></td>									
									<td>${{ $subscriptionDetails->fs_total_amount }}</td>																																				
                                </tr>
                                <tr>																		
									<td><b>Crops</b></td>									
									<td>
                                        <ul>
                                        @foreach($subscriptionDetails->subscribed_crops as $farm_crop)
                                            <li>
                                                {{ $farm_crop->single_crop->agriculture_title }}
                                            </li>
                                        @endforeach
                                        </ul>
                                    </td>																																				
								</tr>
								@if($subscriptionDetails->fs_change_loc_status == 1)
								<tr>																		
									<td><b>Delivery Address</b></td>									
									<td>
                                        <p>
										Name : {{$subscriptionDetails->fs_delivery_full_name}}
										</p>
										<p>
										Phone : {{$subscriptionDetails->fs_ph_no}}
										</p>
										<p>
										Address : {{$subscriptionDetails->fs_delivery_address}}
										</p>
										<p>
										City : {{$subscriptionDetails->fs_delivery_city}}
										</p>
										<p>
										Zip : {{$subscriptionDetails->fs_delivery_zip}}
										</p>
										<p>
										Country : {{$subscriptionDetails->deliveryCountry->country_name}}
										</p>
                                    </td>																																				
								</tr>
								@else
								<tr>																		
									<td><b>Delivery Address</b></td>									
									<td>
                                        <p>
										Name : {{$subscriptionDetails->subscriber_details->user_full_name}}
										</p>
										<p>
										Phone : {{$subscriptionDetails->subscriber_details->user_phone_number}}
										</p>
										<p>
										Address : {{$subscriptionDetails->subscriber_details->user_address}}
										</p>
										<p>
										Country : {{$subscriptionDetails->subscriber_details->userNationality->country_name}}
										</p>
                                    </td>																																				
								</tr>
								@endif
							</tbody>
							
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@stop