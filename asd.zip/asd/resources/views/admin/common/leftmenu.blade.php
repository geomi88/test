<div class="nav-left-sidebar sidebar-dark">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light"> 
            <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider">
                        Menu
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ get_admin_menu_active_class($currentURI,['dashboard']) }}" href="{{ apa('dashboard') }}"><i class="fas fa-chart-pie"></i>Dashboard</a>
                    </li>
					<?php /*
                    <li class="nav-item">
                        <a class="nav-link {{ get_admin_menu_active_class($currentURI,['menu_manager']) }}" href="{{ apa('menu_manager') }}">
							<i class="fas fa-chart-pie"></i>Menu Manager
						</a>
					</li>
					*/ ?>
					<li class="nav-item ">
						<a class="nav-link active collapsed" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-1" aria-controls="submenu-1"><i class="fa fa-fw fa-user-circle"></i>Master Records</a>
						<div id="submenu-1" class="submenu collapse" style="">
							<ul class="nav flex-column">
								<li class="nav-item">
									<a class="nav-link {{ get_admin_menu_active_class($currentURI,['agriculture_manager']) }}" href="{{ apa('agriculture_manager') }}"><i class="fas fa-chart-pie"></i>Agriculture Manager</a>
								</li>
								<li class="nav-item">
									<a class="nav-link {{ get_admin_menu_active_class($currentURI,['agriculture_type']) }}" href="{{ apa('agriculture_type') }}"><i class="fas fa-chart-pie"></i>Agriculture Type</a>
								</li>
								<li class="nav-item">
									<a class="nav-link {{ get_admin_menu_active_class($currentURI,['facility_manager']) }}" href="{{ apa('facility_manager') }}"><i class="fas fa-chart-pie"></i>Facilities Manager</a>
								</li>
								<li class="nav-item">
									<a class="nav-link {{ get_admin_menu_active_class($currentURI,['irrigation']) }}" href="{{ apa('irrigation') }}"><i class="fas fa-chart-pie"></i>Irrigation</a>
								</li>
								<li class="nav-item">
									<a class="nav-link {{ get_admin_menu_active_class($currentURI,['category_manager']) }}" href="{{ apa('category_manager') }}"><i class="fas fa-chart-pie"></i>Category Manager</a>
								</li>
								<li class="nav-item">
									<a class="nav-link {{ get_admin_menu_active_class($currentURI,['country']) }}" href="{{ apa('country') }}"><i class="fas fa-chart-pie"></i>Country</a>
								</li>								
								<li class="nav-item">
									<a class="nav-link {{ get_admin_menu_active_class($currentURI,['soil']) }}" href="{{ apa('soil') }}"><i class="fas fa-chart-pie"></i>Soil</a>
								</li>
							</ul>
						</div>
					</li>
					<li class="nav-item">
                        <a class="nav-link {{ get_admin_menu_active_class($currentURI,['farm_manager']) }}" href="{{ apa('farm_manager') }}"><i class="fas fa-chart-pie"></i>Farm Manager</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ get_admin_menu_active_class($currentURI,['farm_subscriptions']) }}" href="{{ apa('farm_subscriptions') }}"><i class="fas fa-chart-pie"></i>Farm Subscriptions</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ get_admin_menu_active_class($currentURI,['admin_users']) }}" href="{{ apa('admin_users') }}"><i class="fas fa-chart-pie"></i>Admin Users</a>
                    </li>					
                    <li class="nav-item">
                        <a class="nav-link {{ get_admin_menu_active_class($currentURI,['users']) }}" href="{{ apa('users') }}"><i class="fas fa-chart-pie"></i>Users</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ get_admin_menu_active_class($currentURI,['permissions']) }}" href="{{ apa('permissions') }}"><i class="fas fa-chart-pie"></i>Permissions</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ get_admin_menu_active_class($currentURI,['roles']) }}" href="{{ apa('roles') }}"><i class="fas fa-chart-pie"></i>Roles</a>
                    </li>
                   
                    <li class="nav-item">
                        <a class="nav-link {{ get_admin_menu_active_class($currentURI,['setting']) }}" href="{{ apa('setting') }}"><i class="fas fa-chart-pie"></i>Setting</a>
                    </li>                    
                    
                    
                    
                </ul>
            </div>
        </nav>
    </div>
</div>