<section class="form-group basic_settings multipuploader">
	
	
		
	<div id="old_gallery" class="row galleryWrapper">
		
	</div>
	
	<div class="clearfix"></div>
	
	
	
	<div class="row" id="container">
		<div class="col-sm-12"><div id="no-image"></div></div>
		<div class="fileUploadBtnWrap col-sm-3 pull-right">
			<button id="pickfiles" class="btn btn-primary ">Select Photos </button>	
			<button id="start" class="btn btn-success">Upload <div id="loader" style="display:none;float:right;margin-left:5px;"><img width="25px;"src="{{ asset('assets/admin/images/loader.gif') }}" /></div></button>
			<input type="hidden" name="imageGalleryID" id="imageGalleryID" value="" />
			<div id="console"></div>
			<div id="upProgWrapper fileUploadProgressBtnWrap">
				<div id="upProg"></div>
			</div>		
		</div>	
	</div>
	
</section>
@section('scripts')
@parent
<!--<script src="<?php echo asset('/assets/admin/js/fu/plupload.full.min.js');?>" type="text/javascript"></script>-->
<script>
	<?php $editID = empty($farm_id) ? '-1' : $farm_id; ?>
	var resize = '';
	var imgPath = "<?php echo asset('storage/uploads/gallery/small/')?>";
	<?php if(in_array($postType,['banner_logos'])) { ?>
		resize = '?resize=false';
		imgPath = "<?php echo asset('storage/uploads/gallery/')?>";
		setTimeout(function(){
			$('.imageHolder').css({background: 'rgb(25, 24, 24)'});
		},4000)
		
	<?php	}?>
	function delete_gallery_image(id,elem){
		console.log(elem);
		$.ajax({
			url:'<?php echo asset(Config::get('app.admin_prefix').'/image-gallery/delete/'); ?>/'+id+resize,
			type:'get',
			async:false,
			data:{},
			dataType:'json',
			statusCode: {
				302:function(){ alert('Forbidden. Access Restricted'); },
				403:function(){ alert('Forbidden. Access Restricted','403'); },
				404:function(){ alert('Page not found','404'); },
				500:function(){ alert('Internal Server Error','500'); }
			},
            success:(function(responseData){
			if(responseData.status==true){
				//var el=  elem.closest('.imageHolder');
				//el.parent().remove();
				elem.parent().parent().remove();
			}				
			}),
            error:(function(jqXHR,textStatus){
			t = false;
            })
			});
	}
	
	function get_Image_gallery(){
		$('#old_gallery').html('');	
		$('#loader').show();
		$.ajax({
			url:'<?php echo asset(Config::get('app.admin_prefix').'/image-gallery/get_old_files/?type='.$postType.'&farm_id='.$editID); ?>',
			type:'post',
			async:false,
			data:{_token:window.Laravel.csrfToken},
			dataType:'json',
			statusCode: {
				302:function(){ alert('Forbidden. Access Restricted'); 	$('#loader').hide();},
				403:function(){ alert('Forbidden. Access Restricted','403'); 	$('#loader').hide();},
				404:function(){ alert('Page not found','404'); 	$('#loader').hide();},
				500:function(){ alert('Internal Server Error','500'); 	$('#loader').hide();}
			},
            success:(function(responseData){
			if(responseData.status==true){
				
				var images = responseData.gallery;
				if(images.length==0){
					$('#no-image').html('No Images found!');
				}
				for(var kk=0,ll=images.length;kk<ll;kk++){
					$('#old_gallery').append('<div class="col-sm-3"><div class="imageHolder"><div class="img_" style="background-image:url('+imgPath+'/'+images[kk].gallery_image_name+')"></div></div><div class="toolbox"><a href="javscript:void(0);" class="delGalImg" data-id="'+images[kk].gallery_id+'"><i class="fa fa-trash"></i></a></div></div>');
				}
			}	
			$('#loader').hide();				
			}),
            error:(function(jqXHR,textStatus){
			t = false;
			$('#loader').hide();
		})
			});
	}
	
	$(document).ready(function(){
		
		$('.addVideo').on('click',function(){
			
			$('.table tbody').append('<tr><td><img width="100px" src="{{ asset("assets/admin/images/no-youtube-thumb.png") }}" /></td>'+
			'<td><input type="text" name="shows_link[]" class="form-control" placeholder="Enter the Youtube link  here" /></td>'+
			'<td><a href="#" class="deleteTableRow">Delete</a></td></tr>');	
		});
		
		$('.table').on('click','.deleteTableRow',function(e){
			e.preventDefault();
			$(this).parent().parent().remove();
		});
		var cusBaseURL = '<?php echo asset('/'); ?>';
		
		
		$('#old_gallery').on('click','.delGalImg',function(e){
			if(confirm('Are you sure you want to delete?')==true){
				delete_gallery_image($(this).attr('data-id'),$(this));
			}
		});
		$('.video_gallery').on('click','.delGalImg',function(e){
			if(confirm('Are you sure you want to delete?')==true){
				delete_gallery_image($(this).attr('data-id'),$(this));
			}
		});
		
		get_Image_gallery();
		
		var uploader = new plupload.Uploader({
			runtimes : 'html5,flash,silverlight,html4',
			browse_button : 'pickfiles', // you can pass in id...
			container: document.getElementById('container'), // ... or DOM Element itself
			url : '<?php echo asset(Config::get('app.admin_prefix').'/image-gallery/file-upload?type='.$postType.'&farm_id='.$editID)?>',
			flash_swf_url : '<?php echo asset('assets/admin/js/fu/Moxie.swf')?>',
			silverlight_xap_url :  '<?php echo asset('assets/admin/js/fu/Moxie.xap')?>',
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			},
			filters : {
				max_file_size : '10mb',
				mime_types: [
				{title : "Image files", extensions : "jpg,gif,png"},
				]
			},
			multipart_params : {
				"ImageIDE" : '',
			},
			init: {
				PostInit: function() {
					document.getElementById('start').onclick = function() {
						uploader.start();
						return false;
					};
					
					
				},
				BeforeUpload:function (up,files){
					var status_before = files.status;
					$('#loader').show();
					uploader.settings.url = '<?php echo asset(Config::get('app.admin_prefix').'/image-gallery/file-upload?type='.$postType.'&farm_id='.$editID)?>';	
				},										
				FilesAdded: function(up, files) {

				},
				
				UploadProgress: function(up, file) {

				},
				FileUploaded:function(up,file,response){
					var t = response.response;
					var rt  = $.parseJSON(t);
					if(!rt.uploadDetails){
						alert('Upload Failed');
						return false;
					}
					rt = rt.uploadDetails;
					if(rt.status == true ){
						$('#no-image').hide();
						$('#old_gallery').prepend('<div class="col-sm-3"><div class="imageHolder"><img src="'+imgPath+'/'+rt.fileName+'"/><div class="toolbox"><input type="hidden" name="gallaryImages[]" value="'+rt.id+'"/><a href="javscript:void(0);" class="delGalImg" data-id="'+rt.id+'"><i class="fa fa-trash"></i></a></div></div></div>');
					}
				},
				UploadComplete:function(up,files){
					$('#loader').hide();
				},
				Error: function(up, err) {
					document.getElementById('console').innerHTML += "\nError #" + err.code + ": " + err.message;
				}
			}
		});
		
		uploader.init();
	});
</script>
@stop
