@extends('admin.layouts.master')
@section('metatags')
<meta name="description" content="{{{@$websiteSettings->site_meta_description}}}" />
<meta name="keywords" content="{{{@$websiteSettings->site_meta_keyword}}}" />
<meta name="author" content="{{{@$websiteSettings->site_meta_title}}}" />

@stop
@section('seoPageTitle')
<title>{{{ $pageTitle }}}</title>
@stop
@section('styles')
@parent
<style>
	#view-selector-container {
		display: none;
	}

	.anchorWhite {
		color: #fff !important;
	}

	.anchorWhite:hover {
		color: #00000057 !important;
	}
</style>
@stop

@section('content')
@section('bodyClass')
@parent
hold-transition skin-blue sidebar-mini
@stop

<div class="container-fluid dashboard-content">
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="page-header">
				<h2 class="pageheader-title">{{ $pageTitle }} </h2>
			</div>
			@if(!empty($userMessage))
			{!! $userMessage !!}
			@endif
		</div>
	</div>
	<!-- <div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="card">
				<h5 class="card-header">User Statistics</h5>
				<div class="card-body">
					<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
						<div class="card">
							<h5 class="card-header">Registrations By Year</h5>
							<div class="card-body">
								content here
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div> -->
	<div class="row">
		<div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
			<div class="card">
				<div class="card-body">
					<h5 class="text-muted">Total Farms</h5>
					<div class="metric-value d-inline-block">
						<h1 class="mb-1">{{$farms_count}}</h1>
					</div>
					<!-- <div class="metric-label d-inline-block float-right text-success font-weight-bold">
						<span><i class="fa fa-fw fa-arrow-up"></i></span><span>5.86%</span>
					</div> -->
				</div>
				<!-- <div id="sparkline-revenue"><canvas style="display: inline-block; width: 370.375px; height: 100px; vertical-align: top;" width="370" height="100"></canvas></div> -->
			</div>
		</div>
		<div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
			<div class="card">
				<div class="card-body">
					<h5 class="text-muted">Farm Subscriptions</h5>
					<div class="metric-value d-inline-block">
						<h1 class="mb-1">{{$farms_subscriptions_count}}</h1>
					</div>
					<!-- <div class="metric-label d-inline-block float-right text-success font-weight-bold">
						<span><i class="fa fa-fw fa-arrow-up"></i></span><span>5.86%</span>
					</div> -->
				</div>
				<!-- <div id="sparkline-revenue2"><canvas width="370" height="100" style="display: inline-block; width: 370.375px; height: 100px; vertical-align: top;"></canvas></div> -->
			</div>
		</div>
		<div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
			<div class="card">
				<div class="card-body">
					<h5 class="text-muted">Users</h5>
					<div class="metric-value d-inline-block">
						<h1 class="mb-1">{{$users_count}}</h1>
					</div>
					<!-- <div class="metric-label d-inline-block float-right text-primary font-weight-bold">
						<span>N/A</span>
					</div> -->
				</div>
				<!-- <div id="sparkline-revenue3"><canvas width="370" height="100" style="display: inline-block; width: 370.375px; height: 100px; vertical-align: top;"></canvas></div> -->
			</div>
		</div>
		
	</div>
</div>

@stop

@section('scripts')
@parent

@stop