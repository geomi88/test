@extends('admin.layouts.master')
@section('content')
@section('bodyClass')
@parent 
hold-transition skin-blue sidebar-mini
@stop
<div class="container-fluid dashboard-content">
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="page-header">
				<h2 class="pageheader-title">Country List
					<a class="float-sm-right" href="{{ apa('country/create') }}">
						<button class="btn btn-success btn-flat">Create New</button>
					</a>
				</h2>
			</div>
		</div>
	</div> 
	
	<div class="row">
		<div class="col-sm-12">
			@include('admin.common.user_message')
		</div>
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="card">
				<div class="col-sm-12 card-header my-table-header">
					<div class="row align-items-center">
						<div class="col-sm-6"><h5 class="">{{ $countryList->count() }} results found.</h5></div>
						<?php /*<div class="col-sm-6"><h5 class="text-right">Showing {{ $hubList->currentPage() }} of {{  $hubList->total() }} pages</h5></div> */ ?>
					</div>
				</div>
				<div class="card-body">
					<div class="table-responsive-md">
						
						
						
						<?php  if(count($countryList)>0){ ?>												
							<table id="members1" class="table table-bordered table-hover">
							 <thead>
								<tr>
									<th>#</th>
									<th>Name</th>								
									<th>Name Arabic</th>								
									<th>Flag</th>								
                                    <th>Status</th>					
									<th>Manage</th>											
								</tr>
							</thead>								
								<tbody>	
								<?php 
									$inc=1;
									foreach ($countryList as $country){
                                        // pre($country);
									$activeUrl= apa( 'country/changestatus/'.$country->country_id.'/'.$country->country_status);
									$DeactiveUrl= apa('country/changestatus/'.$country->country_id.'/'.$country->country_status);
								
								?>
										<tr>
											<td>{{ $inc++ }}</td>
											<td>{{ $country->country_name }}</td>
											<td><div style="text-align:right;direction:rtl"><strong>{{ $country->country_name_arabic }}</strong></div></td>
											<td style="text-align:center"><img src="{{ asset('assets/country-flags/svg/'.strtolower($country->iso).'.svg') }}" style="height:40px;width:80px"/></td>
                                            <td class="status">
												{!! ($country->country_status == 1)?"<a href='".$activeUrl."'><i class='fa fa-check-circle'></i></a>":"<a href='".$DeactiveUrl."' ><i class='fa fa-trash'></i></a>" !!}
                                            </td>
											
											<td class="manage">
												<ul>
                                                    <li>
														<a href="{{ apa('country/update/'.$country->country_id) }}" class="btn btn-xs btn-info">Edit</a>
                                                    </li>
													<!-- <li>
														<a data-id="{{ $country->country_id }}" href="{{ apa('country/delete/'.$country->country_id) }}" class="deleteRecord btn btn-xs btn-danger">Delete</a>
													</li> -->
												</ul>
											</td>
												
												
										</tr>
										<?php } ?>
								   </tbody>                            
							</table>							
							<?php }else{ ?>
							<div class="row col-sm-12">
								<div class="alert alert-danger alert-dismissable">
									<i class="fa fa-ban"></i>
									<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
									<b>Alert!</b> No Records Found!.  
								</div> 
							</div>  
							<?php } ?>
				</div>
				</div>
			</div>
		</div>
	</div>
</div>
@stop