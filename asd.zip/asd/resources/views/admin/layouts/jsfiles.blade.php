<script type="text/javascript" src="{{ asset('assets/admin/vendor/jquery/jquery-3.4.1.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/admin/vendor/jquery-ui/jquery-ui.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/admin/vendor/bootstrap/js/bootstrap.bundle.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/admin/vendor/moment/moment.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/admin/vendor/fancybox/jquery.fancybox.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/admin/vendor/sweetalert2/sweetalert2.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/admin/vendor/stickymessage/sticky.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/admin/vendor/jquery-validator/jquery.validate.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/admin/vendor/slimscroll/jquery.slimscroll.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/admin/vendor/basictable/jquery.basictable.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/admin/vendor/select2/js/select2.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/admin/vendor/inputmask/js/jquery.inputmask.bundle.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/admin/vendor/pgs/js/admin.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/admin/vendor/bootstrap-select/js/bootstrap-select.js') }}"></script>

<script>
 $(document).ready(function(){
     $('.selectpicker').selectpicker({
        liveSearch: true,
      });

     $('#post-form').validate();

 });
</script>
<script>
  $.widget.bridge('uibutton', $.ui.button);
 
</script>
<script>
$(function(){
    $('.table').basictable({
        breakpoint: 768,
    });
    $(".custom-select").select2({});
});  
function sendAjax(URL,type,data,func,loaderDivID,$elem){
		if(loaderDivID){ $(loaderDivID).show(); }
		$.ajax({
			url:URL,
			type:type,
			async:true,
			data:data,
			dataType:'json',
			statusCode: {
				302:function(){ console.log('Forbidden. Access Restricted'); },
				403:function(){ console.log('Forbidden. Access Restricted','403'); },
				404:function(){ console.log('Page not found','404'); },
				500:function(){ console.log('Internal Server Error','500'); }
			}
		}).done(function(responseData){
			if(loaderDivID){$(loaderDivID).hide();}
			func(responseData,$elem);

		});

	}  
</script>
@if($hasPluploader)
	<script src="<?php echo asset('assets/admin/plugins/plupload/plupload.full.min.js'); ?>" type="text/javascript"></script> 
	@include('admin.common.general_file_uploader_script')
@endif
	
@if($hasTextEditor)
	<script src="<?php echo asset('assets/admin/vendor/tinymce/tinymce.min.js'); ?>" type="text/javascript"></script> 
@endif

<script type="text/javascript">			
$(function() {
	<?php /* open parent menu by adding class */ ?>
	$('.submenu ').find('.nav-link').each(function(i,el){
		if($(el).hasClass('active')){
			$(el).closest('.submenu').addClass('show');
		}
	});
	
	$('.datepicker').datepicker({autoclose:true});
	$(".landphonemaskUAE").inputmask("99 999 9999");
	$(".mobileUAE").inputmask("00\\971 999 999 999");
	
	@if($hasTextEditor)
		tinymce.init({
			selector: '.editor',
			plugins: ["link","paste","spellchecker","preview","fullscreen","code","table","directionality",'lists'],
			toolbar: ["fullscreen | undo redo | ltr rtl  |  bullist numlist |styleselect | bold italic | aligncenter alignright alignjustify | link"],
			extended_valid_elements: "span[]",
			valid_elements: "*[*]",
			forced_root_block : false
		});
		tinymce.init({
			selector: '.editorAr',
			directionality:'rtl',
			plugins: ["link","paste","spellchecker","preview","fullscreen","code","table","directionality",'lists'],
			toolbar: ["fullscreen | undo redo | ltr rtl  | bullist numlist |styleselect | bold italic | aligncenter alignright alignjustify | link"],
			extended_valid_elements: "span[]",
			valid_elements: "*[*]",
			forced_root_block : false
		});
	@endif
	
	@if($hasPluploader)     
		createAjaxFileUploader("{{ asset(Config::get('app.admin_prefix').'/general_fileupload') }}");
	@endif 
}); 

$(document).ready(function() {
	if ($(".menu-list").length) {
		$('.menu-list').slimScroll({});
		}
	
	setTimeout(function(){
		$('.message-wrapper').fadeOut();
	},20000) 
	
	$('body').on('click','.deleteRecord',function(e){
		var _this = $(this);
		var _dataMsg = $(this).attr('data-message');
		
		var _message = (_dataMsg) ? _dataMsg :'{{empty($postType) ? 'Delete this entry ?' : 'Delete this '.$postType.' ?' }}'
		e.preventDefault();
		
		Swal.fire({
			title: 'Are you sure ?',
			text: _message,
			type: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes !'
			}).then((result) => {
			if (result.value) {
				window.location.href = _this.attr('href');
			}
		});
		
	});
	$(".numOnly").keydown(function (e) {
		if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
		(e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
		(e.keyCode >= 35 && e.keyCode <= 40)) {
			return;
		}
		if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
			e.preventDefault();
		}
	});
	
	@if(!empty($topMessage))
	$('#topMessage').html("{{ $topMessage }}");
	$('#topMessage').removeClass('hidden');
	setTimeout(function(){
		$('#topMessage').addClass('hidden');
		$('#topMessage').html('');
	},6000);
	@endif
});
</script>


