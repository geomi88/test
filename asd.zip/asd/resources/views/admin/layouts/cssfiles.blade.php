<?php /*
<link href="https://fonts.googleapis.com/css?family=Cairo:300,400,600,700&amp;subset=arabic" rel="stylesheet">
{{ HTML::style('assets/admin/plugins/bootstrap/css/bootstrap.min.css') }}
{{ HTML::style('assets/admin/plugins/bootstrap/css/bootstrap-theme.css') }}
{{ HTML::style('assets/admin/dist/css/skins/_all-skins.css') }}
{{ HTML::style('assets/admin/dist/css/font-awesome.min.css') }}
{{ HTML::style('assets/admin/dist/css/AdminLTE.min.css') }}
{{ HTML::style('assets/admin/plugins/jQueryUI/jquery-ui.min.css') }}
{{ HTML::style('assets/admin/dist/css/custom_admin.css') }}
{{ HTML::style('assets/admin/dist/css/datetimepicker/bootstrap-datetimepicker.css') }}
{{ HTML::style('assets/admin/plugins/sweetalert/sweetalert.css') }}
{{ HTML::style('assets/admin/plugins/stickymessage/sticky.css') }}
{{ HTML::style('assets/admin/plugins/colorpicker/bootstrap-colorpicker.min.css') }}
{{ HTML::style('assets/admin/dist/dataTable/css/dataTables.bootstrap.min.css') }}
{{ HTML::style('assets/admin/dist/css/pgs.css') }}
*/ ?>

{{ HTML::style('assets/admin/vendor/bootstrap/css/bootstrap.min.css') }}
{{ HTML::style('assets/admin/vendor/jquery-ui/jquery-ui.min.css') }}
{{ HTML::style('assets/admin/vendor/basictable/basictable.css') }}
{{ HTML::style('assets/admin/vendor/select2/css/select2.css') }}
{{ HTML::style('assets/admin/vendor/inputmask/css/inputmask.css') }}
{{ HTML::style('assets/admin/vendor/sweetalert2/sweetalert2.min.css') }}
{{ HTML::style('assets/admin/vendor/fonts/circular-std/style.css') }}
{{ HTML::style('assets/admin/vendor/fonts/flag-icon-css/flag-icon.min.css') }}
{{ HTML::style('assets/admin/vendor/fonts/fontawesome/css/fontawesome-all.css') }}
{{ HTML::style('assets/admin/libs/css/style.css') }}
{{ HTML::style('assets/admin/custom-admin.css') }}
{{ HTML::style('assets/admin/vendor/bootstrap-select/css/bootstrap-select.css') }}


