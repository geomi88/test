@extends('admin.layouts.master')
@section('styles')
@parent
<style>
.imageHolder {
	border: 1px solid #ccc;
    margin-bottom: 15px;
    background: #fbfbfb;
}
#map{ width:500px; height: 300px; }
</style>
@stop
@section('content')
  @section('bodyClass')
    @parent
    hold-transition skin-blue sidebar-mini
  @stop
 <div class="container-fluid dashboard-content">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Add Farm
					<a class="float-sm-right" href="{{ apa('farm_manager') }}"><button class="btn btn-outline-dark btn-flat">Back</button></a></h2>
            </div>
        </div>
    </div>  
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <div class="col-sm-12 card-header form-header">
                    <div class="row align-items-center">
                        <h5>Fields marked (<em>*</em> ) are mandatory</h5> 
                    </div>
                </div>
                
                 {!! Form::open(['method' => 'POST', 'url' => apa('farm_manager/create' ), 'id'=>'post-form','files'=>true] ) !!}
				
                    <div class="card-body">
                        <div class="col-sm-12">
                            @include('admin.common.user_message')
                            <div class="clearfix"></div>
                            
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="farm_categories" class="col-form-label">Farm Category<em>*</em></label>
                                            <select id="farm_categories" name="farm_categories[]" class="form-control selectpicker" multiple required>
												@if(!empty($categoryList))
													@foreach($categoryList as $category)
														<option value="{{ $category->category_id }}">{{ $category->category_title }}</option>
													@endforeach
												@endif
											</select>
                                        </div>
                                    </div>
                                    <?php /* <div class="col-sm-6">
                                        <div class="form-group">
                                        <label for="farm_type_id" class="col-form-label">Farm Type<em>*</em></label>
                                            <select id="farm_type_id" name="farm_type_id" class="form-control">
                                                <option value="1">Crop</option>
                                                <option value="2">Live Stock</option>
                                            </select>
                                        </div>
                                    </div> */ ?>
                                </div>
								<div class="row">
									<div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="fm_title" class="col-form-label">Farm Title<em>*</em></label>
                                            <input id="fm_title" name="fm_title" type="text" value="{{ Input::old('fm_title') }}" class="form-control" required>
                                        </div>
                                    </div>
                                     
                                </div>
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_country_id" class="col-form-label">Country</label>
                                            <select id="fm_country_id" name="fm_country_id" class="form-control">
                                                <option value="">Select Country</option>
												@if(!empty($countryList))
													@foreach($countryList as $country)
														<option value="{{ $country->country_id }}">{{ $country->country_name }}</option>
													@endforeach
												@endif
											</select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_state_name" class="col-form-label">Farm State</label>
                                            <input id="fm_state_name" name="fm_state_name" type="text" value="{{ Input::old('fm_state_name') }}" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_city" class="col-form-label">Farm City</label>
                                            <input id="fm_city" name="fm_city" type="text" value="{{ Input::old('fm_city') }}" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_zipcode" class="col-form-label">Farm Zip</label>
                                            <input id="fm_zipcode" name="fm_zipcode" type="text" value="{{ Input::old('fm_zipcode') }}" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <div id="map"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_area" class="col-form-label">Total Area</label>
                                            <input id="fm_area" name="fm_area" type="text" value="{{ Input::old('fm_area') }}" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_area_unit" class="col-form-label">Unit</label>
                                            <select id="fm_area_unit" name="fm_area_unit" class="form-control">
                                                <option value="">Select Unit</option>
                                                <option value="Acre">Acre</option>
												<option value="M2">M2</option>
                                                <option value="Feet">Feet</option>
											</select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_price" class="col-form-label">Price</label>
                                            <input id="fm_price" name="fm_price" type="text" value="" class="form-control">
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_plots_no" class="col-form-label">Number of plots</label>
                                            <input id="fm_plots_no" name="fm_plots_no" type="text" value="{{ Input::old('fm_plots_no') }}" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_plot_map" class="col-form-label">Plot Map</label>
                                            <input  name="fm_plot_map" type="file" accept="image/gif,image/jpeg,image/png" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="farm_agricultures" class="col-form-label">Crops</label>
                                            <select id="farm_agricultures" name="farm_agricultures[]" class="form-control selectpicker" multiple>
												@if(!empty($agricultureList))
													@foreach($agricultureList as $agriculture)
														<option value="{{ $agriculture->agriculture_id }}">{{ $agriculture->agriculture_title }}</option>
													@endforeach
												@endif
											</select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="farm_facilities" class="col-form-label">Facilities</label>
                                            <select id="farm_facilities" name="farm_facilities[]" class="form-control selectpicker" multiple>
												@if(!empty($facilityList))
													@foreach($facilityList as $facility)
														<option value="{{ $facility->facility_id }}">{{ $facility->facility_title }}</option>
													@endforeach
												@endif
											</select>
                                        </div>
                                    </div>
                                </div>
                                <?php /* <div class="row fl fl-wrap">
                                    <div class="col-sm-6  fl fl-wrap fileUploadWrapper form-group">
                                        {!! getPlUploadControl('Featured Image [recommended 600 x 866](jpg,jpeg,png)(2MB)','featured_image',['jpg','png','jpeg'],'image','Select File',null,null,@Input::old('meta')['text']['featured_image'],'farm_manager') !!}
                                    </div>
                                </div> */ ?>
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_soil_id" class="col-form-label">Soil Type</label>
                                            <select id="fm_soil_id" name="fm_soil_id" class="form-control">
                                                <option value="">Select Soil Type</option>
												@if(!empty($soilList))
													@foreach($soilList as $soil)
														<option value="{{ $soil->soil_id }}">{{ $soil->soil_title }}</option>
													@endforeach
												@endif
											</select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_irrigation_id" class="col-form-label">Irrigation</label>
                                            <select id="fm_irrigation_id" name="fm_irrigation_id" class="form-control">
                                            <option value="">Select Irrigation Type</option>
												@if(!empty($irrigationList))
													@foreach($irrigationList as $irrigation)
														<option value="{{ $irrigation->irrigation_id }}">{{ $irrigation->irrigation_title }}</option>
													@endforeach
												@endif
											</select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_agriculture_type_id" class="col-form-label">Agriculture Type</label>
                                            <select id="fm_agriculture_type_id" name="fm_agriculture_type_id" class="form-control">
                                            <option value="">Select Agriculture Type</option>
												@if(!empty($agricultureTypeList))
													@foreach($agricultureTypeList as $agricultureType)
														<option value="{{ $agricultureType->agriculture_type_id }}">{{ $agricultureType->agriculture_type_title }}</option>
													@endforeach
												@endif
											</select>
                                        </div>
                                    </div>                                    
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_main_image" class="col-form-label">Farm Image</label>
                                            <input name="fm_main_image" id="fm_main_image" type="file" accept="image/gif,image/jpeg,image/png" class="form-control">
                                        </div>
                                    </div>
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_main_icon" class="col-form-label">Farm Icon</label>
                                            <input id="fm_main_icon" name="fm_main_icon" type="file" accept="image/gif,image/jpeg,image/png" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_farm_highlights" class="col-form-label">Farm Highlights</label>
                                            <textarea id="fm_farm_highlights" name="fm_farm_highlights" type="file" class="form-control editorLTR">{{ Input::old('fm_farm_highlights') }}</textarea>
                                        </div>
                                    </div>
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_about_farm" class="col-form-label">Farm Description</label>
                                            <textarea id="fm_about_farm" name="fm_about_farm"class="form-control editorLTR">{{ Input::old('fm_about_farm') }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_policies" class="col-form-label">Farm Policies</label>
                                            <textarea id="fm_policies" name="fm_policies" class="form-control editorLTR">{{ Input::old('fm_policies') }}</textarea>
                                        </div>
                                    </div>									
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="available_start_date" class="col-form-label">Available Start Date</label>
                                            <input class="form_control available_start_date" readonly type="text" value="" name="available_start_date" id="available_start_date">
                                        </div>
                                    </div>
                                
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="available_end_date" class="col-form-label">Available End Date</label>
                                            <input class="form_control available_end_date" readonly type="text" value="" name="available_end_date" id="available_end_date">
                                        </div>
                                    </div>
                                </div>
                                <?php /* <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="farm_cultivate_min_duration" class="col-form-label">Farm Min Duration [in months]</label>
                                            <input id="farm_cultivate_min_duration" name="farm_cultivate_min_duration" type="number" value="{{ Input::old('farm_cultivate_min_duration') }}" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="farm_cultivate_max_duration" class="col-form-label">Farm Min Duration [in months]</label>
                                            <input id="farm_cultivate_max_duration" name="farm_cultivate_max_duration" type="number" value="{{ Input::old('farm_cultivate_max_duration') }}" class="form-control">
                                        </div>
                                    </div>
                                </div> */ ?>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_weather_report" class="col-form-label">Weather Report</label>
                                            <input  name="fm_weather_report" type="file" accept="image/gif,image/jpeg,image/png,application/pdf" class="form-control">
                                        </div>
                                    </div>
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_soil_report" class="col-form-label">Soil Report</label>
                                            <input id="fm_soil_report" name="fm_soil_report" type="file" accept="image/gif,image/jpeg,image/png,application/pdf" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_annual_report" class="col-form-label">Annual Report</label>
                                            <input  name="fm_annual_report" type="file" accept="image/gif,image/jpeg,image/png,application/pdf" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                
                                @include('admin.common.image_gallery')
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                        <label for="fm_status" class="col-form-label">Farm Status<em>*</em></label>
                                            <select id="fm_status" name="fm_status" class="form-control">
                                                <option value="1">Active</option>
                                                <option value="2">Inactive</option>
                                            </select>
                                        </div>
                                    </div> 
                                </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="button-control-wrapper">
                                <div class="form-group">
                                    <input class="btn btn-primary" type="submit" name="savebtnsubmit" value="Save"  />
                                    <a href="{{ apa('farm_manager') }}" class="btn btn-danger">Close</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" id="fm_latitude" name="fm_latitude">
                    <input type="hidden" id="fm_longitude" name="fm_longitude">
                {{ Form::close() }}
            </div>
        </div>
    </div>
 </div>  
@stop

@section('scripts')
@parent
<script>
    var dateFormat =  "yy-mm-dd";
    $("#available_start_date").datepicker({
        dateFormat : dateFormat,
        changeMonth: true,
        changeYear: true,
        todayBtn:  1,
        autoclose: true,
    }).on('change', function () {
        var minDate = getDate(this);
        $('#available_end_date').datepicker("option",'minDate', minDate);
    });

    $("#available_end_date").datepicker({
        dateFormat : dateFormat,
        changeMonth: true,
        changeYear: true,
        todayBtn:  1,
        autoclose: true,
    }).on('change', function () {
            var maxDate = getDate(this);
            $('#available_start_date').datepicker("option",'maxDate', maxDate);
    });
    
    function getDate( element ) {
      var date;
      try {
        date = $.datepicker.parseDate( dateFormat, element.value );
      } catch( error ) {
        date = null;
      }
 
      return date;
    }
</script>

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD7dxAhKeEHs4QpOPhGqOSwl2NFfW9rqtk"></script>
<script>
var map;
var marker = false; 
        
function initMap() {
 
    var centerOfMap = new google.maps.LatLng(25.2048, 55.2708);
 
    var options = {
      center: centerOfMap,
      zoom: 7
    };
 
    map = new google.maps.Map(document.getElementById('map'), options);
 
    google.maps.event.addListener(map, 'click', function(event) {                
        var clickedLocation = event.latLng;
        if(marker === false){
            marker = new google.maps.Marker({
                position: clickedLocation,
                map: map,
                draggable: true
            });
            google.maps.event.addListener(marker, 'dragend', function(event){
                markerLocation();
            });
        } else{
            marker.setPosition(clickedLocation);
        }
        markerLocation();
    });
}
 
function codeLatLng(lat, lng) {
var geocoder = new google.maps.Geocoder();
var latlng = new google.maps.LatLng(lat, lng);
geocoder.geocode({
    'latLng': latlng
}, function(results, status) {
    if (status == google.maps.GeocoderStatus.OK) {
        if (results[1]) {
            $('#fm_city').val();
            $('#fm_state_name').val();
            $('#fm_zipcode').val();
            for (var i = 0; i < results[0].address_components.length; i++) {
                for (var b = 0; b < results[0].address_components[i].types.length; b++) {

                    var city_flag = 0;
                    if (results[0].address_components[i].types[b] == "locality") {
                        var city_flag = 1;
                        city = results[0].address_components[i];
                        $('#fm_city').val(city.long_name);
                        break;
                    }

                    if (city_flag == 0) {
                        if (results[0].address_components[i].types[b] == "administrative_area_level_2") {
                            city = results[0].address_components[i];
                            $('#fm_city').val(city.long_name);
                            break;
                        }
                    }

                    if (results[0].address_components[i].types[b] == "administrative_area_level_1") {
                        state = results[0].address_components[i];
                        $('#fm_state_name').val(state.long_name);
                        break;
                    }
                    if (results[0].address_components[i].types[b] == "country") {
                        country = results[0].address_components[i];
                        break;
                    }
                    if (results[0].address_components[i].types[b] == "postal_code") {
                        postal_code = results[0].address_components[i];
                        $('#fm_zipcode').val(postal_code.long_name);
                        break;
                    }
                }
            }

            $("#fm_country_id option").filter(function() {
                return this.text == country.long_name;
            }).attr('selected', true);
        } else {
            //alert("No results found");
        }
    } else {
        //alert("Geocoder failed due to: " + status);
    }
});
}

function markerLocation(){
    var currentLocation = marker.getPosition();
    document.getElementById('fm_latitude').value = currentLocation.lat();
    document.getElementById('fm_longitude').value = currentLocation.lng();


    codeLatLng(currentLocation.lat(), currentLocation.lng());
}
        
        
google.maps.event.addDomListener(window, 'load', initMap);
</script>


<script type="text/javascript">
$(document).ready(function(){

    function changelocation(elem)
    {
        var country = $("#fm_country_id option:selected").text();
        var state = $('#fm_state_name').val();
        var city = $('#fm_city').val();
        var zip = $('#fm_zipcode').val();
        var geocoder = new google.maps.Geocoder();
        var address = city+','+state+','+country+','+zip;
        var zoom_val = 5;
        
           if($.trim(state) != ''){
               zoom_val = 6
           }
           
           if($.trim(city) != ''){
               zoom_val = 10
           }
           
           if($.trim(zip) != ''){
               zoom_val = 13
           }

        geocoder.geocode( { 'address': address}, function(results, status) {

          if (status == google.maps.GeocoderStatus.OK) {
            var latitude = results[0].geometry.location.lat();
            var longitude = results[0].geometry.location.lng();


            var location = results[0].geometry.location;
            geocoder.geocode({
                'latLng': location
            }, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        new_lat = location.lat();
                        new_lng = location.lng();

                        var newLatlng = new google.maps.LatLng({
                            lng: new_lng,
                            lat: new_lat,
                        });
                        if (marker && marker.setMap) {
                            marker.setMap(null);
                        }
                        marker = new google.maps.Marker({
                            position: newLatlng,
                            map: map,
                            draggable: true
                        });   
                                    
                        marker.setPosition(newLatlng);
                        map.setOptions({
                            center: newLatlng,
                            zoom: zoom_val,
                        });
                    }
                }
            });



            /*var newLatlng = new google.maps.LatLng({
                            lng: latitude,
                            lat: longitude,
                        });
            marker = new google.maps.Marker({
                position: newLatlng,
                map: map,
                draggable: true
            });     */   
            
            $('#fm_latitude').val(latitude);
			$('#fm_longitude').val(longitude);
            
          } 
        });
    }
    $( "#fm_country_id" ).change(function() {
        changelocation($(this));
    });
    $( "#fm_state_name,#fm_city,#fm_zipcode" ).blur(function() {
        changelocation($(this));
    });
    
    
});        
</script>
@stop