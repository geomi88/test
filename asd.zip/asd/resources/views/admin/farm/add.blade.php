@extends('admin.layouts.master')
@section('content')
@section('bodyClass')
@parent 
hold-transition skin-blue sidebar-mini
@stop
<div class="container-fluid dashboard-content">
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="page-header">
				<h2 class="pageheader-title">Create {{ empty($postDetails) ? $postType : $postDetails->post_title }}
					<a class="float-sm-right" href="{{ apa('post_collection/'.$postType.'/add') }}">
						<button class="btn btn-success btn-flat">Create New</button>
					</a>
				</h2>
			</div>
		</div>
	</div> 
	
	<div class="row">
		<div class="col-sm-12">
			@include('admin.common.user_message')
		</div>
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="card">
				<div class="col-sm-12 card-header my-table-header">
					<div class="row align-items-center">
						<div class="col-sm-6"><h5 class="">Create Minister</h5></div>
						<?php /*<div class="col-sm-6"><h5 class="text-right">Showing {{ $hubList->currentPage() }} of {{  $hubList->total() }} pages</h5></div> */ ?>
					</div>
				</div>
				<div class="card-body">

				{{ Form::open(array('url' => array(Config::get('app.admin_prefix').'/post_collection/'.$postType.'/add'),'files'=>true,'id'=>'post-form')) }}										
                    <input type="hidden" name="post[type]" value="{{$postType}}" />	
                    <input type="hidden" name="post[title]" value="{{$postType}}" />	
                    <input type="hidden" name="post[title_arabic]" value="{{$postType}}" />	
                    <section class="basic_settings">
                        <div class="row"> 	
                            <div class="col-sm-6 form-group">
                                <label>Title<em class="red">*</em></label>
                                <input type="text" name="meta[largetext][banner_title]" required="true" class="form-control " placeholder="" value="{{ Input::old('meta')['largetext']['banner_title'] }}"   /> 
                            </div>
                             <div class="col-sm-6 form-group">
                                <label>Title [Arabic]<em class="red">*</em></label>
                                <input type="text" name="meta[largetext][banner_title_arabic]" required="true" class="form-control " placeholder="" value="{{Input::old('meta')['largetext']['banner_title_arabic'] }}"   dir="rtl" /> 
                            </div>
                        </div>
						
						<div class="row">
							<div class="col-sm-6 form-group">
								<label>Name</label>
								<input type="text" name="meta[text][name]" class="form-control" placeholder="" value="{{ Input::old('meta')['text']['name'] }}"  /> 
							</div>
							
							<div class="col-sm-6 form-group">
								<label>Name[Arabic]</label>
								<input type="text" name="meta[text][name_arabic]" class="form-control" placeholder="" value="{{ Input::old('meta')['text']['name_arabic'] }}"  /> 
							</div>
						</div>
						
						<div class="row">
							<div class="col-sm-6 form-group">
								<label>Designation</label>
								<input type="text" name="meta[text][designation]" class="form-control" placeholder="" value="{{ Input::old('meta')['text']['designation'] }}"  /> 
							</div>
							
							<div class="col-sm-6 form-group">
								<label>Designation[Arabic]</label>
								<input type="text" name="meta[text][designation_arabic]" class="form-control" placeholder="" value="{{ Input::old('meta')['text']['designation_arabic'] }}"  /> 
							</div>
						</div>
						
						
						<div class="row"> 	
                        <div class="col-sm-6 form-group"> 
                            <label>Description<em class="red">*</em></label>
                            <textarea name="meta[largetext][description]" class="form-control editor" placeholder="" >{{ Input::old('meta')['largetext']['description']}}</textarea>
                        </div>
                        <div class="col-sm-6 form-group">
                            <label>Description [Arabic] <em class="red">*</em></label>
                            <textarea name="meta[largetext][description_arabic]" class="form-control editorAr" placeholder="" dir="rtl" >{{Input::old('meta')['largetext']['description_arabic']}}</textarea>
                        </div>
                    </div> 
					
					<div class="row">
						<div class="col-sm-6  fl fl-wrap fileUploadWrapper form-group">
                            {!! getPlUploadControl('Upload Image (416 X 557) (max 2 MB Size) (png,jpg,jpeg)','minister_image',['jpg','png','jpeg','minister_image'],'image','Select File',null,null,@Input::old('meta')['text']['minister_image'],$postType,'minister_image') !!}  
                        </div>
					</div>
                       
                    </section>
                    <section class="basic_settings">
                        
                        <div class="row"> 	
                            <div class="col-sm-6 form-group">
                                <label>Status<em class="red">*</em></label>
                                <select name="post[status]" class="form-control">
                                  <option value="1" {!! (Input::old('post')['status'] == '1' ) ? 'selected="selected"' : '' !!}>Activate</option>
                                  <option value="2" {!! (Input::old('post')['status'] == '2' ) ? 'selected="selected"' : '' !!}>Deactivate</option>
                                 </select>
                            </div>
                        </div>
                    </section>
                    <div class="form-group"></div>
                    <div class="form-group">
                         <input type="submit" name="btnsubmit" value="Submit"  class="btn btn-success btn-flat">
                         <a href="<?php echo asset(Config::get('app.admin_prefix').'/post_collection/'.$postType); ?>" class="btn btn-danger btn-flat">Close</a>
                    </div>   
				{{ Form::close() }}
			</div>
			</div>
		</div>
	</div>
</div>
@stop

