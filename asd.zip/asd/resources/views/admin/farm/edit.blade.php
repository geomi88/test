@extends('admin.layouts.master')
@section('styles')
@parent
<style>
.imageHolder {
	border: 1px solid #ccc;
    margin-bottom: 15px;
    background: #fbfbfb;
}
#map{ width:500px; height: 300px; }
</style>
@stop
@section('content')
  @section('bodyClass')
    @parent
    hold-transition skin-blue sidebar-mini
  @stop
 <div class="container-fluid dashboard-content">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Update Farm  {{ $farmDetails->fm_title }}
					<a class="float-sm-right" href="{{ apa('farm_manager') }}"><button class="btn btn-outline-dark btn-flat">Back</button></a></h2>
            </div>
        </div>
    </div>  
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <div class="col-sm-12 card-header form-header">
                    <div class="row align-items-center">
                        <h5>Fields marked (<em>*</em> ) are mandatory</h5> 
                    </div>
                </div>
                
				{!! Form::open(array('url' => apa('farm_manager/update/'.$farmDetails->fm_id ) , 'id'=>'post-form','files'=>true)) !!}
                    <div class="card-body">
                        <div class="col-sm-12">
                            @include('admin.common.user_message')
							<div class="clearfix"></div>
                            <div class="row">
									<div class="col-sm-6">
                                        
                                        
                                        <div class="form-group">
                                            <label for="farm_categories" class="col-form-label">Farm Category<em>*</em></label>
                                            <select id="farm_categories" name="farm_categories[]" class="form-control selectpicker" multiple required>
                                            
                                            <?php 
                                             $catId=[];
                                             foreach($farmDetails->categories as $categories){
                                             $catId[]= $categories->category_id ;
                                             }
                                            
                                            ?>
												@if(!empty($categoryList))
													@foreach($categoryList as $category)
														<option {{(in_array($category->category_id,$catId)) ? "selected" : ""}} value="{{ $category->category_id }}">{{ $category->category_title }}</option>
													@endforeach
												@endif
											</select>
                                        </div>
                                    </div>
                             </div>
                             <div class="row">
									<div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="fm_title" class="col-form-label">Farm Title<em>*</em></label>
                                            <input id="fm_title" name="fm_title" type="text" value="{{ $farmDetails->fm_title }}" class="form-control" required>
                                        </div>
                                    </div>
                                     
                                </div>
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_country_id" class="col-form-label">Country</label>
                                            <select id="fm_country_id" name="fm_country_id" class="form-control">
                                                <option value="">Select Country</option>
												@if(!empty($countryList))
													@foreach($countryList as $country)
														<option 
                                                        {{ ($farmDetails->fm_country_id == $country->country_id) ? "selected" : "" }}
                                                        value="{{ $country->country_id }}">{{ $country->country_name }}</option>
													@endforeach
												@endif
											</select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_state_name" class="col-form-label">Farm State</label>
                                            <input id="fm_state_name" name="fm_state_name" type="text" value="{{ $farmDetails->fm_state_name }}" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_city" class="col-form-label">Farm City</label>
                                            <input id="fm_city" name="fm_city" type="text" value="{{ $farmDetails->fm_city }}" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_zipcode" class="col-form-label">Farm Zip</label>
                                            <input id="fm_zipcode" name="fm_zipcode" type="text" value="{{ $farmDetails->fm_zipcode }}" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <div id="map"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_area" class="col-form-label">Total Area</label>
                                            <input id="fm_area" name="fm_area" type="text" value="{{ $farmDetails->fm_area }}" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_area_unit" class="col-form-label">Unit</label>
                                            <select id="fm_area_unit" name="fm_area_unit" class="form-control">
                                                <option value="">Select Unit</option>
                                                <option value="Acre" {{($farmDetails->fm_area_unit=="Acre") ? "selected" : "" }}>Acre</option>
												<option value="M2" {{($farmDetails->fm_area_unit=="M2") ? "selected" : "" }}>M2</option>
                                                <option value="Feet" {{($farmDetails->fm_area_unit=="Feet") ? "selected" : "" }}>Feet</option>
											</select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_plots_no" class="col-form-label">Number of plots</label>
                                            <input id="fm_plots_no" name="fm_plots_no" type="text" value="{{ $farmDetails->fm_plots_no }}" class="form-control">
                                        </div>
                                    </div>
                                    
                                
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_price" class="col-form-label">Price</label>
                                            <input id="fm_price" name="fm_price" type="text" value="{{ $farmDetails->fm_price }}" class="form-control">
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="row">
									
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_plot_map" class="col-form-label">Plot Map</label><br/>
											@if($farmDetails->fm_plot_map != '' && $farmDetails->fm_plot_map != NULL)
												<img src="{{ asset('storage/uploads/farm/plot/'.$farmDetails->fm_plot_map) }}" style="width:60px"/>
											@endif
                                            <input  name="fm_plot_map" type="file" accept="image/gif,image/jpeg,image/png" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="farm_agricultures" class="col-form-label">Crops</label>
                                            <select id="farm_agricultures" name="farm_agricultures[]" class="form-control selectpicker" multiple>
                                            <?php 
                                             $cropId=[];
                                             foreach($farmDetails->crops as $crops){
                                             $cropId[]= $crops->agriculture_id ;
                                             }
                                            
                                            ?>
												@if(!empty($agricultureList))
													@foreach($agricultureList as $agriculture)
														<option {{(in_array($agriculture->agriculture_id,$cropId)) ? "selected" : ""}} value="{{ $agriculture->agriculture_id }}">{{ $agriculture->agriculture_title }}</option>
													@endforeach
												@endif
											</select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="farm_facilities" class="col-form-label">Facilities</label>
                                            <select id="farm_facilities" name="farm_facilities[]" class="form-control selectpicker" multiple>
                                            <?php 
                                             $facilityId=[];
                                             foreach($farmDetails->facilities as $facilities){
                                             $facilityId[]= $facilities->facility_id ;
                                             }
                                            
                                            ?>
												@if(!empty($facilityList))
													@foreach($facilityList as $facility)
														<option {{(in_array($facility->facility_id,$facilityId)) ? "selected" : ""}} value="{{ $facility->facility_id }}">{{ $facility->facility_title }}</option>
													@endforeach
												@endif
											</select>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_soil_id" class="col-form-label">Soil Type</label>
                                            <select id="fm_soil_id" name="fm_soil_id" class="form-control">
												@if(!empty($soilList))
													@foreach($soilList as $soil)
														<option {{ ($farmDetails->fm_soil_id == $soil->soil_id) ? "selected" : "" }} value="{{ $soil->soil_id }}">{{ $soil->soil_title }}</option>
													@endforeach
												@endif
											</select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_irrigation_id" class="col-form-label">Irrigation</label>
                                            <select id="fm_irrigation_id" name="fm_irrigation_id" class="form-control">
												@if(!empty($irrigationList))
													@foreach($irrigationList as $irrigation)
														<option {{ ($farmDetails->fm_irrigation_id == $irrigation->irrigation_id) ? "selected" : "" }} value="{{ $irrigation->irrigation_id }}">{{ $irrigation->irrigation_title }}</option>
													@endforeach
												@endif
											</select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_agriculture_type_id" class="col-form-label">Agriculture Type</label>
                                            <select id="fm_agriculture_type_id" name="fm_agriculture_type_id" class="form-control">
												@if(!empty($agricultureTypeList))
													@foreach($agricultureTypeList as $agricultureType)
														<option {{ ($farmDetails->fm_agriculture_type_id == $agricultureType->agriculture_type_id) ? "selected" : "" }} value="{{ $agricultureType->agriculture_type_id }}">{{ $agricultureType->agriculture_type_title }}</option>
													@endforeach
												@endif
											</select>
                                        </div>
                                    </div>                                    
                                </div>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_main_image" class="col-form-label">Farm Image</label><br/>
                                           <?php //@if(Storage::exists('public/uploads/farm/image/'.$farmDetails->fm_main_image)) ?>
                                           @if($farmDetails->fm_main_image != '' && $farmDetails->fm_main_image != NULL)
												<img src="{{ asset('storage/uploads/farm/image/'.$farmDetails->fm_main_image) }}" style="width:60px"/>
											@endif
                                            <input name="fm_main_image" id="fm_main_image" type="file" accept="image/gif,image/jpeg,image/png" class="form-control">
                                        </div>
                                    </div>
                                    
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_main_icon" class="col-form-label">Farm Icon</label><br/>
                                            @if($farmDetails->fm_main_icon != '' && $farmDetails->fm_main_icon != NULL)
												<img src="{{ asset('storage/uploads/farm/icon/'.$farmDetails->fm_main_icon) }}" style="width:60px"/>
											@endif
                                            <input id="fm_main_icon" name="fm_main_icon" type="file" accept="image/gif,image/jpeg,image/png" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_farm_highlights" class="col-form-label">Farm Highlights</label>
                                            <textarea id="fm_farm_highlights" name="fm_farm_highlights" class="form-control editorLTR">{{ $farmDetails->fm_farm_highlights }}</textarea>
                                        </div>
                                    </div>
									<div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_about_farm" class="col-form-label">Farm Description</label>
                                            <textarea id="fm_about_farm" name="fm_about_farm" class="form-control editorLTR">{{ $farmDetails->fm_about_farm }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="fm_policies" class="col-form-label">Farm Policies</label>
                                            <textarea id="fm_policies" name="fm_policies" class="form-control editorLTR">{{ $farmDetails->fm_policies }}</textarea>
                                        </div>
                                    </div>									
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="available_start_date" class="col-form-label">Available Start Date</label>
                                            <input class="form_control available_start_date" readonly type="text" value="{{ $farmDetails->fm_start_date }}" name="available_start_date" id="available_start_date">
                                        </div>
                                    </div>
                                
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="available_end_date" class="col-form-label">Available End Date</label>
                                            <input class="form_control available_end_date" readonly type="text" value="{{ $farmDetails->fm_end_date }}" name="available_end_date" id="available_end_date">
                                        </div>
                                    </div>
                                </div>
                                @include('admin.common.image_gallery')
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                        <label for="fm_status" class="col-form-label">Farm Status<em>*</em></label>
                                            <select id="fm_status" name="fm_status" class="form-control">
                                                <option {{($farmDetails->fm_status==1) ? "selected" : "" }} value="1">Active</option>
                                                <option {{($farmDetails->fm_status==2) ? "selected" : "" }} value="2">Inactive</option>
                                            </select>
                                        </div>
                                    </div> 
                                </div>
						</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="button-control-wrapper">
                                <div class="form-group">
                                    <input class="btn btn-primary" type="submit" name="updatebtnsubmit" value="Update"  />
                                    <a href="{{ apa('agriculture_manager') }}" class="btn btn-danger">Close</a>
                                </div>
                            </div>
                        </div>           
                    </div>           
                    <input type="hidden" id="fm_latitude" name="fm_latitude" value="{{ $farmDetails->fm_latitude }}">
                    <input type="hidden" id="fm_longitude" name="fm_longitude" value="{{ $farmDetails->fm_longitude }}">
                {{ Form::close() }}
            </div>
        </div>
    </div>
 </div>  
@stop

@section('scripts')
@parent
<script>
 $(document).ready(function(){
     $('#post-form').validate();

 });
</script>

<script>
    var dateFormat =  "yy-mm-dd";
    $("#available_start_date").datepicker({
        dateFormat : dateFormat,
        changeMonth: true,
        changeYear: true,
        todayBtn:  1,
        autoclose: true,
    }).on('change', function () {
        var minDate = getDate(this);
        $('#available_end_date').datepicker("option",'minDate', minDate);
    });

    $("#available_end_date").datepicker({
        dateFormat : dateFormat,
        changeMonth: true,
        changeYear: true,
        todayBtn:  1,
        autoclose: true,
    }).on('change', function () {
            var maxDate = getDate(this);
            $('#available_start_date').datepicker("option",'maxDate', maxDate);
    });
    
    function getDate( element ) {
      var date;
      try {
        date = $.datepicker.parseDate( dateFormat, element.value );
      } catch( error ) {
        date = null;
      }
 
      return date;
    }
</script>

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD7dxAhKeEHs4QpOPhGqOSwl2NFfW9rqtk"></script>
<script>
var map;
var marker = false; 
        
function initMap() {
    var latiude = $('#fm_latitude').val();
    var longitude = $('#fm_longitude').val();
    var centerOfMap = new google.maps.LatLng(latiude, longitude);
 
    var options = {
      center: centerOfMap,
      zoom: 7
    };
 
    map = new google.maps.Map(document.getElementById('map'), options);
    marker = new google.maps.Marker({
                            position: centerOfMap,
                            map: map,
                            draggable: true
                        });
    google.maps.event.addListener(map, 'click', function(event) {                
        var clickedLocation = event.latLng;
        if(marker === false){
            marker = new google.maps.Marker({
                position: clickedLocation,
                map: map,
                draggable: true
            });
            google.maps.event.addListener(marker, 'dragend', function(event){
                markerLocation();
            });
        } else{
            marker.setPosition(clickedLocation);
        }
        markerLocation();
    });
}
 
function codeLatLng(lat, lng) {
var geocoder = new google.maps.Geocoder();
var latlng = new google.maps.LatLng(lat, lng);
geocoder.geocode({
    'latLng': latlng
}, function(results, status) {
    if (status == google.maps.GeocoderStatus.OK) {
        if (results[1]) {
            $('#fm_city').val();
            $('#fm_state_name').val();
            $('#fm_zipcode').val();
            for (var i = 0; i < results[0].address_components.length; i++) {
                for (var b = 0; b < results[0].address_components[i].types.length; b++) {

                    var city_flag = 0;
                    if (results[0].address_components[i].types[b] == "locality") {
                        var city_flag = 1;
                        city = results[0].address_components[i];
                        $('#fm_city').val(city.long_name);
                        break;
                    }

                    if (city_flag == 0) {
                        if (results[0].address_components[i].types[b] == "administrative_area_level_2") {
                            city = results[0].address_components[i];
                            $('#fm_city').val(city.long_name);
                            break;
                        }
                    }

                    if (results[0].address_components[i].types[b] == "administrative_area_level_1") {
                        state = results[0].address_components[i];
                        $('#fm_state_name').val(state.long_name);
                        break;
                    }
                    if (results[0].address_components[i].types[b] == "country") {
                        country = results[0].address_components[i];
                        break;
                    }
                    if (results[0].address_components[i].types[b] == "postal_code") {
                        postal_code = results[0].address_components[i];
                        $('#fm_zipcode').val(postal_code.long_name);
                        break;
                    }
                }
            }

            $("#fm_country_id option").filter(function() {
                return this.text == country.long_name;
            }).attr('selected', true);
        } else {
            //alert("No results found");
        }
    } else {
        //alert("Geocoder failed due to: " + status);
    }
});
}

function markerLocation(){
    var currentLocation = marker.getPosition();
    document.getElementById('fm_latitude').value = currentLocation.lat();
    document.getElementById('fm_longitude').value = currentLocation.lng();


    codeLatLng(currentLocation.lat(), currentLocation.lng());
}
        
        
google.maps.event.addDomListener(window, 'load', initMap);
</script>


<script type="text/javascript">
$(document).ready(function(){

    function changelocation(elem)
    {
        var country = $("#fm_country_id option:selected").text();
        var state = $('#fm_state_name').val();
        var city = $('#fm_city').val();
        var zip = $('#fm_zipcode').val();
        var geocoder = new google.maps.Geocoder();
        var address = city+','+state+','+country+','+zip;
        var zoom_val = 5;
        
           if($.trim(state) != ''){
               zoom_val = 6
           }
           
           if($.trim(city) != ''){
               zoom_val = 10
           }
           
           if($.trim(zip) != ''){
               zoom_val = 13
           }

        geocoder.geocode( { 'address': address}, function(results, status) {

          if (status == google.maps.GeocoderStatus.OK) {
            var latitude = results[0].geometry.location.lat();
            var longitude = results[0].geometry.location.lng();


            var location = results[0].geometry.location;
            geocoder.geocode({
                'latLng': location
            }, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        new_lat = location.lat();
                        new_lng = location.lng();

                        var newLatlng = new google.maps.LatLng({
                            lng: new_lng,
                            lat: new_lat,
                        });
                        if (marker && marker.setMap) {
                            marker.setMap(null);
                        }
                        marker = new google.maps.Marker({
                            position: newLatlng,
                            map: map,
                            draggable: true
                        });   
                                    
                        marker.setPosition(newLatlng);
                        map.setOptions({
                            center: newLatlng,
                            zoom: zoom_val,
                        });
                    }
                }
            });

           
            
            $('#fm_latitude').val(latitude);
			$('#fm_longitude').val(longitude);
            
          } 
        });
    }
    $( "#fm_country_id" ).change(function() {
        changelocation($(this));
    });
    $( "#fm_state_name,#fm_city,#fm_zipcode" ).blur(function() {
        changelocation($(this));
    });
    
    
});        
</script>
@stop