@extends('admin.layouts.master')
@section('content')
@section('bodyClass')
@parent 
hold-transition skin-blue sidebar-mini
@stop
<div class="container-fluid dashboard-content">
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="page-header">
				<h2 class="pageheader-title">Farm Management
					<a class="float-sm-right" href="{{ apa('farm_manager/create') }}">
						<button class="btn btn-success btn-flat">Create New</button>
					</a>
				</h2>
			</div>
		</div>
	</div> 
	<div>
			@include('admin.farm.list_filters')
	</div>
	<div class="row">
		<div class="col-sm-12">
			@include('admin.common.user_message')
		</div>
		<!-- ============================================================== -->
		<!-- striped table -->
		<!-- ============================================================== -->
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="card">
				<div class="col-sm-12 card-header my-table-header">
					<div class="row align-items-center">
						<div class="col-sm-6"><h5 class="">{{ $farmList->total() }} results found.</h5></div>
						<?php /*<div class="col-sm-6"><h5 class="text-right">Showing {{ $hubList->currentPage() }} of {{  $hubList->total() }} pages</h5></div> */ ?>
					</div>
				</div>
				<div class="card-body">
					<div class="table-responsive-md">
						<table class="table table-striped table-bordered">
							<thead>
								<tr>
									
									<th scope="col">#</th>
									
									<th scope="col">Farm Details</th>
									
									<th scope="col">Farm Highlights</th>
									
									<th scope="col">Status</th>
									
									<th scope="col">Option</th>
									
									
								</tr>
							</thead>
							<tbody>
								@if (count($farmList) > 0)
									<?php $inc = getPaginationSerial($farmList); 	?>
								
									@foreach ($farmList as $farm)
									<?php 
                                        
										$activeUrl= apa( 'farm_manager/changestatus/'.$farm->fm_id);
										$DeactiveUrl= apa('farm_manager/changestatus/'.$farm->fm_id);
									?>
									<tr data-entry-id="{{ $farm->fm_id }}">
										<td>{{ $inc++ }}</td>
										<td>
											<p>{{ $farm->fm_title }}</p>
                                            <p>Owner : {{ $farm->owner->user_full_name }}</p>
                                            @if($farm->city != '' && $farm->state_name!= ''){
                                            <p>Location : {{ $farm->fm_city }},{{ $farm->fm_state_name }}</p>
                                            @endif
                                            @if($farm->fm_area != '')
                                            <p>Area : {{ $farm->fm_area }} {{ $farm->fm_area_unit }}</p>
                                            @endif
                                            @if($farm->fm_price != '')
                                            <p>Price : {{ $farm->fm_price }}/month</p>
                                            @endif
										</td>
										<td>{{ $farm->fm_farm_highlights }}</td> 
										<td class="status">
										 {!! ($farm->fm_status == 1)?"<a href='".$activeUrl."/$farm->fm_status'><i class='fa fa-check-circle'></i></a>":"<a href='".$DeactiveUrl."/$farm->fm_status' ><i class='fa fa-trash'></i></a>" !!}
										</td>
										<td>
											<a href="{{ apa('farm_manager/update/'.$farm->fm_id) }}" class="btn btn-xs btn-info">Edit</a>
											<!-- <a data-id="{{ $farm->fm_id }}" href="{{ apa('farm_manager/delete/'.$farm->fm_id) }}" class="deleteRecord btn btn-xs btn-danger">Delete</a> -->
											
										</td>
										
									</tr>
									@endforeach
								@else
									<tr>
										<td colspan="5">@lang('global.app_no_entries_in_table')</td>
									</tr>
								@endif
									<tr>
                                        <td colspan="5">{{$farmList->links()}}</td>
                                    </tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@stop