@extends('admin.layouts.master')
@section('styles')
@parent
<style>
    #tinymce h1{
        font-size: 16px;
        letter-spacing: .1em;
        font-weight: 200 !important;
        text-transform: uppercase;
    }
    
    iframe #tinymce strong {
        color: red !important;
    }
    
</style>
@stop
@section('content')
@section('bodyClass')
@parent
hold-transition skin-blue sidebar-mini
@stop
<aside class="right-side">         
    <!-- Main content -->
    <section class="content">
        <div class="box ">
            <div class="col-sm-12">	

                <h3>Edit {{ $postType }}</h3>

            </div>

            <div class="box-body">
                <div class="clearfix"></div>
                <?php 
                
                
                    if (!empty($userMessage)) {
                        echo $userMessage; 
                    } 
                ?>	
               
                {{ Form::open(array('url' => array(Config::get('app.admin_prefix').'/post_collection/'.$postType.'/edit/'.$postDetails->post_id),'files'=>true,'id'=>'post-form')) }} 										
                    <input type="hidden" name="post[type]" value="{{$postType}}" />	
                    <input type="hidden" name="post[title]" value="{{$postType}}" />	
                    <input type="hidden" name="post[title_arabic]" value="{{$postType}}" />	
                    <section class="basic_settings">
                        <div class="row"> 	
						<div class="col-sm-6 form-group">
							<label>Entity/Company Type<em class="red">*</em></label>
							<input type="text" name="post[title]" maxlength="150"  class="form-control" placeholder="" value="{{ $postDetails->title }}" required="true"   /> 
						</div>	
					</div>	
                      <div class="row"> 	
                        <div class="col-sm-6 form-group">
                            <label>Entity/Company Type Description<em class="red">*</em></label>
                            <textarea name="meta[largetext][entity_description]" class="form-control editor" placeholder="" >{{ $postDetails->getMeta('entity_description') }}</textarea>
                        </div>
                    </div>    
                    
					  
					
                    </section>
				
				<section class="basic_settings">					
					<div class="row"> 						
						<div class="col-sm-6 form-group">
							<label>Status<em class="red">*</em></label>
							<select name="post[status]" class="form-control">
							  <option value="1" {!! (@$postDetails->post_status == '1' ) ? 'selected="selected"' : '' !!}>Activate</option>
							  <option value="0" {!! (@$postDetails->post_status == '0' ) ? 'selected="selected"' : '' !!}>Deactivate</option>
							 </select>
						</div>
						
					</div>
					
				</section>

				<div class="form-group"></div>
				
				<div class="form-group">
					 <input type="submit" name="updatebtnsubmit" value="Submit"  class="btn btn-success btn-flat">
					 <a href="<?php echo asset(Config::get('app.admin_prefix').'/post_collection/'.$postType); ?>" class="btn btn-danger btn-flat">Close</a>
				</div>   


                {{ Form::close() }}

            </div> 				   <!-- /.box-body -->
        </div>
    </section><!-- /.content -->
</aside>
@stop

@section('scripts')
@parent
<script src="<?php echo asset('assets/admin/plugins/tinymce/tinymce.min.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
    $(function() {
       tinyMCE.PluginManager.add('stylebuttons', function(editor, url){
          ['pre', 'p', 'code', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6','span'].forEach(function(name){
           editor.addButton("style-" + name, {
               tooltip: "Toggle " + name,
                 text: name.toUpperCase(),
                 onClick: function() { editor.execCommand('mceToggleFormat', false, name); },
                 onPostRender: function() {
                     var self = this, setup = function() {
                         editor.formatter.formatChanged(name, function(state) {
                             self.active(state);
                         });
                     };
                     editor.formatter ? setup() : editor.on('init', setup);
                 }
             })
          });
        });
		tinymce.init({
			mode : "exact",
			selector: '.editorEN',
			plugins: ["link", "paste", "spellchecker", "preview", "fullscreen", "code", "table", "directionality , stylebuttons"],
			// toolbar: ["fullscreen | undo redo | ltr rtl  | filemanager  | bullist numlist |styleselect | bold italic | aligncenter alignright alignjustify | link | style-p style-h1 style-h2 style-h3 style-pre style-code"],
			toolbar: [" bold | link"],
            menubar:false,
            statusbar: false,
			extended_valid_elements: "span[!class]",
			valid_elements: "*[*]"

		});
		tinymce.init({
			mode : "exact",
			selector: '.editorAR',
            menubar:false,
            statusbar: false,
			plugins: ["link", "paste", "spellchecker", "preview", "fullscreen", "code", "table", "directionality , stylebuttons"],
			// toolbar: ["fullscreen | undo redo | ltr rtl  | filemanager  | bullist numlist |styleselect | bold italic | aligncenter alignright alignjustify | link | | style-p style-h1 style-h2 style-h3 style-pre style-code"],
			toolbar: [" bold | link"],
            directionality : "rtl",
			extended_valid_elements: "",
			valid_elements: "*[*]"

		});
        
        

	});
</script>

@stop