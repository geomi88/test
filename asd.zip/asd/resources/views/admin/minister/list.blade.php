@extends('admin.layouts.master')
@section('content')
@section('bodyClass')
@parent 
hold-transition skin-blue sidebar-mini
@stop
<div class="container-fluid dashboard-content">
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="page-header">
				<h2 class="pageheader-title">Manage {{ empty($postDetails) ? $postType : $postDetails->post_title }}
					<a class="float-sm-right" href="{{ apa('post_collection/'.$postType.'/add') }}">
						<button class="btn btn-success btn-flat">Create New</button>
					</a>
				</h2>
			</div>
		</div>
	</div> 
	
	<div class="row">
		<div class="col-sm-12">
			@include('admin.common.user_message')
		</div>
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="card">
				<div class="col-sm-12 card-header my-table-header">
					<div class="row align-items-center">
						<div class="col-sm-6"><h5 class="">{{ $post_items->count() }} results found.</h5></div>
						<?php /*<div class="col-sm-6"><h5 class="text-right">Showing {{ $hubList->currentPage() }} of {{  $hubList->total() }} pages</h5></div> */ ?>
					</div>
				</div>
				<div class="card-body">
					<div class="table-responsive-md">
						
						
						
														
							<table id="members1" class="table table-bordered table-hover">
							 <thead>
								<tr>
									<th>#</th>
									<th>Title</th>	
									<th>Status</th>											
									<th>Manage</th>											
								</tr>
							</thead>								
								<tbody>	
								<?php  if(count($post_items)>0){ ?>	
									<?php 
										$inc=1;
										foreach ($post_items as $item){
											// pre($item);
										$activeUrl= asset( Config::get('app.admin_prefix').'/post_collection/'.$postType.'/changestatus/'.$item->post_id.'/'.$item->post_status);
										$DeactiveUrl= asset(Config::get('app.admin_prefix').'/post_collection/'.$postType.'/changestatus/'.$item->post_id.'/'.$item->post_status);
									
									?>
										<tr>
											<td>{{ $inc++ }}</td>
											
											<td>{!! $item->post_title !!}</td>
											
                                            
											<?php if($buttons['status'] ) { ?>
												<td class="status">
													<?php echo ($item->post_status == 1)?"<a href='".$activeUrl."' class='btn btn-success btn-sm'><i class='fa fa-check-square'></i></a>":"<a href='".$DeactiveUrl."' class='btn btn-danger btn-sm'><i class='fa fa-times-circle'></i></a>"; ?>
												</td>
											<?php } ?>
											<td class="manage">
												<ul>
                                                <?php if($buttons['edit'] ) { ?>
                                                    <li>
                                                        <a href="<?php echo asset(Config::get('app.admin_prefix').'/post_collection/'.$postType.'/edit/'.$item->post_id); ?>" class="btn btn-primary btn-sm" title="edit"><i class="fa fa-pencil"></i></a> <br/>
                                                        Edit
                                                    </li>
                                                <?php } ?>
												<?php if($buttons['delete'] ) { ?>
													<li>
														<a class="btn btn-danger btn-sm deleteRecord" href="<?php echo asset(Config::get('app.admin_prefix').'/post_collection/'.$postType.'/delete/'.$item->post_id); ?>"  title="delete" ><i class="fa fa-trash-o"></i></a><br/>
														Delete
													</li>
												<?php } ?>
												</ul>
											</td>
												
												
										</tr>
										<?php } ?>
								<?php }else{ ?>
								<tr>
									<td colspan="4">										
										<div class="col-sm-12 alert alert-danger alert-dismissable">
											<i class="fa fa-ban"></i>
											<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
											<b>Alert!</b> No Records Found!.  
										</div> 										
									</td>
								</tr>
							<?php } ?>
								   </tbody>                            
							</table>							
							
				</div>
				</div>
			</div>
		</div>
	</div>
</div>
@stop