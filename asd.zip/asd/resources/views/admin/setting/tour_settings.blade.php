@extends('admin.layouts.master')
@section('metatags')
	<meta name="description" content="{{{@$websiteSettings->site_meta_description}}}" />
	<meta name="keywords" content="{{{@$websiteSettings->site_meta_keyword}}}" />
	<meta name="author" content="{{{@$websiteSettings->site_meta_title}}}" />
@stop
@section('seoPageTitle')
 <title>{{{ $pageTitle }}}</title>
@stop
@section('styles')
@parent
	{{ HTML::style('assets/admin/plugins/iCheck/all.css') }}
@stop

@section('content')
@section('bodyClass')
  @parent
  hold-transition skin-blue sidebar-mini
@stop
<aside class="right-side">
                <!-- Content Header (Page header) -->
                <!-- Main content -->
                <section class="content">
  					<div class="box box-warning">
                        <div class="box-header">
                        <h3 class="box-title">Book a Tour Content & Settings</h3>
                      </div>
  					<!-- /.box-header -->
			<div class="box-body admin">
				<?php if(!empty($userMessage)){ ?>
					<div class="alert alert-success">
						<?php  echo $userMessage; ?>
					</div>
				<?php } ?>
			 <?php echo Form::open(array('url' => array(Config::get('app.admin_prefix').'/tour_settings'),'files' => true)); ?>
						<div class="row">
							<div class="col-sm-6">
								<label>English Content</label>
								<textarea name="tour_content" class="form-control editorEN" placeholder="Content English"><?php echo @$tourSettings->tour_content;?></textarea>
							</div>
							<div class="col-sm-6">
								<label>Arabic Content</label>
								<textarea type="text" dir="rtl" name="tour_content_arabic" placeholder="Content Arabic" class="form-control editorAR" ><?php echo @$tourSettings->tour_content_arabic;?></textarea>
							</div>
						</div>					
						
						<div class="row">
						   <div class="col-sm-12">
									
							<input type="checkbox" {{ ($tourSettings->tour_content_show ==2) ?'checked':''}} name="tour_content_show" placeholder="" value="2" class="flat-red"/><label style="padding-left:5px;line-height: 30px;vertical-align: middle;">Hide Book a Tour</label>
							</div>
						</div>
			  <div class="form-group"></div>
				<div class="form-group">
				 <input type="submit" name="updatebtnsubmit" value="Submit"  class="btn btn-success btn-flat">
				 <a href="<?php echo asset(Config::get('app.admin_prefix').'/dashboard'); ?>" class="btn btn-danger btn-flat">Close</a>
			  </div>
			 {{ Form::close() }}
		 </div> 				   <!-- /.box-body -->
</div>
</section><!-- /.content -->
</aside>
@stop
@section('styles')
@parent
@stop
@section('scripts')
@parent
<script src="<?php echo asset('assets/admin/plugins/iCheck/icheck.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo asset('assets/admin/plugins/tinymce/tinymce.min.js'); ?>" type="text/javascript"></script>
<script>
 	$(function() {
 		$('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
	      checkboxClass: 'icheckbox_flat-green',
	      radioClass   : 'iradio_flat-green'
	    })
		tinymce.init({
			menubar:false,

			mode : "exact",
			selector: '.editorEN',
			plugins: ["link", "paste", "spellchecker", "preview", "fullscreen", "code", "table", "directionality","media","image"],
			toolbar: ["fullscreen | undo redo | ltr rtl  | bullist numlist |styleselect | bold italic | aligncenter alignright alignjustify | link"],
		});
		tinymce.init({
			menubar:false,
			mode : "exact",
			selector: '.editorAR',
			plugins: ["link", "paste", "spellchecker", "preview", "fullscreen", "code", "table", "directionality","media","image"],
			toolbar: ["fullscreen | undo redo | ltr rtl  | bullist numlist |styleselect | bold italic | aligncenter alignright alignjustify | link"],
			 directionality : "rtl",
		});


	});
</script>
@stop
