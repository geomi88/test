@extends('frontend.layouts.master')
@section('seoPageTitle')
<title>{{Lang::get('messages.page_not_found')}}</title>
@stop
@section('styles')
@parent

@stop
@section('content')

<main id="content" class="page-404">
		<div class="errorPage">
			<img src="{{ asset('assets/frontend/images/page_not_found.gif')}}" />			
		</div>
</main>

@stop

@section('scripts')
@parent
<script>
	$(function() {
		$('body').removeClass('loading').addClass('is-loaded');
	})
</script>

@stop