<script type="text/javascript">
var uploaders = []
var count =1,total;
$(document).ready(function () {
 
		$('.uploader').each(function(i,v){
		var _this = $(this);
		var _type = $(this).attr('data-type');
		var _mimeTypes = [];
		var _mimeTypesTmp = $(this).attr('data-mimes');
		var swalDialogue = false;
		if(!_type){
			_type = 'user';
		}
	
		if(!_mimeTypesTmp){
			_mimeTypes = [
				{title : "Pdf Document", extensions : "pdf"},
				{title : "Word Document", extensions : "doc"},
				{title : "Word Document", extensions : "docx"},
				{title : "Word Document", extensions : "odt"},
				{title : "Image file", extensions : "jpg"},
				{title : "Image file", extensions : "jpeg"},
				{title : "Image file", extensions : "png"},
			];
		}else{
			_mimeTypes = [];
			var _spitArr = _mimeTypesTmp.split(',');
			
			$.each(_spitArr,function(i,v){
				_mimeTypes.push({title : "document",extensions:v })
			})
		}

		var uploader = new plupload.Uploader({
					runtimes : 'html5,flash,silverlight,html4',
					//drop_element : 'startup_attachment',
					browse_button : $(this).attr('id'),
					//container: document.getElementById('container'), // ... or DOM Element itself
					url : "{{ asset('/upload-file') }}",
					// chunk_size: '100kb',
					flash_swf_url : "{{ asset('assets/frontend/dist/scripts/Moxie.swf') }}",
					silverlight_xap_url : "{{ asset('assets/frontend/dist/scripts/Moxie.xap') }}",
					multi_selection : false,
					filters : {
						max_file_size : '10mb',
						mime_types: _mimeTypes
					},
					multipart_params : {
						'controlName': _type,
						'_token': window._token.csrfToken
					},
					headers: { 'X-CSRF-TOKEN': window._token.csrfToken },
					init: {
						PostInit: function() {
							
						},
						
						BeforeUpload:function (up,files){
							var status_before = files.status;
							_this.closest('.input_parent').find('.uploadProgress').css({'width':'0%'});					
							_this.closest('.input_parent').find('.uploadPercentage').html('');		
							uploader.settings.url = '{{ asset('/upload-file') }}';		
						
						},										
						FilesAdded: function(up, files) {
							_this.closest('.input_parent').find('.uploadFileName').html(files[0].name)
							_this.closest('.input_parent').find('input[type="file"]').attr('required',true)
							uploader.start();
						},
						UploadProgress: function(up, file) {
							_this.closest('.input_parent').find('.uploadProgress').css({'width':file.percent+'%'});					
							_this.closest('.input_parent').find('.uploadPercentage').html(file.percent+'%');				
						},
						FileUploaded:function(up,file,response){
					
							var t = response.response;
							var rt  = $.parseJSON(t);
							if(rt.status == true ){
								_this.closest('.input_parent').find('input[type="file"]').removeClass('error')
								_this.closest('.input_parent').find('input[type="file"]').next('label').hide()
								_this.closest('.input_parent').find('input[type="file"]').attr('required',false)
								_this.closest('.input_parent').find('.filename').val(rt.uploadDetails.fileName);
								_this.closest('.input_parent').find('.original_name').val(file.name);
						
								if(rt.uploadDetails.type == 'personal_photo'){
									
									var _profileUrl = $('#updateProfile').attr('action');
									var _profileData = $('#updateProfile').serializeArray();
									sendAjax(_profileUrl,'post',_profileData, function(responseData){
										if(responseData.status){
											_this.closest('.input_parent').find('.uploadPercentage').html('');
										}
									 },'');	
									_this.closest('.avatar').find('img').attr('src',rt.uploadDetails.image)
								}
							}else{
								_this.closest('.input_parent').find('.uploadFileName').html('');
								_this.closest('.input_parent').find('.original_name').val('');
								_this.closest('.input_parent').find('.uploadProgress').css({'width':'0%'});					
								_this.closest('.input_parent').find('.uploadPercentage').html('');
								// _this.closest('.input_parent').find('input[type="file"]').attr('required',true)
								_this.closest('.input_parent').find('.uploadFileName').html('<small class="red-color">'+rt.response+'</small>');
								if(swalDialogue){
									swal({
										  title: "{{Lang::get('messages.error')}}",
										  text: rt.response,
										  type: "warning",
										  confirmButtonText: "{{Lang::get('messages.ok')}}",
										  confirmButtonColor:'#000',
										  closeOnConfirm: false
										})
								}
								
							}
						},
						UploadComplete:function(up,files){
							uploader.splice();
						},
						Error: function(up, err) {
							_this.closest('.input_parent').find('.uploadFileName').html('<small class="red-color">{!! Lang::get('messages.invalid_file') !!}</small>');
							if(swalDialogue){
								swal({
										  title: "{{Lang::get('messages.error')}}",
										  text: "{!! Lang::get('messages.invalid_file') !!}",
										  type: "warning",
										  confirmButtonText: "{{Lang::get('messages.ok')}}",
										  confirmButtonColor:'#000',
										  closeOnConfirm: false
									})
							}
							
						}
					}
				});
			
	
				uploader.init();

				uploaders.push(uploader);
			
		})
	});
    

</script>