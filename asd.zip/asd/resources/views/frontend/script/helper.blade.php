<script>
function toAcre(area_val,area_unit){
	
	var acre = 0;
	if(area_unit == 'M2')
	{
		acre = parseFloat(area_val) * 0.000247105;
	}
	if(area_unit == 'Feet')
	{
		acre = parseFloat(area_val) * 0.00002295684;
	}
	acre = acre.toPrecision(1);
	if(area_unit == 'Acre')
	{
		acre = area_val;
	}
	
	
	return acre+' acre';
}
function sendAjax(URL,type,data,func,loaderDivID,$elem){
            if(loaderDivID){ $(loaderDivID).show(); }
            $.ajax({
                url:URL,
                type:type,
                async:true,
                data:data,
                dataType:'json',
                statusCode: {
                    302:function(){ console.log('Forbidden. Access Restricted'); },
                    403:function(){ console.log('Forbidden. Access Restricted','403'); },
                    404:function(){ console.log('Page not found','404'); },
                    500:function(){ console.log('Internal Server Error','500'); }
                }
            }).done(function(responseData){	
                if(loaderDivID){$(loaderDivID).hide();}								
                func(responseData,$elem);	
                                    
            });
            
        }
function sendAjaxFormdata(URL,type,data,func,loaderDivID,$elem){
            if(loaderDivID){ $(loaderDivID).show(); }
            $.ajax({
                url:URL,
                type:type,
                async:true,
                data:data,
                dataType:'json',
                enctype: 'multipart/form-data',
                traditional: true,                
                processData: false,
                contentType: false,
                statusCode: {
                    302:function(){ console.log('Forbidden. Access Restricted'); },
                    403:function(){ console.log('Forbidden. Access Restricted','403'); },
                    404:function(){ console.log('Page not found','404'); },
                    500:function(){ console.log('Internal Server Error','500'); }
                }
            }).done(function(responseData){	
                if(loaderDivID){$(loaderDivID).hide();}								
                func(responseData,$elem);	
                                    
            });
            
        }        
</script>