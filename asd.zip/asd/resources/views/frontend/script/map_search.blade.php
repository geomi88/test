<!-- Maps -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD7dxAhKeEHs4QpOPhGqOSwl2NFfW9rqtk"></script>
<script type="text/javascript" src="{{ htmlAsset('scripts/vendor/package/infobox.min.js') }}"></script>
<?php /* <script type="text/javascript" src="{{ htmlAsset('scripts/vendor/package/maps.js') }}"></script> */ ?>
