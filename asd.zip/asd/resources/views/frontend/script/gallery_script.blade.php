<script type="text/javascript">
// Initialize the widget when the DOM is ready
var gallery_list = []; 
$(function() {
	$("#uploader").plupload({
        buttons:{browse:true,start:false,stop:false},
		// General settings
		runtimes : 'html5,flash,silverlight,html4',
		url : '{{ asset('/upload-gallery') }}',
        headers: {
        'X-CSRF-TOKEN': window._token.csrfToken
        },
		// User can upload no more then 20 files in one go (sets multiple_queues to false)
		max_file_count: 20,

		//chunk_size: '1mb',

		// Resize images on clientside if we can
		/*resize : {
			width : 200,
			height : 200,
			quality : 90,
			crop: true // crop to exact dimensions
		},*/

		filters : {
			// Maximum file size
			max_file_size : '1000mb',
			// Specify what files to browse for
			mime_types: [
				{title : "Image files", extensions : "jpg,gif,png"}
				//{title : "Zip files", extensions : "zip"}
			]
		},

        init: {
				PostInit: function(){					
					setTimeout(function() {						
						if($("#uploader").closest('.m_step_').hasClass('form_edit')) {							
							$("#uploader").closest('.m_step_').removeClass('form_edit');
						}
					},100);					
				},
				FilesAdded: function(up, files) {
				$('#uploader').addClass('plupload_not_empty');
                  up.start();
                },
				UploadProgress: function(up, file) {

				},
				FileUploaded:function(up,file,response){
					console.log(file.name);
                    var gal_img_id = file.uid;
					var t = response.response;
					var rt  = $.parseJSON(t);
					if(!rt.uploadDetails){
						setTimeout(function() {
							$('#upload_gal_err').html(file.name+' cannot be uploaded.Please upload image files only');
						}, 1000);
						setTimeout(function() {
							$('#upload_gal_err').html('');
						}, 5000);
						return false;
					}
					rt = rt.uploadDetails;
					if(rt.status == true ){
						//gallery_list.push(rt.fileName);
                        
                        gallery_list.push({
                        gal_img_id : gal_img_id,
                        gal_img : rt.fileName,         
                        });
					}
				},
				UploadComplete:function(up,files){
					$('#loader').hide();
				},
                
                FilesRemoved: function(up, files) {
                // Called when files are removed from queue
                var rem_gal_img_id = files[0].uid;
                for(var i = 0; i < gallery_list.length; i++) {
                    if(gallery_list[i].gal_img_id == rem_gal_img_id) {
                        gallery_list.splice(i, 1);
                        break;
                        }
                    }
				if(gallery_list.length < 1){
					$('#uploader').removeClass('plupload_not_empty');
				}	
                },
                
				Error: function(up, err) {
					document.getElementById('console').innerHTML += "\nError #" + err.code + ": " + err.message;
				}
			},
		// Rename files by clicking on their titles
		rename: true,

		// Sort files
		sortable: true,

		// Enable ability to drag'n'drop files onto the widget (currently only HTML5 supports that)
		dragdrop: true,

		// Views to activate
		views: {
			list: true,
			thumbs: true, // Show thumbs
			active: 'thumbs'
		},

		// Flash settings
		flash_swf_url : "{{asset('assets/frontend/uploader_tools/js/Moxie.swf')}}",

		// Silverlight settings
		silverlight_xap_url : "{{asset('assets/frontend/uploader_tools/js/Moxie.xap')}}",
	});


	// Handle the case when form was submitted before uploading has finished
	$('#form').submit(function(e) {
		// Files in queue upload them first
		if ($('#uploader').plupload('getFiles').length > 0) {

			// When all files are uploaded submit form
			$('#uploader').on('complete', function() {
				$('#form')[0].submit();
			});

			$('#uploader').plupload('start');
		} else {
			alert("You must have at least one file in the queue.");
		}
		return false; // Keep the form from submitting
	});
    $('body').on('click','#uploader_dropbox',function(){
        //$( "#uploader_browse" ).click();
    });
});
</script>