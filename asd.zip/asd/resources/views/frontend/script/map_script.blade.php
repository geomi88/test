<script type="text/javascript">
    var map_box = '',marker_frame = '',marker = '',single_map = '',
			new_lat = $('#singleListingMap').data('latitude'),
			new_lng = $('#singleListingMap').data('longitude');
            var geocoder = new google.maps.Geocoder();
	function singleListingMap() {
		var click_ = $('#singleListingMap').data('click');

		var myLatlng = new google.maps.LatLng({
			lng: $('#singleListingMap').data('longitude'),
			lat: $('#singleListingMap').data('latitude'),
		});

		var options = {
			zoom: 16,
			center: myLatlng,
			scrollwheel: true,
			zoomControl: false,
			mapTypeControl: false,
			scaleControl: false,
			panControl: false,
			navigationControl: false,
			streetViewControl: false,
			fullscreenControl: false,
			styles: [{
					"featureType": "administrative",
					"elementType": "labels.text.fill",
					"stylers": [{
						"color": "#444444"
					}]
				},
				{
					"featureType": "landscape",
					"elementType": "all",
					"stylers": [{
						"color": "#f2f2f2"
					}]
				},
				{
					"featureType": "poi",
					"elementType": "all",
					"stylers": [{
						"visibility": "off"
					}]
				},
				{
					"featureType": "road",
					"elementType": "all",
					"stylers": [{
							"saturation": -100
						},
						{
							"lightness": 45
						}
					]
				},
				{
					"featureType": "road.highway",
					"elementType": "all",
					"stylers": [{
						"visibility": "simplified"
					}]
				},
				{
					"featureType": "road.arterial",
					"elementType": "labels.icon",
					"stylers": [{
						"visibility": "off"
					}]
				},
				{
					"featureType": "transit",
					"elementType": "all",
					"stylers": [{
						"visibility": "off"
					}]
				},
				{
					"featureType": "water",
					"elementType": "all",
					"stylers": [{
							"color": "#88e9ad"
						},
						{
							"visibility": "on"
						}
					]
				}
			]
		};
		 map_box = new google.maps.Map(document.getElementById('map_box'), options);
		single_map = new google.maps.Map(document.getElementById('singleListingMap'), options);

		var zoomControlDiv = document.createElement('div');
		var zoomControl = new ZoomControl(zoomControlDiv, single_map);

		function ZoomControl(controlDiv, single_map) {
			zoomControlDiv.index = 1;
			single_map.controls[google.maps.ControlPosition.RIGHT_CENTER].push(zoomControlDiv);
			controlDiv.style.padding = '5px';
			var controlWrapper = document.createElement('div');
			controlDiv.appendChild(controlWrapper);
			var zoomInButton = document.createElement('div');
			zoomInButton.className = "custom-zoom-in";
			controlWrapper.appendChild(zoomInButton);
			var zoomOutButton = document.createElement('div');
			zoomOutButton.className = "custom-zoom-out";
			controlWrapper.appendChild(zoomOutButton);
			google.maps.event.addDomListener(zoomInButton, 'click', function() {
				single_map.setZoom(single_map.getZoom() + 1);
			});
			google.maps.event.addDomListener(zoomOutButton, 'click', function() {
				single_map.setZoom(single_map.getZoom() - 1);
			});
		}
		var image = {
			url: "{{asset('assets/frontend/images/map_pin.png')}}",
			// This marker is 20 pixels wide by 32 pixels high.
			size: new google.maps.Size(25, 32),
			// The origin for this image is (0, 0).
			origin: new google.maps.Point(0, 0),
			// The anchor for this image is the base of the flagpole at (0, 32).
			anchor: new google.maps.Point(13, 33)
		};

		marker_frame = new google.maps.Marker({
			flat: true,
			position: myLatlng,
			draggable: true,
			map: map_box,
			optimized: false,
			visible: true,
			icon: image,
			animation: google.maps.Animation.DROP,
		});



		function toggleBounce() {
			if (marker_frame.getAnimation() !== null) {
				marker_frame.setAnimation(null);
			} else {
				marker_frame.setAnimation(google.maps.Animation.BOUNCE);
			}
		}

		marker = new google.maps.Marker({
			flat: true,
			position: myLatlng,
			draggable: true,
			map: single_map,
			optimized: false,
			icon: image,

			visible: true
		});

		

		google.maps.event.addListener(marker, 'dragend', function() {

			geocoder.geocode({
				'latLng': marker.getPosition()
			}, function(results, status) {
				if (status == google.maps.GeocoderStatus.OK) {
					if (results[0]) {
						new_lat = marker.getPosition().lat();
						new_lng = marker.getPosition().lng();
					}
				}
			});
		});
		if (click_ == true) {
			google.maps.event.addListener(single_map, 'click', function(event) {
				var location = event.latLng;
				/*var marker = new google.maps.Marker({
				position: location, 
				map: single_map
				});*/


				geocoder.geocode({
					'latLng': location
				}, function(results, status) {
					if (status == google.maps.GeocoderStatus.OK) {
						if (results[0]) {
							new_lat = location.lat();
							new_lng = location.lng();

							var newLatlng = new google.maps.LatLng({
								lng: new_lng,
								lat: new_lat,
							});
							single_map.setOptions({
								center: newLatlng
							})

							marker.setPosition(newLatlng);
						}
					}
				});

			});

		}
		


		

	}

    function codeLatLng(lat, lng) {

			var latlng = new google.maps.LatLng(lat, lng);
			geocoder.geocode({
				'latLng': latlng
			}, function(results, status) {
				if (status == google.maps.GeocoderStatus.OK) {
					$('#farm_latitude').val(lat);
					$('#farm_longitude').val(lng);
					if (results[1]) {
						console.log(results[0].address_components);
						for (var i = 0; i < results[0].address_components.length; i++) {
							for (var b = 0; b < results[0].address_components[i].types.length; b++) {

								var city_flag = 0;
								if (results[0].address_components[i].types[b] == "locality") {
									var city_flag = 1;
									city = results[0].address_components[i];
									$('#city').val(city.long_name);
									break;
								}

								if (city_flag == 0) {
									if (results[0].address_components[i].types[b] == "administrative_area_level_2") {
										city = results[0].address_components[i];
										$('#city').val(city.long_name);
										break;
									}
								}

								if (results[0].address_components[i].types[b] == "administrative_area_level_1") {
									state = results[0].address_components[i];
									$('#state').val(state.long_name);
									break;
								}
								if (results[0].address_components[i].types[b] == "country") {
									country = results[0].address_components[i];
									break;
								}
								if (results[0].address_components[i].types[b] == "postal_code") {
									postal_code = results[0].address_components[i];
									$('#zip').val(postal_code.long_name);
									break;
								}
							}
						}
						var selectedIndex = 0;
						$("#country_id option").filter(function(i) {
							if(this.text == country.long_name){
								selectedIndex = i;
							}
						
						});
						//$('#country_id').selectric('refresh');
						$('#country_id').prop('selectedIndex', selectedIndex).selectric('refresh');
					} else {
						//alert("No results found");
					}
				} else {
					//alert("Geocoder failed due to: " + status);
				}
			});
	}
    $('#map_done').click(function(e) {
			e.preventDefault();
			var this_ = $(this),
				target_ = this_.closest('.crop_popup');
			//console.log('click',target_);
			if (target_) {
				$(target_).removeClass('active_');
			}
			var newLatlng = new google.maps.LatLng({
				lng: new_lng,
				lat: new_lat,
			});
			map_box.setOptions({
				center: newLatlng
			})

			marker_frame.setPosition(newLatlng);
			marker_frame.setAnimation(google.maps.Animation.BOUNCE);

			codeLatLng(new_lat, new_lng);


			setTimeout(function() {
				marker_frame.setAnimation(null);
			}, 750);

		});
	var single_map = document.getElementById('singleListingMap');
	if (typeof(single_map) != 'undefined' && single_map != null) {
		google.maps.event.addDomListener(window, 'load', singleListingMap);

	}
</script>

<script type="text/javascript">
$(document).ready(function(){

    function changelocation(elem)
    {
        var country = elem.find("option:selected").text();
        var state = $('#state').val();
        var city = $('#city').val();
        var zip = $('#zip').val();
        var geocoder = new google.maps.Geocoder();
        var address = city+','+state+','+country+','+zip;
        var zoom_val = 5;
        
           if($.trim(state) != ''){
               zoom_val = 6
           }
           
           if($.trim(city) != ''){
               zoom_val = 10
           }
           
           if($.trim(zip) != ''){
               zoom_val = 13
           }

        geocoder.geocode( { 'address': address}, function(results, status) {

          if (status == google.maps.GeocoderStatus.OK) {
            var latitude = results[0].geometry.location.lat();
            var longitude = results[0].geometry.location.lng();
            
            $('#singleListingMap').data('latitude', latitude); 
            $('#singleListingMap').data('longitude', longitude); 
            
            $('#farm_latitude').val(latitude);
			$('#farm_longitude').val(longitude);
            var location = results[0].geometry.location;
            geocoder.geocode({
                'latLng': location
            }, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        new_lat = location.lat();
                        new_lng = location.lng();

                        var newLatlng = new google.maps.LatLng({
                            lng: new_lng,
                            lat: new_lat,
                        });
                        
                            map_box.setOptions({
                                    center: newLatlng,
                                    zoom: zoom_val,
                                });
                            single_map.setOptions({
                                    center: newLatlng,
                                    zoom: zoom_val,
                                });
                                    
                            marker_frame.setPosition(newLatlng);
                            marker.setPosition(newLatlng);
                    }
                }
            });
          } 
        });
    }
    $( "#country_id" ).change(function() {
        changelocation($(this));
    });
    $( "#state,#city,#zip" ).blur(function() {
        changelocation($(this));
    });
    
    
});        
</script>