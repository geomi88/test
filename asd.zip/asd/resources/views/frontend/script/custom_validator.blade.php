<script>
$.validator.addMethod( "noSpace", function( value, element ) {

return !value.startsWith(" ");
}, "No space allowed at the beginning");

$.validator.addMethod("alphanumeric", function(value) {
    var _return = true;
    var matches = ['!',	'@','#','$','%','^','&','*','(',')','=','+','[',']','~','|','\\','{','}'];
    $.each(matches,function(i,v){
    if(value.indexOf(v)!=-1){
    _return = false;
    return;
    }
    });
    return _return;
}, "Special characters not allowed");
</script>