<script >
    var infoBox_ratingType = 'star-rating';


function mainMap(farms) {
    var ib = new InfoBox();


    function locationData(locationURL, locationImg, locationPerosan, locationTitle, FarmName, locationArea, locationPrice, locationPeriod, crop_list, profile_name,farm_slug,owner_id) {

        var crop_list_details = "";


        for (var key in crop_list) {
            crop_list_details += '<div class="crop_" >' +
                '<a href="#" class="inner_ mg-tooltip" data-title="' + key + '"> ' +
                '<img src="' + crop_list[key] + '" />' +
                '</a>' +
                '</div>';

        }




        return ('' +


            '<div class="grid">' +
            '<div class="block_">' +
            '<div class="top_block">' +
            '<a href="'+window.request+'farm/'+farm_slug+'" class="block_link"></a>' +
            '<div class="top_box">' +
            '<div class="user_ tooltip-bottom"  title="' + profile_name + '">' +
            '<a href="'+window.request+'farm-owner/'+owner_id+'">' +
            '<div class="img  "  style="background-image: url(' + locationPerosan + ');"  ></div>' +
            '</a>' +
            '</div>' +


            '<div  data-icon="" class="icon infoBox-close" ></div>' +

            '</div>' +
            '<div class="social_share">' +
            ' <ul>' +
            '<li>' +
            '<a href="#" class="social_icon">' +
            '<div class="icon icon-social-facebook"></div>' +
            '</a>' +
            '</li>' +
            '<li>' +
            '<a href="#" class="social_icon">' +
            '<div class="icon icon-social-google"></div>' +
            '</a>' +
            '</li>' +
            '<li>' +
            '<a href="#" class="social_icon">' +
            '<div class="icon icon-social-twitter"></div>' +
            '</a>' +
            '</li>' +
            '</ul>' +
            '</div>' +
            '<div class="crop_details_box">' +
            '<div class="crop_icon">' +
            '<img  class="img_auto source_" /> ' +
            '</div>' +
            '<div class="crop_text_"></div>' +
            '</div>' +
            '<div class="bottom_box">' +
            '<div class="location_">' +
            '<div class="icon icon-graphics-icon-location-03"></div>' +
            '<div class="text_">' + locationTitle + '</div>' +
            '</div>' +
            '<div class="crops_box w_slick" data-crop-slider="true">' +

            crop_list_details +

            '</div>' +
            '</div>' +
            '<div class="img resourceBig"  style="background-image: url(' + locationImg + ' );"></div>' +
            '</div>' +
            '<a href="'+window.request+'farm/'+farm_slug+'" class="details_box">' +
            '<div class="info_box">' +
            '<div class="f_name">' + FarmName + '</div>' +
            '<div class="f_area">Land Area: ' + locationArea + ' </div>' +
            '<div class="meta_info">' + locationPeriod + '</div>' +
            ' </div>' +
            ' <div class="amount_box">' +
            '<div class="currency">$</div>' +
            '<div class="amount_">' +
            '<span>' + locationPrice + '</span>' +
            '<span class="small_">per month</span>' +
            '</div>' +
            '</div>' +
            '</a>' +
            '</div>' +
            '</div>')



    }


    var farm = farms;
    var locations = [];

    var i = 1;
    var new_center_lat = 0;
    var new_center_lng = 0;
    $.each(farm, function(key, value) {
        var area_val = toAcre(value.fm_area, value.fm_area_unit);
        var temp_arr = [];
        //temp_arr[] = locationData('listings-single-page.html', 'assets/images/image.jpg', 'assets/images/person01.jpg', "Los Angeles California", 'Farm Name 02', '10 Acre', '220', 'Minimum : 1 Year', crop_list_1);
        temp_arr.push(locationData('listings-single-page.html', value.fm_main_image, value.profile_image, value.fm_state_name, value.fm_title, area_val, value.fm_price, '', value.crops, value.profile_name,value.fm_slug,value.fm_owner_id));
        temp_arr.push(value.fm_latitude);
        temp_arr.push(value.fm_longitude);
        temp_arr.push(i);
        temp_arr.push(area_val);
        locations.push(temp_arr);
        if(i == 1)
        {
        new_center_lat = value.fm_latitude;
        new_center_lng = value.fm_longitude;
        }
        i++;
        
    });




    google.maps.event.addListener(ib, 'domready', function() {
        FarmsGate_.m_tooltip();
        FarmsGate_.grid_user_name() ;
        /*   if (infoBox_ratingType = 'numerical-rating') {
               numericalRating('.infoBox .' + infoBox_ratingType + '');
           }
           if (infoBox_ratingType = 'star-rating') {
               starRating('.infoBox .' + infoBox_ratingType + '');
           } */
    });
    var mapZoomAttr = $('#map').attr('data-map-zoom');
    var mapScrollAttr = $('#map').attr('data-map-scroll');
    if (typeof mapZoomAttr !== typeof undefined && mapZoomAttr !== false) {
        //var zoomLevel = parseInt(mapZoomAttr);
        var zoomLevel = 7;
    } else {
        var zoomLevel = 1;
    }
    if (typeof mapScrollAttr !== typeof undefined && mapScrollAttr !== false) {
        var scrollEnabled = parseInt(mapScrollAttr);
    } else {
        var scrollEnabled = false;
    }
    console.log(zoomLevel);
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: zoomLevel,
        scrollwheel: scrollEnabled,
        center: new google.maps.LatLng(new_center_lat, new_center_lng),
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        zoomControl: false,
        mapTypeControl: false,
        scaleControl: false,
        panControl: false,
        navigationControl: false,
        streetViewControl: false,
        gestureHandling: 'cooperative',
        styles: [{
            "featureType": "poi",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#747474"
            }, {
                "lightness": "23"
            }]
        }, {
            "featureType": "poi.attraction",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#f38eb0"
            }]
        }, {
            "featureType": "poi.government",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#ced7db"
            }]
        }, {
            "featureType": "poi.medical",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#ffa5a8"
            }]
        }, {
            "featureType": "poi.park",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#c7e5c8"
            }]
        }, {
            "featureType": "poi.place_of_worship",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#d6cbc7"
            }]
        }, {
            "featureType": "poi.school",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#c4c9e8"
            }]
        }, {
            "featureType": "poi.sports_complex",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#b1eaf1"
            }]
        }, {
            "featureType": "road",
            "elementType": "geometry",
            "stylers": [{
                "lightness": "100"
            }]
        }, {
            "featureType": "road",
            "elementType": "labels",
            "stylers": [{
                "visibility": "off"
            }, {
                "lightness": "100"
            }]
        }, {
            "featureType": "road.highway",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#ffd4a5"
            }]
        }, {
            "featureType": "road.arterial",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#ffe9d2"
            }]
        }, {
            "featureType": "road.local",
            "elementType": "all",
            "stylers": [{
                "visibility": "simplified"
            }]
        }, {
            "featureType": "road.local",
            "elementType": "geometry.fill",
            "stylers": [{
                "weight": "3.00"
            }]
        }, {
            "featureType": "road.local",
            "elementType": "geometry.stroke",
            "stylers": [{
                "weight": "0.30"
            }]
        }, {
            "featureType": "road.local",
            "elementType": "labels.text",
            "stylers": [{
                "visibility": "on"
            }]
        }, {
            "featureType": "road.local",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#747474"
            }, {
                "lightness": "36"
            }]
        }, {
            "featureType": "road.local",
            "elementType": "labels.text.stroke",
            "stylers": [{
                "color": "#e9e5dc"
            }, {
                "lightness": "30"
            }]
        }, {
            "featureType": "transit.line",
            "elementType": "geometry",
            "stylers": [{
                "visibility": "on"
            }, {
                "lightness": "100"
            }]
        }, {
            "featureType": "water",
            "elementType": "all",
            "stylers": [{
                "color": "#d2e7f7"
            }]
        }]
    });
    $('.block_link').on('mouseover', function() {
        var listingAttr = $(this).data('marker-id');
        if (listingAttr !== undefined) {
            var listing_id = $(this).data('marker-id') - 1;
            var marker_div = allMarkers[listing_id].div;
            $(marker_div).addClass('clicked');
            $(this).on('mouseout', function() {
                if ($(marker_div).is(":not(.infoBox-opened)")) {
                    $(marker_div).removeClass('clicked');
                }
            });
        }
    });
    var boxText = document.createElement("div");
    boxText.className = 'map-box'
    var currentInfobox;
    var boxOptions = {
        content: boxText,
        disableAutoPan: false,

        alignBottom: true,
        maxWidth: 0,
        pixelOffset: new google.maps.Size(-134, -55),
        zIndex: null,
        boxStyle: {
            //  width: "220px" 
            width: $('#right-wrap').width() + "px"
        },
        closeBoxMargin: "0",
        closeBoxURL: "",
        infoBoxClearance: new google.maps.Size(0, 0),
        isHidden: false,
        pane: "floatPane",
        enableEventPropagation: false,
    };
    var markerCluster, overlay, i;
    var allMarkers = [];
    var clusterStyles = [{
        textColor: 'white',
        url: '',
        height: 50,
        width: 50
    }];
    var markerIco;
    for (i = 0; i < locations.length; i++) {
        markerIco = locations[i][4];
        var overlaypositions = new google.maps.LatLng(locations[i][1], locations[i][2]),
            overlay = new CustomMarker(overlaypositions, map, {
                marker_id: i
            }, markerIco);
        allMarkers.push(overlay);
        google.maps.event.addDomListener(overlay, 'click', (function(overlay, i) {
            return function() {
                ib.setOptions(boxOptions);
                boxText.innerHTML = locations[i][0];
                ib.close();
                ib.open(map, overlay);
                currentInfobox = locations[i][3];
                google.maps.event.addListener(ib, 'domready', function() {
                    $('.infoBox-close').click(function(e) {
                        e.preventDefault();
                        ib.close();
                        $('.map-marker-container').removeClass('clicked infoBox-opened');
                    });
                });

                setTimeout(function() {
                    $('.infoBox .w_slick').on('init', function(event, slick) {
                        if (slick.slideCount <= 3) {
                            $('.infoBox .w_slick').addClass('no_slide_center');
                        }

                        setTimeout(function() {
                            slick.refresh();
                        }, 100);

                    });
                    $('.infoBox .w_slick').slick({
                        infinite: false,
                        slidesToShow: 3,
                        slidesToScroll: 1
                    });

                    // Crop hover init
                    FarmsGate_.crop_slider_overlay($('.infoBox .w_slick'));
                }, 100);
            }
        })(overlay, i));

        //

        //
    }
    var options = {
        imagePath: 'images/',
        styles: clusterStyles,
        minClusterSize: 2
    };
    // markerCluster = new MarkerClusterer(map, allMarkers, options);
    google.maps.event.addDomListener(window, "resize", function() {
        var center = map.getCenter();
        google.maps.event.trigger(map, "resize");
        map.setCenter(center);
    });
    // map drag
    google.maps.event.addDomListener(map, "drag", function() { //

        ib.close();
    });
    google.maps.event.addDomListener(map, "zoom_changed", function() { //
        console.log("drag");
        ib.close();
    });
    //
    var zoomControlDiv = document.createElement('div');
    var zoomControl = new ZoomControl(zoomControlDiv, map);

    function ZoomControl(controlDiv, map) {
        zoomControlDiv.index = 1;
        map.controls[google.maps.ControlPosition.RIGHT_CENTER].push(zoomControlDiv);
        controlDiv.style.padding = '5px';
        controlDiv.className = "zoomControlWrapper";
        var controlWrapper = document.createElement('div');
        controlDiv.appendChild(controlWrapper);
        var zoomInButton = document.createElement('div');
        zoomInButton.className = "custom-zoom-in";
        controlWrapper.appendChild(zoomInButton);
        var zoomOutButton = document.createElement('div');
        zoomOutButton.className = "custom-zoom-out";
        controlWrapper.appendChild(zoomOutButton);
        google.maps.event.addDomListener(zoomInButton, 'click', function() {
            map.setZoom(map.getZoom() + 1);
        });
        google.maps.event.addDomListener(zoomOutButton, 'click', function() {
            map.setZoom(map.getZoom() - 1);
        });
    }
    var scrollEnabling = $('#scrollEnabling');
    $(scrollEnabling).click(function(e) {
        e.preventDefault();
        $(this).toggleClass("enabled");
        if ($(this).is(".enabled")) {
            map.setOptions({
                'scrollwheel': true
            });
        } else {
            map.setOptions({
                'scrollwheel': false
            });
        }
    })
    $("#geoLocation, .input-with-icon.location a").click(function(e) {
        e.preventDefault();
        geolocate();
    });

    function geolocate() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                var pos = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
                map.setCenter(pos);
                map.setZoom(12);
            });
        }
    }

    var leftPanel = $("#left_slide_panel");
    var resize = $("#left-wrap");
    var containerWidth = $("#container").width();
    $(resize).resizable({
        handles: 'e',
        maxWidth: $("#container").width() - $('#right-wrap').width(),
        minWidth: $("#container").width() / 3,
        resize: function(event, ui) {
            var containerWidth = $("#container").width();
            var currentWidth = ui.size.width;

            // this accounts for padding in the panels +
            // borders, you could calculate this using jQuery
            var padding = 0;

            // this accounts for some lag in the ui.size value, if you take this away
            // you'll get some instable behaviour
            $(this).width(currentWidth);

            // set the content panel width
            $("#right-wrap").width(containerWidth - currentWidth - padding);
            $(".ui-resizable-handle.ui-resizable-e").css("right", $('#right-wrap').width());
            //$(".ui-resizable-handle.ui-resizable-e").righ(containerWidth - currentWidth - padding);
            // $('#ui-resizable-handle ui-resizable-e')


            if (currentWidth < 500) {
                $(".grid").addClass("one-clm");
            } else if (currentWidth < 800) {
                $(".grid").addClass("two-clm");
                $(".grid").removeClass("one-clm");
            } else {
                $(".grid").removeClass("two-clm");
                $(".grid").removeClass("one-clm");
            }

            if ($('[data-listing="true"]').length != 0) {
                $('[data-listing="true"]').find('.block_').each(function() {

                    var block_ = $(this),
                        crop_slider = block_.find('.crops_box');

                    // Inner Crop slider init                                            
                    if ($(crop_slider).hasClass('slick-initialized')) {
                        console.log('call_', crop_slider);

                        $(crop_slider).slick('refresh');

                    }

                });
            }
        }
    });
}
var map = document.getElementById('map');
if (typeof(map) != 'undefined' && map != null) {
    google.maps.event.addDomListener(window, 'load', mainMap);
}

function singleListingMap() {
    var myLatlng = new google.maps.LatLng({
        lng: $('#singleListingMap').data('longitude'),
        lat: $('#singleListingMap').data('latitude'),
    });
    var single_map = new google.maps.Map(document.getElementById('singleListingMap'), {
        zoom: 15,
        center: myLatlng,
        scrollwheel: false,
        zoomControl: false,
        mapTypeControl: false,
        scaleControl: false,
        panControl: false,
        navigationControl: false,
        streetViewControl: false,
        styles: [{
            "featureType": "poi",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#747474"
            }, {
                "lightness": "23"
            }]
        }, {
            "featureType": "poi.attraction",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#f38eb0"
            }]
        }, {
            "featureType": "poi.government",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#ced7db"
            }]
        }, {
            "featureType": "poi.medical",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#ffa5a8"
            }]
        }, {
            "featureType": "poi.park",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#c7e5c8"
            }]
        }, {
            "featureType": "poi.place_of_worship",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#d6cbc7"
            }]
        }, {
            "featureType": "poi.school",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#c4c9e8"
            }]
        }, {
            "featureType": "poi.sports_complex",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#b1eaf1"
            }]
        }, {
            "featureType": "road",
            "elementType": "geometry",
            "stylers": [{
                "lightness": "100"
            }]
        }, {
            "featureType": "road",
            "elementType": "labels",
            "stylers": [{
                "visibility": "off"
            }, {
                "lightness": "100"
            }]
        }, {
            "featureType": "road.highway",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#ffd4a5"
            }]
        }, {
            "featureType": "road.arterial",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#ffe9d2"
            }]
        }, {
            "featureType": "road.local",
            "elementType": "all",
            "stylers": [{
                "visibility": "simplified"
            }]
        }, {
            "featureType": "road.local",
            "elementType": "geometry.fill",
            "stylers": [{
                "weight": "3.00"
            }]
        }, {
            "featureType": "road.local",
            "elementType": "geometry.stroke",
            "stylers": [{
                "weight": "0.30"
            }]
        }, {
            "featureType": "road.local",
            "elementType": "labels.text",
            "stylers": [{
                "visibility": "on"
            }]
        }, {
            "featureType": "road.local",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#747474"
            }, {
                "lightness": "36"
            }]
        }, {
            "featureType": "road.local",
            "elementType": "labels.text.stroke",
            "stylers": [{
                "color": "#e9e5dc"
            }, {
                "lightness": "30"
            }]
        }, {
            "featureType": "transit.line",
            "elementType": "geometry",
            "stylers": [{
                "visibility": "on"
            }, {
                "lightness": "100"
            }]
        }, {
            "featureType": "water",
            "elementType": "all",
            "stylers": [{
                "color": "#d2e7f7"
            }]
        }]
    });
    $('#streetView').click(function(e) {
        e.preventDefault();
        single_map.getStreetView().setOptions({
            visible: true,
            position: myLatlng
        });
    });
    var zoomControlDiv = document.createElement('div');
    var zoomControl = new ZoomControl(zoomControlDiv, single_map);

    function ZoomControl(controlDiv, single_map) {
        zoomControlDiv.index = 1;
        single_map.controls[google.maps.ControlPosition.RIGHT_CENTER].push(zoomControlDiv);
        controlDiv.style.padding = '5px';
        var controlWrapper = document.createElement('div');
        controlDiv.appendChild(controlWrapper);
        var zoomInButton = document.createElement('div');
        zoomInButton.className = "custom-zoom-in";
        controlWrapper.appendChild(zoomInButton);
        var zoomOutButton = document.createElement('div');
        zoomOutButton.className = "custom-zoom-out";
        controlWrapper.appendChild(zoomOutButton);
        google.maps.event.addDomListener(zoomInButton, 'click', function() {
            single_map.setZoom(single_map.getZoom() + 1);
        });
        google.maps.event.addDomListener(zoomOutButton, 'click', function() {
            single_map.setZoom(single_map.getZoom() - 1);
        });
    }
    var singleMapIco = "<i class='" + $('#singleListingMap').data('map-icon') + "'></i>";
    new CustomMarker(myLatlng, single_map, {
        marker_id: '1'
    }, singleMapIco);
}
var single_map = document.getElementById('singleListingMap');
if (typeof(single_map) != 'undefined' && single_map != null) {
    google.maps.event.addDomListener(window, 'load', singleListingMap);
}

function CustomMarker(latlng, map, args, markerIco) {
    this.latlng = latlng;
    this.args = args;
    this.markerIco = markerIco;
    this.setMap(map);
}
CustomMarker.prototype = new google.maps.OverlayView();
CustomMarker.prototype.draw = function() {
    var self = this;
    var div = this.div;
    if (!div) {
        div = this.div = document.createElement('div');
        div.className = 'map-marker-container';
        div.innerHTML = '<div class="marker-container">' +
            '<div class="marker-card">' +
            '<div class="front face">' + self.markerIco + '</div>' +
            '<div class="back face">' + self.markerIco + '</div>' +
            '<div class="marker-arrow"></div>' +
            '</div>' +
            '</div>'
        google.maps.event.addDomListener(div, "click", function(event) {
            $('.map-marker-container').removeClass('clicked infoBox-opened');
            google.maps.event.trigger(self, "click");
            $(this).addClass('clicked infoBox-opened');
        });
        if (typeof(self.args.marker_id) !== 'undefined') {
            div.dataset.marker_id = self.args.marker_id;
        }
        var panes = this.getPanes();
        panes.overlayImage.appendChild(div);
    }
    var point = this.getProjection().fromLatLngToDivPixel(this.latlng);
    if (point) {
        div.style.left = (point.x) + 'px'; /////
        div.style.top = (point.y) + 'px';

        //  div.style.left ='0px';/////
        // div.style.top =  '0px';
    }
};
CustomMarker.prototype.remove = function() {
    if (this.div) {
        this.div.parentNode.removeChild(this.div);
        this.div = null;
        $(this).removeClass('clicked');
    }
};
CustomMarker.prototype.getPosition = function() {
    return this.latlng;
}; 
</script>