<input type="hidden" name="near_latitude" id="near_latitude" value="">
<input type="hidden" name="near_longitude" id="near_longitude" value="">	
<script>
$.getJSON("https://geoip-db.com/json/",
function(data) {
    $('#near_latitude').val(data.latitude); 
    $('#near_longitude').val(data.longitude);
});

</script>