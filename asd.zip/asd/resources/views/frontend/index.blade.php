@extends('frontend.layouts.master') 
@section('metatags')
	<meta name="description" content="{{{@$websiteSettings->site_meta_description}}}" />
	<meta name="keywords" content="{{{@$websiteSettings->site_meta_keyword}}}" />
	<meta name="author" content="{{{@$websiteSettings->site_meta_title}}}" /> 
@stop 
@section('seoPageTitle')
	<title>
		<?php $pageTitle = (!empty($websiteSettings->home_page_title))?$websiteSettings->home_page_title:$websiteSettings->sitename; ?>
		{{ ($lang == 'en') ? $pageTitle : '' }}
	</title>
@stop 
@section('styles')
@parent
	
@stop
@section('content')
	
	@include('frontend.partials.home_banner')
	@include('frontend.partials.home_categories')
@if(!empty($userMessage['show_modal']))
   <div class="aj_loader {{$userMessage['show_staus']}}" id="email_verification_loader">
         <div class="loader_wrapper">
            <div class="shape shape1"></div>
            <div class="shape shape2"></div>
            <div class="shape shape3"></div>
            <div class="shape shape4"></div>
         </div>

         <div class="msg {{$userMessage['flag']}}" id="email_verification_success_msg"> 
            {{$userMessage['userMessage']}}               
         </div>
   </div>
@endif
<section class="home-section section_farms fade-in-Up" id="recommended_farms">
   <div class="container">
      <h3 class="section-title "><span>{!! lang('recommended_farms') !!}</span> </h3>
      <div class="farms-grid-container">
         <div class="grid-wrap ">
            <div class="swiper-container " 
               data-grid-slider="true" 
               data-grid-mobile='1' 
               data-grid-tab='2' 
               data-grid-normal='3' 
               data-grid-large='4'               
               >
               <!-- data-autoplay= '5000' -->
               <div class="swiper-wrapper">
				@include('frontend.partials.recommended_farm_block')                                                   
			   </div>
            </div>

            <div class="nav_box side_">
               <div class="nav_ back_nav"><i class="icon icon-ios-arrow-left"></i></div>
               <div class="nav_ next_nav"><i class="icon icon-ios-arrow-right"></i></div>
            </div>
         </div>
      </div>
      <div class="viewMoreBtnWrap ">
         <a href="{!! url($lang.'/search'); !!}" class="moreBtn btn-2">{!! lang('view_all_farms') !!}</a>
      </div>
   </div>
</section>
<div>
@if($userMessage)
@endif
</div>	
@stop
@section('scripts')
@parent
<script type="text/javascript">
   $(document).ready(function () {
     $('select').selectric();   
     setTimeout(function() {
      $( "#email_verification_loader" ).removeClass('show_');
      $( "#email_verification_success_msg" ).html('');
      $( "#email_verification_success_msg" ).removeClass('error');
      $( "#email_verification_loader .loader_wrapper" ).removeClass('hide_');
      }, 4000);
   });   
</script>
@stop