@extends('frontend.layouts.login') 
@section('metatags')
	<meta name="description" content="{{{@$websiteSettings->site_meta_description}}}" />
	<meta name="keywords" content="{{{@$websiteSettings->site_meta_keyword}}}" />
	<meta name="author" content="{{{@$websiteSettings->site_meta_title}}}" /> 
@stop 
@section('seoPageTitle')
	<title>
		<?php $pageTitle = (!empty($websiteSettings->home_page_title))?$websiteSettings->home_page_title:$websiteSettings->sitename; ?>
		{{ ($lang == 'en') ? $pageTitle : '' }}
	</title>
@stop 
@section('styles')
@parent
	
@stop
@section('content')

<div id="cd-loginform" style="width: 500px;margin: 20vh auto;"> <!-- log in form -->
      <div class="commonMessage" style="color:red">
      </div>
      <div class="cdFormTitle">Login to FarmsGate</div>
         {{ Form::open(['url'=>asset($lang.'/login'),'id'=>'user-login','class'=>'cd-form']) }}
            <div class="aj_loader" id="login_loader">
                    <div class="loader_wrapper">
                        <div class="shape shape1"></div>
                        <div class="shape shape2"></div>
                        <div class="shape shape3"></div>
                        <div class="shape shape4"></div>
                    </div>

                    <div class="msg" id="login_success_msg">                
                    </div>
            </div>
          <div class="fieldset">
            <label class="head_" for="user_email">E-mail</label>
            <input class="full-width" id="email" name="user_email" type="user_email">
            
          </div>
          
          <div class="fieldset">
            <label class="head_" for="password">Password</label>
            <input class="full-width" id="password" name="password" type="password">
            
          </div>          

          <div class="fieldset text-right">
            <button class="btn-style2" type="submit" value="Login">Login</button>
          </div>
        {{ Form::close() }}   
      

      
        <!-- <a href="#0" class="cd-close-form">Close</a> -->
      </div> <!-- cd-login -->

      
    
@stop  
@section('scripts')
@parent
@include('frontend.script.helper')

<script type="text/javascript">
    $(document).ready(function() {
    
		
		$('#user-register').validate({		
        
        rules: {              
            'name':{
                required:true
            }, 
            'user_email':{
                required:true,
                email:true,
            },
			'phone':{
				required:true,
            },
            'password':{
                required:true,
                minlength : 8,
            },
            'repassword':{
                required:true,
                equalTo: "#password",
                minlength : 8,
            },           
        },
      submitHandler: function() {
            var _url = "{{ asset($lang.'/register') }}";
            var _data = $('#user-register').serializeArray();
            
            sendAjax(_url,'post',_data, function(responseData){
              if(!responseData.status){
                    $('.commonMessage').html(responseData.userMessage);
                }else{
                    if(responseData.redirectURL){
                        window.location.href = responseData.redirectURL;
                    }else{                
                        $('.commonMessage').html('<i class=" icon icon-success "></i> '+ responseData.message);
                    }
                    
                }  
            });
            return false;
        } 

    }); 
    
    
    $('#user-login').validate({		
        
        rules: {              
            'user_email':{
                required:true,
                email:true,
            },
            'password':{
                required:true,
            },          
        },
        messages:{
              "user_email" : {
                required:"{!! lang('field_required') !!}",
                email:"{!! lang('invalid_email_address') !!}",
              },
              "password" : {
                required:"{!! lang('field_required') !!}",
              },												
        },
      submitHandler: function() {
            var _url = "{{ asset($lang.'/login') }}";
            var _data = $('#user-login').serializeArray();
            $( "#login_loader" ).addClass('show_');
            sendAjax(_url,'post',_data, function(responseData){                
              if(!responseData.status){
                    //$('.commonMessage').html(responseData.userMessage);
                    setTimeout(function() {
                        $( "#login_success_msg" ).html(responseData.userMessage);
                        $( "#login_success_msg" ).addClass('error');
                        $( "#login_loader .loader_wrapper" ).addClass('hide_');
                        }, 1000);

                    setTimeout(function() {
                        $( "#login_loader" ).removeClass('show_');
                        $( "#login_success_msg" ).html('');
                        $( "#login_success_msg" ).removeClass('error');
                        $( "#login_loader .loader_wrapper" ).removeClass('hide_');
                        }, 3000);
                        
                }else{
                    if(responseData.redirectURL){                        
                           window.location.href = responseData.redirectURL;                        
                    }else{                
                        $('.commonMessage').html('<i class=" icon icon-success "></i> '+ responseData.message);
                    }
                    
                }  
            });
            return false;
        } 

    });
    
    });
</script>
@stop
