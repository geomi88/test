@extends('frontend.layouts.master')
@section('content')
<main class="inner_body">
    <section class="page-section user_dashboard">
        <div class="container-fluid">

            <div class="row sticky-sidebar-parent">
                <div class="col-lg-4 col-xl-3 sticky-sidebar-top100">

                    @include('frontend.layouts.user_dashboard_side')

                </div>

                <div class="col-lg-8 col-xl-9 content_box">
                    <div class="breadcrumb_wrapper">
                        <nav id="breadcrumbs">
                            <ul>
                                <li><a href='{{url("$lang/home")}}'>Home</a></li>
                                <li><a href='{{url("$lang/user/dashboard")}}'>Dashboard</a></li>                        
                                <li>Reviews</li>                           
                            </ul>
                        </nav>
                    </div>
                    <div class="page-title ">{!! lang('reviews') !!}</div>
                    <aside class="in_block small_padd review_tab ">

                        <!-- Tabs Navigation -->
                        <ul class="tabs-nav">
                            <li class="active"><a href="#tab1b">{!! lang('reviews_about_you') !!}</a></li>
                            <li><a href="#tab2b">{!! lang('reviews_by_you') !!}</a></li>

                        </ul>

                        <!-- Tabs Content -->
                        <div class="tabs-container">
                            <div class="tab-content" id="tab1b">
                            @if($reviews_for_user->count()>0)
                                <div class="row rating_list_box small_">
                                
                                    @foreach($reviews_for_user as $user_review)
                                @php 
                                    $farm = $user_review->getOwnedFarmDetails;
                                @endphp
                                    <div class="col-md-12 rating_">
                                        <div class="rate_head_box">
                                            <div class="avatar_box green_border">
                                                <a href='{{url("$lang/farm-owner/$user_review->fr_user_id")}}' class="link_">
                                                    <div class="img_ b-lazy b-loaded" style="background-image: url({{get_profile_image($user_review->owner->user_avatar)}});"></div>
                                                </a>
                                            </div>
                                            <div class="title_wrapper">
                                                <div class="title_">
                                                    {{$user_review->owner->user_full_name}}
                                                </div>
                                                <a href='{{url("$lang/farm/$farm->fm_slug")}}' target="_blank" class="meta_fname">{{$farm->fm_title}}</a>
                                            </div>
                                            <div class="star-rating" data-s-rating='true' data-rating="{{$user_review->fr_rating}}">						
                                                <span class="star"></span>
                                                <span class="star"></span>
                                                <span class="star"></span>
                                                <span class="star"></span>
                                                <span class="star"></span>

                                                <div class="rate_box">
                                                    <span>{{$user_review->fr_rating}}</span>
                                                    <span>/ 5</span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="details_box">


                                            <div class="text_box">
                                                <p>{{$user_review->fr_comment}}</p>
                                            </div>
                                            <div class="date_"><span>{{date_convert($user_review->fr_created_at)}}</span></div>
                                        </div>
                                    </div>
                                    @endforeach
                                                                                                                                                                       
                                </div>
                            @else
                                @include('frontend.partials.no_results', ['message' => lang('reviews_not_found')]) 
                            @endif   
                            </div>

                            <div class="tab-content" id="tab2b">
                            @if($reviews_by_user->count()>0)
                                <div class="row rating_list_box small_">
                            
                                @foreach($reviews_by_user as $revDetails)
                                    @if(!empty($revDetails->getFarmDetails))
                                @php
                                    $farm=$revDetails->getFarmDetails;
                                @endphp
                                    <div class="col-md-12 rating_">
                                        <div class="rate_head_box">
                                            <div class="avatar_box green_border">
                                                <a href='{{url("$lang/farm-owner/$farm->fm_owner_id")}}' class="link_">
                                                    <div class="img_ b-lazy b-loaded" style="background-image: url({{get_profile_image($farm->owner->user_avatar)}});"></div>
                                                </a>
                                            </div>
                                            <div class="title_wrapper">
                                                <div class="title_">
                                                    {{$farm->owner->user_full_name}}
                                                </div>
                                                <a href='{{url("$lang/farm/$farm->fm_slug")}}' class="meta_fname">{{$farm->fm_title}}</a>
                                            </div>

                                            <div class="star-rating" data-s-rating='true' data-rating="{{$revDetails->fr_rating}}">						
                                                <span class="star"></span>
                                                <span class="star"></span>
                                                <span class="star"></span>
                                                <span class="star"></span>
                                                <span class="star"></span>

                                                <div class="rate_box">
                                                    <span>{{$revDetails->fr_rating}}</span>
                                                    <span>/ 5</span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="details_box">


                                            <div class="text_box">
                                                <p>{{$revDetails->fr_comment}}</p>
                                            </div>
                                            <div class="date_"><span>{{date_convert($revDetails->fr_created_at)}}</span></div>
                                        </div>
                                    </div>
                                    
                                    @endif
                                @endforeach
                                                                
                                </div>
                            @else
                                @include('frontend.partials.no_results', ['message' => lang('reviews_not_found')])
                            @endif    
                            </div>
                        </div>
                    </aside>
                </div>

            </div>

    </section>

</main>
@stop