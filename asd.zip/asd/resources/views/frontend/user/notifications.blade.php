@extends('frontend.layouts.master')
@section('content')
<main class="inner_body">
  <section class="page-section user_dashboard">
    <div class="container-fluid">

      <div class="row sticky-sidebar-parent">
        <div class="col-lg-4 col-xl-3 sticky-sidebar-top100">

            @include('frontend.layouts.user_dashboard_side')
          
        </div>
        <div class="col-lg-8 col-xl-9 content_box">
          <div class="breadcrumb_wrapper">
              <nav id="breadcrumbs">
                  <ul>
                      <li><a href='{{url("$lang/home")}}'>Home</a></li>
                      <li><a href='{{url("$lang/user/dashboard")}}'>Dashboard</a></li>                        
                      <li>Notifications</li>                           
                  </ul>
              </nav>
          </div>
        <div class="page-title ">{{ lang('user_notifications') }}</div>
        <aside class="in_block small_padd notification-container ">
        @if($notifications->count() > 0)
        <div class="notification-inbox">
          @include('frontend.partials.user_notifications')
        </div>
        @else
          @include('frontend.partials.no_results', ['message' => "No Notifications Found"])
        @endif
        </aside>

        </div>

      </div>
    </div>
  </section>

</main>
@stop