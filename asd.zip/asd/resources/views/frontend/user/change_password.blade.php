@extends('frontend.layouts.master')
@section('content')
<main class="inner_body">
    <section class="page-section user_dashboard">
        <div class="container-fluid">

            <div class="row sticky-sidebar-parent">
                <div class="col-lg-4 col-xl-3 sticky-sidebar-top100">

                    @include('frontend.layouts.user_dashboard_side')

                </div>
                <div class="col-lg-8 col-xl-9 content_box">

                    <div class="page-title ">{{ lang('change_password') }}</div>
                    <aside class="in_block  ">
                        <div class="formv2">

                            {!! Form::open(['method' => 'POST', 'url' => url("$lang/user/change_password" ), 'id'=>'change-password'] ) !!}
                            <div class="aj_loader" id="u_change_pwd_loader">
                                <div class="loader_wrapper">
                                    <div class="shape shape1"></div>
                                    <div class="shape shape2"></div>
                                    <div class="shape shape3"></div>
                                    <div class="shape shape4"></div>
                                </div>

                                <div class="msg" id="u_change_pwd_success_msg">
                                </div>
                            </div>
                            
                            <div class="input-group">
                                <div class="input-box">
                                    <label for="current_pwd">{{ lang('current_password') }}</label>
                                    <input class="form-control" type="password" value="" name="current_pwd" id="current_pwd">
                                </div>                                
                            </div>
                            <div class="input-group">
                                <div class="input-box">
                                    <label for="new_pwd">{{ lang('new_password') }}</label>
                                    <input class="form-control" type="password" value="" name="new_pwd" id="new_pwd">
                                </div>
                                <div class="input-box">
                                    <label for="confirm_pwd">{{ lang('confirm_password') }}</label>
                                    <input class="form-control" type="password" value="" name="confirm_pwd" id="confirm_pwd">
                                </div>
                            </div>                           

                            <div class="btn_wrapper text-right with_link ">
                                <button type="submit" class="btn-style2 ">Save</button>
                            </div>

                            {{ Form::close() }}
                        </div>
                    </aside>

                </div>

            </div>
        </div>
    </section>

</main>
@stop
@section('scripts')
@parent
<script>
    $(document).ready(function() {

        $('#change-password').validate({
            errorElement: 'label',
            ignore: [],
            rules: {
                'current_pwd': {
                    required: true
                },
                'new_pwd': {
                    required: true,
                    minlength : 8,
                },
                'confirm_pwd': {
                    required: true,
                    equalTo: "#new_pwd",
                    minlength : 8,
                },
            },
            messages: {
                "current_pwd" : {
                    required:"{!! lang('field_required') !!}",
                },
                "new_pwd" : {
                    required:"{!! lang('field_required') !!}",
                    minlength:"{!! lang('atleast_8_chars') !!}",
                },
                "confirm_pwd" : {
                    required:"{!! lang('field_required') !!}",
                    minlength:"{!! lang('atleast_8_chars') !!}",
                    equalTo:"{!! lang('password_match') !!}",
                },
            },
            submitHandler: function() {
                var _url = "{{ url($lang.'/user/change-password') }}";
                var _data = $('#change-password').serializeArray();
                console.log(_data);
                sendAjax(_url, 'post', _data, function(responseData) {
                    $("#u_change_pwd_loader").addClass('show_');
                    if (!responseData.status) {
                        //$('.commonMessage').html(responseData.userMessage);
                        setTimeout(function() {
                        $( "#u_change_pwd_success_msg" ).html(responseData.userMessage);
                        $( "#u_change_pwd_success_msg" ).addClass('error');
                        $( "#u_change_pwd_loader .loader_wrapper" ).addClass('hide_');
                        }, 1000);
                        setTimeout(function() {
                            $( "#u_change_pwd_loader" ).removeClass('show_');
                            $( "#u_change_pwd_success_msg" ).html('');
                            $( "#u_change_pwd_success_msg" ).removeClass('error');
                            $( "#u_change_pwd_loader .loader_wrapper" ).removeClass('hide_');
                            }, 5000);
                    } else {
                        if (responseData.redirectURL) {
                            setTimeout(function() {
                                $("#u_change_pwd_success_msg").html('Your Password has been updated');
                                $("#u_change_pwd_success_msg").addClass('success');
                                $("#u_change_pwd_loader .loader_wrapper").addClass('hide_');
                            }, 1000);
                            setTimeout(function() {
                                window.location.reload();
                            }, 2000);
                        } else {
                            $('.commonMessage').html('<i class=" icon icon-success "></i> ' + responseData.message);
                        }

                    }
                });
                return false;
            }

        });
    });
</script>
@stop