@extends('frontend.layouts.master')
@section('content')
<main class="inner_body">
  <section class="page-section user_dashboard">
    <div class="container-fluid">

      <div class="row sticky-sidebar-parent">
        <div class="col-lg-4 col-xl-3 sticky-sidebar-top100">

            @include('frontend.layouts.user_dashboard_side')
          
        </div>
        <div class="col-lg-8 col-xl-9 content_box">
          <div class="breadcrumb_wrapper">
              <nav id="breadcrumbs">
                  <ul>
                      <li><a href='{{url("$lang/home")}}'>Home</a></li>
                      <li><a href='{{url("$lang/user/dashboard")}}'>Dashboard</a></li>                        
                      <li>Favorites</li>                           
                  </ul>
              </nav>
          </div>
          <div class="page-title ">{{ lang('my_favorites') }}</div>
          <aside class="in_block small_padd">
          @if($farmList->count() > 0)
          <div class="grid-wrap " data-listing="true" data-colum="3">
            @include('frontend.partials.user_fav_farms') 
          </div>
          @else
            @include('frontend.partials.no_results', ['message' => lang('favorites_not_found')])
          @endif
          </aside>

        </div>

      </div>
    </div>
  </section>

</main>
@stop