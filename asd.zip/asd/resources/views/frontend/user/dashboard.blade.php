@extends('frontend.layouts.master')
@section('content')
<main class="inner_body">
  <section class="page-section user_dashboard">
    <div class="container-fluid">

      <div class="row sticky-sidebar-parent">
        <div class="col-lg-4 col-xl-3 sticky-sidebar-top100">

          @include('frontend.layouts.user_dashboard_side')

        </div>

        <div class="col-lg-8 col-xl-9 content_box">
          <div class="breadcrumb_wrapper">
              <nav id="breadcrumbs">
                <ul>
                    <li><a href='{{url("$lang/home")}}'>Home</a></li>                           
                    <li><a href="#">Dashboard</a></li>                           
                </ul>
              </nav>
          </div>
          <article class="number_grid_list">

            <div class="number_wrapper" data-colum="2">
              <div class="number_box text-center">
                <div class="number_">                
                {{Auth::user()->subscribedFarms->count()}}
                  <span class="number_span" data-number="{{Auth::user()->subscribedFarms->count()}}"></span>
                  <span class="number_span" data-number="{{Auth::user()->subscribedFarms->count()}}"></span>

                </div>
                <div class="title_ text-green"><span>{{ lang('subscription_farms') }}</span></div>
              </div>

              <!-- <div class="number_box text-center">
                <div class="number_">04
                  <span class="number_span" data-number="04"></span>
                  <span class="number_span" data-number="04"></span>
                </div>
                <div class="title_ text-green"><span>{{ lang('type_of_crops') }}</span></div>
              </div> -->

              <div class="number_box text-center">
                <div class="number_">{{Auth::user()->favFarms->count()}}
                  <span class="number_span" data-number="{{Auth::user()->favFarms->count()}}"></span>
                  <span class="number_span" data-number="{{Auth::user()->favFarms->count()}}"></span>
                </div>
                <div class="title_ text-green"><span>{{ lang('favorites') }}</span></div>
              </div>


            </div>



          </article>

          <aside class="in_block grid-wrap personal_farms_list with_avatar">
            <div class="sub-title with_tool">{{ lang('my_farms') }}<span class="text-green">({{$farmList->count()}})</span>
              <div class="tool_box">
                <a href="{!! url($lang.'/farm-signup'); !!}" class="button link_ with-icon icon_right">{{ lang('add_more_farms') }}<i class="icon icon-ios-plus"></i></a>
              </div>
            </div>
            @if($farmList->count() > 0)
            <div class="grid-wrap" data-listing="true" data-colum="3">
              @include('frontend.partials.user_active_farms')
            </div>
            @else
              @include('frontend.partials.no_results', ['message' => "No Farms Found"])
            @endif
          </aside>
        </div>




      </div>

    </div>

  </section>

</main>
@stop
@section('scripts')
@parent 
<script>
$(document).ready(function(){
   $('.switch').tooltipster();
   $(".disable_status").click( function(){
      
      var _url = "{{ url('/api/disable-farm') }}";        
      var farm_id = $(this).data('id');
      var disable_status = $(this).is(':checked')?0:1;
      var status_txt = '';
      if(disable_status == 0){
        status_txt = "Active";
      }
      else{
        status_txt = "Inactive";
      }
      var _data = {
                  '_token':'{{csrf_token()}}',
                  'farm_id':farm_id,
                  'disable_status':disable_status,
                  }
      
      sendAjax(_url,'post',_data, function(responseData){
        if(!responseData.status){
          return false;
        }
        else{
          var this_el = $(".switch[data-fmid="+farm_id+"]");
          //this_el.attr('title', status_txt);
          this_el.tooltipster('content', status_txt);
          return true;
          
        }

      });
      

   });
});
</script>
@stop