@extends('frontend.layouts.master')
@section('content')
<main class="inner_body">
  <section class="page-section user_dashboard">
    <div class="container-fluid">

      <div class="row sticky-sidebar-parent">
        <div class="col-lg-4 col-xl-3 sticky-sidebar-top100">

            @include('frontend.layouts.user_dashboard_side')
          
        </div>
        <div class="col-lg-8 col-xl-9 content_box">
            <div class="breadcrumb_wrapper">
                <nav id="breadcrumbs">
                    <ul>
                        <li><a href='{{url("$lang/home")}}'>Home</a></li>
                        <li><a href='{{url("$lang/user/dashboard")}}'>Dashboard</a></li>                        
                        <li>Settings</li>                           
                    </ul>
                </nav>
            </div>
            <div class="page-title ">{{ lang('user_settings') }}</div>
            <aside class="in_block  ">
            @include('frontend.partials.user_settings') 
            </aside>

        </div>

      </div>
    </div>
  </section>

</main>
@stop
@section('scripts')
@parent 
<script>
$(document).ready(function(){
    
profilereadURL = function(input) {
    if (input.files && input.files[0]) {

        var reader = new FileReader();

        reader.onload = function (e) {
            var image = new Image();
            
            image.src = e.target.result;


            image.onload = function () {
            //Image preview
            $('.av_img > .img_ ').css({
            'background-image': 'url(' + this.src + ')'
            });

            };
        };

        reader.readAsDataURL(input.files[0]);
    }

}
$('#user-settings').validate({		
        errorElement: 'label',
        ignore: [],
        rules: {              
            'full_name':{
                required:true,
                alphanumeric: true,
            }, 
            'u_phone':{
                required:true,
                number:true,
            },   
        },
        messages:{
            "full_name" : {
                required:"{!! lang('field_required') !!}",
            },
            "u_phone" : {
                required:"{!! lang('field_required') !!}",
                number:"{!! lang('valid_number') !!}",
            },
        },
      submitHandler: function() {
            var _url = "{{ url($lang.'/user/settings') }}";
            var form = $('#user-settings')[0];
            var formdata = new FormData(form);
            var _data = formdata;
            sendAjaxFormdata(_url,'post',_data, function(responseData){
                $( "#u_settings_loader" ).addClass('show_');
              if(!responseData.status){
                    //$('.commonMessage').html(responseData.userMessage);
                    setTimeout(function() {
                        $( "#u_settings_success_msg" ).html(responseData.userMessage);
                        $( "#u_settings_success_msg" ).addClass('error');
                        $( "#u_settings_loader .loader_wrapper" ).addClass('hide_');
                        }, 1000);
                    setTimeout(function() {
                            $( "#u_settings_loader" ).removeClass('show_');
                            $( "#u_settings_success_msg" ).html('');
                            $( "#u_settings_success_msg" ).removeClass('error');
                            $( "#u_settings_loader .loader_wrapper" ).removeClass('hide_');
                            }, 5000);
                }else{
                    if(responseData.redirectURL){
                        setTimeout(function() {
                        $( "#u_settings_success_msg" ).html('Your Profile has been updated');
                        $( "#u_settings_success_msg" ).addClass('success');
                        $( "#u_settings_loader .loader_wrapper" ).addClass('hide_');
                        }, 1000);
                        setTimeout(function() {
                            window.location.reload();
                        }, 2000);
                    }else{                
                        $('.commonMessage').html('<i class=" icon icon-success "></i> '+ responseData.message);
                    }
                    
                }  
            });
            return false;
        } 

    });
 }); 
</script> 
@stop