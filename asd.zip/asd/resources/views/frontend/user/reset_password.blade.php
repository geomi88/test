@extends('frontend.layouts.login')
@section('styles')
@parent
	
@stop
@section('content')


<div id="cd-loginform" style="width: 500px;margin: 20vh auto;"> <!-- log in form -->
    <div class="commonMessage" style="color:red">
    </div>
    <div class="cdFormTitle">Password Reset</div>
    {!! Form::open(['method' => 'POST', 'url' => url($lang.'/password-reset' ), 'id'=>'pwd-reset', 'class'=>'pwd-reset cd-form'] ) !!}
        <input type="hidden" name="resetCode" id="resetCode" value="{{$resetCode}}">       
            @csrf
        <div class="fieldset">
            <label class="head_" for="password">New Password</label>
            <input class="full-width" id="password" name="password" type="password" placeholder="Password">        
        </div>
        
        <div class="fieldset">
            <label class="head_" for="confirm_password">Confirm Password</label>
            <input class="full-width" id="confirm_password" name="confirm_password" type="password" placeholder="Confirm Password">
        </div>          

        <div class="fieldset text-right">
        <button class="btn-style2">Submit</button>
        </div>
        <div class="aj_loader" id="reset_password_loader">
            <div class="loader_wrapper">
                <div class="shape shape1"></div>
                <div class="shape shape2"></div>
                <div class="shape shape3"></div>
                <div class="shape shape4"></div>
            </div>

            <div class="msg" id="reset_password_success_msg">                
            </div>
        </div>
    {{ Form::close() }}   



    <!-- <a href="#0" class="cd-close-form">Close</a> -->
</div> <!-- cd-login -->




@stop
@section('scripts')
@parent
@include('frontend.script.helper')
<script>
$(document).ready(function(){    
    $('#pwd-reset').validate({
        
        rules: {              
            'password': {
                required: true,
                minlength : 8,
                },
            'confirm_password': {
                required: true,
                equalTo: "#password",
                minlength : 8,
            },                    
        },
      submitHandler: function() {
            var _url = "{{ url($lang.'/password-reset') }}";
            var password = $( "#password" ).val();            
            var resetCode = $( "#resetCode" ).val();
            var _data = {
                        '_token':'{{csrf_token()}}',
                        'password':password,
                        'resetCode':resetCode,
                        }
            $("#reset_password_loader").addClass('show_');
            sendAjax(_url,'get',_data, function(responseData){
              if(!responseData.status){
                    setTimeout(function() {
                        $( "#reset_password_success_msg" ).html(responseData.userMessage);
                        $( "#reset_password_success_msg" ).addClass('error');
                        $( "#reset_password_loader .loader_wrapper" ).addClass('hide_');
                        }, 1000);

                    setTimeout(function() {
                        $( "#reset_password_loader" ).removeClass('show_');
                        $( "#reset_password_success_msg" ).html('');
                        $( "#reset_password_success_msg" ).removeClass('error');
                        $( "#reset_password_loader .loader_wrapper" ).removeClass('hide_');
                        }, 3000);
                }else{
                    if(responseData.redirectURL){
                        setTimeout(function() {
                        $( "#reset_password_success_msg" ).html(responseData.userMessage);
                        $( "#reset_password_success_msg" ).addClass('success');
                        $( "#reset_password_loader .loader_wrapper" ).addClass('hide_');
                        }, 1000);
                        setTimeout(function() {
                            window.location.reload();
                        }, 4000);
                        
                    }else{                
                        $('.commonMessage').html('<i class=" icon icon-success "></i> '+ responseData.userMessage);
                    }
                    
                }  
            });
            return false;
        } 

    });
                  
});
</script>
   
@stop