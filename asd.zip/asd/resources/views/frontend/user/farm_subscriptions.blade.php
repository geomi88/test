@extends('frontend.layouts.master')
@section('content')
<main class="inner_body">
    <section class="page-section user_dashboard">
        <div class="container-fluid">

            <div class="row sticky-sidebar-parent">
                <div class="col-lg-4 col-xl-3 sticky-sidebar-top100">

                    @include('frontend.layouts.user_dashboard_side')

                </div>

                <div class="col-lg-8 col-xl-9 content_box">
                    <div class="breadcrumb_wrapper">
                        <nav id="breadcrumbs">
                            <ul>
                                <li><a href='{{url("$lang/home")}}'>Home</a></li>
                                <li><a href='{{url("$lang/user/dashboard")}}'>Dashboard</a></li>                        
                                <li>Farm Subscriptions</li>                           
                            </ul>
                        </nav>
                    </div>
                    <div class="page-title ">{!! lang('subscribed_farms') !!}</div>
                    @if($farmList->count()>0)
                        @include('frontend.partials.user_subscribed_farms')
                    @else
                        @include('frontend.partials.no_results', ['message' => "No Farms Found"])
                    @endif

                </div>

            </div>

    </section>

</main>
@stop