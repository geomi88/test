 <tr>
	<td align="center" valign="top" id="templateHeader" data-template-container>
		<!--[if gte mso 9]>
			<table align="center" border="0" cellspacing="0" cellpadding="0" width="600" style="width:600px;">
			<tr>
			<td align="center" valign="top" width="600" style="width:600px;">
			<![endif]-->
		<table style="" align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="templateContainer">
			<tr>
				<td valign="top" class="headerContainer">
					<table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnImageBlock" style="min-width:100%;">
						<tbody class="mcnImageBlockOuter">
							<tr>
								<td valign="top" style="" class="mcnImageBlockInner">
									<table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="mcnImageContentContainer" style="min-width:100%;">
										<tbody>
											<tr>
												<td class="mcnImageContent" valign="top" style=" text-align:center;">

													<a href="#" title="" class="" target="_blank">
													
														<img align="center" alt="" src="{{ asset('assets/frontend/images/farmsgate_email.jpg') }}" alt="" width="600" style="max-width:600px; padding-bottom: 0; display: inline !important; vertical-align: bottom;" class="mcnImage">
													</a>

												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
		</table>
		<!--[if gte mso 9]>
			</td>
			</tr>
			</table>
			<![endif]-->
	</td>
</tr>