  <tr>
                            <td align="center" valign="top" id="templateFooter" data-template-container>
                                <!--[if gte mso 9]>
									<table align="center" border="0" cellspacing="0" cellpadding="0" width="600" style="width:600px;background: #8e8b8b;">
									<tr>
									<td align="center" valign="top" width="600" style="width:600px;">
									<![endif]-->
                                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="templateContainer">
                                    <tr>
                                        <td valign="top" class="footerContainer">
                                           
                                        
                                            <table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnTextBlock" style="min-width:100%;">
                                                <tbody class="mcnTextBlockOuter">
                                                    <tr>
                                                        <td valign="top" class="mcnTextBlockInner" >
                                                            <!--[if mso]>
				<table align="left" border="0" cellspacing="0" cellpadding="0" width="100%" style="width:100%;">
				<tr>
				<![endif]-->

                                                            <!--[if mso]>
				<td valign="top" width="600" style="width:600px;">
				<![endif]-->
                                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%; min-width:100%;" width="100%" class="mcnTextContentContainer">
                                                                <tbody>
                                                                    <tr>

                                                                        <td valign="top" class="mcnTextContent" style="padding-top:12px; padding-right:18px; padding-bottom:12px; padding-left:18px;">

                                                                            <div ><a> Copyright © {{ date('Y') }} Public Policy Lab. All Rights Reserved </a>
                                                                            </div>

                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                            <!--[if mso]>
				</td>
				<![endif]-->

                                                            <!--[if mso]>
				</tr>
				</table>
				<![endif]-->
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                                <!--[if gte mso 9]>
									</td>
									</tr>
									</table>
									<![endif]-->
                            </td>
                        </tr>
                    </table>
                    <!-- // END TEMPLATE -->
                </td>
            </tr>
        </table>
    </center>
</body>

</html>