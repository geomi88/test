<table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnImageBlock" style="min-width:100%;">
	<tbody class="mcnImageBlockOuter">
		<tr>
			<td valign="top" style="padding:9px" class="mcnImageBlockInner">
				<table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="mcnImageContentContainer" style="min-width:100%;">
					<tbody>
						<tr>
							<td class="mcnImageContent" valign="top" style="padding-right: 9px; padding-left: 9px; padding-top: 0; padding-bottom: 0; text-align:center;">


								<img align="center"  alt="" src="{{ asset('assets/frontend/dist/images/email-template.jpg') }}" width="564" style="max-width:600px; padding-bottom: 0; display: inline !important; vertical-align: bottom;" class="mcnImage banner" />


							</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
	</tbody>
</table>