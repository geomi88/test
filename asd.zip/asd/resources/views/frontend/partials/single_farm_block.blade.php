@foreach($farmList as $farm)
<div class="swiper-slide">
 <div class="grid">
    <div class="block_">

       <div class="top_block">
          <a href="micro_farm.html" class="block_link"></a>
          <div class="top_box">
             <div class="user_ tooltip-bottom"  title="{{$farm->owner->user_full_name}}">
                <a href="owner_profile.html">
                   <div class="img b-lazy" data-src="{{get_profile_image($farm->owner->user_avatar)}}" ></div>
                </a>
             </div>
             <div class="share_">
                <div class="icon icon-graphics-icon-share" ></div>
             </div>
          </div>
          <div class="social_share">
                <ul>
                  <li><a href="#" class="social_icon"><div class="icon icon-social-facebook"></div></a></li>
                  <li><a href="#" class="social_icon"><div class="icon icon-social-google"></div></a></li>
                  <li><a href="#" class="social_icon"><div class="icon icon-social-twitter"></div></a></li>
                </ul>
          </div>
          <div class="crop_details_box">
             <div class="crop_icon">
                <img  class="img_auto source_" /> 
             </div>
             <div class="crop_text_"></div>
          </div>
          <div class="bottom_box">
             <div class="location_">
                <div class="icon icon-graphics-icon-location-03"></div>
                <div class="text_">{{$farm->fm_state_name}}</div>
             </div>
             <div class="crops_box w_slick" data-crop-slider='true'>
               @foreach($farm->crops as $farm_crop)
               <div class="crop_">
                  <a href="#" class="inner_ mg-tooltip" data-title="{{ $farm_crop->agriculture_title }}">
                     <img src="{{ asset('storage/uploads/agriculture/icon/'.$farm_crop->agriculture_icon) }}" />
                  </a>
               </div>
               @endforeach
               

            </div>
          </div>
          <div class="img b-lazy resourceBig" data-src="{{ asset('storage/uploads/farm/image/'.$farm->fm_main_image) }}"></div>
       </div>
       <a href='{{url("$lang/farm/$farm->fm_slug")}}' class="details_box">
         <div class="info_box">
            <div class="f_name">{{ $farm->fm_title }}</div>
            <div class="f_area">{{ $farm->fm_area }} {{ $farm->fm_area_unit }}</div>
         </div>
         <div class="amount_box">
            <div class="currency">$</div>
            <div class="amount_">
               <span>{{ $farm->fm_price }}</span>
               <span class="small_">per month</span>
            </div>
         </div>
      </a>
    </div>
 </div>
</div>
@endforeach