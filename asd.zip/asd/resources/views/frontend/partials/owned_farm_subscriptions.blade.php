@if(!empty($farmSubscriptions))
@foreach($farmSubscriptions as $subsDetails)
@php 
$farm = $subsDetails->getOwnedFarmDetails;
@endphp
<aside class="in_block small_padd grid-wrap farms_status_list " data-listing="true">
    <div class="sub-title ">{{ $farm->fm_title }}</div>
    <div class="grid wide_grid">
        <div class="block_">
            <div class="top_block">
                <a href='{{url("$lang/farm/$farm->fm_slug")}}' class="block_link"></a>
                <div class="top_box">

                    <div class="watchlive">
                        <a href="#">
                            <div class="icon icon-graphics-icon-farmlive">
                                <div class="circle_wrapper">
                                    <span class="circle_"></span>
                                    <span class="circle_"></span>
                                    <span class="circle_"></span>
                                    <span class="circle_"></span>

                                </div>

                            </div>
                        </a>

                    </div>
                </div>

                <div class="crop_details_box">
                    <div class="crop_icon">
                        <img class="img_auto source_" />
                    </div>
                    <div class="crop_text_"></div>
                </div>
                <div class="bottom_box">
                    <div class="location_">
                        <div class="icon icon-graphics-icon-location-03"></div>
                        <div class="text_">{{ $farm->fm_state_name }}</div>
                    </div>
                    @if($subsDetails->subscribed_crops->count() > 3)
                        <div class="crops_box w_slick" data-crop-slider='true'>
                    @else
                        <div class="crops_box">
                    @endif
                            @foreach($subsDetails->subscribed_crops as $farm_crop)
                            <div class="crop_">
                                <a href="#" class="inner_ mg-tooltip" data-title="{{ $farm_crop->single_crop->agriculture_title }}">
                                    <img src="{{ get_crop_image($farm_crop->single_crop->agriculture_icon) }}" />
                                </a>
                            </div>
                            @endforeach


                        </div>
                </div>
                <div class="img b-lazy resourceBig" data-src="{{ get_farm_image($farm->fm_main_image) }}"></div>
            </div>
            @if($subsDetails->fs_change_loc_status == 1)
            <div class="delivery_location_">
                <div class="link_">
                    <div class="icon icon-graphics-icon-delivery"></div>
                    <div class="text_">@if(!empty($subsDetails->fs_delivery_full_name)) {{$subsDetails->fs_delivery_full_name}} @endif                        
                        @if(!empty($subsDetails->fs_delivery_address)), {{$subsDetails->fs_delivery_address}} @endif
                        @if(!empty($subsDetails->fs_delivery_city)), {{$subsDetails->fs_delivery_city}} @endif
                        @if(!empty($subsDetails->fs_delivery_zip))-{{$subsDetails->fs_delivery_zip}} @endif
                        @if(isset($subsDetails->deliveryCountry)), {{$subsDetails->deliveryCountry->country_name}} @endif
                    </div>
                </div>
                @if(!empty($subsDetails->fs_ph_no))
                <div class="contact_box">
                    <ul>
                        <li>
                            <div class="icon icon-ios-telephone-outline"></div>
                            <div class="text_">{{$subsDetails->fs_ph_no}}</div>
                        </li>
                        
                    </ul>
                </div>
                @endif
            </div>
            @else
            <div class="delivery_location_">
                <div class="link_">
                    <div class="icon icon-graphics-icon-delivery"></div>
                    <div class="text_">@if(!empty($subsDetails->subscriber_details->user_full_name)) {{$subsDetails->subscriber_details->user_full_name}} @endif                        
                        @if(!empty($subsDetails->subscriber_details->user_address)), {{$subsDetails->subscriber_details->user_address}} @endif
                        @if(isset($subsDetails->subscriber_details->userNationality)), {{$subsDetails->subscriber_details->userNationality->country_name}} @endif
                    </div>
                </div>
                @if(!empty($subsDetails->subscriber_details->user_phone_number))
                <div class="contact_box">
                    <ul>
                        <li>
                            <div class="icon icon-ios-telephone-outline"></div>
                            <div class="text_">{{$subsDetails->subscriber_details->user_phone_number}}</div>
                        </li>
                        
                    </ul>
                </div>
                @endif
            </div>
            @endif
        </div>
            

        <div class="crop_details_list">
            <div class="status_details_box">
                <div class="item_">
                    <div class="icon icon-graphics-icon-soil-70"></div>
                    <div class="text_">{{ $subsDetails->subscribed_crops->count() }}  {{trans_choice('messages.crops_pl', $subsDetails->subscribed_crops->count())}}</div>
                </div>
                <!-- <div class="item_">
                    <div class="icon icon-graphics-icon-trade-1"></div>
                    <div class="text_">0 Livestocks</div>
                </div> -->

            </div>

            <div class="d_row_wrapper">
                <div class="d_row">
                    <div class="d_h">Subscriber :</div>
                    <div class="d_c">{{ $subsDetails->subscriber_details->user_full_name }}</div>

                </div>
                <div class="d_row">
                    <div class="d_h">Start Date :</div>
                    <div class="d_c">{{date_convert($subsDetails->fs_start_date)}}</div>
                </div>
                <div class="d_row">
                    @php $expiry_date = date('Y-m-d', strtotime("+$subsDetails->fs_duration_months months", strtotime($subsDetails->fs_start_date))); @endphp
                    <div class="d_h">Expiry Date :</div>
                    <div class="d_c">{{date_convert($expiry_date)}}</div>
                </div>
                <div class="d_row">
                    <div class="d_h">Total Duration :</div>
                    <div class="d_c">{{$subsDetails->fs_duration_months}} {{trans_choice('messages.months_pl', $subsDetails->fs_duration_months)}}</div>
                </div>
                <div class="d_row">
                    <div class="d_h">Number of Plots :</div>
                    <div class="d_c">{{$subsDetails->fs_number_of_plots}}</div>
                </div>
                <div class="d_row">
                    <div class="d_h">Total Price :</div>
                    <div class="d_c"><span class="text-red">$ {{$subsDetails->fs_total_amount}}</span> <small class="text-gray">(${{ $farm->fm_price }} per month)</small></div>
                </div>


            </div>
            <div class="footer_">
                <!-- <a href="mailto:{{$subsDetails->subscriber_details->user_email}}" class="link_"> -->
                <a href='{{url("$lang/farm-owner/$subsDetails->fs_user_id")}}' class="link_">
                    <span>Contact subscriber</span>
                    <div class="icon_">
                        <img class="img_auto" src="{{htmlAsset('images/icon-chat.svg')}}" />
                    </div>
                </a>
            </div>
        </div>

</aside>

@endforeach

@else
@include('frontend.partials.no_results', ['message' => "No subscribers Found"])
@endif