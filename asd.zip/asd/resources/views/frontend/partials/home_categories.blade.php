<section class="home-section howitwrks fade-in-Up" id="howitwrks">
   <div class="container">
      <h3 class="section-title text-center line_b">
         <span>{{ lang('select_monitor_enjoy') }}</span>
         <span>{{ lang('farms_anywhere_world') }}</span>
      </h3>
      <div class="row">
         <div class="col-sm-12">
            <div class="intro_wrapper">
               <div class="intro_ bg-pink">
                  <div class="link_">
                     <div class="inner_ text-center">
                        <div class="head_box">
                           <div class="image_box">
                              <img src="{{ htmlAsset('images/icon-farms.svg') }}" class="img_auto" />
                           </div>
                           <div class="title">{{ lang('farms') }}</div>
                        </div>
                        <div class="hover_info">
                           <p>{!! lang('farms_message') !!}</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="intro_ bg-gray">
                  <div class="link_">
                     <div class="inner_ text-center">
                        <div class="head_box">
                           <div class="image_box">
                              <img src="{{ htmlAsset('images/icon-metrofarms.svg') }}" class="img_auto" />
                           </div>

                           <div class="title">{{ lang('metro-farms') }}</div>

                        </div>

                        <div class="hover_info">
                           <p>{!! lang('metro_farms_message') !!}</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="intro_ bg-orange">
                  <div class="link_">
                     <div class="inner_ text-center">
                        <div class="head_box">
                           <div class="image_box">
                              <img src="{{ htmlAsset('images/icon-farm_experience.svg') }}" class="img_auto" />
                           </div>

                           <div class="title">{{ lang('farms_experience') }}</div>

                        </div>

                        <div class="hover_info">
                           <p>{!! lang('farm_experience_message') !!}</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="intro_ bg-blue">
                  <div class="link_">
                     <div class="inner_ text-center">
                        <div class="head_box">
                           <div class="image_box">
                              <img src="{{ htmlAsset('images/icon-farm_stays.svg') }}" class="img_auto" />
                           </div>

                           <div class="title">{{ lang('farms_stays') }}</div>

                        </div>

                        <div class="hover_info">
                           <p>{!! lang('farms_stay_message') !!}</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>