<div class="formv2">
    
    {!! Form::open(['method' => 'POST', 'url' => url("$lang/user/settings" ), 'id'=>'user-settings','files'=>true] ) !!}
    <div class="aj_loader" id="u_settings_loader">
        <div class="loader_wrapper">
        <div class="shape shape1"></div>
        <div class="shape shape2"></div>
        <div class="shape shape3"></div>
        <div class="shape shape4"></div>
        </div>

        <div class="msg" id="u_settings_success_msg">
        </div>
    </div>
      <div class="input-group">
         <div class="input-box edit-profile-photo">
         
             <div class="avatar_info box">  
               <div class="av_img">
                 <div class="img_ b-lazy b-loaded" style="background-image: url({{get_profile_image(@$userDetails->user_avatar)}});"></div>
               </div>

               <div class="change-photo-btn">
                 
                      <i class="icon icon-icon-login"></i>
                      <input type="file" class="upload" name="avatar" id="avatar" onchange="profilereadURL(this);"/>
                 
                </div>

             </div>                          
                                                                  
                <label for="avatar" class="cursor_pointer">{!! lang('change_profile_pic') !!}</label>
                                                                                                
        </div>
        
      </div>

       <div class="input-group">
         <div class="input-box">
            <label for="uname">{!! lang('name') !!}</label>
            <input class="form-control" type="text" value="{{@$userDetails->user_full_name}}" name="full_name" id="full_name">                                                                      
        </div>
        <div class="input-box">
            <label for="phone">{!! lang('phone_number') !!}</label>
            <input class="form-control" type="text" value="{{@$userDetails->user_phone_number}}" name="u_phone" id="u_phone">                                                                          
        </div>
      </div>

      <div class="input-group">
         <div class="input-box">
               <label for="country_id">{!! lang('country') !!}</label>
               <div class="select-box-wrap select-border">
                  <select class="select_" name="country_id" id="country_id">
                     <option label="blank" value="">Select your country</option>
                     @if(!empty($countryList))
                        @foreach($countryList as $country)
                            <option {{ ($country->country_id == @$userDetails->user_nationality)?' selected="selected"':'' }} value="{{ $country->country_id }}">{{ $country->country_name }}</option>
                        @endforeach
                    @endif
                  </select>
               </div>
        </div>
        
        <div class="input-box">
            <label for="address">{!! lang('address') !!}</label>
            <textarea class="form-control" name="address" id="address">{{@$userDetails->user_address}}</textarea>       
                                                                       
        </div>
      </div>
      <div class="input-group">
         <div class="input-box full_">
            <label for="describe">{!! lang('describe_yourself') !!}</label>
            <textarea class="form-control" name="describe" id="describe">{{@$userDetails->user_description}}</textarea>       
                                                                       
        </div>
        
      </div>

      <div class="btn_wrapper text-right with_link ">         
        <a href='{{url("$lang/user/change-password")}}' class="link_ skip_button">{!! lang('change_password') !!} ?</a>           
        <button type="submit" class="btn-style2 ">Save</button>
      </div>
      
    {{ Form::close() }}
 </div>