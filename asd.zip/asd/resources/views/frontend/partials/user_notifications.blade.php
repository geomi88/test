<ul>
@foreach($notifications as $notification)
@php 
$read_status = ($notification->un_read_status == 0)?'unread':'';

if($notification->un_type == 1)
{
    $title = "Your Farm Subscribed";
    $message = $notification->fromuserDetails->user_full_name." has subscribed your farm ".$notification->farmDetails->fm_title;   
    $link = url("$lang/user/owned-farm-subscriptions"); 
}

if($notification->un_type == 2)
{
    $title = "Farm Favorited";
    $message = $notification->fromuserDetails->user_full_name." has favorited your farm ".$notification->farmDetails->fm_title; 
    $link = url("$lang/farm-owner/$notification->un_from_user_id");    
}

if($notification->un_type == 3)
{
    $title = "Farm Reviewed";
    $message = $notification->fromuserDetails->user_full_name." has reviewed your farm ".$notification->farmDetails->fm_title;    
    $link = url("$lang/user/reviews"); 
}
@endphp
    <li class="{{$read_status}}">

        <div class="message-title">
            <a href='javascript:void(0);'>
                <h3>{{$title}}</h3>
            </a>
        </div>
        <div class="message-content">

            <div class="message-body">
                <a href='{{$link}}'>
                    <p><span class="message-by-headline">{{date_format($notification->un_created_at,"d-m-Y h:i:s A")}}</span>{{$message}}</p>
                </a>
            </div>
            <div class="btn_wrapper text-center">

                <a href="{{ url('user/delete_notification/'.$notification->un_id) }}" data-not_id="{{$notification->un_id}}" class="btn-style3 " onclick="return confirm('Are you sure?')">
                    <div class="icon icon-ios-trash-outline"></div><span>Delete</span>
                </a>
            </div>
        </div>

    </li>
@endforeach   
</ul>