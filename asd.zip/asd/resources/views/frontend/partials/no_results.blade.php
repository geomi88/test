<div class="no-result"> 
<h3>{{$message}}</h3>
</div>