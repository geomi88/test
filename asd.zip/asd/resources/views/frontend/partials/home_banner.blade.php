<section class="banner" id="banner">
	<div class="container-fluid">
		<div class="banner_slider_">
           @if(!empty($categoryList))
                @foreach($categoryList as $category)
                   <div class="slide_">
                      <div class="bg_" style="background-image: url('{{asset('storage/uploads/category/image/'.$category->category_image)}}')"></div>
                   </div>        
                @endforeach
           @endif
		</div>
        
		<div class="search_box">
			<div class="head_"><span>{{ lang('start_your_farm') }}</span></div>
			<div class="sub_text">{!! lang('online_farm_slogan') !!}</div>
			<div class="s_container">
				<div class="tab_">                       
				   <?php 
                        $i = 1;
                        $data_index = 0;
                   ?>
                    @if(!empty($categoryList))
                        @foreach($categoryList as $category)
                        
                            <label data-source="c2" id ="tabid-{{$i++}}" data-index="{{$data_index}}" data-ft="{{ $category->category_slug }}" @if ($loop->first) class="current tabcat" @else class="tabcat" @endif ><span>{{ $category->category_title }}</span></label>
                            @php $data_index++; @endphp
                        @endforeach
                    @endif
                    
				</div>                   
				<div class="content-container">
				  <div class="content" id="c2">
					 @include('frontend.partials.search')
				  </div>
				</div>
			</div>
		</div>
   </div>
</section>
@section('scripts')
@parent
 
<script>
	$(document).ready(function(){
        
        var cat_id = $('#tabid-1').data('ft');
        $('#ft').val(cat_id);
        $(".tabcat").on("click", function(){
            var cat_id = $(this).data('ft');
            $('#ft').val(cat_id);
        });
    });
</script>
@stop