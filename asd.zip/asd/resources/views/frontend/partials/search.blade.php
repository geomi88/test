{{ Form::open(['method' => 'GET', 'url' => asset($lang.'/search') , 'id'=>'search-form']) }}
	<div class="search_input">
		  <div class="icon_"><div  class="icon icon-graphics-icon-search"></div></div>
	   <div class="input_box">
		  <input class="form_control auto_search_key" type="text" name="search_key" value="" placeholder="" autocomplete="off">
		  <span class="auto_suggest_width"></span>
          <input type="hidden" name="ft" id="ft"  value="" placeholder="">
	   </div>
	   <div class="floating_suggestion_wrapper">
		   <ul class="auto_suggest_options">
			   
		   </ul>

	   </div>  
	</div>
	<div class="btn_wrapper">
	   <button type="submit" class="btn btn-medium btn-fill">{{ lang('search') }}</button> <a href="{!! url($lang.'/how-it-works'); !!}" class="link_">{{ lang('how_it_works') }}</a>
	</div>
{{ Form::close() }}