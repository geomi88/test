@foreach($farmList as $farm)
<div class="grid">
    <div class="block_ edit_ @if($farm->fm_status ==2) approval_pending @endif">

       <div class="top_block">
          <a href='{{url("$lang/farm/$farm->fm_slug")}}' class="block_link"></a>
          <div class="top_box">
             <div class="user_ tooltip-bottom"  title="{{$farm->owner->user_full_name}}">
                <a href='{{url("$lang/farm-owner/$farm->fm_owner_id")}}''>
                   <div class="img b-lazy" data-src="{{get_profile_image($farm->owner->user_avatar)}}" ></div>
                </a>
             </div>
             <div class="share_">
                <div class="icon icon-graphics-icon-share" ></div>
             </div>
          </div>
          @php
            $share_url = urlencode(url("$lang/farm/$farm->fm_slug"));
          @endphp
          @include('frontend.partials.farm_social_share')
          <div class="crop_details_box">
             <div class="crop_icon">
                <img  class="img_auto source_" /> 
             </div>
             <div class="crop_text_"></div>
          </div>
          <div class="bottom_box">
             <div class="location_">
                <div class="icon icon-graphics-icon-location-03"></div>
                <div class="text_">{{$farm->fm_state_name}}</div>
             </div>
             @if($farm->crops->count() > 3)
                <div class="crops_box w_slick" data-crop-slider='true'>
             @else
                <div class="crops_box">
             @endif
               @foreach($farm->crops as $farm_crop)
               <div class="crop_">
                  <a href="#" class="inner_ mg-tooltip" data-title="{{ $farm_crop->agriculture_title }}">
                     <img src="{{ get_crop_image($farm_crop->agriculture_icon) }}" />
                  </a>
               </div>
               @endforeach
               

            </div>
          </div>
          <div class="img b-lazy resourceBig" data-src="{{ get_farm_image($farm->fm_main_image) }}"></div>
       </div>
       <div class="details_box">
         <a href='{{url("$lang/farm/$farm->fm_slug")}}' class="info_box">
            <div class="f_name">{{ $farm->fm_title }}</div>
            <div class="f_area">{{ toAcre($farm->fm_area,$farm->fm_area_unit)  }}</div>
         </a>
         <!--<div class="amount_box">
            <div class="currency">$</div>
            <div class="amount_">
               <span>{{ $farm->fm_price }}</span>
               <span class="small_">per month</span>
            </div>
         </div>-->
         <div class="tool_box">
            <a href='{{url("$lang/farm-edit/$farm->fm_uuid")}}' class="r_btn"><i class="icon icon-android-create"></i> Edit</a>
            <!-- <a href='{{ url("$lang/farm-disable/$farm->fm_uuid/$farm->fm_disable_status") }}' class="r_btn r_edit"><i class="icon icon-android-delete"></i> Delete</a>-->
            @if($farm->fm_status ==1)
            <div class="switch" data-fmid="{{$farm->fm_id}}" title="@if($farm->fm_disable_status) Inactive @else Active @endif">
               <label>
                  
                  <input type="checkbox" @if($farm->fm_disable_status)  @else checked @endif data-id="{{$farm->fm_id}}" name="disable_status" class="disable_status">
                  <span class="lever"></span>
                  
               </label>
            </div>
            @endif 
         </div>
      </div>
    </div>
</div>
@endforeach