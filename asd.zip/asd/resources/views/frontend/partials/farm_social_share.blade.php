<div class="social_share">
    <ul>
        <li><a href='https://www.facebook.com/sharer/sharer.php?u={{$share_url}}' target="_blank" class="social_icon">
                <div class="icon icon-social-facebook"></div>
            </a></li>
        <li><a href="https://plus.google.com/share?url={{$share_url}}" target="_blank" class="social_icon">
                <div class="icon icon-social-google"></div>
            </a></li>
        <li><a href="https://twitter.com/share?url={{$share_url}}" target="_blank" class="social_icon">
                <div class="icon icon-social-twitter"></div>
            </a></li>
    </ul>
</div>