@extends('frontend.layouts.master')
@section('content')
<main class="inner_body">
   <section class="page-section inner-section container-banner"> 
      <div class="container">
        
         <img class="img_auto " src="{{ htmlAsset('images/how_it_work_banner.jpg') }}" />

         <div class="banner_text "><span>{{ lang('welcome_to') }}</span><span>Farm’sGate</span></div>
      </div>
      
   </section>

   <section class="page-section inner-section search-section"> 
      <div class="container">
         <div class="row">
            <div class="col-md-4">
               <div class="section_side_box">
                  <img class="pin_locate" src="{{ htmlAsset('images/icon-location-fill.svg') }}" />
                  <div class="img_ b-lazy" data-src="{{ htmlAsset('images/search_side_banner.jpg') }}" ></div>
               </div>
            </div>

            <div class="col-md-8 padding_l_2">
               <div class="title_wrapper">
                  <div class="section_title with_line line_r">
                     <span>{{ lang('search') }} & </span>
                     <span>{{ lang('select') }}</span>
                  </div>
               </div>

               <div class="sub_title">{{ lang('farm_of_your_choice') }}</div>

               <div class="farms_choice_wrapper">

                  <div class="choice_">
                     <div class="icon_">
                        <div class="icon icon-graphics-icon-location-03"></div>
                     </div>
                     <div class="title_">{{ lang('location') }}</div>
                     <div class="text_box">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed elementum feugiat dolor, id malesuada ligula blandit vel. </p>
                     </div>

                  </div>
                  <div class="choice_">
                     <div class="icon_">
                        <div class="icon icon-graphics-icon-crop"></div>
                     </div>
                     <div class="title_">{{ lang('crop') }}</div>
                     <div class="text_box">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed elementum feugiat dolor, id malesuada ligula blandit vel. </p>
                     </div>

                  </div>
                  <div class="choice_">
                     <div class="icon_">
                        <div class="icon icon-graphics-icon-price"></div>
                     </div>
                     <div class="title_">{{ lang('price') }}</div>
                     <div class="text_box">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed elementum feugiat dolor, id malesuada ligula blandit vel. </p>
                     </div>

                  </div>


               </div>

            </div>
         </div>
      </div>

   </section>
   <section class="page-section inner-section monitor-section"> 
      <div class="container">
         <div class="title_wrapper">
               <div class="section_title with_line line_l">
                  <span>{{ lang('monitor') }}</span>                
               </div>
            </div>
         <div class="row">
            <div class="col-md-6">
                  <div class="support_24">24<span>X</span>7</div>

                  <div class="support_info_wrap">
                        <div class="title_">{{ lang('part_of_it') }}</div>
                        <div class="text_box">
                              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed elementum feugiat dolor, id malesuada ligula blandit vel. </p>
                        </div>
                  </div>
            </div>
            <div class="col-md-6">

               <div class="monitor_wrapper">
                     <div class="monitor_ text-center">
                           <div class="image_box bg-gray">
                                 <div class="icon icon-graphics-icon-picture-video"></div>
                           </div>

                           <div class="title_">{{ lang('frequent_pictures_videos') }}</div>
                     </div>
                     <div class="monitor_ text-center">
                           <div class="image_box bg-blue">
                                 <div class="icon icon-graphics-icon-soil-70"></div>
                           </div>

                           <div class="title_">{{ lang('live_farm_datas') }}<span><small>{{ lang('soil_condition') }}</small></span></div>
                     </div>
                     <div class="monitor_ text-center">
                           <div class="image_box bg-orange">
                                 <div class="icon icon-graphics-icon-communicate"></div>
                           </div>

                           <div class="title_">{{ lang('communicate_with_farmers') }}<small>{{ lang('chat_email_review') }}</small></div>
                     </div>

               </div>

            </div>
         </div>
      </div>
   </section>

   <section class="page-section inner-section benefits-section"> 
      <div class="container">
         <div class="title_wrapper text-center">
            <div class="section_title with_line line_r">
               <span>{{ lang('enjoy_benefits') }}</span>                
            </div>
         </div>
         <div class="benefit_wrapper">
               <div class="colum_ colum_one">
                  <div class="benefit_">
                     <a href="#" class="inner_">
                           <div class="image_box stay_">
                              <span class="frame_"></span>
                              <div class="img_ b-lazy" data-src="{{ htmlAsset('images/benefit_img_1.jpg') }}" ></div>
                              <div class="over_title">{{ lang('stay') }}</div>
                           </div>
                           <div class="details_box">
                              <div class="icon icon-graphics-icon-stay"></div>
                              <div class="text_box">
                                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed elementum feugiat dolor, id malesuada ligula blandit vel. </p>
                              </div>
                           </div>
                     </a>
                  </div>

               </div>
               <div class="colum_ colum_two">
                     <div class="benefit_">
                        <a href="#" class="inner_">
                              <div class="image_box trade_">
                                 <span class="frame_"></span>
                                 <div class="img_ b-lazy" data-src="{{ htmlAsset('images/benefit_img_2.jpg') }}" ></div>
                                 <div class="over_title">{{ lang('trade') }}</div>
                              </div>
                              <div class="details_box">
                                 <div class="icon icon-graphics-icon-trade"></div>
                                 <div class="text_box">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed elementum feugiat dolor, id malesuada ligula blandit vel. </p>
                                 </div>
                              </div>
                        </a>
                     </div>
               </div>
               <div class="colum_ colum_three">
                     <div class="benefit_">
                     <a href="#" class="inner_">
                           <div class="image_box experience_">
                              <span class="frame_"></span>
                              <div class="img_ b-lazy" data-src="{{ htmlAsset('images/benefit_img_3.jpg') }}" ></div>
                              <div class="over_title">{{ lang('experience') }}</div>
                           </div>
                           <div class="details_box">
                              <div class="icon icon-graphics-icon-experience"></div>
                              <div class="text_box">
                                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed elementum feugiat dolor, id malesuada ligula blandit vel. </p>
                              </div>
                           </div>
                     </a>
                  </div>
               </div>

         </div>
         </div>
      </section>

</main>
@stop