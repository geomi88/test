@extends('frontend.layouts.master')
@section('content')
<main class="inner_body">
    <section class="page-section multi_form_page">
        <div class="container">
            <div class="section_title text-center lg_">Submit your feedback</div>
            <div class="row ">

                <div class="col-md-12 overflow-hidden in_block ">


                    <div id="add-review" class="add-review-box">
                    {!! Form::open(['method' => 'POST', 'url' => url('farm-review' ), 'id'=>'add-comment', 'class'=>'add-comment'] ) !!}
                        
                        <input type="hidden" name="rev_fm_id" id="rev_fm_id" value="{{$farmDetails->fm_id}}">
                        <div class="farm_grid_thum">
                            <div class="item_">
                                <a href="#" class="link_">
                                    <div class="img_box">
                                        <div class="img b-lazy" data-src="{{asset('storage/uploads/farm/image/small/'.$farmDetails->fm_main_image)}}"></div>
                                    </div>
                                    <div class="details_box">
                                        <h3>{{$farmDetails->fm_title}}</h3>
                                        <div class="text_box">
                                            <p>{{ lang('area') }}: {{ toAcre($farmDetails->fm_area,$farmDetails->fm_area_unit) }}</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>                       
                        

                        <div class="rating_toolbox">
                            <div class="tool_">
                                <span class="leave-rating-title">Your rating for this farm</span>
                                <!-- Leave Rating -->
                                <div class="leave-rating">
                                
                                    <input type="radio" name="rating" id="rating-5" value="5">
                                    <label for="rating-5" class="fa fa-star"></label>
                                    <input type="radio" name="rating" id="rating-4" value="4">
                                    <label for="rating-4" class="fa fa-star"></label>
                                    <input type="radio" name="rating" id="rating-3" value="3">
                                    <label for="rating-3" class="fa fa-star"></label>
                                    <input type="radio" name="rating" id="rating-2" value="2">
                                    <label for="rating-2" class="fa fa-star"></label>
                                    <input type="radio" name="rating" id="rating-1" value="1">
                                    <label for="rating-1" class="fa fa-star"></label>
                                                                            
                                    
                                </div>
                            </div>                            
                        </div>

                            <fieldset>

                                <div class="input-box-row">



                                    <div class="input-box full_">
                                        <label>Comments:</label>
                                        <textarea class="form-control" name="comment" id="comment" cols="40" rows="3"></textarea>
                                    </div>
                                </div>

                            </fieldset>

                            <button class="btn-style2">Submit Review</button>
                            <div class="aj_loader" id="comment_loader">
                                <div class="loader_wrapper">
                                    <div class="shape shape1"></div>
                                    <div class="shape shape2"></div>
                                    <div class="shape shape3"></div>
                                    <div class="shape shape4"></div>
                                </div>

                                <div class="msg" id="comment_success_msg">                
                                </div>
                            </div>
                            {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>

    </section>
    <div class="tooltip_templates">
        <div class="info-guide-popup" id="info-guide-1">
            <div class="head_">
                <div class="icon_">
                    <div class="icon icon-icons-initiative"></div>
                </div>
            </div>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed elementum feugiat dolor.
            </p>
        </div>
    </div>
</main>
@stop

@section('scripts')
@parent 
<script>
$(document).ready(function(){    
    $('#add-comment').validate({
        
        rules: {              
            'comment':{
                required:true
            },                    
        },
      submitHandler: function() {
            var _url = "{{ url('/api/farm-review') }}";
            var comment = $( "#comment" ).val();
            var rating = $('input[name=rating]:checked').val();
            if (!$("input[name='rating']:checked").val())
            {
                rating = 0;
            }
            var farm_id = $( "#rev_fm_id" ).val();
            var _data = {
                        '_token':'{{csrf_token()}}',
                        'comment':comment,
                        'farm_id':farm_id,
                        'rating':rating,
                        }
            
            sendAjax(_url,'post',_data, function(responseData){
                $( "#comment_loader" ).addClass('show_');
              if(!responseData.status){
                    $('.commonMessage').html(responseData.userMessage);
                }else{
                    if(responseData.redirectURL){
                        setTimeout(function() {
                        $( "#comment_success_msg" ).html('Your review has been added');
                        $( "#comment_success_msg" ).addClass('success');
                        $( "#comment_loader .loader_wrapper" ).addClass('hide_');
                        }, 1000);
                        setTimeout(function() {
                            window.location.href = "/{{$lang}}/home";
                        }, 2000);
                    }else{                
                        $('.commonMessage').html('<i class=" icon icon-success "></i> '+ responseData.message);
                    }
                    
                }  
            });
            return false;
        } 

    });
                  
});
</script>
   
@stop