@extends('frontend.layouts.master')
@section('styles')
@parent
{{ HTML::style('assets/frontend/uploader_tools/js/jquery.ui.plupload/css/jquery.ui.plupload.css') }}
@stop
@section('content')
@php
   $share_url = urlencode(url("$lang/farm/$farmDetails->fm_slug"));
@endphp


<main class="inner_body">
   <section class="banner-inner">
      
      <div class="container-fluid">
         <div class="image_grid">
         
            <div class="lg_grid">
               <a class="link_" data-fancybox="gallery" href="{{get_farm_large_image($farmDetails->fm_main_image)}}" data-thumb="{{get_farm_large_image($farmDetails->fm_main_image)}}">
                  <div class="img_ b-lazy" data-src="{{get_farm_large_image($farmDetails->fm_main_image)}}" ></div>
               </a>
            </div>
            @if(isset($farmDetails->gallery) && $farmDetails->gallery->count() > 0)   
            <div class="half_grid" data-gallery-count="{{$farmDetails->gallery->count()}}">                         
               @foreach($farmDetails->gallery->take(4) as $gallery)
               <div class="sm_grid">
                  <a  class="link_" data-fancybox="gallery" href="{{asset('storage/uploads/gallery/large/'.$gallery->gallery_image_name)}}" data-thumb="{{asset('storage/uploads/gallery/small/'.$gallery->gallery_image_name)}}">
                     <div class="img_ b-lazy" data-src="{{asset('storage/uploads/gallery/small/'.$gallery->gallery_image_name)}}" ></div>
                  </a>
               </div>
               @endforeach                                                  
            </div>
            <div class="galerry_box">
                @foreach($farmDetails->gallery->slice(4) as $gallery)
                  <a data-fancybox="gallery" href="{{asset('storage/uploads/gallery/large/'.$gallery->gallery_image_name)}}" data-thumb="{{asset('storage/uploads/gallery/small/'.$gallery->gallery_image_name)}}">
                     <div class="img_ b-lazy" data-src="{{asset('storage/uploads/gallery/small/'.$gallery->gallery_image_name)}}" ></div>
                  </a>
                @endforeach
            </div>
            @endif  
         </div>
      </div>
      <div class="container">
      <div class="breadcrumb_wrapper">
         <nav id="breadcrumbs">
            <ul>
               <li><a href='{{url("$lang/home")}}'>Home</a></li>                           
               <li><a href='{{url("$lang/search")}}'>Search list</a></li>                           
               <li>{{ $farmDetails->fm_title }}</li>
            </ul>
         </nav>
      </div>

         <div class="footer_tool">
            <ul>
               <li>
                  <div class="avatar_info box white_ small">
                        <a href='{{url("$lang/farm-owner/$farmDetails->fm_owner_id")}}' class="link_">
                           <div class="av_img">
                              <div class="img_ b-lazy" data-src="{{ get_profile_image($farmDetails->owner->user_avatar) }}" ></div>
                           </div>
                           <div class="details_box">
                              <div class="av_meta">{{ lang('managed_by') }}</div>
                              <div class="av_name">{{ $farmDetails->owner->user_full_name }}</div>                              
                           </div>
                          
                        </a>
                     </div>
               </li>
              
               <li>
                  <a href="#" class="live_view">
                     <div class="icon icon-graphics-icon-farmlive" ></div>
                     <span>{{ lang('live_view') }}</span> 
                  </a>
               </li>
               <li>
               <a href="#" class="share_ tooltip-top"  data-tooltip-content="#share_1" data-class="social_tooltip">
                     <div class="icon icon-graphics-icon-share" ></div>
                  </a>
               </li>
               <li>
                  <div class="bookmark_ @if($farmDetails->isFav) booked_ @endif" id="farm_fav">
                     <div class="icon icon-graphics-icon-fav"></div>
                  </div>
               </li>
               <li>
                  <div class="star_rate">
                     <!--<select data-star="true" @if($farmDetails->reviews->count()) data-current-rating="{{$farmDetails->reviews->sum('fr_rating')/$farmDetails->reviews->count()}}" @else data-current-rating="0" @endif >
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                     </select>-->
                     @php
                         $rating_val = 0;
                         if($farmDetails->reviews->count())
                         {
                            $rating_val = $farmDetails->reviews->sum('fr_rating')/$farmDetails->reviews->count();
                         }
                         if(!is_int($rating_val)){
                            $rating_val = number_format($rating_val, 1, '.', '');
                         }
                     @endphp
                     <div class="star-rating" data-s-rating='true' data-rating="{{$rating_val}}">						
                        <span class="star"></span>
                        <span class="star"></span>
                        <span class="star"></span>
                        <span class="star"></span>
                        <span class="star"></span>
                     </div>
                     <div class="count_">{{ (isset($farmDetails->reviews))?$farmDetails->reviews->count():0 }}</div>
                  </div>
               </li>
                <li><a href="#" class="btn-style1 gal-link"><span>{{ lang('gallery') }}</span></a></li>
            </ul>
         </div>
      </div>
   </section>
   <section class="page-section farm_details macro_farm">
      <div class="container">
      <div class="row sticky-sidebar-parent">
         <div class="col-lg-12 col-xl-7 content_area">
            <article id="header" class="farm_header">
               <div class="top_line">
                  <div class="section_title">{{ $farmDetails->fm_title }}</div>
                  <div class="avatar_info">
                     <div class="link_">
                        <div class="details_box">
                           @if(!empty($farmDetails->fm_price))<div class="av_name">$ {{ $farmDetails->fm_price }}/month</div>@endif
                           @if($farmDetails->crops->count()>0)<div class="av_meta">{{ lang('maximum') }} {{ $farmDetails->crops->count() }} {{ lang('crops_in_a_plot') }}</div>@endif
                        </div>                     
                     </div>
                  </div>
               </div>
               <div class="location_">
                  <a href="#" class="link_">
                     <div class="icon icon-graphics-icon-location-03"></div>
                     <div class="text_">@if(!empty($farmDetails->fm_city)){{ $farmDetails->fm_city }},@endif @if(!empty($farmDetails->fm_state_name)){{ $farmDetails->fm_state_name }}@endif</div>
                  </a>
               </div>
               <div class="land_details">
                  <div class="land_points">
                     <ul>
                     @if(!empty($farmDetails->fm_area))
                        <li>
                           <div class="points_">
                              <a href="#" class="link_">
                                 <div class="icon_">
                                    <div class="icon icon-graphics-icon-area-microfarm"></div>
                                 </div>
                                 <span >{{ lang('area') }}: {{ toAcre($farmDetails->fm_area,$farmDetails->fm_area_unit) }}</span>
                              </a>
                           </div>
                        </li>
                     @endif
                     @if(!empty($farmDetails->fm_plots_no))   
                        <li>
                           <div class="points_">
                              <a href="#" class="link_">
                                 <div class="icon_">
                                    <div data-icon="%" class="icon"></div>
                                 </div>
                                 <span >{{ lang('plot') }}: {{ $farmDetails->fm_plots_no }}</span>
                              </a>
                           </div>
                        </li>
                     @endif   
                        <li>
                           <div class="points_">
                              <a href="#" class="link_">
                                 
                                 <span >{{ lang('farm_id') }}: FK {{ $farmDetails->fm_code }} </span>
                              </div>
                           </a>
                        </li>
                     </ul>
                  </div>
                 
               </div>
            </article>
            <!-- /article -->
			@if(isset($farmDetails->crops) && $farmDetails->crops->count() > 0)
				
				<aside class="in_block">
				   <div class="section_title">{{ lang('available_crops') }}</div>				   
				   <div class="crops_list_box m-top crop_hover">
						@foreach($farmDetails->crops as $farmCrop)	
							
							<div class="crop_" data-crop='{{ $farmCrop->agriculture_title }}'>
								<div class="link_">
									<div class="inner_">
									   <div class="img_box">
											@if(Storage::exists('public/uploads/agriculture/image/'.$farmCrop->agriculture_image))
												<img class="img_auto" src="{{ get_crop_image($farmCrop->agriculture_icon) }}"/>
											@else
												<img class="img_auto" src="{{ asset('assets/frontend/images/default_crop.svg') }}" />
											@endif										  
									   </div>
									   <div class="title_">{{ $farmCrop->agriculture_title }}</div>                                            
									   @if($farmCrop->pivot->fc_min_duration)<div class="meta_small"><span>{{ lang('min_duration') }}</span><span>{{ $farmCrop->pivot->fc_min_duration }} {{trans_choice('messages.months_pl', $farmCrop->pivot->fc_min_duration)}}</span></div>@endif
									</div>
								</div>
							</div>
						@endforeach
				   </div>
				  
				</aside>
			@endif
			
			@if(isset($farmDetails->facilities) && $farmDetails->facilities->count() > 0)
				<aside class="in_block">
				   <div class="section_title">{{ lang('facilities_available') }}</div>
				   <div class="facility_list_box sty_3">
					  <ul>
						@foreach($farmDetails->facilities as $facility)	 
							<li>
								<div class="facility_">
								   <a href="javacript:void(0);" class="link_ tooltip-top"  data-tooltip-content="#facility_{{ $facility->facility_id }}">
									  <div class="icon_">
										 <div class="icon icon-graphics-icon-{{ $facility->facility_slug }}"></div>
									  </div>
									  <span>{{ $facility->facility_title }}</span>
								   </a>
								</div>
							</li>
						 @endforeach						
					  </ul>
				   </div>
				</aside>
			@endif
			@if(!empty($farmDetails->fm_weather_report) || !empty($farmDetails->fm_annual_report) || !empty($farmDetails->fm_soil_report))
            <aside class="in_block">
               <div class="section_title">{{ lang('quick_facts') }}</div>
               <div class="row quickfacts_list_box ">
               @if(!empty($farmDetails->fm_weather_report))
					<div class="col-md-3 facts_ ">
						<a href="javascript:void(0);" class="link_ tooltip-top"  data-tooltip-content="#facts_1">
							<div class="icon_">
							   <div data-icon="<" class="icon"></div>
							</div>
							<span>{{ lang('weather_report') }}</span>
						</a>
					</div>
				  @endif
				  
				  @if(!empty($farmDetails->fm_soil_report))
					<div class="col-md-3 facts_ ">
					 <a href="javascript:void(0);" class="link_ tooltip-top"  data-tooltip-content="#facts_2">
						<div class="icon_">
						   <div data-icon="/" class="icon"></div>
						</div>
						<span>{{ lang('soil_report') }}</span>
					 </a>
					</div>
				  @endif
				  
				   @if(!empty($farmDetails->fm_annual_report))
					<div class="col-md-3 facts_ ">
						<a href="javascript:void(0);" class="link_ tooltip-top"  data-tooltip-content="#facts_3">
							<div class="icon_">
							   <div data-icon="&quot;" class="icon"></div>
							</div>
							<span>{{ lang('yearly_report') }}</span>
						</a>
					</div>
				   @endif
				   
					  <div class="col-md-3 facts_ ">
						 <a href="javascript:void(0);" class="link_ tooltip-top"  data-tooltip-content="#facts_4">
							<div class="icon_">
							   <div data-icon="9" class="icon"></div>
							</div>
							<span>Farm Live View</span>
						 </a>
					  </div>
				 
               </div>
               <div class="row">
                  <div class="col-md-12 text_box">
                     <p>{{ $farmDetails->fm_about_farm }}</p>
                  </div>
               </div>
            </aside>
         @endif

         @if($screen_width <= 1024 && Auth::user())	
            @if($farmDetails->fm_owner_id != Auth::user()->id)
            <aside class="in_block mobile_form">	 
               @if($farmDetails->plots_available > 0)                  
                  @include('frontend.farm.subscribe')
               @else
                  @include('frontend.farm.not_available')
               @endif
            </aside>      
            @endif
         @endif
         @if($farmDetails->reviews->count())
            <aside class="in_block">
                
                   <div class="section_title underline_ justify-content-between">
                      <div class="left_">
                         <div class="text-green text-lg_">{{ $rating_val }}</div>
                         <div class="text-gray text-sm_">/ 5</div>
                         <span>Rating</span>
                      </div>
                      <div class="text-sm_">{{ (isset($farmDetails->reviews))?$farmDetails->reviews->count():0 }} Reviews</div>
                   </div>
               
               <?php /*
               @if($farmDetails->reviews->count())
                   <div class="row rating_list_box">               
                      @foreach($farmDetails->reviews as $review)
                      <div class="col-md-12 rating_">
                         <div class="avatar_box">
                            <a href="owner_profile.html" class="link_">
                               <div class="img_ b-lazy" data-src="{{get_profile_image($review->owner->user_avatar)}}" ></div>
                            </a>
                         </div>
                         <div class="details_box">
                            <div class="title_">
                                {{$review->owner->user_full_name}}
                               <div class="badge">{{$review->fr_rating}}</div>
                            </div>
                            <div class="date_">{{date_convert($review->fr_created_at)}}</div>
                            
                            @if(strlen($review->fr_comment) > 340)
                            <div class="show-more" id="more_box_{{$review->fr_id}}">
                                <div class="text_box">
                                   <p>{{$review->fr_comment}} </p>
                                                                       
                                </div>
                            </div>
                            <a href="#" class="show-more-btn" data-more-title="Read More" data-less-title="Read Less" data-height="150" data-source="more_box_{{$review->fr_id}}"></a>
                            @else
                            <div class="text_box">
                               <p>{{$review->fr_comment}} </p>
                                                                   
                            </div>
                            @endif  
                         </div>
                      </div>
                      @endforeach                                 
                   </div>
                   <!--<div class="btn_wrapper m-top"> 
                      <a href="#" class="btn-style2">View all</a>
                   </div>-->
                   
               @endif  
                */?>
               
               
               <div class="clearfix"></div>
               @if($reviews->total() > 0)
               <div class="row rating_list_box" id="review_paginate">               
                   <div class="aj_loader" id="review_loader">
                        <div class="loader_wrapper">
                            <div class="shape shape1"></div>
                            <div class="shape shape2"></div>
                            <div class="shape shape3"></div>
                            <div class="shape shape4"></div>
                        </div>

                        <div class="msg" id="review_success_msg">                
                        </div>
                    </div>                      
               </div>    
               <?php /*<div class="row">
                  <div class="col-md-12">
                     <!-- Pagination -->
                     <div class="pagination-container margin-top-30">
                        <nav class="pagination">
                           <ul>
                           @php for($pn=1;$pn<=$reviews->lastPage();$pn++) {
                              $class_='';
                              if($pn === $reviews->currentPage()){
                                 $class_ ='current-page';
                              }
                              @endphp
                              <li><a href="javascript:void(0);" onclick="get_reviews({{$farmDetails->fm_id}},{{$pn}})" class="{{$class_}}">{{$pn}}</a></li>
                              
                           @php } @endphp   
                              <!--<li><a href="#"><i class="icon icon-ios-arrow-forward"></i></a></li>-->
                              
                              
                           </ul>
                        </nav>
                     </div>
                  </div>
               </div> */?>
               <div id="review_page_links"></div>
               @endif
               <div class="clearfix"></div>
               
               
               
              <?php /* ?> 
              <div id="add-review" class="add-review-box">
              {!! Form::open(['method' => 'POST', 'url' => url('farm-review' ), 'id'=>'add-comment', 'class'=>'add-comment'] ) !!}
                                          
              
                <div class="aj_loader" id="comment_loader">
                    <div class="loader_wrapper">
                        <div class="shape shape1"></div>
                        <div class="shape shape2"></div>
                        <div class="shape shape3"></div>
                        <div class="shape shape4"></div>
                    </div>

                    <div class="msg" id="comment_success_msg">                
                    </div>
                </div>                                          
              
              <input type="hidden" name="rev_fm_id" id="rev_fm_id" value="{{$farmDetails->fm_id}}">  
              <!-- Add Review -->
              <div class="section_title margin-bottom-20">Add Review</div>
              <!-- Rating / Upload Button -->
              <div class="rating_toolbox">
                <div class="tool_">
                  <span class="leave-rating-title">Your rating for this listing</span>
                  <!-- Leave Rating -->
                  <div class="leave-rating">
                  
                    <input type="radio" name="rating" id="rating-5" value="5">
                    <label for="rating-5" class="fa fa-star"></label>
                    <input type="radio" name="rating" id="rating-4" value="4">
                    <label for="rating-4" class="fa fa-star"></label>
                    <input type="radio" name="rating" id="rating-3" value="3">
                    <label for="rating-3" class="fa fa-star"></label>
                    <input type="radio" name="rating" id="rating-2" value="2">
                    <label for="rating-2" class="fa fa-star"></label>
                    <input type="radio" name="rating" id="rating-1" value="1">
                    <label for="rating-1" class="fa fa-star"></label>
                                                            
                    
                  </div>
                </div>
                
              </div>
              <!-- Review Comment -->
              
                <fieldset>

                  <div class="input-box-row">                    
                    <div class="input-box full_">
                      <label>Review:</label>
                      <textarea class="form-control" name="comment" id="comment" cols="40" rows="3"></textarea>
                    </div>
                  </div>

                </fieldset>

                <input type="submit" class="btn-style2" value="Submit Review">
                
               {{ Form::close() }}
            </div>
            */?>
            </aside>
         @endif   
			@if(!empty($farmDetails->fm_latitude) && !empty($farmDetails->fm_longitude))
				<aside class="in_block">
				   <div class="section_title">{{ lang('location_map') }}</div>
				   <div class="map_wrapper">
					  <div id="singleListingMap-container">
						 <div id="singleListingMap" 
						 data-latitude="{{ $farmDetails->fm_latitude }}" 
						 data-longitude="{{ $farmDetails->fm_longitude }}" 
						 data-map-icon="icon icon-graphics-icon-farmer"
						 ></div>
						 <a href="#" id="streetView">Street View</a>
					  </div>
				   </div>
				</aside>
			@endif
			@if(!empty($farmDetails->fm_policies))
            <aside class="in_block">
               <div class="section_title">{{ lang('policies') }}</div>
               <div class="text_box m-top">
                  <p>{{ $farmDetails->fm_policies }}</p>
               </div>
            </aside>
         @endif   
         </div>
         @if($screen_width > 1024 && Auth::user())	
            @if($farmDetails->fm_owner_id != Auth::user()->id)	 
               @if($farmDetails->plots_available > 0)                  
                  @include('frontend.farm.subscribe')
               @else
                  @include('frontend.farm.not_available')
               @endif   
            @endif
         @endif   
         </div>
      </div>
   </section>
   
   <div class="tooltip_templates">
      <div class="share_popup" id="share_1">
         <div class="social_share">
               <ul>
                  <li><a href='https://www.facebook.com/sharer/sharer.php?u={{$share_url}}' target="_blank" class="social_icon"><div class="icon icon-social-facebook"></div></a></li>
                  <li><a href="https://plus.google.com/share?url={{$share_url}}" target="_blank" class="social_icon"><div class="icon icon-social-google"></div></a></li>
                  <li><a href="https://twitter.com/share?url={{$share_url}}" target="_blank" class="social_icon"><div class="icon icon-social-twitter"></div></a></li>
               </ul>
         </div>
      </div>
   @if(isset($farmDetails->facilities) && $farmDetails->facilities->count() > 0)
      @foreach($farmDetails->facilities as $facility)
      <div class="facility_popup" id="facility_{{$facility->facility_id}}">
         <div class="head_">
            <div class="icon_">
               <div class="icon icon-graphics-icon-{{$facility->facility_slug}}"></div>
            </div>
            <span>{{$facility->facility_title}}</span> 
         </div>
         <p>      
            {{$facility->facility_exceprt}}
         </p>
      </div>
      @endforeach
      @endif
      
     
      <div class="facility_popup with_link" id="facts_1">
         <div class="head_">
            <div class="icon_">
               <div data-icon="<" class="icon"></div>
            </div>
            <span>Weather Report</span> 
         </div>
         <p class="text-center">      
            
         </p>
         <div class="btn_wrapper text-center"><a href='{{url("api/download/weather/$farmDetails->fm_id")}}' download class="btn-style1">Download</a></div>
      </div>
      <div class="facility_popup with_link" id="facts_2">
         <div class="head_">
            <div class="icon_">
              <div data-icon="/" class="icon"></div>
            </div>
            <span>Soil Report</span> 
         </div>
         <p class="text-center">      
            
         </p>
         <div class="btn_wrapper text-center"><a href='{{url("api/download/soil/$farmDetails->fm_id")}}' download class="btn-style1">Download</a></div>
      </div>
      <div class="facility_popup with_link" id="facts_3">
         <div class="head_">
            <div class="icon_">
              <div data-icon="&quot;" class="icon"></div>
            </div>
            <span>Yearly Report</span> 
         </div>
         <p class="text-center">      
            
         </p>
         <div class="btn_wrapper text-center"><a href='{{url("api/download/annual/$farmDetails->fm_id")}}' download class="btn-style1">Download</a></div>
      </div>
      <div class="facility_popup with_link" id="facts_4">
         <div class="head_">
            <div class="icon_">
              <div data-icon="9" class="icon"></div>
            </div>
            <span>Farm Live View</span> 
         </div>
         <p class="text-center">      
            
         </p>
         <div class="btn_wrapper text-center"><a href="javascript:void(0);" class="btn-style1">Read more</a></div>
      </div>
   </div>
   <input type="hidden" name="rev_fm_id" id="rev_fm_id" value="{{$farmDetails->fm_id}}">  
</main>
@stop
@section('scripts')
@parent 
<script type="text/javascript" src="{{ asset('assets/frontend/scripts/vendor/package/markerclusterer.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/frontend/scripts/vendor/package/maps.js') }}"></script> 
<script>
$(document).ready(function(){
    get_reviews(1);
    
            
    function get_reviews(page = 1){
        var farm_id = $('#rev_fm_id').val();
            var _data = {
                        '_token':'{{csrf_token()}}',
                        'farm_id':farm_id,
                        'page':page
                        }
										     
			sendAjax("{{ url('/api/farm_reviews') }}",'GET',_data,function(data){
                $( "#review_loader" ).addClass('show_');
                if(data.status){
                setTimeout(function() {
                    $( "#review_loader .loader_wrapper" ).addClass('hide_');
                }, 2000);           
                var review_data = '';
                var pagination_data = '';
                var toal_review_data = data.reviews;
                var reviews = data.reviews.data;
                
                $(reviews).each(function(review_key,review){
                    review_data += '<div class="col-md-12 rating_"><div class="avatar_box"><a href="javascript:void();" class="link_"><div class="img_ b-lazy" data-src="'+review.reviewer_avatar+'" ></div></a></div>';
                    review_data += '<div class="details_box"><div class="title_">'+review.reviewer_name+'<div class="badge">'+review.fr_rating+'</div></div><div class="date_">'+review.created_at+'</div>';
                            
                    if((review.fr_comment).length > 340){
                    review_data += '<div class="show-more" id="more_box_'+review.fr_id+'">'+
                                '<div class="text_box">'+
                                   '<p>'+review.fr_comment+'</p>'+
                                                                       
                                '</div>'+
                            '</div>'+
                            '<a href="javascript:void(0);" class="show-more-btn" data-more-title="Read More" data-less-title="Read Less" data-height="150" data-source="more_box_'+review.fr_id+'"></a>';
                    }else{
                            review_data += '<div class="text_box">'+
                               '<p>'+review.fr_comment+'</p>'+
                                                                   
                            '</div>';
                    } 
                         review_data += '</div>'+
                      '</div>';
                
                });
                  
                pagination_data +='';
                                   if(toal_review_data.last_page > 1) {
                                    pagination_data +='<div class="row">'+
                                      '<div class="col-md-12">'+
                                         '<div class="pagination-container margin-top-15 margin-bottom-40">'+
                                            '<nav class="pagination"><ul>';
                                               if(toal_review_data.current_page > 1){
                                                   pagination_data +='<li><a href="javascript:void(0);" onclick="get_reviews('+(parseInt(toal_review_data.current_page)-1)+');"><i class="fas fa-chevron-left"></i></a></li>';
                                               }
                                               for (var p=1;p<=toal_review_data.last_page;p++) {
                                                  
                                                if(p > (toal_review_data.last_page-1) && toal_review_data.current_page < (toal_review_data.last_page-3)  && toal_review_data.last_page > 5){
                                                   pagination_data +='<li>..</li>';  
                                                }

                                                  pagination_data +='<li><a href="javascript:void(0);" onclick="get_reviews('+p+');"';
                                                  var class_='';
                                                  if(p === toal_review_data.current_page){
                                                     class_ ='current-page';
                                                  }
                                                  pagination_data +='class='+class_+'>'+p+'</a></li>';
                                                  
                                                  if(p == 1 && toal_review_data.current_page > 4 ){
                                                   pagination_data +='<li>..</li>';  
                                                  }
                                               }
                                               if(toal_review_data.current_page < toal_review_data.last_page) {
                                                    pagination_data +='<li><a href="javascript:void(0);" onclick="get_reviews('+(parseInt(toal_review_data.current_page)+1)+');"><i class="fas fa-chevron-right"></i></a></li>';
                                               }
                                            pagination_data +='</ul></nav>'+
                                         '</div>'+
                                      '</div>'+
                                   '</div>';
                                   }  
                  
                $('#review_paginate').html(review_data);
                $('#review_page_links').html(pagination_data);
                bLazy.revalidate();
                FarmsGate_.mouse_click();
                }
            });
        }
    
    window.get_reviews=get_reviews;
    
    
    
    
    
    $('.subs_price').on('change', function() {
        
      var plots_no = $( "#plots_no option:selected" ).val();
      var subs_duration = $( "#subs_duration option:selected" ).val();
      var plot_price = {{$farmDetails->fm_price}};
      var total_price = '';
      $('.subs_price_section').hide();
      if(plots_no!='' && subs_duration!='' && plot_price!=''){
        total_price = parseFloat(plots_no)*parseFloat(subs_duration)*parseFloat(plot_price);
        $('#subs_total_price').html(total_price);
        $('.subs_price_section').show();
        $('#subs_total_months').html($( "#subs_duration option:selected" ).text());
      }
      
    });

    var GivenDate = '{{$farmDetails->fm_start_date}}';
    var CurrentDate = new Date();
    GivenDate = new Date(GivenDate);
    var fm_start_date = '{{$farmDetails->fm_start_date}}';
    if(CurrentDate > GivenDate){
      var fm_start_date = 0;

      var someDate = new Date();      
    }
    else{
      var someDate = GivenDate;
    }
   var numberOfDaysToAdd = 10;
   someDate.setDate(someDate.getDate() + numberOfDaysToAdd);

   var dd = someDate.getDate();
   var mm = someDate.getMonth() + 1;
   var y = someDate.getFullYear();

   var lastDate = y + '-'+ mm + '-'+ dd;


    var dateFormat =  "yy-mm-dd";
    $("#start_date").datepicker({
        dateFormat : dateFormat,
        changeMonth: true,
        changeYear: true,
        todayBtn:  1,
        autoclose: true,
        minDate:fm_start_date,
        //maxDate:'{{$farmDetails->fm_end_date}}',
        maxDate:lastDate,
        onSelect: function(date){
         $(this).valid();
         var _url = "{{ url('/api/get-plots-number') }}";
         var _data = {
                     '_token':'{{csrf_token()}}',
                     'selected_date':date,
                     'plot_farm_id':'{{$farmDetails->fm_id}}',
                     }
         
         sendAjax(_url,'post',_data, function(responseData){
            var date_plot_no = responseData.date_plot_no;
            var plots_options = '';
            plots_options += '<option label="blank" value="">Select Number of Plots</option>';
            for(var plo = 1;plo <= date_plot_no; plo++){
               plots_options += '<option value="'+plo+'">'+plo+'</option>';
            }
            $('#plots_no').html(plots_options);
            $('#plots_no').selectric('refresh');
         });
        }
    });
    
    $('#farm-subscribe').validate({		
        errorElement: 'span',
        errorPlacement: function(error, element) {
            error.insertBefore(element);
        },
        ignore: [],
        rules: {              
            'plots_no':{
                required:true
            }, 
            'subs_duration':{
                required:true,
            },
			   'start_date':{
				required:true,
            },
            'farm_type':{
                required:true,
            },
            'subs_crop[]':{
                required:true,
            },           
        },
        messages:{
            'subs_crop[]':{
                required:'Please select atleast one crop',
            },
            'start_date':{
                required:'Please select date',
            },
        },
      submitHandler: function() {
         $("#farm_subscribe_submit").attr('disabled', 'disabled');
            var _url = "{{ url('/api/farm-subscribe') }}";
            var plots_no = $( "#plots_no option:selected" ).val();
            var subs_duration = $( "#subs_duration option:selected" ).val();
            var farm_type = $( "#farm_type option:selected" ).val();
            var start_date = $( "#start_date" ).val();
            var farm_id = $( "#farm_id" ).val();
            var total_price = $('#subs_total_price').text();
            var subs_crop = [];
            $('.crops_arr:checked').each(function(i){
              subs_crop[i] = $(this).val();
            });

            var change_loc_status = $('#change_loc_status').val();
            var delivery_full_name = $('#delivery_full_name').val();
            var delivery_ph_no = $('#delivery_ph_no').val();
            var delivery_address = $('#delivery_address').val();
            var delivery_country_id = $('#delivery_country_id').val();
            var delivery_city = $('#delivery_city').val();
            var delivery_zip = $('#delivery_zip').val();
            var home_delivery = $('#home_delivery:checked').val()?1:0;



            var _data = {
                        '_token':'{{csrf_token()}}',
                        'subs_crop':subs_crop,
                        'farm_id':farm_id,
                        'plots_no':plots_no,
                        'subs_duration':subs_duration,
                        'farm_type':farm_type,
                        'start_date':start_date,
                        'total_price':total_price,
                        'change_loc_status':change_loc_status,
                        'delivery_full_name':delivery_full_name,
                        'delivery_ph_no':delivery_ph_no,
                        'delivery_address':delivery_address,
                        'delivery_country_id':delivery_country_id,
                        'delivery_city':delivery_city,
                        'delivery_zip':delivery_zip,
                        'home_delivery':home_delivery
                        }
            
            sendAjax(_url,'post',_data, function(responseData){
            $( "#subscribe_loader" ).addClass('show_');
              if(!responseData.status){
                    //$('.commonMessage').html(responseData.userMessage);
                  setTimeout(function() {
                        $( "#subscribe_success_msg" ).html(responseData.userMessage);
                        $( "#subscribe_success_msg" ).addClass('error');
                        $( "#subscribe_loader .loader_wrapper" ).addClass('hide_');
                        }, 1000);
                  setTimeout(function() {
                        $( "#subscribe_loader" ).removeClass('show_');
                        $( "#subscribe_success_msg" ).html('');
                        $( "#subscribe_success_msg" ).removeClass('error');
                        $( "#subscribe_loader .loader_wrapper" ).removeClass('hide_');
                        }, 4000);
                  if(responseData.redirectURL){
                        setTimeout(function() {
                              window.location.reload();
                           }, 5000);
                  }      
                }else{
                    if(responseData.redirectURL){
                        setTimeout(function() {
                        $( "#subscribe_success_msg" ).html('You have successfully subscribed');
                        $( "#subscribe_success_msg" ).addClass('success');
                        $( "#subscribe_loader .loader_wrapper" ).addClass('hide_');
                        }, 1000);
                        setTimeout(function() {
                            window.location.reload();
                        }, 2000);
                    }else{                
                        $('.commonMessage').html('<i class=" icon icon-success "></i> '+ responseData.message);
                    }
                    
                }  
            });
            return false;
        } 

    });
    
    $('#add-comment').validate({
        
        rules: {              
            'comment':{
                required:true
            },                    
        },
      submitHandler: function() {
            var _url = "{{ url('/api/farm-review') }}";
            var comment = $( "#comment" ).val();
            var rating = $('input[name=rating]:checked').val();
            if (!$("input[name='rating']:checked").val())
            {
                rating = 0;
            }
            var farm_id = $( "#rev_fm_id" ).val();
            var _data = {
                        '_token':'{{csrf_token()}}',
                        'comment':comment,
                        'farm_id':farm_id,
                        'rating':rating,
                        }
            
            sendAjax(_url,'post',_data, function(responseData){
                $( "#comment_loader" ).addClass('show_');
              if(!responseData.status){
                    $('.commonMessage').html(responseData.userMessage);
                }else{
                    if(responseData.redirectURL){
                        setTimeout(function() {
                        $( "#comment_success_msg" ).html('Your review has been added');
                        $( "#comment_success_msg" ).addClass('success');
                        $( "#comment_loader .loader_wrapper" ).addClass('hide_');
                        }, 1000);
                        setTimeout(function() {
                            window.location.reload();
                        }, 2000);
                    }else{                
                        $('.commonMessage').html('<i class=" icon icon-success "></i> '+ responseData.message);
                    }
                    
                }  
            });
            return false;
        } 

    });
    
    $('#farm_fav').on('click', function() {
        
        var _url = "{{ url('/api/farm-fav') }}";        
        var farm_id = $( "#rev_fm_id" ).val();
        var _data = {
                    '_token':'{{csrf_token()}}',
                    'farm_id':farm_id,
                    }
        
        sendAjax(_url,'post',_data, function(responseData){
          if(!responseData.status){
                $('.commonMessage').html(responseData.userMessage);
            }else{
                if(responseData.status){
                    
                }else{                
                    $('.commonMessage').html('<i class=" icon icon-success "></i> '+ responseData.message);
                }
                
            }  
        });
        return false;
      
    });
    $('[data-fancybox="gallery"]').fancybox({
        margin : [44,0,22,0],
        thumbs : {
            autoStart : true,
            axis      : 'x'
        }
    });
       
    $('.gal-link').on('click', function(e){
        e.preventDefault();
         $.fancybox.open( $('[data-fancybox="gallery"]'), {
            touch: false,
            infobar: false,
            margin : [44,0,22,0],
            thumbs : {
                autoStart : true,
                axis : 'x'
            }
        });     
    });

    $('#confirm_loc_change').on('click', function(e){
        e.preventDefault();

         var delivery_full_name = $('#delivery_full_name').val();
         var delivery_ph_no = $('#delivery_ph_no').val();
         var delivery_address = $('#delivery_address').val();
         var delivery_country_id = $('#delivery_country_id').val();
         var delivery_city = $('#delivery_city').val();
         var delivery_zip = $('#delivery_zip').val();
         var change_loc_err = 0;
         
         if(delivery_full_name == ''){        
            $('#dfn_err').html('Name is required');
            change_loc_err = 1;
            $('#dfn_err').show();
         }
         else{
            $('#dfn_err').hide();
            $('#dfn_err').html(''); 
         }
         
         if(delivery_ph_no == ''){        
            $('#dpn_err').html('Phone is required');
            change_loc_err = 1;
            $('#dpn_err').show();
         }
         else{
            $('#dpn_err').html(''); 
            $('#dpn_err').hide();
         }

         if(delivery_address == ''){        
            $('#da_err').html('Address is required');
            change_loc_err = 1;
            $('#da_err').show();
         }
         else{
            $('#da_err').html(''); 
            $('#da_err').hide();
         }

         if(delivery_city == ''){        
            $('#dc_err').html('City is required');
            change_loc_err = 1;
            $('#dc_err').show();
         }
         else{
            $('#dc_err').html(''); 
            $('#dc_err').hide();
         }

         
         if(change_loc_err == 1){
            return false;
         }



        $('#change_loc_status').val(1);    
        $('#location_box').removeClass('active_');
    });
    $('#availability_notify').on('click', function() {
        
        var _url = "{{ url('/api/farm-availability-notify') }}";        
        var farm_id = $( "#rev_fm_id" ).val();
        var _data = {
                    '_token':'{{csrf_token()}}',
                    'farm_id':farm_id,
                    }
        
            sendAjax(_url,'post',_data, function(responseData){
               $( "#subscribe_notify_loader" ).addClass('show_');
              if(!responseData.status){
                    $('.commonMessage').html(responseData.userMessage);
                }else{
                    if(responseData.redirectURL){
                        setTimeout(function() {
                        $( "#subscribe_notify_success_msg" ).html('You will be notified when this farm is available');
                        $( "#subscribe_notify_success_msg" ).addClass('success');
                        $( "#subscribe_notify_loader .loader_wrapper" ).addClass('hide_');
                        }, 1000);
                        setTimeout(function() {
                            window.location.reload();
                        }, 2000);
                    }else{                
                        $('.commonMessage').html('<i class=" icon icon-success "></i> '+ responseData.message);
                    }
                    
                }  
            });
        return false;
      
    });
   $('select').on('change', function() {    
      $(this).valid();
   });
});
</script>
<script>
var map = document.getElementById('map');
    if (typeof (map) != 'undefined' && map != null) {
        google.maps.event.addDomListener(window, 'load', mainMap);
    }
</script>    
@stop