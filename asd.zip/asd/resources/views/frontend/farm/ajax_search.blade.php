@extends('frontend.layouts.master')
@section('styles')
@parent
{{ HTML::style('assets/frontend/uploader_tools/js/jquery.ui.plupload/css/jquery.ui.plupload.css') }}

@stop

@section('content')
<main class="inner_body">
   <section class="blocks-listing-container">
      <div class="row no-margin" id="container">
         

      </div>
   </section>
</main>
@stop
@section('scripts')
@parent
@include('frontend.script.helper')

<script>
    $( document ).ready(function() {
        var search_key = '';
        if($('#search_key').val() != '')
        {
            var search_key = $('#search_key').val();
        }
        get_farms(1);
        
        function sendAjax(URL,type,data,func,loaderDivID,$elem){
            if(loaderDivID){ $(loaderDivID).show(); }
            $.ajax({
                url:URL,
                type:type,
                async:true,
                data:data,
                dataType:'json',
                statusCode: {
                    302:function(){ console.log('Forbidden. Access Restricted'); },
                    403:function(){ console.log('Forbidden. Access Restricted','403'); },
                    404:function(){ console.log('Page not found','404'); },
                    500:function(){ console.log('Internal Server Error','500'); }
                }
            }).done(function(responseData){	
                if(loaderDivID){$(loaderDivID).hide();}								
                func(responseData,$elem);	
                                    
            });
            
        }
        
        function get_farms(page = 1){
            var search_key = $('#search_key_set').val();
            $('#search_key').val(search_key);
            var ft = $('#ft').val();
            var search_location = [];
            $('.state_search:checked').each(function(i){
              //search_location[i] = "'"+$(this).val()+"'";
              search_location[i] = $(this).val();
            });
            var search_price = [];
            $('.price_search:checked').each(function(i){
              search_price[i] = $(this).val();
            });
            var search_crop = [];
            $('.crop_search:checked').each(function(i){
              search_crop[i] = $(this).val();
            });
            var search_facility = [];
            $('.facility_search:checked').each(function(i){
              search_facility[i] = $(this).val();
            });


            

            //var near_latitude = $('#near_latitude').val();
            //var near_longitude = $('#near_longitude').val();
            var near_latitude = Cookies.get('near_latitude');
            var near_longitude = Cookies.get('near_longitude');
            var _data = {
                        '_token':'{{csrf_token()}}',
                        'search_key':search_key,
                        'ft':ft,
                        'page':page,
                        'search_location':search_location,
                        'search_price':search_price,
                        'search_crop':search_crop,
                        'search_facility':search_facility,
                        'near_latitude':near_latitude,
                        'near_longitude':near_longitude,
                        }
					
					     
         $( "#farm_search_loader" ).addClass('show_');               
			sendAjax("{{ url('/api/farm_search') }}",'GET',_data,function(data){

               $( "#farm_search_loader .loader_wrapper" ).addClass('hide_');
               $( ".aj_loader" ).removeClass('show_');

                var html_data = '';
                var farms = data.farms;
                var farms_list = data.farms.data;
                var states_ = data.states;
                var prices_ = data.prices;
                var crops_ = data.crops;
                var facilities_ = data.facilities;
               
                html_data += '<div class="bl-left-wrap  " id="left-wrap"><section class="place-list-section section_farms fade-in-Up" id="recommended_farms"><div class="search"><div class="row"><div class="col-md-12"><div class="breadcrumb_wrapper"><nav id="breadcrumbs"><ul><li><a href="'+window.request+'home/">Home</a></li><li><a href="#">Search list</a></li></ul></nav></div><div class="row with-forms"><div class="col-md-12 col-lg-5"><h3 class="section-title "><span>Total '+farms.total+ ' Results</span> </h3></div>';
                
                html_data += '<div class="col-md-12 col-lg-7 panel-container">'+
                                 '<div class="panel-dropdown">'+
                                    '<a href="#">Location</a>'+                                    
                                    '<div class="panel-dropdown-content checkboxes categories">'+
                                       '<div class="row">';
                                            $(states_).each(function(state_key,state){
                                               html_data += '<div class="col-md-6">';                                                
                                                            html_data +='<input id="check-fm-'+state.fm_id+'" type="checkbox" value="'+state.fm_state_name+'" name="search_location[]" class="state_search" '+state.checked+'>'+
                                                            '<label for="check-fm-'+state.fm_id+'"><span>'+state.fm_state_name+'</span></label>';
                                                        
                                                html_data +='</div>';
                                            });
                                       html_data +='</div>'+                                       
                                       '<div class="panel-buttons">'+
                                          '<button class="panel-cancel">Cancel</button>'+
                                          '<button class="panel-apply search_button">Apply</button>'+
                                       '</div>'+                                        
                                    '</div>'+                                    
                                 '</div>'+
                                 '<div class="panel-dropdown wide">'+
                                    '<a href="#">Price</a>'+                                    
                                    '<div class="panel-dropdown-content checkboxes">'+
                                       '<div class="row">';
                                            $(prices_).each(function(price_key,price){
                                               html_data += '<div class="col-md-6">';                                                
                                                            html_data +='<input id="check-pr-'+price.fm_id+'" type="checkbox" value="'+price.fm_price+'" name="search_price[]" class="price_search" '+price.checked+'>'+
                                                            '<label for="check-pr-'+price.fm_id+'"><span>'+price.fm_price+'$</span></label>';
                                                        
                                                html_data +='</div>';
                                            });
                                       html_data +='</div>'+                                       
                                       '<div class="panel-buttons">'+
                                          '<button class="panel-cancel">Cancel</button>'+
                                          '<button class="panel-apply search_button">Apply</button>'+
                                       '</div>'+                                        
                                    '</div>'+                                    
                                 '</div>'+
                                 '<div class="panel-dropdown">'+
                                    '<a href="#">Crops</a>'+                                    
                                    '<div class="panel-dropdown-content checkboxes">'+
                                       '<div class="row">';
                                            $(crops_).each(function(crop_key,crop){
                                               html_data += '<div class="col-md-6">';                                                
                                                            html_data +='<input id="check-cr-'+crop.agriculture_id+'" type="checkbox" value="'+crop.agriculture_id+'" name="search_crop[]" class="crop_search" '+crop.checked+'>'+
                                                            '<label for="check-cr-'+crop.agriculture_id+'"><span>'+crop.agriculture_title+'</span></label>';
                                                        
                                                html_data +='</div>';
                                            });
                                       html_data +='</div>'+                                       
                                       '<div class="panel-buttons">'+
                                          '<button class="panel-cancel">Cancel</button>'+
                                          '<button class="panel-apply search_button">Apply</button>'+
                                       '</div>'+                                        
                                    '</div>'+                                    
                                 '</div>'+
                                 '<div class="panel-dropdown">'+
                                    '<a href="#">Facilities</a>'+                                    
                                    '<div class="panel-dropdown-content checkboxes">'+
                                       '<div class="row">';
                                            $(facilities_).each(function(facility_key,facility){
                                               html_data += '<div class="col-md-6">';                                                
                                                            html_data +='<input id="check-fac-'+facility.facility_id+'" type="checkbox" value="'+facility.facility_id+'" name="search_facility[]" class="facility_search" '+facility.checked+'>'+
                                                            '<label for="check-fac-'+facility.facility_id+'"><span>'+facility.facility_title+'</span></label>';
                                                        
                                                html_data +='</div>';
                                            });
                                       html_data +='</div>'+                                       
                                       '<div class="panel-buttons">'+
                                          '<button class="panel-cancel">Cancel</button>'+
                                          '<button class="panel-apply search_button">Apply</button>'+
                                       '</div>'+                                        
                                    '</div>'+                                    
                                 '</div>'+
                                 '<a href="#" class="button gray reject reset_search d-none"><i class="icon icon-android-cancel"></i> Reset</a>'+                                 
                              '</div>';
                
                
                html_data += '</div></div></div></div><div class="search_list_wrapper" data-listing="true">';
                if(farms_list.length > 0){
                    html_data += '<div class="grid-wrap ">';
                
                    html_data += '<div class="aj_loader" id="farm_search_loader">'+
                                    '<div class="loader_wrapper">'+
                                       '<div class="shape shape1"></div>'+
                                       '<div class="shape shape2"></div>'+
                                       '<div class="shape shape3"></div>'+
                                       '<div class="shape shape4"></div>'+
                                    '</div>'+

                                    '<div class="msg" id="farm_search_success_msg">'+                
                                    '</div>'+
                                 '</div>'; 

                    $(farms_list).each(function(farm_key,farm){

                      html_data +='<div class="grid"><div class="block_"><div class="top_block"><a href="'+window.request+'farm/'+farm.fm_slug+'" class="block_link" data-marker-id="1"></a><div class="top_box"><div class="user_ tooltip-bottom" title="'+farm.owner_name+'"><a href="'+window.request+'farm-owner/'+farm.fm_owner_id+'"><div class="img b-lazy" data-src="'+farm.owner_avatar+'"></div></a></div><div class="share_"><div class="icon icon-graphics-icon-share"></div></div></div>'+
                                       '<div class="social_share">'+
                                       '<ul>'+
                                       '<li>'+
                                          '<a href="https://www.facebook.com/sharer/sharer.php?u='+escape(window.request+'farm/'+farm.fm_slug)+'" target="_blank" class="social_icon">'+
                                             '<div class="icon icon-social-facebook"></div>'+
                                          '</a>'+
                                       '</li>'+
                                       '<li>'+
                                          '<a href="https://plus.google.com/share?url='+escape(window.request+'farm/'+farm.fm_slug)+'" target="_blank" class="social_icon">'+
                                             '<div class="icon icon-social-google"></div>'+
                                          '</a>'+
                                       '</li>'+
                                       '<li>'+
                                          '<a href="https://twitter.com/share?url='+escape(window.request+'farm/'+farm.fm_slug)+'" target="_blank" class="social_icon">'+
                                             '<div class="icon icon-social-twitter"></div>'+
                                          '</a>'+
                                       '</li>'+
                                    '</ul>'+
                                 '</div>'+
                                 '<div class="crop_details_box">'+
                                    '<div class="crop_icon">'+
                                       '<img class="img_auto source_" />'+
                                    '</div>'+
                                    '<div class="crop_text_"></div>'+
                                 '</div>'+
                                 '<div class="bottom_box">'+
                                    '<div class="location_">'+
                                       '<div class="icon icon-graphics-icon-location-03"></div>'+
                                       '<div class="text_">'+farm.fm_state_name+'</div>'+
                                    '</div>';
                                    if(farm.crops.length > 3){
                                        html_data +='<div class="crops_box w_slick" data-crop-slider="true">';
                                    }
                                    else{
                                        html_data +='<div class="crops_box">';
                                    }
                                       $(farm.crops).each(function(crop_key,crop){
                                       html_data +='<div class="crop_">'+
                                          '<a href="javascript:void(0);" class="inner_ mg-tooltip" data-title="' + crop.agriculture_title +'">'+
                                             '<img src="'+ crop.agriculture_image +'" />'+
                                          '</a>'+
                                       '</div>';
                                       });

                                    html_data +='</div>'+
                                    

                                    '</div>'+
                                 '<div class="img b-lazy resourceBig" data-src="'+ farm.fm_main_image +'"></div>'+
                              '</div>'+
                              '<a href="'+window.request+'farm/'+farm.fm_slug+'" class="details_box">'+
                                 '<div class="info_box">'+
                                    '<div class="f_name">'+farm.fm_title+'</div>'+
                                    //'<div class="f_area">'+farm.fm_area+' '+farm.fm_area_unit+'</div>'+
                                    '<div class="f_area">'+toAcre(farm.fm_area,farm.fm_area_unit)+'</div>'+ 
                                 '</div>'+
                                 '<div class="amount_box">'+
                                    '<div class="currency">$</div>'+
                                    '<div class="amount_">'+
                                       '<span>'+ farm.fm_price +'</span>'+
                                       '<span class="small_">per month</span>'+
                                    '</div>'+
                                 '</div>'+
                              '</a>'+
                           '</div>'+
                        '</div>';
                        });
                        
                     html_data +='</div>'+
                  '</div>';
                  }else {
                     html_data +='<div class="no-result">'+
                        '<h3>No Results Found</h3>'+
                      '</div>';
                  }
                  html_data +='</section><div class="row fs-listings">';
                           if(farms.last_page > 1) {
                            html_data +='<div class="col-md-12">'+
                                 '<div class="pagination-container margin-top-15 margin-bottom-40">'+
                                    '<nav class="pagination"><ul>';
                                       if(farms.current_page > 1){
                                           html_data +='<li><a href="javascript:void(0)" onclick="get_farms('+(parseInt(farms.current_page)-1)+');"><i class="fas fa-chevron-left"></i></a></li>';
                                       }
                                       
                                       for (var p=1;p<=farms.last_page;p++) { 
                                          
                                          if(p > (farms.last_page-1) && farms.current_page < (farms.last_page-3)  && farms.last_page >= 5){
                                             html_data +='<li>..</li>';  
                                          }
                                          
                                          if(((farms.current_page+2) >= p) && (p >= (farms.current_page-2)) || (p == 1 || p == farms.last_page)){                                              
                                          html_data +='<li><a href="javascript:void(0)" onclick="get_farms('+p+');"';
                                          var class_='';
                                          if(p === farms.current_page){
                                             class_ ='current-page';
                                          }
                                          html_data +='class='+class_+'>'+p+'</a></li>';      
                                          }


                                          if(p == 1 && farms.current_page > 4 ){
                                             html_data +='<li>..</li>';  
                                          }
                                                                                                                              
                                       }
                                       
                                       if(farms.current_page < farms.last_page) {
                                            html_data +='<li><a href="javascript:void(0)" onclick="get_farms('+(parseInt(farms.current_page)+1)+');"><i class="fas fa-chevron-right"></i></a></li>';
                                       }
                                    html_data +='</ul></nav>'+
                                 '</div>'+
                              '</div>';
                           }
                           html_data +='<div class="clearfix"></div>'+                                                   
                        '</div>'+
                     '</div>';
                  <!-- Search / End -->
                  <!--   -->
                  
                html_data +='<div class="bl-right-wrap  " id="right-wrap">'+
                                '<div class="fs-inner-container map-fixed">'+
                                   '<div id="map-container">'+
                                      '<div id="map" data-map-zoom="9" data-map-scroll="true">'+
                                      '</div>'+
                                   '</div>'+
                                '</div>'+
                             '</div>';
                  
                $('#container').html(html_data);
                bLazy.revalidate();
                FarmsGate_.init();
                FarmsGate_.grid_user_name();
                FarmsGate_.panel_dropdown();
                mainMap(data.map_array);
                if(search_location.length > 0 || search_price.length > 0 || search_crop.length > 0 || search_facility.length > 0){
                  $('.reset_search').removeClass('d-none');
                }
              
            });
        }
        window.get_farms=get_farms;
        
        $( "#farmsearchbtn" ).click(function(e) {
            e.preventDefault();
            $('.floating_suggestion_wrapper').removeClass('show_');
            $('#search_key_set').val($('#search_key').val());
            get_farms(1);
        });
        $('body').on('click','.search_button',function(e) {
            e.preventDefault();
            $('#search_key_set').val($('#search_key').val());
            get_farms(1);
        });

        $('body').on('click','.reset_search',function(e) {
         $('.reset_search').addClass('d-none');
            e.preventDefault();
            $('input[name="search_facility[]"]').attr('checked',false);
            $('input[name="search_crop[]"]').attr('checked',false);
            $('input[name="search_price[]"]').attr('checked',false);
            $('input[name="search_location[]"]').attr('checked',false);
            get_farms(1);
        });
    });
</script>

@include('frontend.script.farm_map')
@stop