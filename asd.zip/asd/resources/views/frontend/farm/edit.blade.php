@extends('frontend.layouts.master')
@section('styles')
@parent
{{ HTML::style('assets/frontend/uploader_tools/js/jquery.ui.plupload/css/jquery.ui.plupload.css') }}
	
@stop
@section('content') 

@php

$completed_percentage = 0;
$step_1_status = 'skip_';
if(!empty($farmDetails->fm_title) && !empty($farmDetails->fm_price) && $farmDetails->fm_main_image != '' && $farmDetails->fm_main_image != NULL){
$step_1_status = 'done_';
$completed_percentage = $completed_percentage+10;
}

$step_2_status = 'skip_';
if($farmDetails->categories->count()>0){
$step_2_status = 'done_';
$completed_percentage = $completed_percentage+9;
}

$step_3_status = 'skip_';
if(!empty($farmDetails->fm_latitude) && !empty($farmDetails->fm_longitude)){
$step_3_status = 'done_';
$completed_percentage = $completed_percentage+9;
}

$step_4_status = 'skip_';
if(!empty($farmDetails->fm_area) && !empty($farmDetails->fm_plots_no)){
$step_4_status = 'done_';
$completed_percentage = $completed_percentage+9;
}

$step_5_status = 'skip_';
if($farmDetails->crops->count()>0){
$step_5_status = 'done_';
$completed_percentage = $completed_percentage+9;
}

$step_6_status = 'skip_';
if($farmDetails->facilities->count()>0){
$step_6_status = 'done_';
$completed_percentage = $completed_percentage+9;
}

$step_7_status = 'skip_';
if(!empty($farmDetails->fm_soil_id) && !empty($farmDetails->fm_irrigation_id) && !empty($farmDetails->fm_agriculture_type_id)){
$step_7_status = 'done_';
$completed_percentage = $completed_percentage+9;
}

$step_8_status = 'skip_';
if($farmDetails->fm_weather_report != '' && $farmDetails->fm_weather_report != NULL && $farmDetails->fm_soil_report != '' && $farmDetails->fm_soil_report != NULL && $farmDetails->fm_annual_report != '' && $farmDetails->fm_annual_report != NULL){
$step_8_status = 'done_';
$completed_percentage = $completed_percentage+9;
}

$step_9_status = 'skip_';
if(!empty($farmDetails->fm_farm_highlights) && !empty($farmDetails->fm_about_farm)){
$step_9_status = 'done_';
$completed_percentage = $completed_percentage+9;
}

$step_10_status = 'skip_';
if($farmDetails->gallery->count()>0){
$step_10_status = 'done_';
$completed_percentage = $completed_percentage+9;
}

$step_11_status = 'skip_';
if(!empty($farmDetails->fm_policies) && !empty($farmDetails->fm_start_date) && !empty($farmDetails->fm_end_date)){
$step_11_status = 'done_';
$completed_percentage = $completed_percentage+9;
}
@endphp
<main class="inner_body">
   <section class="page-section multi_form_page profile_status">
      <div class="container-fluid">
         <div class="breadcrumb_wrapper">
            <nav id="breadcrumbs">
               <ul>
                  <li><a href='{{url("$lang/home")}}'>Home</a></li>                           
                  <li><a href='{{url("$lang/user/dashboard")}}'>Dashboard</a></li>                           
                  <li>{{ @$farmDetails->fm_title }}</li>
               </ul>
            </nav>
         </div>
      <div class="section_title text-center lg_">{!! lang('update_farm_details') !!}</div>
      <div class="row ">
         <div class="col-md-12 col-lg-2 col-xl-3 progress_side">
            <aside class="steps_block">
               <div class="swiper-percentage"><span class="number_">{{$completed_percentage}}</span>%</div>
               <div class="swiper-pagination swiper-pagination-clickable swiper-pagination-bullets">
               @if($screen_width > 1024)
                  <div class="swiper-pagination-bullet {{$step_1_status}}">{{ lang('farm_name') }}<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_2_status}}" >{{ lang('type_of_farm') }}<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_3_status}}" >{{ lang('location_of_farm') }}<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_4_status}}" >{{ lang('plot') }}<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_5_status}}" >{{ lang('suitable_crops') }}<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_6_status}}" >{{ lang('facilities') }}<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_7_status}}" >{{ lang('quick_facts') }}<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_8_status}}" >{{ lang('reports') }}<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_9_status}}" >{{ lang('about') }}<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_10_status}}" >{{ lang('gallery') }}<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_11_status}}" >{{ lang('others') }}<span class="point_"></span></div>
                  <div class="swiper-line_"></div>
               @else
                  <div class="swiper-pagination-bullet {{$step_1_status}}">01<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_2_status}}" >02<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_3_status}}" >03<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_4_status}}" >04<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_5_status}}" >05<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_6_status}}" >06<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_7_status}}" >07<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_8_status}}" >08<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_9_status}}" >09<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_10_status}}" >10<span class="point_"></span></div>
                  <div class="swiper-pagination-bullet {{$step_11_status}}" >11<span class="point_"></span></div>
                  <div class="swiper-line_"></div>
               @endif   
               </div>
            </aside>
         </div>
         
        
         <div class="col-md-12 col-lg-10 col-xl-9 overflow-hidden">
            {!! Form::open(['method' => 'POST', 'class' => 'multi_form_wrapper listing_farm_reg' ,'url' => url('farm-signup' ), 'id'=>'farm-signup','files'=>true] ) !!} 
            <div class="aj_loader" id="edit_farm_loader">
                <div class="loader_wrapper">
                    <div class="shape shape1"></div>
                    <div class="shape shape2"></div>
                    <div class="shape shape3"></div>
                    <div class="shape shape4"></div>
                </div>

                <div class="msg" id="edit_farm_success_msg">                
                </div>
            </div>
            <input type="hidden" name="uuid" value="{{$uuid}}"> 
            <input type="hidden" name="farm_status" value="{{ @$farmDetails->fm_status }}">
                        <div class="m_step_ {{$step_1_status}}">
                           <div class="inner_">
                              <div class="m_head">
                                 <span>{{ lang('enter_farm_name') }}</span>
                                 <div class="icon icon-graphics-icon-verified verified_"></div>
                              </div>
                              <div class="form_body">
                                <div class="input-box">
                                        <label>{{ lang('farm_name') }}</label>
                                        <input class="form-control" type="text" value="{{ @$farmDetails->fm_title }}" name="farm_name">
                                    </div>
                                    <div class="input-box">
                                        <label>{{ lang('price_per_month') }}</label>
                                        <input class="form-control" type="number" value="{{ @$farmDetails->fm_price }}" name="farm_price">
                                    </div>
                                    <div class="input-box margin-bottom-20">
                                        <label>{{ lang('farm_image') }}<small>(Allowed : jpeg,jpg,png Max Size:10mb)</small></label>
                                        <!-- file upload -->
                                        <div class="input_parent">
                                        <input type="file" class="form-control uploader" data-type="farm_image" data-mimes="jpg,jpeg,png" data-crop="true" data-width="1254" data-height="962" title="Farm Image" id="farm_image" name="farm_image" required />
                                        <div class="choose">
                                            <div class="choose-btn">Choose</div>
                                            <div class="choose-file uploadFileName">No file chosen</div>
                                            <div class="uploadPercentage"></div>
                                            <div class="uploadProgressWrapper">
                                                <div class="uploadProgress" ></div>
                                            </div>
                                        </div>
                                        <input class="filename" type="hidden"  id="farm_main_image"  value=""  name="farm_main_image"  placeholder="">
                                        <input class="original_name" type="hidden"  id="farm_main_image_orig" value=""  name="farm_main_image_orig"  placeholder="">
                                        </div>
                                        <!-- file upload -->
                                    </div>
                                    @if(@$farmDetails->fm_main_image != '' && @$farmDetails->fm_main_image != NULL)
                                    <div class="image_preview_box">
                                        <div class="items_box">
                                        <div class="inner_">
                                            <div class="img_box">
                                                <div class="img_" style="background-image:url('{{ asset('storage/uploads/farm/image/'.@$farmDetails->fm_main_image) }}')"></div>
                                            </div>
                                                <div class="title"></div>
                                        </div>
                                        </div>
                                    </div>
                                    @endif
                                
                              </div>
                              <div class="line_bottom" ></div>
                           </div>
                        </div>
                   
                    
                        <div class="m_step_ {{$step_2_status}}">
                           <div class="inner_">
                              <div class="m_head">
                                 <span>{{ lang('select_farm_type') }}</span>
                                 <div class="icon icon-graphics-icon-verified verified_"></div>
                              </div>
                              <div class="form_body">
                                 <div class="input-box margin-bottom-20">
                                    <label>{{ lang('choose_farm_type') }}</label>
                                 </div>
                                 @if(!empty($categoryList))
                                     @foreach($categoryList as $category)
                                     <div class="checkboxes  margin-bottom-30">
                                        <input 
											@if(isset($farmDetails->categories)) 
												@foreach(@$farmDetails->categories as $fCat) 
													@if($category->category_id == $fCat->category_id ) 
														checked
													@endif 
												@endforeach
											@endif 
										id="cat-{{ $category->category_id }}" value="{{ $category->category_id }}" type="checkbox" name="farm_categories[]">
                                        <label for="cat-{{ $category->category_id }}">{{ $category->category_title }}</label>
                                     </div>
                                     @endforeach
								 @endif
                              </div>
                              <div class="line_bottom" ></div>
                           </div>
                        </div>
                  
                 
                        <div class="m_step_ {{$step_3_status}}">
                           <div class="inner_">
                              <div class="m_head">
                                 <span>{{ lang('select_your_location') }}</span>
                                 <div class="icon icon-graphics-icon-verified verified_"></div>
                              </div>
                              <div class="form_body">
                                <input type="hidden" id="farm_latitude" name="farm_latitude" value="{{ @$farmDetails->fm_latitude }}">
                                <input type="hidden" id="farm_longitude" name="farm_longitude" value="{{ @$farmDetails->fm_longitude }}">
                                 <div class="input-group mg_ve" >
                                    <div class="input-box margin-bottom-20">
                                       <label>{{ lang('country_region') }}</label>
                                       <div class="select-box-wrap select-border">
                                          <select class="select_" name="country_id" id="country_id">
                                             <option label="blank" value="">Select your country</option>
                                             @if(!empty($countryList))
                                                @foreach($countryList as $country)
                                                   <option {{ ($country->country_id == @$farmDetails->fm_country_id)?' selected="selected"':'' }} value="{{ $country->country_id }}">{{ $country->country_name }}</option>
                                                @endforeach
                                            @endif
                                          </select>
                                       </div>
                                    </div>
                                    <div class="input-box margin-bottom-20">
                                       <label>{{ lang('state') }}</label>
                                       <input class="form-control" type="text" name="state" id="state" value="{{ @$farmDetails->fm_state_name }}">                             
                                    </div>
                                 </div>
                                 <div class="input-group mg_ve">
                                    <div class="input-box margin-bottom-20">
                                       <label>{{ lang('city') }}</label>
                                       <input class="form-control" type="text" name="city" id="city" value="{{ @$farmDetails->fm_city }}">                             
                                    </div>
                                    <div class="input-box">
                                       <label>{{ lang('zip_code') }}</label>
                                       <input class="form-control" type="text" name="zip" id="zip" value="{{ @$farmDetails->fm_zipcode }}">                                                                          
                                    </div>
                                 </div>
                                 <div class="input-box">
                                    <label>{!! lang('pin_your_location') !!}</label>
                                    <div class="image_box add_crop" data-source="#area_a">
                                       <!-- <div class="img b-lazy"  data-src="assets/images/map_img.png"></div> -->
                                       <div class="map_box" id="map_box"></div>
                                    </div>
                                 </div>
                              </div>
                              <div class="line_bottom" ></div>
                           </div>
                        </div>
                     
                    
                        <div class="m_step_ {{$step_4_status}}">
                           <div class="inner_">
                              <div class="m_head">
                                 <span>{!! lang('plot') !!}</span>
                                 <div class="icon icon-graphics-icon-verified verified_"></div>
                              </div>
                              <div class="form_body">
                                 <div class="input-box margin-bottom-20">
                                    <label>{!! lang('total_area') !!}</label>
                                    <div class="input-group">
                                       <input class="form-control" type="text" value="{{ @$farmDetails->fm_area }}" name="total_area">
                                       <div class="select-box-wrap select-border">
                                          <select class="select_" name="area_unit">
                                             <option {{ ('M2' == @$farmDetails->fm_area_unit)?' selected="selected"':'' }} value="M2">M<sup>2</sup></option>
                                             <option {{ ('Feet' == @$farmDetails->fm_area_unit)?' selected="selected"':'' }} value="Feet">Feet</option>
                                             <option {{ ('Acre' == @$farmDetails->fm_area_unit)?' selected="selected"':'' }} value="Acre">Acre</option>
                                          </select>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="input-group mg_ve">
                                    <div class="input-box margin-bottom-20">
                                       <label>{!! lang('no_of_plots') !!}</label>
                                      <?php /* <div class="select-box-wrap select-border ">
										  <input type="number"	value=""  class="plot_split_choose"
                                          <select class="plot_split_choose" name="plots">
                                             <option label="blank" value="">Select Plots</option>
                                             <option value="1">1</option>
                                             <option value="2">2</option>
                                             <option value="4">4</option>
                                             <option value="6">6</option>
                                             <option value="8">8</option>
                                          </select>
										  
                                       </div>*/ ?>									  
                                       <input class="form-control" type="text" name="plots" id="plots" value="{{ @$farmDetails->fm_plots_no }}">                                                                          
                                    </div>
                                    
                                 </div>
                                 <div class="input-box margin-bottom-20">
                                    <label>{!! lang('upload_plot_map') !!}<small>(Allowed : jpeg,jpg,png Max Size:10mb)</small></label>
                                    <!-- file upload -->
                                    <div class="input_parent">
                                       <input type="file" class="form-control uploader" data-type="plot_image" data-mimes="jpg,jpeg,png" data-crop="true" data-width="1254" data-height="962" title="Plot Map" id="plot_map" name="plot_map" required onchange="readURL(this);"/>
                                       <div class="choose">
                                          <div class="choose-btn">Choose</div>
                                          <div class="choose-file uploadFileName">No file chosen</div>
                                          <div class="uploadPercentage"></div>
                                          <div class="uploadProgressWrapper">
                                             <div class="uploadProgress" ></div>
                                          </div>
                                       </div>
                                       <input class="filename" type="hidden" id="plot_map_image" name="plot_map_image" placeholder="">
                                       <input class="original_name" type="hidden"  id="plot_map_orig" value=""  name="plot_map_orig"  placeholder="">
                                    </div>
                                    <!-- file upload -->
                                 </div>
                                 <!--<div class="input-box">
                                    <div class="land_map">
                                       <div class="img_" style="background-image: url(assets/images/plot-map.svg);"></div>
                                       <div class="land_split_ ">
                                       </div>
                                    </div>
                                 </div>-->
                                 @if(@$farmDetails->fm_plot_map != '' && @$farmDetails->fm_plot_map != NULL)
                                 <div>
                                    <img src="{{ asset('storage/uploads/farm/plot/'.@$farmDetails->fm_plot_map) }}" style="height:100px;width:100px;">
                                 </div>
                                 @endif
                              </div>
                              <div class="line_bottom" ></div>
                           </div>
                        </div>
                     
                     
                        <div class="m_step_ {{$step_5_status}}">
                           <div class="inner_">
                              <div class="m_head">
                                 <span>{!! lang('crops_suitable_for_land') !!}</span>
                                 <div class="icon icon-graphics-icon-verified verified_"></div>
                              </div>
                              <div class="form_body">
                                 
                                 <div class="input-box">
                                    <label>{!! lang('select_crop') !!}</label>
                                    <div class="select-box-wrap select-with-icon">
                                       <select class="crop_select_box_with_icon listing_crop_select" title="Select Crop" onchange="FarmsGate_.listing_crop_select(value)">
                                       <option  value="-1" data-suffix="<div class='title_'><span>Select Crop</span></div>">
                                             Select Crop
                                       </option>
                                       @if(!empty($agricultureList))
                                          @foreach($agricultureList as $agriculture)
                                          <option  value="{{ $agriculture->agriculture_id }}"
                                             data-prefix="<img class='icon_' src='{{ asset('storage/uploads/agriculture/icon/'.$agriculture->agriculture_icon) }}' />" 
                                             data-suffix="<div class='title_'><span>{{ $agriculture->agriculture_title }}</span></div>" data-title = "{{ $agriculture->agriculture_title }}"
                                             data-image = "{{ asset('storage/uploads/agriculture/icon/'.$agriculture->agriculture_icon) }}"
                                             >
                                             {{ $agriculture->agriculture_title }}
                                          </option>
                                          @endforeach
                                        @endif
                                       </select>
                                    </div>
                                 </div>
                                 <div class="crops_list_box with_close wide_ margin-bottom-10">
                                    
                                    
                                 </div>
                              </div>
                              <div class="line_bottom" ></div>
                           </div>
                        </div>
                     
                     
                        <div class="m_step_ {{$step_6_status}}">
                           <div class="inner_">
                              <div class="m_head">
                                 <span>{!! lang('select_facilities_available') !!}</span>
                                 <div class="icon icon-graphics-icon-verified verified_"></div>
                              </div>
                              <div class="form_body">
                                 <div class="input-box margin-bottom-20">
                                    <label>{!! lang('choose_facilites') !!}</label>
                                 </div>
                                 <div class="checkboxes-inline ">
                                 @if(!empty($facilityList))
									         @foreach($facilityList as $facility)
                                    <div class="checkboxes ">
                                       <input 
                                          @if(isset($farmDetails->facilities)) 
                                             @foreach(@$farmDetails->facilities as $fFac) 
                                                @if($facility->facility_id == $fFac->facility_id ) 
                                                   checked
                                                @endif 
                                             @endforeach
                                          @endif 
                                       id="facility-{{ $facility->facility_id }}" value="{{ $facility->facility_id }}" type="checkbox" name="farm_facilities[]">
                                       <label for="facility-{{ $facility->facility_id }}">{{ $facility->facility_title }}</label>
                                    </div>
                                    @endforeach
								         @endif
                                 </div>  
                                  
                              </div>
                              <div class="line_bottom" ></div>
                           </div>
                        </div>
                     
                     
                        <div class="m_step_ {{$step_7_status}}">
                           <div class="inner_">
                              <div class="m_head">
                                 <span>{!! lang('farm_quick_facts') !!}</span>
                                 <div class="icon icon-graphics-icon-verified verified_"></div>
                              </div>
                              <div class="form_body">
                                 <div class="input-box margin-bottom-20">
                                    <label>{!! lang('type_of_soil') !!}</label>
                                    <div class="select-box-wrap select-border">
                                       <select class="select_" name="soil_id">
                                          <option label="blank" value="">Select Soil Type</option>
                                          @if(!empty($soilList))
                                             @foreach($soilList as $soil)
                                                <option 
                                                               @if($soil->soil_id == @$farmDetails->fm_soil_id ) 
                                                      selected
                                                   @endif 
                                                            value="{{ $soil->soil_id }}">{{ $soil->soil_title }}</option>
                                             @endforeach
                                          @endif                                          
                                       </select>
                                    </div>
                                 </div>
                                 <div class="input-box margin-bottom-20">
                                    <label>{!! lang('irrigation') !!}</label>
                                    <div class="select-box-wrap select-border">
                                       <select class="select_" name="irrigation_id">
                                          <option label="blank" value="">Select Irrigation</option>
                                          @if(!empty($irrigationList))
                                            @foreach($irrigationList as $irrigation)
                                                <option 
                                                    @if($irrigation->irrigation_id == @$farmDetails->fm_irrigation_id ) 
														selected
													@endif
                                                value="{{ $irrigation->irrigation_id }}">{{ $irrigation->irrigation_title }}</option>
                                            @endforeach
                                          @endif
                                       </select>
                                    </div>
                                 </div>
                                 <div class="input-box">
                                    <label>{!! lang('type_of_agriculture') !!}</label>
                                    <div class="select-box-wrap select-border">
                                       <select class="select_" name="agriculture_type_id">
                                          <option label="blank" value="">Select Agriculture</option>
                                          @if(!empty($agricultureTypeList))
                                            @foreach($agricultureTypeList as $agricultureType)
                                                <option 
                                                    @if($agricultureType->agriculture_type_id == @$farmDetails->fm_agriculture_type_id ) 
														selected
													@endif
                                                value="{{ $agricultureType->agriculture_type_id }}">{{ $agricultureType->agriculture_type_title }}</option>
                                            @endforeach
                                          @endif
                                         
                                       </select>
                                    </div>
                                 </div>
                              </div>
                              <div class="line_bottom" ></div>
                           </div>
                        </div>
                     
                     
                        <div class="m_step_ {{$step_8_status}}">
                           <div class="inner_">
                              <div class="m_head">
                                 <span>{!! lang('upload_reports') !!}</span>
                                 <div class="icon icon-graphics-icon-verified verified_"></div>
                              </div>
                              <div class="form_body">
                                 
                                 <div class="input-box margin-bottom-20">
                                    <label>{!! lang('weather_report') !!}<small>(Allowed : pdf,jpeg,jpg,docx Max Size:10mb)</small></label>
                                    <!-- file upload -->
                                    <div class="input_parent">
                                       <input type="file" class="form-control uploader" data-type="weather_image" data-crop="true" data-width="1254" data-height="962" title="Weather Report" id="weather_report" name="weather_report" required />
                                       <div class="choose">
                                          <div class="choose-btn">Choose</div>
                                          <div class="choose-file uploadFileName">No file chosen</div>
                                          <div class="uploadPercentage"></div>
                                          <div class="uploadProgressWrapper">
                                             <div class="uploadProgress" ></div>
                                          </div>
                                       </div>
                                       <input class="filename" type="hidden"  id="weather_report_image"  value=""  name="weather_report_image"  placeholder="">
                                       <input class="original_name" type="hidden"  id="weather_report_image_orig" value=""  name="weather_report_image_orig"  placeholder="">
                                    </div>
                                    <!-- file upload -->
                                    @if(@$farmDetails->fm_weather_report != '' && @$farmDetails->fm_weather_report != NULL)
                                     <div>
                                        <a href="{{ asset('storage/uploads/farm/weather_report/'.@$farmDetails->fm_weather_report) }}" download class="r_btn text-green"><i class="icon icon-android-clipboard"></i>Current File</a>
                                     </div>
                                     
                                    @endif
                                 </div>                                 
                                 <div class="input-box margin-bottom-20">
                                    <label>{!! lang('soil_report') !!}<small>(Allowed : pdf,jpeg,jpg,docx Max Size:10mb)</small></label>
                                    <!-- file upload -->
                                    <div class="input_parent">
                                       <input type="file" class="form-control uploader" data-type="soil_image" data-crop="true" data-width="1254" data-height="962" title="Soil Report" id="soil_report" name="soil_report" required />
                                       <div class="choose">
                                          <div class="choose-btn">Choose</div>
                                          <div class="choose-file uploadFileName">No file chosen</div>
                                          <div class="uploadPercentage"></div>
                                          <div class="uploadProgressWrapper">
                                             <div class="uploadProgress" ></div>
                                          </div>
                                       </div>
                                       <input class="filename" type="hidden"  id="soil_report_image" name="soil_report_image"  value=""  placeholder="">
                                       <input class="original_name" type="hidden"  id="soil_report_image_orig" value=""  name="soil_report_image_orig"  placeholder="">
                                    </div>
                                    <!-- file upload -->
                                    @if(@$farmDetails->fm_soil_report != '' && @$farmDetails->fm_soil_report != NULL)
                                     <div>
                                        <a href="{{ asset('storage/uploads/farm/soil_report/'.@$farmDetails->fm_soil_report) }}" download class="r_btn text-green"><i class="icon icon-android-clipboard"></i>Current File</a>
                                     </div>
                                    @endif 
                                 </div>                                
                                 <div class="input-box ">
                                    <label>{!! lang('annual_report') !!}<small>(Allowed : pdf,jpeg,jpg,docx Max Size:10mb)</small></label>
                                    <!-- file upload -->
                                    <div class="input_parent">
                                       <input type="file" class="form-control uploader" data-type="annual_image" data-crop="true" data-width="1254" data-height="962" title="Annual Report" id="annual_report" name="annual_report" required />
                                       <div class="choose">
                                          <div class="choose-btn">Choose</div>
                                          <div class="choose-file uploadFileName">No file chosen</div>
                                          <div class="uploadPercentage"></div>
                                          <div class="uploadProgressWrapper">
                                             <div class="uploadProgress" ></div>
                                          </div>
                                       </div>
                                       <input class="filename" type="hidden"  id="annual_report_image"  value=""  name="annual_report_image"  placeholder="">
                                       <input class="original_name" type="hidden"  id="annual_report_image_orig" value=""  name="annual_report_image_orig"  placeholder="">
                                    </div>
                                    <!-- file upload -->
                                    @if(@$farmDetails->fm_annual_report != '' && @$farmDetails->fm_annual_report != NULL)
                                     <div>
                                        <a href="{{ asset('storage/uploads/farm/annual_report/'.@$farmDetails->fm_annual_report) }}" download class="r_btn text-green"><i class="icon icon-android-clipboard"></i>Current File</a>
                                     </div>
                                    @endif
                                 </div>

                              </div>
                              <div class="line_bottom" ></div>
                           </div>
                        </div>
                    
                     
                        <div class="m_step_ {{$step_9_status}}">
                           <div class="inner_">
                              <div class="m_head">
                                 <span>{!! lang('about_your_farm') !!}</span>
                                 <div class="icon icon-graphics-icon-verified verified_"></div>
                              </div>
                              <div class="form_body">
                                 <div class="input-box margin-bottom-20">
                                    <label><span>{!! lang('farm_highlights') !!}</span><i class="tip tooltip-top icon icon-help2" title=""></i></label>
                                    <input class="" type="text" value="{{ @$farmDetails->fm_farm_highlights }}" data-role="tagsinput" placeholder="" name="farm_highlights">
                                 </div>
                                 <div class="input-box margin-bottom-20">
                                    <label>{!! lang('about_this_farm') !!}</label>
                                    <textarea name="farm_about" class="form-control" row='3'>{{ @$farmDetails->fm_about_farm }}</textarea>
                                 </div>
                                 
                              </div>
                              <div class="line_bottom" ></div>
                           </div>
                        </div>
                    
                     
                        <div class="m_step_ {{$step_10_status}}">
                           <div class="inner_">
                              <div class="m_head">
                                 <span>{!! lang('gallery') !!}</span>
                                 <div class="icon icon-graphics-icon-verified verified_"></div>
                              </div>
                              <div class="form_body">
                                
                                <div class="input-box margin-bottom-20">
                                    <div id="upload_gal_err" style="color:red">
                                       
                                    </div>
                                    <label>{!! lang('upload_images') !!}</label>
                                    <div class="pl_upload" id="uploader">
                                       <p>Your browser doesn't have Flash, Silverlight or HTML5 support.</p>
                                    </div>
                                    <div class="line_bottom" ></div>
                                 </div>

                                 <div class="image_preview_box" id="old_gallery">
                                 @if(isset($farmDetails->gallery)) 
                                    @foreach(@$farmDetails->gallery as $gallery)
                                    <div class="items_box">
                                       <div class="inner_">
                                          <div class="img_box">
                                             <div class="img_" style="background-image:url('{{ asset('storage/uploads/gallery/small/'.$gallery->gallery_image_name) }}')"></div>
                                             <span class="delGalleryImg close_btn" data-id="{{$gallery->gallery_id}}"><i class="icon icon-android-delete"></i></span>
                                          </div>
                                          <div class="title"></div>
                                       </div>
                                    </div>
                                    @endforeach
                                 @endif
                                 </div>
                              </div>
                              <div class="line_bottom" ></div>
                           </div>
                        </div>
                     
                    
                        <div class="m_step_ {{$step_11_status}}">
                           <div class="inner_">
                              <div class="m_head">
                                 <span>{!! lang('farm_policies') !!}</span>
                                 <div class="icon icon-graphics-icon-verified verified_"></div>
                              </div>
                              <div class="form_body">
                                 <div class="m_inner_body">
                                    <!-- <div class="input-box margin-bottom-20">
                                       <label>Description for farm house</label>
                                       <textarea name="farm_house_description" class="form-control" row="3">{{ @$farmDetails->fm_house_description }}</textarea>
                                    </div> -->
                                    <div class="input-box margin-bottom-20">
                                       <label>{!! lang('policies') !!}</label>
                                       <textarea name="farm_policies" class="form-control" row="3">{{ @$farmDetails->fm_policies }}</textarea>
                                    </div>
                                    <!--<div class="input-box margin-bottom-20">
                                       <label>Select available dates</label>
                                       <div class="multidatepick_">
                                          <div class="multi_date" ></div>
                                       </div>
                                    </div>-->
                                    <!--<div class="input-box">
                                       <label>Upload Images</label>
                                       <div class="dropzone" id="my-dropzone2" ></div>
                                    </div>-->
                                    <div class="input-box margin-bottom-20">
                                       <label>{!! lang('start_date') !!}</label>
                                       <div class="input-box-wrap icon_">
                                          <input class="form_control available_start_date" readonly type="text" value="{{ @$farmDetails->fm_start_date }}" name="available_start_date" id="available_start_date">
                                          <div class="icon icon-graphics-icon-calendar"></div>
                                       </div>
                                    </div>
                                    <div class="input-box margin-bottom-20">
                                       <label>{!! lang('end_date') !!}</label>
                                       <div class="input-box-wrap icon_">
                                          <input class="form_control available_end_date" readonly type="text" value="{{ @$farmDetails->fm_end_date }}" name="available_end_date" id="available_end_date">
                                          <div class="icon icon-graphics-icon-calendar"></div>
                                       </div>   
                                    </div>
                                 </div>
                              </div>
                              <div class="line_bottom" ></div>
                           </div>
                        </div>
                  
                        <div class="crop_popup" id="area_a">
                  <div class="inner_">
                    <div class="popup_header">
                        <div class="crop_type">{!! lang('select_location') !!}</div>
                        <div class="icon icon-ios-close-empty close_btn"></div>
                     </div>
                     <div class="map_wrapper">
                        <div id="singleListingMap-container">
                           @if($farmDetails->fm_latitude != '' && $farmDetails->fm_longitude != '')                           
                           <div id="singleListingMap" 
                              data-latitude="{{ @$farmDetails->fm_latitude }}" 
                              data-longitude="{{ @$farmDetails->fm_longitude }}" 
                              data-map-icon="icon icon-graphics-icon-farmer"
                              data-click="true"
                              ></div>
                           @else
                           <div id="singleListingMap" 
                              data-latitude="25.2048" 
                              data-longitude="55.2708" 
                              data-map-icon="icon icon-graphics-icon-farmer"
                              data-click="true"
                              ></div>
                           @endif   
                           <a href="#" id="map_done">{!! lang('pin_location') !!}</a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="crop_popup" id="crop_pop">
                  <div class="inner_">
                  <div class="crop_exist_err" style="color:red"></div>
                     <div class="popup_header">
                        <div class="crop_type">Plot A</div>
                        <div class="icon icon-ios-close-empty close_btn"></div>
                     </div>
                     <div class="crop_cart_wrapper">
                        <div class="input-box margin-bottom-20">
                           <label>{!! lang('min_duration') !!}</label>
                           <input type="number" class="form-control" placeholder="5 Months" name="crop_min_duration" id="crop_min_duration">
                           <label class="error" id="duration_err" style="display:none;"></label>
                        </div>
                        <input type="hidden" name="crop_id" id="crop_id" value="">
                        <input type="hidden" name="crop_title" id="crop_title" value="">
                        <input type="hidden" name="crop_image" id="crop_image" value="">
                        <div class="input-box margin-bottom-20">
                           <label>{!! lang('season') !!}</label>
                           <input type="text" class="form-control" placeholder="July to June" name="crop_season" id="crop_season">
                        </div>
                        <div class="input-box margin-bottom-20">
                           <label>
                              {!! lang('farming_type') !!}
                              <div class="badge icon_ tooltip-top" title="info">
                                 <div class="icon icon-help2"></div>
                              </div>
                           </label>
                           <div class="select-box-wrap select-border">
                              <select class="select_" name="farm_type" id="crop_farm_type">
                                 <option value="" disabled selected>Type</option>
                                 <option value="Organic">Organic</option>
                                 <option value="Inorganic">Inorganic</option>
                                 <!-- <option value="Other">Other</option> -->
                              </select>
                              
                           </div>
                           <label class="error" id="farm_type_err" style="display:none;"></label>
                        </div>
                        
                     </div>
                     <div class="total_wrapper  align-items-center justify-content-center">
                        <div class="btn_wrapper text-center"><a href="javascript:void(0);" class="btn-style2 lg_ add_farm_crop">Add</a></div>
                     </div>
                  </div>
               </div>
               {{ Form::close() }}  
         </div>
        
      </div>
      <div class="row align-items-center">

         <div class="col-md-12 ">
            <div class="btn_wrapper text-center  lg_g_">
           
               <a href="#" class="btn-style2 save_button farm_button">Update</a>
            </div>
         </div>
      </div>
   </section>
   <div class="tooltip_templates">
      <div class="info-guide-popup" id="info-guide-1">
         <div class="head_">
            <div class="icon_">
               <div class="icon icon-icons-initiative"></div>
            </div>
         </div>
         <p>      
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed elementum feugiat dolor.
         </p>
      </div>
   </div>
</main>
@stop
@section('scripts')
@parent
@include('frontend.layouts.editfarmjsfiles')
@include('frontend.script.uploader_script')

<script>
$(document).ready(function(){
   // setTimeout(function() {
   //    $('.form_edit').removeClass("form_edit");
   // }, 100);
    var crops_list = []; 
   
    var cropsArray = <?php echo json_encode(@$farmDetails->crops) ?>;
    var cropImagePath = '{{ URL::asset('storage/uploads/agriculture/icon/') }}';
    $.each(cropsArray, function (i, elem) {
        crops_list.push({
        crop_id : elem.agriculture_id,
        crop_min_duration : elem.pivot.fc_min_duration,
        crop_season : elem.pivot.fc_season,
        crop_farm_type : elem.pivot.fc_farm_type
        });
        var month_txt = 'Months';
        if(crop_min_duration == 1){
            month_txt = 'Month';
        }
        $('#crop_pop').removeClass('active_');
        $( ".crops_list_box" ).append('<div class="crop_" data-crop="'+elem.agriculture_title+'"><div class="link_"><div class="inner_"><div class="top_"><div data-id='+elem.agriculture_id+' class="icon icon-ios-close-empty close_btn crop_remove_btn"></div></div><div class="c_body"><div class="img_box"><img class="img_auto" src="'+cropImagePath+'/'+elem.agriculture_icon+'" /></div><div class="info_box_"><div class="title_">'+elem.agriculture_title+'</div><div class="meta_small">'+elem.pivot.fc_min_duration+ ' '+month_txt+'</div></div></div></div></div></div>');
    });
    
   
   
    var crops_html = '';    
   $(".farm_button").on("click", function(){
       var form = $('#farm-signup')[0];
       var formdata = new FormData(form);
       formdata.append('crops_list', JSON.stringify(crops_list));
       formdata.append('gallery_list', JSON.stringify(gallery_list));
      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $( "#edit_farm_loader" ).addClass('show_');
      $.ajax({
        url: '{{ url("$lang/farm-signup/$farmDetails->fm_uuid") }}',
        type: "POST",
        enctype: 'multipart/form-data',
        //data: $('#farm-signup').serialize(),
        data: formdata,
        processData: false,
        contentType: false,
        cache: false,
        success: function( response ) {         
         window.location.reload();                                    
        }
      });
   });
$(".add_farm_crop").on("click", function(){
    var crop_min_duration = $('#crop_min_duration').val();
    var crop_farm_type = $('#crop_farm_type option:selected').val();
    var crop_err = 0;
    
    if(crop_min_duration == '')
    {        
        $('#duration_err').html('Duration is required');
        crop_err = 1;
        $('#duration_err').show();
    }
    else
    {
       $('#duration_err').hide();
       $('#duration_err').html(''); 
    }
    
    if(crop_farm_type == '')
    {        
        $('#farm_type_err').html('Type is required');
        crop_err = 1;
        $('#farm_type_err').show();
    }
    else
    {
       $('#farm_type_err').html(''); 
       $('#farm_type_err').hide();
    }
    
    if(crop_err == 1)
    {
        return false;
    }
   var month_txt = 'Months';
   if(crop_min_duration == 1){
         month_txt = 'Month';
   }
    var crop_id = parseInt($('#crop_id').val());
    var crop_title = $('#crop_title').val();
    var crop_image = $('#crop_image').val();
    var crop_min_duration = $('#crop_min_duration').val();
    var crop_season = $('#crop_season').val();
    var crop_farm_type = $('#crop_farm_type').val();
    var crop_price = $('#crop_price').val();

    var exist_flag = 0;
    if(crops_list.length > 0) {
        for (var i = 0; i < crops_list.length; i++) {
            if (crops_list[i]['crop_id'] === parseInt($('#crop_id').val())) {
                var exist_flag = 1;
                crops_list[i]['crop_id'] = parseInt($('#crop_id').val());
                crops_list[i]['crop_min_duration'] = $('#crop_min_duration').val();
                crops_list[i]['crop_season'] = $('#crop_season').val();
                crops_list[i]['crop_farm_type'] = $('#crop_farm_type').val();
                $('#crop_pop').removeClass('active_');

                var this_el = $(".crops_list_box .close_btn[data-id="+crop_id+"]").parent().parent();
                this_el.find('.meta_small').html(crop_min_duration+" "+month_txt);
                break;
            } 
        }
    }
    if(exist_flag == 0)
    {
             
        crops_list.push({
        crop_id : crop_id,
        crop_min_duration : crop_min_duration,
        crop_season : crop_season,
        crop_farm_type : crop_farm_type,
        crop_price : crop_price,
        });  
        $('#crop_pop').removeClass('active_');
        $( ".crops_list_box" ).append('<div class="crop_" data-crop="'+crop_title+'"><div class="link_"><div class="inner_"><div class="top_"><div data-id='+crop_id+' class="icon icon-ios-close-empty close_btn crop_remove_btn"></div></div><div class="c_body"><div class="img_box"><img class="img_auto" src="'+crop_image+'" /></div><div class="info_box_"><div class="title_">'+crop_title+'</div><div class="meta_small">'+crop_min_duration+ ' '+month_txt+'</div></div></div></div></div></div>');
        $('#crop_min_duration').val('');
        //$('#crop_farm_type option:selected').val('');
        $('#crop_season').val('');
        $('#crop_farm_type').val('').change().selectric('refresh');
    }
    else
    {
        $('#crop_min_duration').val('');
        $('#crop_season').val('');
        $('#crop_farm_type').val('').change().selectric('refresh');
        //alert('Crop Already Exist');
        /*$('.crop_exist_err').html('Crop Already Exist.Please remove it and add again.');
        setTimeout(function() {
            $( ".crop_exist_err" ).html('');
         }, 3000);*/
    }
    $(".listing_crop_select").prop("selectedIndex", 0);
    window.crop_select_box.refresh();
    
  });
  $('body').on('click','.crop_remove_btn',function(e){   
    e.preventDefault();
    var rem_crop_id = $(this).data('id');
    $(this).parent().parent().parent().parent().remove();
    
    for(var i = 0; i < crops_list.length; i++) {
    if(crops_list[i].crop_id == rem_crop_id) {
        crops_list.splice(i, 1);
        break;
        }
    }
  });
    var dateFormat =  "yy-mm-dd";
    $("#available_start_date").datepicker({
        dateFormat : dateFormat,
        changeMonth: true,
        changeYear: true,
        todayBtn:  1,
        autoclose: true,
    }).on('change', function () {
        var minDate = getDate(this);
        $('#available_end_date').datepicker("option",'minDate', minDate);
    });

    $("#available_end_date").datepicker({
        dateFormat : dateFormat,
        changeMonth: true,
        changeYear: true,
        todayBtn:  1,
        autoclose: true,
    }).on('change', function () {
            var maxDate = getDate(this);
            $('#available_start_date').datepicker("option",'maxDate', maxDate);
    });
    
    function getDate( element ) {
      var date;
      try {
        date = $.datepicker.parseDate( dateFormat, element.value );
      } catch( error ) {
        date = null;
      }
 
      return date;
    }
    var galArray = <?php echo json_encode(@$farmDetails->gallery) ?>;
    $.each(galArray, function (i, elem) {
        gallery_list.push({
                        gal_img_id : elem.gallery_id,
                        gal_img : elem.gallery_image_name,       
                        });
        
        
    });
    $('body').on('click','.delGalleryImg',function(e){   
        e.preventDefault();
        console.log(gallery_list);
        
        var rem_gal_id = $(this).data('id');
        console.log(rem_gal_id);
        $(this).parent().parent().remove();
        for(var i = 0; i < gallery_list.length; i++) {
            if(gallery_list[i].gal_img_id == rem_gal_id) {
                gallery_list.splice(i, 1);
                break;
                }
        }
        
        
    });
   /*$('body').on('change','.listing_crop_select',function(e){   
      var crop_exist_flag = 0;
      $('.crop_exist_err').html('');
      $(".add_farm_crop").show();
      if(crops_list.length > 0) {
         for (var i = 0; i < crops_list.length; i++) {
               if (crops_list[i]['crop_id'] === parseInt($('#crop_id').val())) {
                  var crop_exist_flag = 1;
                  break;
               } 
         }
      }
      if(crop_exist_flag){
         $('.crop_exist_err').html('Crop Already Exist.Please remove it and add again.');
         $(".add_farm_crop").hide();
      }
   }); */
   $('body').on('change','.listing_crop_select',function(e){        
      if(crops_list.length > 0) {
        for (var i = 0; i < crops_list.length; i++) {
            if (crops_list[i]['crop_id'] === parseInt($('#crop_id').val())) {
               $('#crop_min_duration').val(crops_list[i]['crop_min_duration']);
               $('#crop_season').val(crops_list[i]['crop_season']);
               //$('#crop_farm_type option:selected').val(crops_list[i]['crop_farm_type']);
               $('#crop_farm_type').val(crops_list[i]['crop_farm_type']).change();
               $('#crop_farm_type option:selected').val(crops_list[i]['crop_farm_type']);
               $('#crop_farm_type').val(crops_list[i]['crop_farm_type']).change().selectric('refresh');
               break;
            } 
        }
      }
   });
});
</script>
<script src="{{asset('assets/frontend/uploader_tools/js/plupload.full.min.js')}}"></script>
<script src="{{asset('assets/frontend/uploader_tools/js/jquery.ui.plupload/jquery.ui.plupload.js')}}"></script>

@include('frontend.script.gallery_script')
<script>
var map = document.getElementById('map');
    if (typeof (map) != 'undefined' && map != null) {
        google.maps.event.addDomListener(window, 'load', mainMap);
    }
</script>
<script>
/*$("#uploader").plupload({
    // Do default configuration stuff
    preinit: {
       Init: function(up) {
           // create a new file array for plupload queue
           var files = new Array();

           // create a new file object
           var f = new plupload.File("Test0.png", "read_image_name.png", 0);
           f.status = plupload.DONE;
           f.percent = 100;
           files.push(f);

           // append files to our array
           up.files = files;

           // create a new QueueProgress and configure
           var queueprogress = new plupload.QueueProgress();
           queueprogress.size = 1;
           queueprogress.uploaded = 1;
           queueprogress.percent= 100;

           // set uploader queue process and reload ui
           up.total = queueprogress;
           up.trigger("QueueChanged");
       }
    }
}); */
</script>   
@stop