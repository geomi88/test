@extends('frontend.layouts.master')
@section('content')
<main class="inner_body">
   <section class="page-section owner-dashboard">
      <div class="container">
            <div class="row sticky-sidebar-parent">
                  <div class="col-lg-4 col-xl-3 profile_box  sticky-sidebar">
                     <aside class="avatar_block">
                        <div class="image_box black_overlay">
                           <div class="img_ b-lazy" data-src="{{ get_profile_large_image($userDetails->user_avatar) }}" ></div>

                           <div class="pro_id">
                              <div class="h_">Owner ID</div>
                              <div class="id_">{{$userDetails->user_code}}</div>
                           </div>
                        </div>
                     </aside>

                      

                     <div class="side_bar">
                            <aside class="location_list_box">
                                <ul class="l_meta_list">
                                       <li class="l_meta">
                                          <div class="icon_"><div class="icon icon-icon-msg"></div></div>
                                          <div class="meta_info">
                                             <div class="title_">Email</div>                                 
                                             <a href="mailto:{{$userDetails->user_email}}" class="sub_title">{{$userDetails->user_email}}</a>
                                          </div>
                                       </li>
                                    @if(!empty($userDetails->user_phone_number))
                                       <li class="l_meta">
                                          <div class="icon_"><div class="icon icon-android-call"></div></div>
                                          <div class="meta_info">
                                             <div class="title_">Phone</div>                                 
                                             <a href="tel:{{$userDetails->user_phone_number}}" class="sub_title">{{$userDetails->user_phone_number}}</a>
                                          </div>
                                       </li>
                                    @endif   
                                    @if(isset($userDetails->userNationality))
                                       <li class="l_meta">
                                          <div class="icon_"><div class="icon icon-graphics-icon-location-03"></div></div>
                                          <div class="meta_info">
                                             <div class="title_">Location</div>                                 
                                             <div class="sub_title">{{$userDetails->userNationality->country_name}}</div>
                                          </div>
                                       </li>
                                    @endif
                                    @if(!empty($userDetails->user_address))
                                       <li class="l_meta">
                                          <div class="icon_"><div class="icon icon-graphics-icon-farmhouse"></div></div>
                                          <div class="meta_info">
                                             <div class="title_">Address</div>                                 
                                             <div class="sub_title">{{$userDetails->user_address}}</div>
                                          </div>
                                       </li>
                                    @endif
                                   <li class="l_meta">
                                      <div class="icon_"><div class="icon icon-icons-calendar"></div></div>
                                      <div class="meta_info">
                                         <div class="title_">Date Joined</div>
                                         <div class="sub_title">{{date_convert($userDetails->created_at)}}</div>
                                      </div>
                                   </li>
                                </ul>
                            </aside>
                     </div>

                  </div>

                  <div class="col-lg-8 col-xl-9 content_box">
                     <article class="owner_header">
                        <div class="section_title">{{$userDetails->user_full_name}}</div>
                        <div class="info_box">
                           <p>{{$userDetails->user_description}}</p>
                        </div>

                     </article>

                     <aside class="in_block personal_farms_list">
                        <div class="sub-title">Farms <span class="text-green">({{$farms->count()}})</span></div>
                        <div class="grid-wrap" data-colum="3" data-listing="true">
                        @foreach($farms as $farm)
                        
                        <div class="grid" >
                                <div class="block_ small">
                                    <div class="top_block">
                                     <a href='{{url("$lang/farm/$farm->fm_slug")}}' class="block_link"></a>
                                     <div class="top_box">

                                        <div class="share_">
                                           <div class="icon icon-graphics-icon-share" ></div>
                                        </div>
                                     </div>
                                    @php
                                       $share_url = urlencode(url("$lang/farm/$farm->fm_slug"));
                                    @endphp
                                    @include('frontend.partials.farm_social_share')
                                     <div class="crop_details_box">
                                        <div class="crop_icon">
                                           <img  class="img_auto source_" /> 
                                        </div>
                                        <div class="crop_text_"></div>
                                     </div>
                                     <div class="bottom_box">
                                        <div class="location_">
                                           <div class="icon icon-graphics-icon-location-03"></div>
                                           <div class="text_">{{$farm->fm_state_name}}</div>
                                        </div>
                                     @if($farm->crops->count() > 3)
                                        <div class="crops_box w_slick" data-crop-slider='true'>
                                     @else
                                        <div class="crops_box">
                                     @endif
                                        
                                               @foreach($farm->crops as $farm_crop)
                                               <div class="crop_">
                                                  <a href="#" class="inner_ mg-tooltip" data-title="{{ $farm_crop->agriculture_title }}">
                                                     <img src="{{ get_crop_image($farm_crop->agriculture_icon) }}" />
                                                  </a>
                                               </div>
                                               @endforeach
                                        </div>
                                             
                                    </div>
                                    <div class="img b-lazy resourceBig" data-src="{{get_farm_image($farm->fm_main_image)}}"></div>
                                    </div>
                                     <a href='{{url("$lang/farm/$farm->fm_slug")}}' class="details_box">
                                         <div class="info_box">
                                            <div class="f_name">{{ $farm->fm_title }}</div>
                                            <div class="f_area">{{ toAcre($farm->fm_area,$farm->fm_area_unit)  }}</div>
                                         </div>
                                         <div class="amount_box">
                                            <div class="currency">$</div>
                                            <div class="amount_">
                                               <span>{{ $farm->fm_price }}</span>
                                               <span class="small_">per month</span>
                                            </div>
                                         </div>
                                      </a>
                                </div>
                                  
                           </div>
                       @endforeach
                       </div>
                     </aside>

                  </div>

               </div>
       
        </div>
      
   </section>

</main>
@stop