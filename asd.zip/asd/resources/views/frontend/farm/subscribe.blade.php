<div class="col-lg-12 col-xl-5 side_bar sticky-sidebar">
<aside class="book_box ">
   <div class="header_">
	  <div class="text_">{{ lang('subscribe_this_farm') }}</div>
	  <div class="meta_">
		 <span class="nice_">From</span>
		 <div class="amount_">
			<span>$ {{$farmDetails->fm_price}}/month</span>
			
		 </div>
	  </div>
   </div>
{!! Form::open(['method' => 'POST', 'url' => url('farm-subscribe' ), 'id'=>'farm-subscribe','files'=>true] ) !!}
<div class="aj_loader" id="subscribe_loader">
    <div class="loader_wrapper">
    <div class="shape shape1"></div>
    <div class="shape shape2"></div>
    <div class="shape shape3"></div>
    <div class="shape shape4"></div>
    </div>

    <div class="msg" id="subscribe_success_msg">
    </div>
</div>
<div class="book_inner">
      <input type="hidden" name="farm_id" id="farm_id" value="{{$farmDetails->fm_id}}">  
	  <div class="inner_block_">
	  <div class="area_box">
			<div class="crop_popup lg_box" id="location_box">
				<div class="inner_">
					<div class="popup_header">
						<div class="ploat_">{{ lang('change_location') }}</div>
						<div class="icon icon-ios-close-empty close_btn"></div>
					</div>
					<input type="hidden" value="0" id="change_loc_status" name="change_loc_status">
					<div class="input-box-row">
						<div class="input_box">
							<label>{{ lang('full_name') }}</label>
							<input type="text" class="form-control" name="delivery_full_name"  id="delivery_full_name"/>
							<label class="error" id="dfn_err" style="display:none;"></label>
						</div>
						<div class="input_box">
							<label>{{ lang('phone_number') }}</label>
							<input type="text" class="form-control" name="delivery_ph_no"  id="delivery_ph_no"/>
							<label class="error" id="dpn_err" style="display:none;"></label>
						</div>
						<div class="input_box full_">
							<label>{{ lang('address') }}</label>
							<textarea  class="form-control" name="delivery_address"  id="delivery_address"></textarea>
							<label class="error" id="da_err" style="display:none;"></label>
						</div>
						<div class="input_box">
							<label>{{ lang('country') }}</label>
							<select class="select_"  name="delivery_country_id"  id="delivery_country_id" >
								<option value="{{$farmDetails->country->country_id}}" selected>{{$farmDetails->country->country_name}}</option>
							</select>
						</div>
						<div class="input_box">
							<label>{{ lang('city') }}</label>
							<input type="text" class="form-control" name="delivery_city"  id="delivery_city"/>
							<label class="error" id="dc_err" style="display:none;"></label>
						</div>
						<div class="input_box">
							<label>{{ lang('pincode') }}</label>
							<input type="text" class="form-control" name="delivery_zip"  id="delivery_zip"/>
						</div>
						
					</div>
					
					<div class="total_wrapper  align-items-center">
					

						<div class="btn_wrapper text-center"><a href="#" class="btn-style2 " id="confirm_loc_change">Change</a></div>

					</div>
				</div>

				</div>
			</div>
		 <div class="input-row mg_b_1">
			
			<div class="input-box">
			   <label class="sub-title-light">{{ lang('select_date') }}</label>
			   
               <div class="input-box-wrap input-border icon_">
				   <input class="form_control start_date" readonly type="text" value="" placeholder="Select Date" name="start_date" id="start_date">
				   <div class="icon icon-graphics-icon-calendar"></div>
               </div>
			</div>
			<!-- <div class="input-box">
			   <label class="sub-title-light">{{ lang('select_no_of_plots') }}</label>
			   <div class="select-box-wrap select-border" id="plot_no_options">
				  <select class="select_ subs_price" name="plots_no" id="plots_no">
					 <option label="blank" value="">Select Number of Plots</option>
                        
				  </select>
			   </div>
			</div> -->
			<div class="input-box">
			   <label class="sub-title-light">{{ lang('select_duration') }}</label>
			   <div class="select-box-wrap select-border">
				  <select class="select_ subs_price" name="subs_duration" id="subs_duration">
                  @if(!empty($farmDetails->fm_start_date) && !empty($farmDetails->fm_start_date))
                      @php $duration = get_months_duration($farmDetails->fm_start_date,$farmDetails->fm_end_date);
                            
                      @endphp
                         <option label="blank" value="">Select Duration</option>
                         @for($fm_duartion=1;$fm_duartion<=$duration;$fm_duartion++)
                            @php $mn_txt = "month"; if($fm_duartion > 1){$mn_txt = "months";} @endphp
                            <option value="{{$fm_duartion}}">{{$fm_duartion}} {{$mn_txt}}</option>
                         @endfor
                  @endif          
				  </select>
			   </div>
			</div>

		 </div>
		 <div class="input-row">
			
		 	<div class="input-box">
			   <label class="sub-title-light">{{ lang('select_no_of_plots') }}</label>
			   <div class="select-box-wrap select-border">
				  <select class="select_ subs_price" name="plots_no" id="plots_no">
					 <option label="blank" value="">Select Number of Plots</option>
                     @if($farmDetails->plots_available > 0)
                         @for($plot_no=1;$plot_no<=$farmDetails->plots_available;$plot_no++)
                            <option value="{{$plot_no}}">{{$plot_no}}</option>
                         @endfor
                     @endif           
				  </select>
			   </div>
			</div>
			<div class="input-box">
			   <label class="sub-title-light">{{ lang('farming_type') }}</label>
			   <div class="select-box-wrap select-border">
				  <select class="select_" name="farm_type" id="farm_type">
					 <option label="blank" value="">Farming Type</option>
					 <option value="1">Organic</option>
					 <option value="2">Inorganic</option>
					 <!-- <option value="3">Other</option> -->
											   
				  </select>
			   </div>
			</div>

		 </div>

	  </div>
	  <div class="inner_block_">
		 <label class="sub-title-light">{{ lang('select_crops') }}</label>
    @if(isset($farmDetails->crops) && $farmDetails->crops->count() > 0)
		 <div class="checkboxes-inline ">
        @foreach($farmDetails->crops as $farmCrop)
			<div class="checkboxes ">
			   <input id="subs_crop-{{ $farmCrop->agriculture_id }}" type="checkbox" name="subs_crop[]" value="{{ $farmCrop->agriculture_id }}" class="crops_arr" >
			   <label for="subs_crop-{{ $farmCrop->agriculture_id }}"><span>{{ $farmCrop->agriculture_title }}</span></label>
			</div>			
		@endforeach	
		 </div>
    @endif         
	  </div>
	 <div class="inner_block_">
		 <div class="agree_dev">
			<div class="checkboxes ">
			   <input id="home_delivery" type="checkbox" name="home_delivery" value="1">
			   <label for="home_delivery"><span>{{ lang('need_home_delivery') }}<a href="#" class="booking_wrap_popup" data-source="#location_box">({{ lang('change_location') }})</a><i class="tip tooltip-top icon icon-help2 " title="Change Location"> </i></span></label>
			</div>
			
		 </div>
		<div class="total_wrapper  align-items-center">
			<div class="grand_total">
				<div class="amount_">
					<span class="lg_ text-red calc_amount" >$ {{$farmDetails->fm_price}}</span>
					<span>/ month</span>
				</div>
                
				<div class="info_ subs_price_section" style="display:none;">Total $ <span class="calc_amount_6month" id="subs_total_price">{{$farmDetails->fm_price}}</span> for <span id="subs_total_months">1 month </span></div>
			</div>

			<div class="btn_wrapper text-center"><input type="submit" class="btn-style2 " id="farm_subscribe_submit" value="Subscribe"></div>

		</div>

	 </div>
 </div>
 {{ Form::close() }}
	<div class="footer_">
		<!-- <a href="mailto:{{$farmDetails->owner->user_email}}" class="link_"> -->
		<a href='{{url("$lang/farm-owner/$farmDetails->fm_owner_id")}}' class="link_">
			<span>{{ lang('contact_farm_owner') }}</span>
			<div class="icon_">
				<img class="img_auto" src="{{ asset('assets/frontend/images/icon-chat.svg') }}" />
			</div>
		</a>
	 </div>

</aside>

</div>