<div class="col-md-12 col-lg-5 side_bar sticky-sidebar">
    <aside class="book_box ">
        <div class="header_">
            <div class="text_ ">{{ lang('subscribe_this_farm') }}</div>
            <!-- <div class="meta_">
                <span class="nice_">From</span>
                <div class="amount_">
                    <span>$ 15/month</span>

                </div>
            </div> -->
        </div>
        <div class="aj_loader" id="subscribe_notify_loader">
            <div class="loader_wrapper">
                <div class="shape shape1"></div>
                <div class="shape shape2"></div>
                <div class="shape shape3"></div>
                <div class="shape shape4"></div>
            </div>

            <div class="msg" id="subscribe_notify_success_msg">
            </div>
        </div>
        <div class="book_inner">
            <label class="title-light text-red">{!! lang('farm_not_available_to_subscribe') !!}</label>
        </div>
        <div class="footer_ with_tool">
            <a href='{{url("$lang/farm-owner/$farmDetails->fm_owner_id")}}' class="link_">
                <span>Contact farm owner</span>
                <div class="icon_">
                    <img class="img_auto" src="{{ asset('assets/frontend/images/icon-chat.svg') }}" />
                </div>
            </a>
            <div class="btn_wrapper text-center"><button type="submit" href="#" class="btn-style2 " id="availability_notify">Notify me when available</button></div>
        </div>

    </aside>

</div>