<!-- dateDropper lib -->
<script src="{{ htmlAsset('scripts/vendor/package/datedropper.js') }}"></script>
<script type="text/javascript">
	function CaptchaCallback() {
	    $('.g-recaptcha').each(function () {
	        grecaptcha.render(this, {
	            'sitekey': '6LduzggUAAAAAEFpHflbMn2MhApiYPpvvEmaqp4D',
	            'lang': 'en',
	        });
	    });
	};
	// captcha


	$(function() {
		

		
		 // $( ".daterangepicker" ).dateDropper();  
		 var date_list = [
		 	"2019-01-14",
		 	"2019-01-15",
		 	"2019-01-5",
		 	"2019-01-1",
		 	"2019-01-2",
		 	"2019-01-16",
		 	"2019-01-22",
		 	"2019-01-22",
		 	"2019-01-24",
		 	"2019-01-25",
		 	"2019-01-27",
		 	"2019-01-30",
		 	"2019-01-06",
		 	"2019-01-14",
		 	"2019-01-10",
		 	"2019-01-08",
		 	"2019-01-09",
		 	"2019-01-19",
		 	"2019-01-21",
		 	"2019-02-22",
		 	"2019-02-10",
		 	"2019-02-11",
		 	"2019-02-17",
		 	"2019-02-15",
		 	"2019-02-06",
		 	"2019-02-07",
		 	"2019-02-08",
		 	"2019-02-09", 

		 	];
		 $( ".available_date_picker" ).datepicker({
		    dateFormat: "MM dd, yy",
		    showOtherMonths: true,
		    selectOtherMonths: true,
		    onSelect: function () {
		   
		    },
		    minDate: 0,
		    beforeShowDay: function(date){
		        var string = jQuery.datepicker.formatDate('yy-mm-dd', date);
		        return [ date_list.indexOf(string) == -1 ]
		    },
		});	
		 
		 $('.ck_in').dateDropper();
		 $('.ck_o').dateDropper();
		$('.booking-date').dateDropper();

		 $( ".available_date_picker_two_month" ).datepicker({
		    dateFormat: "MM dd, yy",
		    showOtherMonths: true,
		    selectOtherMonths: true,
		    numberOfMonths: 2,		    
		    onSelect: function () {
		   
		    },
		    beforeShowDay: function(date){
		        var string = jQuery.datepicker.formatDate('yy-mm-dd', date);
		        return [ date_list.indexOf(string) == -1 ]
		    },
		  	minDate: 0,
		   /* maxDate: '+1w',*/		    
		});	

		  $('.select_').selectric();

		  window.crop_select_box = $('.crop_select_box_with_icon').prettyDropdown({
		    afterLoad: function() {		       
		    }
		  });

		 // Sidebar sticky
		  $('.sticky-sidebar').stickit({
	          screenMinWidth: 1050,
	          top: 120
	    });
		 // Sidebar sticky
		  $('.sticky-sidebar-top100').stickit({
	          screenMinWidth: 1050,
	          top: 100
	    });


		    

	});
</script>