<!DOCTYPE html>
<html lang="{{ @$lang }}" dir="{{ (@$lang=='ar')?'rtl':'ltr' }}" class="{{ (@$lang=='ar')?'rtl':'ltr' }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	@section('seoPageTitle')
		<title>{{ (!empty($pageTitle))?trim($pageTitle):trim(@$seoPageTitle)  }}</title>
	@show
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, initial-scale=1, user-scalable=no, maximum-scale=1.0">
    <meta name="robots" content="nofollow" />
	<meta name="gCaptchaKey" content="{{ @$websiteSettings->googleCaptchaSiteKey }}" />	

	@if(isset($farmDetails))
	<meta property="og:title" content="{{ $farmDetails->fm_title }}" />
	<meta property="og:description" content="{!! $farmDetails->fm_about_farm !!}" />
	<meta property="og:image" content="{{get_farm_large_image($farmDetails->fm_main_image)}}" />
	<meta property="og:url" content='{{url("$lang/farm/$farmDetails->fm_slug")}}' />

	<!-- For Twitter -->
	<meta name="twitter:card" content="summary" />
	<meta name="twitter:title" content="{{ $farmDetails->fm_title }}" />
	<meta name="twitter:description" content="{!! $farmDetails->fm_about_farm !!}" />
	<meta name="twitter:image" content="{{get_farm_large_image($farmDetails->fm_main_image)}}" />
	@endif

	<?php /*<link rel="preload" href="{{ htmlAsset('images/logo-en.svg') }}" as="image"> */ ?>
    <link rel="shortcut icon" href="{{ htmlAsset('images/favicon.png') }}"> 

	@section('styles')
		@include('frontend.layouts.cssfiles')
	@show
	<script>
		
		window._token = {!! json_encode([
			'csrfToken' => csrf_token(),
		]) !!};
		window.baseURL = "{{ asset('/') }}";
		window.isMobile = {{ (Agent::isMobile() === true ) ? 'true' : 'false' }};
		window.siteLang = "{{ trim($lang) }}";
		window.request = "{{ asset('/'.$lang) }}/";
		var recaptcha = [];
		var recaptchaArr = [];
		var _isValidUser = {{ (!Auth::user() || Auth::user()->isAdmin()) ? 'false' : 'true' }};
				
		function resetRecaptcha(){
			$(recaptchaArr).each(function(i,v){
			   grecaptcha.reset(v.obj);
			});
		}
		
		function haveRecaptchaResponse(elemID){
			var hasResponse = false;
			$(recaptchaArr).each(function(i,v){
			   if(v.ID == elemID){
					if(grecaptcha.getResponse(v.obj) != ''){
						hasResponse = true;
					}
			   }
			});
			return hasResponse;
		}
		
    </script>
</head>
<body  class="<?php echo @$lang; echo (!empty($isHomePage) ? ' home ' :' inner__page ');echo (!empty($isSearchPage) ? ' __place-list ' :'') ?> {{ (!empty($bodyClass))?$bodyClass:''}}" >
 <!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
	@include('frontend.layouts.preloader')
	<header>
		<div class="container header-container">
			@include('frontend.layouts.topnav')
		</div>	
	</header>
	
		@yield('content')

		@include('frontend.layouts.footer')
        @include('frontend.layouts.user_modal')
		
	</main>
	@section('scripts')
		@include('frontend.layouts.jsfiles')
	@show


<script>
	var selected_auto_word = $('.auto_search_key').val();
	var current_auto_word = $('.auto_search_key').val();
	var width_word = $('.auto_search_key').val();
	$( ".auto_search_key" ).keyup(function(e) {
		
		var search_key = $('.auto_search_key').val();
		var lastword = search_key.split(" ").pop();


		var lastIndex = search_key.lastIndexOf(" ");
		current_auto_word = search_key.substring(0, lastIndex);

		//current_auto_word = search_key.replace(lastword,'');
		// if(e.keyCode == 8 || e.keyCode == 46){
		// 	width_word = search_key.replace(lastword,'');
		// }
		$('.auto_suggest_width').text(current_auto_word);
		FarmsGate_.search_suggestion();		
		var _data = {
					'_token':'{{csrf_token()}}',
					'search_key':lastword,					
					}
		sendAjax("{{ url('/api/auto_complete') }}",'GET',_data,function(data){
			var auto_suggest_data = '';
			var suggestions = data.suggest.autocomplete[0].options;

			if(suggestions.length > 0){
				$('.floating_suggestion_wrapper').addClass('show_');
			}
			else{
				$('.floating_suggestion_wrapper').removeClass('show_');
			}

			$(suggestions).each(function(suggestion_key,suggestion){
				auto_suggest_data += '<li class="suggest_li">'+suggestion.text+'</li>';
			});
			$('.auto_suggest_options').html(auto_suggest_data);
		});
	});
	$('body').on('click','.suggest_li',function(e) {
		
		$('.floating_suggestion_wrapper').removeClass('show_');	
		if(current_auto_word!=''){	
			current_auto_word = current_auto_word+' '+$(this).text();
		}else{
			current_auto_word = current_auto_word+$(this).text();
		}
		$('.auto_search_key').val(current_auto_word);
		$('.auto_suggest_width').text(current_auto_word);
		/*$(".auto_search_key").val(function() {
			return this.value + selected_auto_word;
		});*/

		FarmsGate_.search_suggestion();
	});
</script>
</body>
</html>