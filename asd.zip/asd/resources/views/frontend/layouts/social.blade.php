<ol class="fl-social">
    @if(!empty(@$websiteSettings->facebook_link))
		<li>
			<a href="{{@$websiteSettings->facebook_link}}" target="_blank" class="browser-window__link">
				<i class="icon icon-fb"></i>
			</a>
		</li>
	@endif
	
	@if(!empty(@$websiteSettings->youtube_link))
		<li>
			<a href="{{@$websiteSettings->youtube_link}}" target="_blank" class="browser-window__link">
				<i class="icon icon-youtube"></i>
			</a>
		</li>
	@endif
	
	@if(!empty(@$websiteSettings->twitter_link))
		<li>
			<a href="{{@$websiteSettings->twitter_link}}" target="_blank" class="browser-window__link">
				<i class="icon icon-twitter"></i>
			</a>
		</li>
	@endif
	
	@if(!empty(@$websiteSettings->instagram_link))
		<li>
			<a href="{{@$websiteSettings->instagram_link}}" target="_blank" class="browser-window__link">
				<i class="icon icon-insta"></i>
			</a>
		</li>
	@endif
    
</ol>