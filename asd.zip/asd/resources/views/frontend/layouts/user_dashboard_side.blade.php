<div class="side_bar">
    <aside class="dashboard-nav ">
      <div class="dashboard-nav-inner" style="max-height: 714px;">
        <ul>

          <li class="active">
            <a href="{!! url($lang.'/user/dashboard'); !!}"><i class="icon icon-graphics-user-dashboard"></i> 
            <span class="text_">Dashboard</span>
            </a>
          </li>

          <li>
            <a href="{!! url($lang.'/user/farm-subscriptions'); !!}"><i class="icon icon-graphics-user-subscribe"></i> 
            <span class="text_">Subscribed Farms</span></a>
          </li>

          <li>
            <a href="{!! url($lang.'/user/owned-farm-subscriptions'); !!}"><i class="icon icon-graphics-user-subscribe-list"></i> 
            <span class="text_">My Farm Subscribers</span></a>
          </li>

          <li>
            <a href="{!! url($lang.'/user/notifications'); !!}"><i class="icon icon-graphics-user-notification"></i> 
            <span class="text_">Notifications @if($unread_notifications)<span class="nav-tag messages">{{$unread_notifications}}</span>@endif</span></a>
          </li>

          <li>
            <a href="{!! url($lang.'/user/favorite-farms'); !!}"><i class="icon icon-graphics-user-fav"></i> 
            <span class="text_">My Favorites</span></a>
          </li>

          <li>
            <a href="{!! url($lang.'/user/reviews'); !!}"><i class="icon icon-graphics-user-reviews"></i> 
            <span class="text_">Reviews</span></a>
          </li>

          <li>
           <a href="{!! url($lang.'/user/settings'); !!}"><i class="icon icon-graphics-user-settings"></i> 
           <span class="text_">User Settings</span></a>
          </li>

        </ul>
      </div>
    </aside>
</div>
@section('scripts')
@parent
<script>
$('.inner__page').addClass('__user_dashboard');

   $(function(){
   
        var url = window.location.pathname;
 
        var urlRegExp = new RegExp(url.replace(/\/$/,'') + "$"); 
      
       $('.dashboard-nav-inner li a').each(function(){
            $(this).parent().removeClass('active');
           if(urlRegExp.test(this.href.replace(/\/$/,''))){
               $(this).parent().addClass('active');
           }
       });

    });     
   
   
</script>
@stop