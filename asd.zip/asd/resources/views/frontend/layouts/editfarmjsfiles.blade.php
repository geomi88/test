<!-- Scripts -->
<script src="https://www.google.com/recaptcha/api.js?onload=CaptchaCallback&render=explicit&hl=en" async defer></script>

@include('frontend.layouts.date_dropperfiles')

<script type="text/javascript" src="{{ htmlAsset('scripts/vendor/package/chosen.min.js') }}"></script>
<!-- Maps -->
<script type="text/javascript" src="{{ htmlAsset('scripts/vendor/package/markerclusterer.js') }}"></script>

<script type="text/javascript" src="https://twitter.github.io/typeahead.js/releases/latest/typeahead.bundle.js"></script>
<script type="text/javascript" src="{{ htmlAsset('scripts/vendor/bootstrap-tagsinput.min.js') }}"></script>
<!-- DropZone | Documentation: http://dropzonejs.com -->


<script type="text/javascript" src="{{ htmlAsset('scripts/vendor/jquery-ui.multidatespicker.js') }}"></script>
<!-- Initialize Swiper -->
<script>
   $(function() {   
      //Dropzone.autoDiscover = false;
      var acceptedFileTypes = "image/*"; //dropzone requires this param be a comma separated list
      var fileList = new Array;
      var i = 0;

          

      //multi datepicker
      $('.multi_date').multiDatesPicker({
         minDate: 0,
      });

      //Plot split change event
      $('.plot_split_choose').selectric({ 
         onChange: function() {
             var this_ = $(this)
                  value_ = this_.val(),
                  template = '<div class="split_"></div>';
                  
               $('.land_split_ ').removeClass('sp_1 sp_2 sp_4 sp_6 sp_8 ');
               //Clear the plot
               $('.land_split_ ').addClass('sp_'+value_);
               $('.land_split_ ').empty();
   
               for (var i = 0; i < value_ ; i++) {
                  $('.land_split_ ').append(template);
               }
   
         }
      });
      var countries = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.obj.whitespace('name'),
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        prefetch: {
         url: 'assets/json/facilities.json',
         filter: function(list) {
           return $.map(list, function(name) {
            return { name: name }; });
         }
        }
      });

      $('.multi-select').tagsinput({
       /*typeaheadjs: {
         name: 'countries',
         displayKey: 'name',
         valueKey: 'name',
         source: countries.ttAdapter()
        }  
        typeahead: {
          source: ['Amsterdam', 'Washington', 'Sydney', 'Beijing', 'Cairo'],
          freeInput: true
        } */            
      });
      
   });
   
   function getAspectRatio(){
     //Formula: "Aspect Ratio = Width / Height".
     return aspectRatio = initialWidth/initialHeight;
   };
      
   function readURL(input) {
   
         if (input.files && input.files[0]) {
   
             var reader = new FileReader();
   
             reader.onload = function (e) {
                var image = new Image(),
                     min_height = 190;
                image.src = e.target.result;

                if($(window).width() < 1500) {
                     min_height = 150;
                }
                  
   
                  image.onload = function() {
                       // access image size here 
                        var initialWidth = this.width,
                            initialHeight = this.height,
                            newWidth,
                            newHeight = min_height,
                            aspectRatio = initialWidth/initialHeight;
   
                           newWidth = Math.round(newHeight*aspectRatio);
   
   
                         //console.log(this.width,this.height,newWidth);
   
                        //Set image preview land
                        $('.m_step_ .land_map').css('width',newWidth);
   
                        //Image preview
                        $('.land_map > .img_ ').css({'background-image':'url('+this.src+')'});
                       
                   };
             };
   
             reader.readAsDataURL(input.files[0]);
         }
   }
                 
   
   var menu = ['Farm Name', 'Type of Farm', 'Location of the farm', 'Plots', 'Suitable Crops', 'Facilities', 'Quick Facts', 'Reports', 'About', 'Gallery', 'Others'];
   
   
   $(function() {      

      //Save button click
      $('.save_button').on('click', function(e) {
            e.preventDefault();
            /*

            if(swiper.slides.length == ( swiper.activeIndex + 1)) {
               $('.multi_form_page ').addClass('form_complete');
            }
            */
      });
   });
      
</script>
@include('frontend.script.map_script')
