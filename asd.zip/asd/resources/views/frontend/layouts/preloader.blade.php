<div class="loader">
    <div class="loader-block">
        <div class="loader-img">
            <img src="{{ htmlAsset('images/loader-logo.png') }}" alt="">
        </div>
        <div class="linePreloader"></div>
    </div>
</div>