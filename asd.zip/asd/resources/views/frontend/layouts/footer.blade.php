<footer>
    <a href="#" class="scrollToTop">
        <i class="icon icon-android-arrow-up"></i>
    </a>
  <div class="container-fluid">
    <div class="inner center">
       
        <ul class="copyRightText">
            <li>Contact : <a href="mailto:info@pgsuae.com.com?Subject=Info%20Inquiry" target="_top">info@pgsuae.com </a></li>
            <li class="sep"> | </li>
            <li>Copyright © 2019 Farm’s Gate. All rights reserved.</li>
        </ul>


    </div>
  </div>
</footer>