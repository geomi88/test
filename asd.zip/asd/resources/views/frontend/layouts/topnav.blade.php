<nav class="navbar navbar-expand-lg navbar-light static-top">
  <div class="header-inner-container ">
	<a class="navbar-brand" href="{{ asset($lang) }}/home">
				  <img class="logo-primary" src="{{ htmlAsset('images/logo.png') }}" alt="">
				  <img class="logo-secondry" src="{{ htmlAsset('images/logo-invert.png') }}" alt="">
				</a>
	
	<?php if(!$isHomePage) {?>
        <div class="searchBoxWrapper">
            {!! Form::open(['method' => 'POST', 'url' => "$lang/search",'class'=>'searchform cf', 'id'=>'farm-search','files'=>true] ) !!}
                
               <input type="text" class="cf-feild auto_search_key" placeholder="Search here" name="search_key" id="search_key" autocomplete="off" @if(!empty(Session::get('search_keyword'))) value="{{ Session::get('search_keyword') }}" @endif >
               <span class="auto_suggest_width"></span>              
               <input type="hidden" name="ft" id="ft" @if(!empty($ft)) value="{{ $ft }}" @endif >
			   <input type="hidden" name="search_key_set" id="search_key_set" @if(!empty($search_key)) value="{{ $search_key }}" @endif >
              <span class="search-icon"></span>
              <input type="submit"  class="cf-button" value="Search" name="farmbtnsubmit" id="farmsearchbtn">
              	<div class="floating_suggestion_wrapper">
					<ul class="auto_suggest_options">
						
					</ul>
				</div>  
            {{ Form::close() }}


        </div>
    <?php }?>
	<div class="collapse navbar-collapse" id="navbarResponsive">
        
	  <ul class="navbar-nav ml-auto">
 
		<li class="nav-item">
		  <a href="{{ asset($lang) }}/home" class="nav-link ">{{ lang('for_farmers') }}</a>
		</li>
		 <li class="nav-item">
		  <a href="{{ asset($lang) }}/home" class="nav-link "  data-href="#4">{{ lang('for_farm_lovers') }}</a>
		</li>
		 <li class="nav-item">
		  <a href="#" class="nav-link "  data-href="#5">{{ lang('help') }}</a>
		</li>
        
       
		@if (!Auth::check())
        
		<li class="nav-item loginButton">
		  <a href="{!! url($lang.'/farm-signup'); !!}" class=" btn btn-small btn-round">{{ lang('login') }}</a>
		</li>
        @endif
        
	  </ul>
	</div>
	@if (Auth::check())
      
        <div class="user_menu">
             <!-- User Menu -->
            
            <div class="dropdown">
              <span class="logged-control dropdown-toggle " id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">                                       
                 
                  <img class="userImg" src="{{ get_profile_image(Auth::user()->user_avatar) }}">
              </span>
              <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
				<span class="name_">{{ Auth::user()->user_full_name }}</span> 
				<a class="dropdown-item" href="{!! url($lang.'/user/dashboard'); !!}">Dashboard</a>
				<a class="dropdown-item" href="{!! url($lang.'/farm-signup'); !!}">{{ lang('add_farm') }}</a>
                <a class="dropdown-item" href="{!! url($lang.'/user/notifications'); !!}">Notifications</a>
                <a class="dropdown-item" href="{!! url($lang.'/logout'); !!}">Logout</a>      
              </div>
            </div>
            <!-- User Menu -->
		</div>
		@if(isset($unread_notifications))
		<div class="navElementsWrap">
			<span class="navbar-text notificationButton">
				<a href="{!! url($lang.'/user/notifications'); !!}" class="cd-signin">
				@if($unread_notifications)
				<span class="notificationCount">{{$unread_notifications}}</span>
				@endif
				<i class="icon icon-graphics-icon-notification"></i>
				</a>		   
			</span>
		</div>
		@endif
	@endif	
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
	  <span class="navbar-toggler-icon"></span>
	</button>
  </div>
</nav>