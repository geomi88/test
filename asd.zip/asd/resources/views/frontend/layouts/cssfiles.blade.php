<style type="text/css">
.loader {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 99999999;
        background: #f9f9f9;
        transition: 1s ease;
        margin:0;
    }

    .is-loaded .loader {
        opacity: 0;
        visibility: hidden;
    }
</style>
@if(!empty($isHomePage))
{{ HTML::style('assets/frontend/styles/main.css') }}
@else
{{ HTML::style('assets/frontend/styles/page.css') }}
@endif

<script src="{{ htmlAsset('scripts/lib/modernizr.min.js') }}"></script>  
  
 