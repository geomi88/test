<?php 
	$mainLogo = @$websiteSettings->sitelogo_english;
	$subLogo = @$websiteSettings->sitelogo_arabic;
	$changeLang = ($lang=='ar')?'en':'ar';

?>
<header id="header">
	<nav class="navbar navbar-expand-lg navbar-light">
		<div class="container"> 
			<a class="navbar-brand primary active" target="_blank" href="{{ route('home',$lang) }}">
				<img class="logo-color" src="{{ asset('assets/frontend/dist/images/logo-govt.svg') }}" alt="">
				<img class="logo-white" src="{{ asset('assets/frontend/dist/images/logo-govt.svg') }}" alt=""> 
			</a>
			<a class="navbar-brand secondary" href="{{ route('home',$lang) }}">
				<img src="{{ asset('assets/frontend/dist/images/logo-en.svg') }}" alt="">
			</a>
			
			<ul class="quick-menu">
				<li><a href="{{ route('page',[$lang,'about']) }}">{{ trans('messages.about') }}</a></li>
				<li><a href="{{ route('register',$lang) }}">{{ trans('messages.register') }}</a></li>
				<li class="menuToggle">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-main" aria-controls="navbar-main" aria-expanded="false" aria-label="Toggle navigation">
                        <div>
                            <div class="shape-o">
                                <div class="diamond">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                                <div class="text">{{ trans('messages.menu') }}</div>
                            </div>
                            <div class="shape-c">
                                <svg width="40px" height="40px" x="0px" y="0px" viewBox="0 0 148 148" enable-background="new 0 0 148 148" xml:space="preserve">
                                <path d="M79.628,75.82l41.963-41.963c1.88-1.88,1.88-4.927,0-6.807c-1.88-1.88-4.927-1.88-6.807,0L72.821,69.014L30.858,27.058
                                    c-1.88-1.88-4.927-1.88-6.807,0c-1.88,1.88-1.88,4.927,0,6.807l41.963,41.963l-41.956,41.956c-1.88,1.88-1.88,4.927,0,6.807
                                    c0.943,0.937,2.168,1.411,3.4,1.411s2.463-0.468,3.4-1.411l41.963-41.963l41.963,41.963c0.943,0.937,2.168,1.411,3.4,1.411
                                    c1.232,0,2.463-0.468,3.4-1.411c1.88-1.88,1.88-4.927,0-6.807L79.628,75.82z"/>
                                </svg>
                            </div>   
                        </div>
                    </button>
                </li>
				@if(!Auth::user())
					<li><a href="{{ route('member_login',$lang) }}">{{ trans('messages.login') }}</a></li>
				@else
					<li><a href="{{ route('logout',$lang) }}">{{ trans('messages.logout') }}</a></li>
				@endif
				<?php /* 
					<!-- <li><a href="#">Logout</a></li> -->
				<li class="loginDropdownBtn dropdown">
                    <!-- <a href="#"><i class="icon icon-user"></i></a> -->
                    <button class="btn_" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <!-- <i class="icon icon-user"></i>  -->{{ trans('messages.login') }}
                  </button>
                  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="#">Logout</a>
                    <a class="dropdown-item" href="#">Dashboard</a>
                    
                  </div>
                </li> */ ?>
                <li class="langSwitch border-btn">
					<?php 
						$hrefLang = 'en';	
						$label = 'EN';
						if($lang == 'en'){
							$hrefLang = 'ar';	
							$label = 'ع';
						}
						
					?>
					<a class="btn_" href="{{ asset('/language/'.$hrefLang).'?redirect_url='.$currentURI }}">
						<span>{{ $label }}</span>
					</a>
            </li>
			</ul>
		</div>
		<div class="collapse navbar-collapse" id="navbar-main">
			<div class="nav-close">&#x2715;</div>
			<div class="navbar-inner">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item active"><a class="nav-link" data-href="#banner" href="{{ route('home',$lang) }}">{{ trans('messages.home') }}</a></li>
					<li class="nav-item"><a class="nav-link" data-href="#about" href="{{ route('page',[$lang,'about']) }}">{{ trans('messages.about') }}</a></li>
					<li class="nav-item"><a class="nav-link" data-href="#participation" href="{{ route('discussion_forum',$lang) }}">{{ trans('messages.discussion_forum') }}</a></li>
					<li class="nav-item"><a class="nav-link scroll" data-href="#policy-idea" href="#policy-idea">{{ trans('messages.policy_idea') }}</a></li>
					<!--<li class="nav-item lang_Switch"><a class=" nav-link" href="">EN</a></li>-->
				</ul>
				<div class="nav-image-section">
                        
                        <svg class="menuBgsvg" id="Layer_1"  x="0px" y="0px"
     viewBox="0 0 795 555" enable-background="new 0 0 795 555" xml:space="preserve">
                            <g class="menuImgBgSec menuImgBgSec1">
                                <g>
                                    <defs>
                                        <rect id="SVGID_1_" x="170.833" y="3.799" width="620.667" height="269.068"/>
                                    </defs>
                                    <clipPath id="SVGID_2_">
                                        <use xlink:href="#SVGID_1_"  overflow="visible"/>
                                    </clipPath>
                                    <g id="NtOnC1_1_" clip-path="url(#SVGID_2_)">
                                        <image overflow="visible" width="800" height="560" xlink:href="{{ asset('assets/frontend/dist/images/menuBgImg.jpg') }}"  transform="matrix(1 0 0 1 -3 -3)">
                                        </image>
                                    </g>
                                </g>
                                <rect x="771.5" y="167.867" fill="#E2804F" width="20" height="105"/>
                            </g>
                            <g class="menuImgBgSec menuImgBgSec2">
                                <g>
                                    <defs>
                                        <rect id="SVGID_3_" x="4.833" y="281.799" width="620.667" height="269.068"/>
                                    </defs>
                                    <clipPath id="SVGID_4_">
                                        <use xlink:href="#SVGID_3_"  overflow="visible"/>
                                    </clipPath>
                                    <g id="NtOnC1_2_" clip-path="url(#SVGID_4_)">
                                        <image overflow="visible" width="800" height="560" xlink:href="{{ asset('assets/frontend/dist/images/menuBgImg.jpg') }}"  transform="matrix(1 0 0 1 -3 -2.2005)">
                                        </image>
                                    </g>
                                </g>
                                <rect x="4.833" y="445.867" fill="#E2804F" width="20" height="105"/>
                            </g>
                            </svg>
                        
                </div>
			</div>
		</div>
	</nav>
</header>