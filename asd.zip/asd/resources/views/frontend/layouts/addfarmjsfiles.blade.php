<!-- Scripts -->
<script src="https://www.google.com/recaptcha/api.js?onload=CaptchaCallback&render=explicit&hl=en" async defer></script>

@include('frontend.layouts.date_dropperfiles')

<script type="text/javascript" src="{{ htmlAsset('scripts/vendor/package/chosen.min.js') }}"></script>
<!-- Maps -->
<script type="text/javascript" src="{{ htmlAsset('scripts/vendor/package/markerclusterer.js') }}"></script>

<script type="text/javascript" src="https://twitter.github.io/typeahead.js/releases/latest/typeahead.bundle.js"></script>
<script type="text/javascript" src="{{ htmlAsset('scripts/vendor/bootstrap-tagsinput.min.js') }}"></script>
<!-- DropZone | Documentation: http://dropzonejs.com -->
<script type="text/javascript" src="{{ htmlAsset('scripts/vendor/package/dropzone.js') }}"></script>


<script type="text/javascript" src="{{ htmlAsset('scripts/vendor/jquery-ui.multidatespicker.js') }}"></script>
<!-- Initialize Swiper -->
<script>
   $(function() {   
      //Dropzone.autoDiscover = false;
      var acceptedFileTypes = "image/*"; //dropzone requires this param be a comma separated list
      var fileList = new Array;
      var i = 0;


      
     /* $("#my-dropzone").dropzone({
       addRemoveLinks: true,
       maxFiles: 10, //change limit as per your requirements
       dictMaxFilesExceeded: "Maximum upload limit reached",
       acceptedFiles: acceptedFileTypes,
       dictInvalidFileType: "upload only JPG/PNG",
       init: function () {

           // Hack: Add the dropzone class to the element
           $(this.element).addClass("dropzone");

           this.on("success", function (file, serverFileName) {
               fileList[i] = {
                   "serverFileName": serverFileName,
                   "fileName": file.name,
                   "fileId": i
               };
               $('.dz-message').show();
               i += 1;
           });
           this.on("removedfile", function (file) {
               var rmvFile = "";
               for (var f = 0; f < fileList.length; f++) {
                   if (fileList[f].fileName == file.name) {
                       rmvFile = fileList[f].serverFileName;
                   }
               }

               if (rmvFile) {
                   $.ajax({
                       url: path, //your php file path to remove specified image
                       type: "POST",
                       data: {
                           filenamenew: rmvFile,
                           type: 'delete',
                       },
                   });
               }
           });

       }
   });*/

      //multi datepicker
      $('.multi_date').multiDatesPicker({
         minDate: 0,
      });

      //Plot split change event
      $('.plot_split_choose').selectric({ 
         onChange: function() {
             var this_ = $(this)
                  value_ = this_.val(),
                  template = '<div class="split_"></div>';
                  
               $('.land_split_ ').removeClass('sp_1 sp_2 sp_4 sp_6 sp_8 ');
               //Clear the plot
               $('.land_split_ ').addClass('sp_'+value_);
               $('.land_split_ ').empty();
   
               for (var i = 0; i < value_ ; i++) {
                  $('.land_split_ ').append(template);
               }
   
         }
      });
      var countries = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.obj.whitespace('name'),
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        prefetch: {
         url: 'assets/json/facilities.json',
         filter: function(list) {
           return $.map(list, function(name) {
            return { name: name }; });
         }
        }
      });

      $('.multi-select').tagsinput({
       /*typeaheadjs: {
         name: 'countries',
         displayKey: 'name',
         valueKey: 'name',
         source: countries.ttAdapter()
        }  
        typeahead: {
          source: ['Amsterdam', 'Washington', 'Sydney', 'Beijing', 'Cairo'],
          freeInput: true
        } */            
      });
      
   });
   
   function getAspectRatio(){
     //Formula: "Aspect Ratio = Width / Height".
     return aspectRatio = initialWidth/initialHeight;
   };
      
   function readURL(input) {
   
         if (input.files && input.files[0]) {
   
             var reader = new FileReader();
   
             reader.onload = function (e) {
                var image = new Image(),
                     min_height = 190;
                image.src = e.target.result;

                if($(window).width() < 1500) {
                     min_height = 150;
                }
                  
   
                  image.onload = function() {
                       // access image size here 
                        var initialWidth = this.width,
                            initialHeight = this.height,
                            newWidth,
                            newHeight = min_height,
                            aspectRatio = initialWidth/initialHeight;
   
                           newWidth = Math.round(newHeight*aspectRatio);
   
   
                         //console.log(this.width,this.height,newWidth);
   
                        //Set image preview land
                        $('.m_step_ .land_map').css('width',newWidth);
   
                        //Image preview
                        $('.land_map > .img_ ').css({'background-image':'url('+this.src+')'});
                       
                   };
             };
   
             reader.readAsDataURL(input.files[0]);
         }
   }
                 
   
   var menu = ['Farm Name', 'Type of Farm', 'Location of the farm', 'Plots', 'Suitable Crops', 'Facilities', 'Quick Facts', 'Reports', 'About', 'Gallery', 'Others'];
   if($(window).width() < 1025){
        menu = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11'];
    }
   var swiper = new Swiper('.swiper-container', {
    slidesPerView: 1,
    spaceBetween: 60,
    centeredSlides: true,
    slideToClickedSlide: false,
    autoplayDisableOnInteraction: false,
    preventClicks: true,
    preventClicksPropagation: true,
    touchRatio: 0,
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
        renderBullet: function(index, className) {
            return '<div class="' + className + '">' + (menu[index]) + '<span class="point_"></span></div>';
        },
    },
    breakpoints: {
        1024: {
            
            spaceBetween: 20,
        },
        980: {
            autoHeight: true,
            spaceBetween: 30,
        }
    },
    navigation: {
        nextEl: '.next_nav',
        prevEl: '.back_nav',
    },
    on: {
        init: function() {
         
         setTimeout(function() {
            $('.swiper-pagination').append('<div class="swiper-line_"></div>');
   
            //multi select
            $('.swiper-container .chosen-select').chosen({
                disable_search_threshold: 10,
                width: "100%"
            });
   
            $('.swiper-container .chosen-select').on('change', function(evt, params) { console.log('select'); });
   
         }, 100);
         
        },
    },
   });
   
   swiper.on('slideChange', function () {  
   // blazy re-init
   bLazy.revalidate;
   

   
   var active_index = swiper.activeIndex + 1,
      one_p_value = (1 * 100 / swiper.slides.length),
      calculatePerc = (active_index * 100 / swiper.slides.length),
      current_pe = $('.swiper-percentage .number_').text();
   
      //set completed level
      $('.swiper-pagination .swiper-pagination-bullet').each(function (index, element) {
         //console.log(index,active_index);
         if(index  < active_index) {
            $(this).addClass('done_');
         }else{
            $(this).removeClass('done_');
         }
         
      });

      //Farm house enable
     /* $(".farm_house_check").on('click', function() {
         if($(this).is(':checked')) {
             swiper.appendSlide('<div class="swiper-slide"><div class="m_step_"><div class="inner_"><div class="m_head"><span>Farm house details</span><i class="tip tooltip-top icon icon-help2" title="Maximum of 15 keywords related with your business"> </i><div class="icon icon-graphics-icon-verified verified_"></div></div><div class="form_body"><div class="m_inner_body"><div class="input-box margin-bottom-20"><lable>Description for farm house</lable><textarea name="" class="form-control" row="3"></textarea></div><div class="input-box margin-bottom-20"><lable>Select available dates</lable><div class="multidatepick_"><div class="multi_date" ></div></div></div><div class="input-box"><lable>Upload Images</lable><form action="#" class="dropzone" id="my-dropzone" ></form></div></div><div class="line_bottom" ></div></div></div></div></div>');
         }else{
            $('.swiper-slide').eq(1).remove();
            swiper.update();
         }
      });*/
     

   
   //Set the percentage value
   $('.swiper-percentage .number_').each(function () {
     var $this = $(this);
     
     console.log(active_index, swiper.slides.length);
     if(active_index == swiper.slides.length) {
         one_p_value = 0;

         //save button text change
         $('.save_button').text('Submit Your Farm');

         //Skip button hide
         $('.skip_button').fadeOut();
     }else{
         //save button text change
         $('.save_button').text('Save and Continue');
         //Skip button show
         $('.skip_button').fadeIn();
     }
   
     jQuery({ Counter: current_pe }).animate({ Counter: calculatePerc.toFixed() }, {
       duration: 1000,
       easing: 'swing',
       step: function () {
         $this.text(Math.ceil(this.Counter));
         $('.swiper-line_').css('height',(Math.ceil(this.Counter - one_p_value) )+'%');
       }
     });
   
   
   });
   });
   
   $(function() {
      //Skip button click
      $('.skip_button').on('click', function(e) {
         e.preventDefault();
         var c_index = swiper.activeIndex,
               swiper_pagination = $('.swiper-pagination .swiper-pagination-bullet');
        // console.log(swiper.slides[c_index]);
         $(swiper.slides[c_index]).addClass('skip_');
         $(swiper_pagination[c_index]).addClass('skip_');
         setTimeout(function() {
            //Move to next slide   
            swiper.slideNext();
         },600);
      });

      //Save button click
      $('.save_button').on('click', function(e) {
            e.preventDefault();
            var c_index = swiper.activeIndex,
               swiper_pagination = $('.swiper-pagination .swiper-pagination-bullet');
            //console.log(swiper.slides[c_index]);
            $(swiper.slides[c_index]).removeClass('skip_');
            $(swiper.slides[c_index]).addClass('done_');
            $(swiper_pagination[c_index]).removeClass('skip_');
            $(swiper_pagination[c_index]).addClass('done_');

            setTimeout(function() {
               //Move to next slide   
                  swiper.slideNext();
            }, 600);

            if(swiper.slides.length == ( swiper.activeIndex + 1)) {
               $('.multi_form_page ').addClass('form_complete');
            }
            
      });
   });
      
</script>
@include('frontend.script.map_script')
