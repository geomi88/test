<div class="cd-user-modal"> <!-- this is the entire modal form, including the background -->
    <div class="cd-user-modal-container"> <!-- this is the container wrapper -->

      <div id="cd-login"> <!-- log in form -->
      
      
         <div class="cdFormTitle">{!! lang('sign_up_to_farmsgate') !!}</div>

         <div class="social_signup">
              <!-- <div class="soical fb_">
                <a href="#" class="link_">
                  <div class="icon_">
                    <img src="{{ htmlAsset('images/icon-fb.svg') }}" />
                  </div>
                  <span>Sign Up with facebook</span>
                </a>
              </div>
              <div class="soical tw_">
                <a href="#" class="link_">
                  <div class="icon_">
                    <img src="{{ htmlAsset('images/icon-twitter.svg') }}" />
                  </div>
                  <span>Sign Up with twitter</span>
                </a>
              </div> -->
              <div class="soical email_">
                <a href="#" class="link_ login_with_email">
                  
                  <span>{!! lang('login') !!}</span>
                </a>
              </div>
              <div class="soical gog_">
                <a href="{{ asset('en/google_redirect') }}" class="link_">
                  <div class="icon_">
                    <img src="{{ htmlAsset('images/icon-google.svg') }}" />
                  </div>
                  <span>{!! lang('gmail_signup') !!}</span>
                </a>
              </div>
         </div>

        <div class="or_box">
          <span class="or_">or</span>
        </div>

        <div class="social_signup mb_">
              <div class="soical em_">
                <a href="#" class="link_ signup_with_email">
                  <div class="icon_">
                    <img src="{{ htmlAsset('images/icon-email.svg') }}" />
                  </div>
                  <span>{!! lang('email_signup') !!}</span>
                </a>
              </div>
          </div>
        
      
        <!-- <a href="#0" class="cd-close-form">Close</a> -->
      </div> <!-- cd-login -->

      <!-- Login Form-->
      <div id="cd-login-email">
      <div class="commonMessage">
      </div>
      <div class="cdFormTitle">{!! lang('login_to_farmsgate') !!}</div>
         {{ Form::open(['url'=>asset($lang.'/login'),'id'=>'user-login','class'=>'cd-form']) }}
         
            <div class="aj_loader" id="login_loader">
                <div class="loader_wrapper">
                    <div class="shape shape1"></div>
                    <div class="shape shape2"></div>
                    <div class="shape shape3"></div>
                    <div class="shape shape4"></div>
                </div>

                <div class="msg" id="login_success_msg">                
                </div>
            </div>
            
          <div class="fieldset">
            <label class="head_" for="user_email">E-mail</label>
            <input class="full-width" id="user_email" name="user_email" type="user_email">
            
          </div>
          
          <div class="fieldset">
            <label class="head_" for="password">Password</label>
            <input class="full-width" id="user_password" name="password" type="password" autocomplete="new-password">
            
          </div>          

          <div class="fieldset text-right">
            <span class="lost_password">
              <a href="#" class="forgetPass">Lost Your Password?</a>
            </span>
            <button class="btn-style2 userLoginBtn" type="submit" value="Login">Login</button>
          </div>
        {{ Form::close() }}   
      </div>
      <!-- Login Form-->

      <div id="cd-signup"> <!-- Signup form -->
            <div class="commonMessage">
            </div>
         <div class="cdFormTitle">{!! lang('email_signup') !!}</div>      

        {{ Form::open(['url'=>asset($lang.'/register'),'id'=>'user-register','class'=>'cd-form']) }}
        
            <div class="aj_loader" id="register_loader">
                <div class="loader_wrapper">
                    <div class="shape shape1"></div>
                    <div class="shape shape2"></div>
                    <div class="shape shape3"></div>
                    <div class="shape shape4"></div>
                </div>

                <div class="msg" id="register_success_msg">                
                </div>
            </div>
          <div class="fieldset">
            <label class="head_" for="name">{!! lang('name') !!}</label>
            <input class="full-width" id="name" name="name" type="text" placeholder="Name" required>
            
          </div>
          <div class="fieldset">
            <label class="head_" for="user_email">{!! lang('email') !!}</label>
            <input class="full-width" id="email" name="user_email" type="user_email" placeholder="E-mail">
            
          </div>
          <div class="fieldset">
            <label class="head_" for="phone">{!! lang('phone') !!}</label>
            <input class="full-width" id="phone" name="phone" type="text" placeholder="Phone" maxlength="15">
            
          </div>
          <div class="fieldset">
            <label class="head_" for="password">{!! lang('password') !!}</label>
            <input class="full-width" id="password" name="password" type="password" autocomplete="new-password">
            
          </div>
          <div class="fieldset">
            <label class="head_" for="repassword">{!! lang('retype_password') !!}</label>
            <input class="full-width" id="repassword" name="repassword" type="password">            
          </div>

          <div class="fieldset capcha_row">
            <div class="recaptcha" id="registerCaptcha"></div>
            <input type="hidden" class="hiddenCaptcha" name="hiddenRecaptcha">
          </div>

          <div class="fieldset text-right">
            <button class="btn-style2 userRegBtn" type="submit" value="Signup">{!! lang('signup') !!}</button>
          </div>
          <div class="userreg_success_msg" id="userreg_success_msg"></div>
        {{ Form::close() }}

        <div class="or_box left_">
          <span class="or_">or</span>
        </div>

        <div class="social_box_link">
          <ul class="">
            <li class="head_">{!! lang('signup_with') !!}</li>
            <!-- <li class="share_"><a href="#" class="link_ fb_">Facebook</a></li> -->
            <li class="share_"><a href="{{ asset('en/google_redirect') }}" class="link_ gog_">Google</a></li>
            <!-- <li class="share_"><a href="#" class="link_ tw_">Twitter</a></li> -->
          </ul>
        </div>

        <div class="clearfix"></div>
       
      </div> <!-- Signup-password -->


      <div id="cd-reset-password"> <!-- reset password form -->
         <div class="cdFormTitle">{!! lang('password_reset') !!}</div>
          <!-- <div class="cd-form-message"><p>{!! lang('enter_your_email') !!}</p>
          
        </div> -->

        {{ Form::open(['url'=>asset($lang.'/forgot_password'),'id'=>'forgot_password','class'=>'cd-form']) }}  
            <div class="fieldset no_margin">
              <div class="forgot_pwd_success_msg userreg_success_msg" id="forgot_pwd_success_msg"></div>
            </div>
            <div class="aj_loader" id="forgot_password_loader">
                <div class="loader_wrapper">
                    <div class="shape shape1"></div>
                    <div class="shape shape2"></div>
                    <div class="shape shape3"></div>
                    <div class="shape shape4"></div>
                </div>

                <div class="msg" id="forgot_password_success_msg">                
                </div>
            </div>
          <div class="fieldset">
            <label class="image-replace cd-email" for="reset-email">{!! lang('email') !!}</label>
            <input class="full-width has-padding has-border" id="reset-email" name="reset-email" type="email" placeholder="E-mail">
            <span class="cd-error-message">Error message here!</span>
          </div>

          <div class="fieldset text-right">
            <span class="cd-form-bottom-message lost_password"><a href="#0">{!! lang('back_to_login') !!}</a></span>
            <button class="btn-style2 full-width has-padding" type="submit" value="Reset password">{!! lang('reset_password') !!}</button>
          </div>
              
          
        {{ Form::close() }}  

       
      </div> <!-- cd-reset-password -->

      
      <a href="#0" class="cd-close-form">Close</a>
    </div> <!-- cd-user-modal-container -->
  </div> <!-- cd-user-modal -->
  
@section('scripts')
@parent
@include('frontend.script.helper')

<script type="text/javascript">
    $(document).ready(function() {
    		
		$('#user-register').validate({		
      ignore: ':hidden:not(.hiddenCaptcha)',
        rules: {
                  "hiddenRecaptcha": {
                      required: function () {
                      var gotResponse = haveRecaptchaResponse('registerCaptcha');
                      //console.log(gotResponse);
                      if(!gotResponse){
                        $('#registerCaptcha').find('iframe').addClass('error-border');
                      }else{
                        $('#registerCaptcha').find('iframe').removeClass('error-border');
                      }
                        return !gotResponse; //using not bcoz validation needs the opposite logic
                      }
                  },              
                  'name':{
                      required:true,
                      noSpace:true,
                      alphanumeric: true,
                  }, 
                  'user_email':{
                      required:true,
                      email:true,
                  },
                  'phone':{
                      required:true,
                      number:true,
                  },
                  'password':{
                      required:true,
                      minlength : 8,
                  },
                  'repassword':{
                      required:true,
                      equalTo: "#password",
                      minlength : 8,
                  },           
              },
              messages:{
                "hiddenRecaptcha" : {
                  required:"{!! lang('field_required') !!}",
                },
                "name" : {
                  required:"{!! lang('field_required') !!}",
                  noSpace:"{!! lang('space_at_beginning') !!}",
                },
                "phone" : {
                  required:"{!! lang('field_required') !!}",
                  number:"{!! lang('valid_number') !!}",
                },
                "password" : {
                  required:"{!! lang('field_required') !!}",
                  minlength:"{!! lang('atleast_8_chars') !!}",
                },
                "repassword" : {
                  required:"{!! lang('field_required') !!}",
                  minlength:"{!! lang('atleast_8_chars') !!}",
                  equalTo:"{!! lang('password_match') !!}",
                },												
              },
      submitHandler: function() {
            var _url = "{{ asset($lang.'/register') }}";
            var _data = $('#user-register').serializeArray();
            $( "#register_loader" ).addClass('show_');
            sendAjax(_url,'post',_data, function(responseData){
              
              if(!responseData.status){
                    setTimeout(function() {
                        $( "#register_success_msg" ).html(responseData.userMessage);
                        $( "#register_success_msg" ).addClass('error');
                        $( "#register_loader .loader_wrapper" ).addClass('hide_');
                        }, 1000);

                        setTimeout(function() {
                            $( "#register_loader" ).removeClass('show_');
                            $( "#register_success_msg" ).html('');
                            $( "#register_success_msg" ).removeClass('error');
                            $( "#register_loader .loader_wrapper" ).removeClass('hide_');
                            }, 4000);
                    //$('.commonMessage').html(responseData.userMessage);
                }else{
                    if(responseData.redirectURL){
                      /*setTimeout(function() {
                        $( "#register_success_msg" ).html(responseData.userMessage);
                        $( "#register_success_msg" ).addClass('success');
                        $( "#register_loader .loader_wrapper" ).addClass('hide_');
                        }, 2000);
                        setTimeout(function() {
                          window.location.href = responseData.redirectURL;
                        }, 4000);*/
                        setTimeout(function() {
                          $( "#register_loader .loader_wrapper" ).addClass('hide_');
                          $( ".aj_loader" ).removeClass('show_');
                        }, 2000);
                        setTimeout(function() {
                          $('#userreg_success_msg').addClass('show_');
                          $('#userreg_success_msg').html(responseData.userMessage);
                          $('#user-register')[0].reset();
                          grecaptcha.reset();
                        }, 2200);
                        setTimeout(function() {
                          $('#userreg_success_msg').html('');
                          $('#userreg_success_msg').removeClass('show_');                        
                        }, 12000);
                    }else{                
                     
                      window.location.reload();
                    }
                    
                }  
            });
            return false;
        } 

    }); 
    
    
    $('#user-login').validate({		
        
        rules: {              
            'user_email':{
                required:true,
                email:true,
            },
            'password':{
                required:true,
            },          
        },
        messages:{
              "user_email" : {
                required:"{!! lang('field_required') !!}",
                email:"{!! lang('invalid_email_address') !!}",
              },
              "password" : {
                required:"{!! lang('field_required') !!}",
              },												
        },
      submitHandler: function() {
            var _url = "{{ asset($lang.'/login') }}";
            var _data = $('#user-login').serializeArray();
            $( "#login_loader" ).addClass('show_');
            sendAjax(_url,'post',_data, function(responseData){                
              if(!responseData.status){
                    //$('.commonMessage').html(responseData.userMessage);
                    setTimeout(function() {
                        $( "#login_success_msg" ).html(responseData.userMessage);
                        $( "#login_success_msg" ).addClass('error');
                        $( "#login_loader .loader_wrapper" ).addClass('hide_');
                        }, 1000);

                    setTimeout(function() {
                        $( "#login_loader" ).removeClass('show_');
                        $( "#login_success_msg" ).html('');
                        $( "#login_success_msg" ).removeClass('error');
                        $( "#login_loader .loader_wrapper" ).removeClass('hide_');
                        }, 3000);
                        
                }else{
                    if(responseData.redirectURL){                        
                           window.location.href = responseData.redirectURL;                        
                    }else{                
                        $('.commonMessage').html('<i class=" icon icon-success "></i> '+ responseData.message);
                    }
                    
                }  
            });
            return false;
        } 

    });

    $('#forgot_password').validate({		
        
        rules: {              
            'reset-email':{
                required:true,
                email:true,
            },                    
        },
        messages:{
              "reset-email" : {
                required:"{!! lang('field_required') !!}",
                email:"{!! lang('invalid_email_address') !!}",
              },              										
        },
      submitHandler: function() {
            var _url = "{{ asset($lang.'/user/forgot_password') }}";
            var _data = $('#forgot_password').serializeArray();
            $( "#forgot_password_loader" ).addClass('show_');
            sendAjax(_url,'post',_data, function(responseData){
                
              if(!responseData.status){
                    //$('.commonMessage').html(responseData.userMessage);
                    setTimeout(function() {
                        $( "#forgot_password_success_msg" ).html(responseData.userMessage);
                        $( "#forgot_password_success_msg" ).addClass('error');
                        $( "#forgot_password_loader .loader_wrapper" ).addClass('hide_');
                        }, 1000);

                    setTimeout(function() {
                        $( "#forgot_password_loader" ).removeClass('show_');
                        $( "#forgot_password_success_msg" ).html('');
                        $( "#forgot_password_success_msg" ).removeClass('error');
                        $( "#forgot_password_loader .loader_wrapper" ).removeClass('hide_');
                        }, 3000);
                        
                }else{
                  if(responseData.status){
                    setTimeout(function() {
                        $( "#forgot_password_loader .loader_wrapper" ).addClass('hide_');
                        $( ".aj_loader" ).removeClass('show_');
                      }, 2000);
                      setTimeout(function() {
                        $('#forgot_pwd_success_msg').addClass('show_');
                        $('#forgot_pwd_success_msg').html(responseData.userMessage);
                        $('#forgot_password')[0].reset();
                        grecaptcha.reset();
                      }, 2200);
                      setTimeout(function() {
                        $('#forgot_pwd_success_msg').html('');
                        $('#forgot_pwd_success_msg').removeClass('show_');                        
                      }, 9000);
                  }
                }  
            });
            return false;
        } 

    });
    
    });
</script>
@stop