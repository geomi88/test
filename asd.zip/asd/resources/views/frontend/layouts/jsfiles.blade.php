<script src="{{ htmlAsset('scripts/lib/jquery-3.3.1.min.js') }}"></script>
<script src="{{ htmlAsset('scripts/vendor/min/plugins.js') }}"></script>
<script src="{{ htmlAsset('scripts/cookie.min.js') }}"></script>


@if(!empty($isHomePage))
	<script src="{{ htmlAsset('scripts/vendor/min/home.js') }}"></script>
	<script src="{{ htmlAsset('scripts/vendor/home/jquery.mCustomScrollbar.concat.min.js') }}"></script>
@else
    
<script src="{{ htmlAsset('scripts/lib/jquery-migrate-3.0.1.min.js') }}"></script>
<script src="{{ htmlAsset('scripts/min/page.js') }}"></script> 

@include('frontend.layouts.date_dropperfiles')
@include('frontend.script.google_autocomplete')
@include('frontend.script.map_search')

	
@endif

<script src="https://www.google.com/recaptcha/api.js?onload=myCaptchaCallBack&render=explicit&hl=en" async defer></script>

<input type="hidden" name="near_latitude" id="near_latitude" value="">
<input type="hidden" name="near_longitude" id="near_longitude" value="">	
<script>
$.getJSON("https://geoip-db.com/json/",
function(data) {
    $('#near_latitude').val(data.latitude); 
    $('#near_longitude').val(data.longitude);
    Cookies.set('near_latitude', data.latitude);
    Cookies.set('near_longitude', data.longitude);
});
var screen_width = screen.width;
Cookies.set('screen_width', screen_width);
</script>
<script>
var myCaptchaCallBack = function() { 
    $('.recaptcha').each(function(){
    var id = $(this).attr('id');
        if(id){
            var tmp = grecaptcha.render( $(this).attr('id'), {
                'sitekey' : '{{ $websiteSettings->googleCaptchaSiteKey }}',
                'theme' : 'light',
                'lang':'en'
            });
            recaptchaArr.push({ID:$(this).attr('id'),obj:tmp});
        }
    })
    
};
</script>
<script src="{{ htmlAsset('scripts/main.js') }}"></script>
<script src="{{ htmlAsset('scripts/index.js') }}"></script>
<script src="{{ htmlAsset('scripts/vendor/login-register.js') }}"></script>
<script src="{{ htmlAsset('scripts/validator/jquery.validate.min.js') }}"></script>
@include('frontend.script.custom_validator')



