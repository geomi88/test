<!DOCTYPE html>
<html lang="{{ @$lang }}" dir="{{ (@$lang=='ar')?'rtl':'ltr' }}" class="{{ (@$lang=='ar')?'rtl':'ltr' }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	@section('seoPageTitle')
		<title>{{ (!empty($pageTitle))?trim($pageTitle):trim(@$seoPageTitle)  }}</title>
	@show
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, initial-scale=1, user-scalable=no, maximum-scale=1.0">
    
	
	<?php /*<link rel="preload" href="{{ htmlAsset('images/logo-en.svg') }}" as="image"> */ ?>
    <link rel="shortcut icon" href="{{ htmlAsset('images/favicon.png') }}"> 

	@section('styles')
		@include('frontend.layouts.cssfiles')
	@show
	<script>
		
		window._token = {!! json_encode([
			'csrfToken' => csrf_token(),
		]) !!};
		window.baseURL = "{{ asset('/') }}";
		window.isMobile = {{ (Agent::isMobile() === true ) ? 'true' : 'false' }};
		window.siteLang = "{{ trim($lang) }}";
		window.request = "{{ asset('/'.$lang) }}/";
		var recaptcha = [];
		var recaptchaArr = [];
		var _isValidUser = {{ (!Auth::user() || Auth::user()->isAdmin()) ? 'false' : 'true' }};
				
		function resetRecaptcha(){
			$(recaptchaArr).each(function(i,v){
			   grecaptcha.reset(v.obj);
			});
		}
		
		function haveRecaptchaResponse(elemID){
			var hasResponse = false;
			$(recaptchaArr).each(function(i,v){
			   if(v.ID == elemID){
					if(grecaptcha.getResponse(v.obj) != ''){
						hasResponse = true;
					}
			   }
			});
			return hasResponse;
		}
		
    </script>
</head>
<body  class="<?php echo @$lang; echo (!empty($isHomePage) ? ' home ' :' inner__page ');echo (!empty($isSearchPage) ? ' __place-list ' :'') ?> {{ (!empty($bodyClass))?$bodyClass:''}}" >
 <!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
	@include('frontend.layouts.preloader')
	
	
		@yield('content')

		@include('frontend.layouts.footer')
		
	</main>
	@section('scripts')
		@include('frontend.layouts.jsfiles')
		
	@show
	<script>
</script>
</body>
</html>