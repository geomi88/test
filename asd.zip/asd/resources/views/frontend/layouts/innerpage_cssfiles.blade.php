{{ HTML::style('assets/frontend/dist/styles/page.css?1') }}
@if($lang=='ar')
{{ HTML::style('assets/frontend/dist/styles/page-rtl.css?1') }}
@endif
{{ HTML::style('assets/frontend/dist/styles/devp.css?1') }}