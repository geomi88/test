<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('test', 'API\APIController@test');
Route::get('search', 'API\SearchController@index');

//Elastic search manager
Route::post('create_index', 'API\ElasticSearchController@create_index');
Route::get('delete_index', 'API\ElasticSearchController@delete_index');
Route::get('get_index_setting', 'API\ElasticSearchController@get_index_setting');
Route::get('get_mappings', 'API\ElasticSearchController@get_mappings');
Route::post('add_farm', 'API\ElasticSearchController@add_farm');
Route::get('list_farms', 'API\ElasticSearchController@list_farms');
Route::get('auto_complete', 'API\ElasticSearchController@auto_complete');
Route::post('add_farm_details', 'API\ElasticSearchController@add_farm_details');
Route::put('update_index', 'API\ElasticSearchController@create_index');


Route::match(array('GET', 'POST'), 'farm_search', 'API\FarmController@search')->name('fm_search');
Route::match(array('GET', 'POST'), 'farm-subscribe', 'API\FarmController@subscribe')->name('farm-subscribe');
Route::match(array('GET', 'POST'), 'farm-review', 'API\FarmController@addreview')->name('farm-review');
Route::match(array('GET', 'POST'), 'farm-fav', 'API\FarmController@addfav')->name('farm-fav');
Route::match(array('GET', 'POST'), 'farm_reviews', 'API\FarmController@reviews')->name('fm_reviews');
Route::match(array('GET', 'POST'), 'farm-availability-notify', 'API\FarmController@availability_notify')->name('farm-availability-notify');
Route::match(array('GET', 'POST'), 'farm-subscription-over-mail', 'API\FarmController@sendSubscriptionOverMail')->name('farm-subscription-over-mail');
Route::match(array('GET', 'POST'), 'get-plots-number', 'API\FarmController@get_plots_number')->name('get-plots-number');
Route::match(array('GET', 'POST'), 'send-farm-availability-notification', 'API\FarmController@sendFarmAvailableNotification')->name('send-farm-availability-notification');
Route::match(array('GET', 'POST'), 'disable-farm', 'API\FarmController@disablefarm')->name('disable-farm');
Route::get('/download/{type}/{farm_id}', 'API\FarmController@downloadfile');

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
