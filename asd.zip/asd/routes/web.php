<?php
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['prefix' => Config::get('app.admin_prefix'), 'namespace' => 'Admin'], function() {
    Route::match(array('GET', 'POST'), '/', 'LoginController@index')->name('admin_login');
    Route::match(array('GET', 'POST'), '/login', 'LoginController@index')->name('admin_login_login');
    Route::match(array('GET', 'POST'), '/create', array('uses' => 'LoginController@create_admin_account'));
});

Route::group(['prefix' => Config::get('app.admin_prefix'), 'namespace' => 'Admin', 'middleware' => ['adminAuth','IsAdmin']], function() {
    
  
    
     // Generic File Upload 
	Route::group(['prefix' => 'file'], function() {
        Route::match(array('POST'),'/upload', 'MultiUploaderController@fileUpload');
    });
    

    Route::get('dashboard', 'UsersController@dashboard')->name('admin_dashboard');
    Route::match(array('GET','POST'),'change_password', 'AdminController@change_password');


	
    /***
        COMMON AJAX FILE UPLOAD CONTROL (only uploads and returns file name image and file are supported) ,
        GOES AS POST META TEXT FIELD IN DB
    ***/

	Route::match(array('GET','POST'),'general_fileupload', 'PostCollectionController@fileupload');
    Route::match(array('GET','POST'),'general_filedelete/{fileName}', 'PostCollectionController@general_filedelete');
    Route::match(array('GET','POST'),'general_filedownload/{fileName}', 'PostCollectionController@general_filedownload');



	Route::match(array('GET','POST'),'/image-gallery', 'GalleryController@image_gallery_index');
	Route::match(array('GET','POST'),'/image-gallery/get_old_files/', 'GalleryController@get_old_files');
	Route::match(array('GET','POST'),'/image-gallery/file-upload/', 'GalleryController@file_upload');
	Route::match(array('GET','POST'),'/image-gallery/videoEdit/{catID}', 'GalleryController@image_gallery');
	Route::match(array('GET','POST'),'/image-gallery/create-category', 'GalleryController@create_category');
	Route::match(array('GET','POST'),'/image-gallery/update-category/{catID}', 'GalleryController@update_category');
	Route::match(array('GET','POST'),'/image-gallery/category-list', 'GalleryController@list_category');

	Route::match(array('GET','POST'),'/image-gallery/download/{imagename}', 'GalleryController@download_image');
	Route::get('/image-gallery/delete/{catid}', 'GalleryController@delete_gallery_image');


	/* Post Collections */
    Route::match(array('GET','POST'),'post_collection/{slug}', 'PostCollectionController@index')->name('post_index');
    Route::match(array('GET','POST'),'post_collection/{slug}/add', 'PostCollectionController@create')->name('post_create');
    Route::match(array('GET','POST'),'post_collection/{slug}/update/{id}', 'PostCollectionController@update')->name('post_update');
    Route::match(array('GET','POST'),'post_collection/{slug}/changestatus/{id}/{status}', 'PostCollectionController@changestatus')->name('post_change_status');
    Route::match(array('GET','POST'),'post_collection/{slug}/delete/{id}', 'PostCollectionController@delete')->name('post_delete');
    Route::match(array('GET','POST'),'post_collection/{slug}/remove_meta_attachment/{field}/{about_id}', 'PostCollectionController@removeMetaAttachment');



    //Menu manager
    Route::match(array('GET', 'POST'), '/menu_manager', 'MenuController@index')->name('menu_manager');
    Route::match(array('GET', 'POST'), '/menu_manager/create', 'MenuController@create')->name('create_menu');
    Route::match(array('GET', 'POST'), '/menu_manager/update/{id}', 'MenuController@update')->name('update_menu');
    Route::match(array('GET', 'POST'), '/menu_manager/delete/{id}', 'MenuController@delete')->name('delete_menu');
    Route::match(array('GET', 'POST'), '/menu_manager/sort_menu', 'MenuController@sort_menu')->name('sort_menu');
    // Route::get('/menu_manager/delete/{id}', 'MenuController@delete');
    Route::get('/menu_manager/changestatus/{id}', 'MenuController@changestatus')->name('menu_status');


    /*Users*/
    Route::get('/users', 'UsersController@index')->name('users');
    Route::match(array('GET', 'POST'), '/admin_users/create', 'UsersController@create')->name('admin_user_create');
    Route::match(array('GET', 'POST'), '/users/update/{id}', 'UsersController@update')->name('user_update');
    Route::get('/users/delete/{id}', 'UsersController@delete')->name('user_delete');
    Route::get('/users/changestatus/{id}', 'UsersController@changestatus')->name('user_change_status');
    Route::get('/admin_users', 'UsersController@index')->name('admin_users');
    Route::match(array('GET', 'POST'), '/admin_users/update/{id}', 'UsersController@update')->name('admin_user_edit');

	/*User Permissions*/
    Route::match(array('GET', 'POST'), 'permissions', 'PermissionsController@index');
    Route::match(array('GET', 'POST'), 'permissions/create', 'PermissionsController@create');
    Route::match(array('GET', 'POST'), 'permissions/edit/{id}', 'PermissionsController@edit');
    Route::match(array('GET', 'POST'), 'permissions/update/{id}', 'PermissionsController@update');
    Route::match(array('GET', 'POST'), 'permissions/delete/{id}', 'PermissionsController@delete');

	/*Roles*/
    Route::match(array('GET', 'POST'), 'roles', 'RolesController@index');
    Route::match(array('GET', 'POST'), 'roles/create', 'RolesController@create');
    Route::match(array('GET', 'POST'), 'roles/update/{id}', 'RolesController@update');
    Route::match(array('GET', 'POST'), 'roles/edit/{id}', 'RolesController@edit');
    Route::match(array('GET', 'POST'), 'roles/delete/{id}', 'RolesController@delete');

    //Settings
    Route::match(array('GET', 'POST'), '/setting', 'SettingController@index');

    //Country
    Route::match(array('GET', 'POST'), '/country', 'CountryController@index');
    Route::match(array('GET', 'POST'), '/country/create', 'CountryController@create');
    Route::match(array('GET', 'POST'), '/country/update/{id}', 'CountryController@update');
    Route::get('/country/delete/{id}', 'CountryController@delete');
    Route::get('/country/changestatus/{id}/{status}', 'CountryController@changestatus');
    
    //Category Manager
    Route::match(array('GET', 'POST'), '/category_manager', 'CategoryController@index');
    Route::match(array('GET', 'POST'), '/category_manager/create', 'CategoryController@create');
    Route::match(array('GET', 'POST'), '/category_manager/update/{id}', 'CategoryController@update');
    Route::get('/category_manager/delete/{id}', 'CategoryController@delete');
    Route::get('/category_manager/changestatus/{id}', 'CategoryController@changestatus');

	//Agriculture Manager
    Route::match(array('GET', 'POST'), '/agriculture_manager', 'AgricultureController@index');
    Route::match(array('GET', 'POST'), '/agriculture_manager/create', 'AgricultureController@create');
    Route::match(array('GET', 'POST'), '/agriculture_manager/update/{id}', 'AgricultureController@update');
    Route::get('/agriculture_manager/delete/{id}', 'AgricultureController@delete');
    Route::get('/agriculture_manager/changestatus/{id}', 'AgricultureController@changestatus');
    
    //Facility Manager
    Route::match(array('GET', 'POST'), '/facility_manager', 'FacilityController@index');
    Route::match(array('GET', 'POST'), '/facility_manager/create', 'FacilityController@create');
    Route::match(array('GET', 'POST'), '/facility_manager/update/{id}', 'FacilityController@update');
    Route::get('/facility_manager/delete/{id}', 'FacilityController@delete');
    Route::get('/facility_manager/changestatus/{id}/{status}', 'FacilityController@changestatus');

    //Farm Manager
    Route::match(array('GET', 'POST'), '/farm_manager', 'FarmController@index');
    Route::match(array('GET', 'POST'), '/farm_manager/create', 'FarmController@create');
    Route::match(array('GET', 'POST'), '/farm_manager/update/{id}', 'FarmController@update');
    Route::get('/farm_manager/delete/{id}', 'FarmController@delete');
    Route::get('/farm_manager/changestatus/{id}/{status}', 'FarmController@changestatus');
	
    //Soil
    Route::match(array('GET', 'POST'), '/soil', 'SoilController@index');
    Route::match(array('GET', 'POST'), '/soil/create', 'SoilController@create');
    Route::match(array('GET', 'POST'), '/soil/update/{id}', 'SoilController@update');
    Route::get('/soil/delete/{id}', 'SoilController@delete');
    Route::get('/soil/changestatus/{id}/{status}', 'SoilController@changestatus');
    
    //Irrigation
    Route::match(array('GET', 'POST'), '/irrigation', 'IrrigationController@index');
    Route::match(array('GET', 'POST'), '/irrigation/create', 'IrrigationController@create');
    Route::match(array('GET', 'POST'), '/irrigation/update/{id}', 'IrrigationController@update');
    Route::get('/irrigation/delete/{id}', 'IrrigationController@delete');
    Route::get('/irrigation/changestatus/{id}/{status}', 'IrrigationController@changestatus');
    
    //Agriculture Type
    Route::match(array('GET', 'POST'), '/agriculture_type', 'AgricultureTypeController@index');
    Route::match(array('GET', 'POST'), '/agriculture_type/create', 'AgricultureTypeController@create');
    Route::match(array('GET', 'POST'), '/agriculture_type/update/{id}', 'AgricultureTypeController@update');
    Route::get('/agriculture_type/delete/{id}', 'AgricultureTypeController@delete');
    Route::get('/agriculture_type/changestatus/{id}/{status}', 'AgricultureTypeController@changestatus');
    
    //Farm Subscription
    Route::match(array('GET', 'POST'), '/farm_subscriptions', 'FarmSubscriptionController@index');
    Route::match(array('GET', 'POST'), '/farm_subscriptions/view/{id}', 'FarmSubscriptionController@view');

    //Logout
    Route::get('/logout', 'LoginController@logout');

});


Route::group(['middleware' => ['auth']], function() {
	Route::get('/language/{lang}', 'HomeController@setlanguage')->name('set_language');


	Route::match(array('GET', 'POST'), '/', 'HomeController@index')->name('home');
	Route::match(array('GET'), '/page-not-found', 'HomeController@page_not_found');
	Route::match(array('GET'), '/service-not-available', 'HomeController@service_not_available');



	Route::match(array('GET', 'POST'), '/upload-gallery', 'FrontendBaseController@ajax_file_upload')->name('ajax_file_upload');
	Route::match(array('GET', 'POST'), '/upload-file', 'FrontendBaseController@single_file_upload')->name('single_file_upload');
	//Route::match(array('GET', 'POST'), '/search', 'FarmController@ajax_search')->name('farm_ajax_search');

	/*Google Login*/
	// Route::match(array('GET', 'POST'), '/google_redirect', 'SocialAuthGoogleController@redirect');  
	// Route::match(array('GET', 'POST'), '/google_callback', 'SocialAuthGoogleController@callback');

	Route::group(array('prefix' => '{sitelang}'), function() {
				
	//	Route::group(['middleware' => ['auth']], function() {
			Route::match(array('GET', 'POST'), '/farm-signup', 'FarmController@add')->name('farm-signup');
			Route::match(array('GET', 'POST'), '/farm-signup/{uuid}', 'FarmController@add')->name('farm-signup-uuid');
            Route::match(array('GET', 'POST'), '/farm-subscribe', 'FarmController@subscribe')->name('farm-subscribe');
            Route::match(array('GET', 'POST'), '/farm-edit/{uuid}', 'FarmController@edit')->name('farm-edit');
	//	});

		
		Route::match(array('GET', 'POST'), 'farm/{slug}', 'FarmController@farm_details')->name('farm-details');	
        Route::match(array('GET','POST'), 'farm-owner/{id}', 'FarmController@owner_profile')->name('owner-profile');      
		//Route::match(array('GET', 'POST'), '/home', 'HomeController@index')->name('home');
		Route::match(array('GET','POST'),'/logout', 'LoginController@logout');				
		Route::match(array('GET', 'POST'), '/search', 'FarmController@ajax_search')->name('farm_ajax_search');
		
		

		
		/* USER REGISTRATION GROUP */
		Route::group(['prefix'=>'register'],function(){
			Route::match(array('GET','POST'), '/', 'UserController@register');

		});
        
        Route::match(array('GET','POST'), '/user/dashboard', 'UserController@dashboard');
        Route::match(array('GET','POST'), '/user/favorite-farms', 'UserController@favoriteFarms');
        Route::match(array('GET','POST'), '/user/farm-subscriptions', 'UserController@farmSubscriptions')->name('farm-subscriptions');
        Route::match(array('GET','POST'), '/user/owned-farm-subscriptions', 'UserController@ownedFarmSubscriptions')->name('owned-farm-subscriptions');
        Route::match(array('GET','POST'), '/user/reviews', 'UserController@reviews')->name('user-reviews');
        Route::match(array('GET','POST'), '/user/notifications', 'UserController@notifications')->name('user-notifications');

        Route::match(array('GET','POST'), '/user/settings', 'UserController@settings')->name('user-settings');
        Route::match(array('GET','POST'), '/user/change-password', 'UserController@change_password')->name('change-password');
        
        Route::match(array('GET', 'POST'), '/how-it-works', 'HomeController@how_it_works')->name('how_it_works');
                

	});
});
Route::match(array('GET','POST'),'/', 'LoginController@signin')->name('user_signin');
Route::get('/confirm-email', 'UserController@confirm_email');

// 
Route::group(array('prefix' => '{sitelang}'), function() {
 Route::match(array('GET','POST'),'/', 'LoginController@signin')->name('user_signin');
 Route::match(array('GET','POST'),'/login', 'LoginController@index');
 Route::match(array('GET', 'POST'), '/home', 'HomeController@index')->name('home');
 Route::group(['prefix'=>'register'],function(){
   Route::match(array('GET','POST'), '/', 'UserController@register');
 });
/*Google Login && Rdirects*/
 Route::match(array('GET', 'POST'), '/google_redirect', 'SocialAuthGoogleController@redirect');  
 Route::match(array('GET', 'POST'), '/google_callback', 'SocialAuthGoogleController@callback');

/*Facebook Login && Rdirects*/
 Route::match(array('GET', 'POST'), '/facebook_redirect', 'SocialAuthFacebookController@redirect');  
 Route::match(array('GET', 'POST'), '/facebook_callback', 'SocialAuthFacebookController@callback');

 Route::match(array('GET', 'POST'), '/addreview/{user_id}/{review_code}', 'FarmController@addreview');
 Route::match(array('GET','POST'), '/user/forgot_password', 'UserController@forgot_password')->name('forgot_password');

 Route::match(array('GET','POST'), '/password-reset', 'UserController@password_reset');

 Route::match(array('GET', 'POST'), '/farm-notify/{user_id}/{farm_slug}', 'FarmController@farm_notify');

});
Route::match(array('GET', 'POST'), 'user/delete_notification/{id}', 'UserController@delete_notification')->name('delete-notification');

/*Route::fallback(function() {
	return Redirect('/');
});*/
