<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Spatie\Permission\Traits\HasRoles;
use Laravel\Passport\HasApiTokens;

use DB;
use App\Traits\DataTrait;
use App\Traits\PGSMetable;

class User extends Authenticatable 
{
    use DataTrait;
	use Notifiable;
    use HasRoles, HasApiTokens;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    const ADMIN_TYPE = 1;
     
   protected $fillable = [		
						'password',
						'user_status',
						'user_code',
						'user_full_name',
						'user_first_name',
						'user_last_name',
						'username',
						'user_email',
						'user_confirm_email_sent',						
						'user_gender',
						'user_address',
						'user_about',
						'user_nationality',
						'user_avatar',
						'user_dob',
						'user_phone_code',
						'user_phone_number',
						'user_phone_verified',
						'user_govt_id_verified',
						'remember_token',
						'user_phone_confirmed',
						'user_email_confirmed',
						'user_govt_id_file',
						'is_admin',
						'is_backend_user',
						'is_super_admin',
						'created_at',
						'updated_at',
						'user_validate_code',
						'user_lang',
						'last_logged_in',
						'pwd_forgot_code'
                ];
		

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
	
	
	
    protected $hidden = [
        'password', 'remember_token',
    ];
	
	protected $with = [
		'userNationality',
	];
	
	
	
    

	
    public static function boot() {
        parent::boot();
    }
    
	
    public function isAdmin()    {        
        return $this->is_admin === self::ADMIN_TYPE;    
    }

     
    public function isEmailConfirmed()    {        
        return ($this->user_email_confirmed == 1);    
    }
    
    public function userNationality(){
        return $this->hasOne('App\Models\CountryModel','country_id','user_nationality');
    }
	
	
    public static  function admin_exist(){
        $tmp = User::where('is_admin','=',1)->first();
      
        return empty($tmp);
    }
    
	function calculateAge(){
		$age = '';
		if(!empty($this->user_dob)){
			$tz  = new \DateTimeZone('Asia/Dubai');
			$age = \DateTime::createFromFormat('Y-m-d', $this->user_dob, $tz)
			 ->diff(new \DateTime('now', $tz))
			 ->y;
		}
		return $age;
	}
    public function favFarms(){
        return $this->hasMany('\App\Models\UserFarmBookmarkModel','ufb_user_id','id');
	}
	
	public function subscribedFarms(){
        return $this->hasMany('\App\Models\FarmSubscriptionModel','fs_user_id','id');
	}
	
	public function reviewedFarms(){
        return $this->hasMany('\App\Models\FarmRatingModel','fr_user_id','id');
	}
	
	public function unreadNotifications(){
        return $this->hasMany('\App\Models\UserNotificationModel','un_to_user_id','id')->where('un_read_status',0)->where('un_status',1);
    }
  
}