<?php
namespace App\Events;

use App\Models\Admodels\ResourceManagerModel;
use Illuminate\Queue\SerializesModels;

class NotificationResourceEvent
{
    use SerializesModels;

    public $resource;


    /**
     * Create a new event instance.
     *
     * @param  ResourceManagerModel  $post
     * @return void
     */
    public function __construct(ResourceManagerModel $resource,$action='approved')
    {
		$resource->action = $action;
        $this->resource = $resource;

    }
}