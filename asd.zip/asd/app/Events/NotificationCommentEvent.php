<?php
namespace App\Events;

use App\Models\Admodels\ResourceCommentModel;
use Illuminate\Queue\SerializesModels;

class NotificationCommentEvent
{
    use SerializesModels;

    public $comment;
    public $source;
    public $action;


    /**
     * Create a new event instance.
     *
     * @param  ResourceCommentModel  $post
     * @return void
     */
    public function __construct(ResourceCommentModel $comment,$action='create',$source='resource_comments')
    {
		// $comment->action = $action;
        $this->comment = $comment;
        $this->source = $source;
        $this->action = $action;

    }
}