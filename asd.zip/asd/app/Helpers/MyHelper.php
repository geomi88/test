<?php

class MyHelper {

    private $menuString = '';
    private $level = 0;
    private $count = 0;
    private $accordionCount = 0;
    private $hasChild = false;
    private $accordionAttr = '';
    private $prevMenuLevel = 0;
    private $baseURL;
    private $currentMenu;
    private $language;
    private $tabIndex;
    private $megaMenuStr = '';
    private $megaMenuDivOpened = false;
    private $megaMenuFirst = false;
    private $megaMenuLevel = 0;
    private $ulOpened = false;
    private $hasMoreChild = false;
	private $currentParent = null;
	
    public function __construct($language = null) {

        $this->language = $language;
        if (empty($language)) {
            $this->language = 'en';
        }
        $this->tabIndex = 10;
    }

    public function get_page_tree_flat_list($data, $baseURL) {
        $this->baseURL = $baseURL;
        foreach ($data as $rspage) {
            $this->level = $rspage->page_level;
            $layoutName = '';
            $activeUrl = $this->baseURL . '/pages/changestatus/' . $rspage->page_id . '/' . $rspage->page_status;
            $DeactiveUrl = $this->baseURL . '/pages/changestatus/' . $rspage->page_id . '/' . $rspage->page_status;
            $this->menuString .= '<tr>';
            $this->menuString .= '<td style="padding:0 0 0 5px;"><div class="adminMenuTDWrapper">' . (($this->level == 0) ? '<strong>' : '') . str_pad(('' . $rspage->page_name), (strlen($rspage->page_name) + 2) + ($rspage->page_level * 4), "--", STR_PAD_LEFT) . (" [<span dir='rtl'>" . $rspage->page_name_arabic . "</span>] ") . (($this->level == 0) ? '</strong>' : '') . '</div></td>';
            $layoutName = '';          
            $this->menuString .= '<td  class="status">';
            $this->menuString .= ($rspage->page_status == 1) ? "<a href='" . $activeUrl . "' class='btn btn-success btn-sm'><i class='fa fa-check-square'></i></a>" : "<a href='" . $DeactiveUrl . "' class='btn btn-danger btn-sm'><i class='fa fa-times-circle'></i></a>";
            $this->menuString .= '</td>';            
            $this->menuString .= '<td class="manage">';           
            $editURL = $this->baseURL . '/pages/update/' . $rspage->page_slug;
            $this->menuString .= '<ul><li><a href="' . $editURL . '" class="btn btn-primary btn-sm" title="edit"><i class="fa fa-pencil"></i></a><br/>Edit </li>';
            $this->menuString .= '<li><a href="' . $this->baseURL . '/pages/delete/' . $rspage->page_id . '" class="btn btn-danger btn-sm" title="edit" onclick=\'return confirm("Are you sure want to delete?");\'><i class="fa fa-trash-o"></i></a><br/>Delete</li></ul> ';           
            $this->menuString .= '</td>';
            $this->menuString .= '</tr>';
            if (count($rspage->childrens) > 0) {
                $this->get_page_tree_flat_list($rspage->childrens, $this->baseURL);
            }
        }
        return $this->menuString;
    }
	
	function apa($path){
	// pre(\Config::get('app.admin_prefix').'/'.$path);
    return asset(\Config::get('app.admin_prefix').'/'.$path);
}

    public function get_mega_menu($data, $first = false, $selected, $lang, $curParentMenu) {
        foreach ($data as $menu) {
            if ($menu->page_is_main_navigation == 1) {
                $this->count++;
                $this->prevMenuLevel = $menu->page_level;
                $this->megaMenuStr .= ' <li class="level-' . $menu->page_level . '">' .
                        '<a aria-title="' . Lang::get('messages.main_navigation') . ' ' . (($this->language == 'en') ? $menu->page_name : (!empty($menu->page_name_arabic) ? $menu->page_name_arabic : $menu->page_name)) . '" href="' . asset($this->language . '/' . $menu->page_slug) . '">' . (($this->language == 'en') ? $menu->page_name : (!empty($menu->page_name_arabic) ? $menu->page_name_arabic : $menu->page_name));

                if ($menu->page_level == 0) {
                    $this->tabIndex++;
                }
                $this->level = $menu->page_level;
                if (count($menu->childrens) > 0) {
                    $this->megaMenuStr .= '</a>';
                    $this->get_mega_menu($menu->childrens, false, $selected, $lang, $curParentMenu);
                } else {
                    $this->megaMenuStr .= '</a>';
                }
                $this->megaMenuStr .= ' </li>';                
            }
        }
        return $this->megaMenuStr;
    }
    
    public function appendPostCollection($data = array(), $type ='ul' , $level = 0, $selected = '', $lang = 'en', $curMenu = null){
      
		if(empty($data)) return false;
		
        // pre($type);
        switch ($type) {
            case 'checkbox':
                foreach ($data as $menu) {
                    $mName = (($lang == 'en') ? $menu->post_title : (!empty($menu->post_title_arabic) ? $menu->post_title_arabic : $menu->post_title));
                    $mName = str_replace("|", "", $mName);
                    $this->menuString .= '<li><input type="checkbox" name="checkboxPage[]" value="post[' . $menu->post_id . ']"' . (($menu->post_id == $selected) ? ' checked="checked" ' : '') . (($level == 0) ? 'class="boldOption"' : '') . ' > ' . str_pad($mName, strlen($mName) + $level, "-", STR_PAD_LEFT) . '</li>';
                }
                break;
            case 'option':
                foreach ($data as $menu) {
                    $mName = (($lang == 'en') ? $menu->post_title : (!empty($menu->post_title_arabic) ? $menu->post_title_arabic : $menu->post_title));
                    $mName = str_replace("|", "", $mName);
                    $this->menuString .= '<option value="post[' . $menu->post_id . ']"' . (($selected == $menu->post_id) ? ' selected="selected" ' : '') . (($level == 0) ? 'class="boldOption"' : '') . ' >' . str_pad($mName, strlen($mName) + $level, "-", STR_PAD_LEFT) . '</option>';
                    
                }
                break;

            case 'slideOutMenu':
                $this->menuString .= '<ul ' . (($this->count == 0) ? ' role="menubar"  class="  "' : (($this->prevMenuLevel == 0) ? ' role="menu" class=" " ' : '')) . '>';
                // $this->menuString .= ($this->count==0)?'<li class="'.(('home'==$selected)?' active-main-menu active':'').'"><a href="'.(asset('/')).'"><i class="fa fa-home" aria-hidden="true"></i></a></li>':'';
                // $this->menuString .= ($this->count == 0) ? '<li class="' . (('home' == $selected) ? ' currentSlideMenu slideActiveMenu ' : '') . '"><a href="' . (asset('/')) . '">' . (($this->language == 'en') ? 'Home' : ' الصفحة الرئيسية') . '</a></li>' : '';
                foreach ($data as $menu) {
                    if ($menu->page_is_main_navigation == 1) {
                        $this->count++;
                        $this->prevMenuLevel = $level;

                        $this->menuString .= ' <li aria-level="' . $level . '" data-lang="' . $lang . '" class="has-slide-submenu"' .(($menu->post_slug == $selected) ? ' active-slide-main-menu slide-active' : '') .
                                '" data-level="' . $level . '" data-id="' . $menu->post_id . '">' . (($menu->visibleChildrens > 0) ? '<span class="arrow-submenu"></span>' : '') .
                                '<a  data-href="#' . $menu->post_slug . '" aria-title="' . Lang::get('messages.main_navigation') . ' ' . (($this->language == 'en') ? str_replace("|", "", $menu->post_title) : (!empty($menu->post_title_arabic) ? str_replace("|", "", $menu->post_title_arabic) : str_replace("|", "", $menu->post_title))) . '" ' . ' data-slug="' . (( $menu->page_nav_link == 2) ? '#' : $menu->post_slug) . '" href="' . (asset($this->language . '/' . $menu->post_slug)) . '" class="' .
                                ((count($menu->childrens) > 0) ? '  slide-menu-toggle slide-menu-disabled' : 'scroll') . (($menu->post_slug == $selected) ? ' current-slide-Menu ' : '') . " " . (($menu->post_slug == $curMenu) ? 'current-slide-subMenu' : '') . '"' . ((count($menu->childrens) > 0) ? 'data-slide-toggle="slide-menu"' : '') . ' >' . (($this->language == 'en') ? str_replace("|", "", $menu->post_title) : (!empty($menu->post_title_arabic) ? str_replace("|", "", $menu->post_title_arabic) : str_replace("|", "", $menu->post_title)));
                        if ($level == 0) {
                            $this->tabIndex++;
                        }
                        $this->level = $level;
                        $this->menuString .= '</a>';
                        $this->menuString .= ' </li>';
                    }
                }

                $this->menuString .= ' </ul>';
                break;

            case 'ul':

				if(!$this->hasMoreChild){
					/* Normal submenu with post collection data */
					$this->menuString .= '<ul ' . (($this->count == 0) ? ' role="menubar"  class="' . $ulClass . ' "' : (($this->prevMenuLevel == 0) ? ' role="menu" class=" dropdown-menu dp-normal " ' : '')) . '>'."\n";
				}
                foreach ($data as $menu) {
                    $menuName = ($this->language == 'en') ? $menu->post_title : $menu->post_title_arabic;
                    $menuName = str_replace("|", " ", $menuName);
                    $this->count++;
                    $this->prevMenuLevel = $level;
                    $class = '';
                    $this->menuString .= ' <li aria-level="' . $level . '" data-lang="' . $lang . '" class="'.(($menu->post_slug == $selected) ? ' active-main-menu active' : '') .
                            '" data-level="' . $level . '" data-id="' . $menu->post_id . '"> <a  data-href="#' . $menu->post_slug . '" aria-title="' . Lang::get('messages.main_navigation') . ' ' . $menuName . '" ' . ' data-slug="' . $menu->post_slug . '" href="' .  (asset($this->language . '/' .$menu->post_type .'/'.$menu->post_slug)) . '" class="' .
                            $class . (($menu->post_slug == $selected) ? ' active-main-menu currentMenu ' : '') . " " . (($menu->post_slug == $curMenu) ? 'currentSubMenu' : '') . '"' . ' >' . $menuName;
                    if ($level == 0) {
                        $this->tabIndex++;
                    }
                    $this->level = $level;
                    $this->menuString .= '</a>';
                    $this->menuString .= ' </li>';
                }
               
                /* set this field false Which was set true while childrens array rendering */
				if($this->hasMoreChild) {
					$this->hasMoreChild = false;
				}
				
				$this->menuString .= ' </ul>'."\n";
                break;
        }
        
    }
    
    public function get_tree_menu($data, $type = "option", $level = 0, $selected = null, $lang = null, $curMenu = null, $ulClass=null) {
        // die($selected); exit();
        switch ($type) {
            case 'checkbox':
                foreach ($data as $menu) {
                    $mName = (($lang == 'en') ? $menu->page_name : (!empty($menu->page_name_arabic) ? $menu->page_name_arabic : $menu->page_name));
                    $mName = str_replace("|", "", $mName);
                    $this->menuString .= '<li><input type="checkbox" name="checkboxPage[]" value="' . $menu->page_id . '"' . ((in_array($menu->page_id, $selected)) ? ' checked="checked" ' : '') . (($menu->page_level == 0) ? 'class="boldOption"' : '') . ' > ' . str_pad($mName, strlen($mName) + $menu->page_level, "-", STR_PAD_LEFT) . '</li>';
                    if (count($menu->childrens) > 0) {
                        $this->get_tree_menu($menu->childrens, 'checkbox', $this->level++, $selected, $lang);
                    }
                    
                    if (count($menu->postCollection) > 0) {
                        $this->appendPostCollection($menu->postCollection, 'checkbox', $this->level++, $selected, $lang);
                    }
                }
                break;
            case 'option':
                foreach ($data as $menu) {
                    $mName = (($lang == 'en') ? $menu->page_name : (!empty($menu->page_name_arabic) ? $menu->page_name_arabic : $menu->page_name));
                    $mName = str_replace("|", "", $mName);
                    $this->menuString .= '<option value="' . $menu->page_id . '"' . (($selected == $menu->page_id) ? ' selected="selected" ' : '') . (($menu->page_level == 0) ? 'class="boldOption"' : '') . ' >' . str_pad($mName, strlen($mName) + $menu->page_level, "-", STR_PAD_LEFT) . '</option>';
                    if (count($menu->childrens) > 0) {
                        $this->get_tree_menu($menu->childrens, 'option', $this->level++, $selected, $lang);
                    }
                    if (count($menu->postCollection) > 0) {
                        $this->appendPostCollection($menu->postCollection, 'option', $this->level++, $selected, $lang);
                    }
                }
                break;
			case 'a':
			
			    foreach ($data as $menu) {
					
					
                    $menuName = ($this->language == 'en') ? $menu->page_name : $menu->page_name_arabic;
                    $menuName = str_replace("|", " ", $menuName);
                    $parentAnchor ='';
                    if($menu->recordType=="post" && isset($menu->page_type)){
                        $parentAnchor = $menu->page_type.'/';
                    }
		
                    if ($menu->page_is_main_navigation == 1) {
                        $this->count++;
                        $this->prevMenuLevel = $menu->page_level;
						
                        $this->menuString .= '<a data-href="#' . $menu->page_slug . '" aria-title="' . Lang::get('messages.main_navigation') . ' ' . $menuName . '" ' . ' data-slug="' . (( $menu->page_nav_link == 2) ? '#' : $menu->page_slug) . '" href="' . (( $menu->page_nav_link == 2) ? (asset($this->language . '/' . '#' . $menu->page_slug)) : asset($this->language . '/' .$parentAnchor.$menu->page_slug)) . '" class=" mainmenu__item scroll ' .(($menu->page_level == 0) ? 'nav-link ' : 'dropdown-item') .
                                ((count($menu->childrens) > 0 ) ? ' dropdown-toggle ' : '') . (($menu->page_slug == $selected) ? ' active-main-menu currentMenu ' : '') . " " . (($menu->page_slug == $curMenu) ? 'currentSubMenu' : '') . '"' . ((count($menu->childrens) > 0 ) ? ' data-toggle="dropdown " aria-haspopup="true" aria-expanded="false"  ' : '') . ' >' .
								$menuName;
                      
                        $this->level = $menu->page_level;
                        
                        $this->menuString .= '</a> ';
                    }
					
                }
			
			
                break;	
				

            case 'slideOutMenu':
                $this->menuString .= '<ul ' . (($this->count == 0) ? ' role="menubar"  class="  "' : (($this->prevMenuLevel == 0) ? ' role="menu" class=" " ' : '')) . '>';
                $this->ulOpened = true;
                foreach ($data as $menu) {
                    if ($menu->page_is_main_navigation == 1) {
                        $this->count++;
                        $this->prevMenuLevel = $menu->page_level;

                        $this->menuString .= ' <li aria-level="' . $menu->page_level . '" data-lang="' . $lang . '" class="' . ((count($menu->childrens) > 0) ? (($menu->page_is_mega_menu == 2) ? ' slideMM ' : (($menu->page_level == 0) ? 'slideMM smallMenu' : 'slide-submenu')) . ' has-slide-submenu ' : '') .
                                ((count($menu->childrens) > 0) ? (($menu->page_level < 1) ? '' : ' sub-menu ') : '') .
                                (($menu->page_slug == $selected) ? ' active-slide-main-menu slide-active' : '') .
                                '" data-level="' . $menu->page_level . '" data-id="' . $menu->page_id . '">' .
                                (($menu->visibleChildrens > 0) ? '<span class="arrow-submenu"></span>' : '') .
                                '<a  data-href="#' . $menu->page_slug . '" aria-title="' . Lang::get('messages.main_navigation') . ' ' . (($this->language == 'en') ? str_replace("|", "", $menu->page_name) : (!empty($menu->page_name_arabic) ? str_replace("|", "", $menu->page_name_arabic) : str_replace("|", "", $menu->page_name))) . '" ' . ' data-slug="' . (( $menu->page_nav_link == 2) ? '#' : $menu->page_slug) . '" href="' . (asset($this->language . '/' . $menu->page_slug)) . '" class="' .
                                ((count($menu->childrens) > 0) ? '  slide-menu-toggle slide-menu-disabled' : 'scroll') . (($menu->page_slug == $selected) ? ' current-slide-Menu ' : '') . " " . (($menu->page_slug == $curMenu) ? 'current-slide-subMenu' : '') . '"' . ((count($menu->childrens) > 0) ? 'data-slide-toggle="slide-menu"' : '') . ' >' . (($this->language == 'en') ? str_replace("|", "", $menu->page_name) : (!empty($menu->page_name_arabic) ? str_replace("|", "", $menu->page_name_arabic) : str_replace("|", "", $menu->page_name)));
                        
                        if ($menu->page_level == 0) {
                            $this->tabIndex++;
                        }
                        
                        $this->level = $menu->page_level;
                        $this->menuString .= '</a>';
                        
                        if (count($menu->postCollection) > 0) {
                            $this->appendPostCollection($menu->postCollection, 'slideOutMenu', $this->level++, $selected, $lang);
                        }
                        
                        if (count($menu->childrens) > 0) {
                            $this->get_tree_menu($menu->childrens, 'slideOutMenu', $this->level++, $selected, $lang, $curMenu);
                        }
                        
                        
                       
                        if($this->ulOpened){
                            $this->ulOpened = false;
                            $this->menuString .= ' </li>';
                        }
                    }
                }

                $this->menuString .= ' </ul>';
                break;

            case 'ul':
				
               
				
				
              $this->menuString .= ($this->count==0)?'<li aria-level="0" data-lang="en" class="nav-item  '.(($selected == 'home') ? 'active-main-menu active' : '').'" data-level="0" > <a data-href="#home" aria-title="Main Navigation home" data-slug="#" href="'.(asset('/')).'#home" class="scroll  nav-link">'.(($this->language=='en')?'Home':' الرئيسية').'</a> </li>':'';
			
				foreach ($data as $menu) {
					
					
                    $menuName = ($this->language == 'en') ? $menu->page_name : $menu->page_name_arabic;
                    $menuName = str_replace("|", " ", $menuName);
                    $parentAnchor ='';
                    if($menu->recordType=="post" && isset($menu->page_type)){
                        $parentAnchor = $menu->page_type.'/';
                    }
		
                    if ($menu->page_is_main_navigation == 1) {
                        $this->count++;
                        $this->prevMenuLevel = $menu->page_level;																		                                                
						
                        $this->menuString .= ' <li aria-level="' . $menu->page_level . '" data-lang="' . $lang . '" class="' .(($menu->page_level == 0) ? 'nav-item ' : '') .((count($menu->childrens) > 0 ) ? ((@$menu->page_is_mega_menu == 2) ? ' dropdown yamm-fw mega-menu' : (($menu->page_level == 0) ? 'dropdown ' : '')) : '') .
                                ((count($menu->childrens) > 0 ) ? (($menu->page_level < 1) ? '' : ' sub-menu ') : '') .
                                (($menu->page_slug == $selected) ? ' active-main-menu active' : '') .								
                                '" data-level="' . $menu->page_level . '" data-id="' . $menu->page_id . '">' .
                                (($menu->visibleChildrens > 0 ) ? '<span class="circle"></span>' : '') .
								
                                ' <a data-href="#' . $menu->page_slug . '" aria-title="' . Lang::get('messages.main_navigation') . ' ' . $menuName . '" ' . ' data-slug="' . (( $menu->page_nav_link == 2) ? '#' : $menu->page_slug) . '" href="' . (( $menu->page_nav_link == 2) ? (asset($this->language . '/' . '#' . $menu->page_slug)) : asset($this->language . '/' .$parentAnchor.$menu->page_slug)) . '" class="  scroll ' .(($menu->page_level == 0) ? 'nav-link ' : 'dropdown-item') .
                                ((count($menu->childrens) > 0 ) ? ' dropdown-toggle ' : '') . (($menu->page_slug == $selected) ? ' active-main-menu currentMenu ' : '') . " " . (($menu->page_slug == $curMenu) ? 'currentSubMenu' : '') . '"' . ((count($menu->childrens) > 0 ) ? ' data-toggle="dropdown " aria-haspopup="true" aria-expanded="false"  ' : '') . ' >' .
								$menuName;
                      
                        $this->level = $menu->page_level;
                        
                        $this->menuString .= '</a>';
						
                        
						
                        if (count($menu->childrens) > 0 ) {
						
						$this->menuString .= '  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">';
                            $this->get_tree_menu($menu->childrens, 'ul', $this->level++, $selected, $lang,$menu);
						$this->menuString .= '  </ul>';
                        }
						else if($menu->page_inject_collection == 1 && $menu->page_slug == 'programs' ){
							
							$this->menuString.= $this->getInteractiveMenu($menu,$lang);
						}
                        
                        $this->menuString .= ' </li>';
						
						
                    }
					
                }
				
				// if($this->currentParent->page_inject_collection == 1){
					//$this->menuString .= '</ul>';
				// }
			
				
                break;
        }
        return $this->menuString;
    }
	
	
    public function get_sitemap($data, $level = 0, $lang = null) {

        $this->menuString .= '<ul ' . (($this->count == 0) ? 'id="sitemap" class="sitemap-wrapper"' : 'class="sitemap-sub"') . '>';
        // $this->menuString .= ($this->count==0)?'<li><a href="'.(asset('/')).'">'.(($this->language=='en')?'Home':' الصفحة الرئيسية').'</a></li>':'';
        foreach ($data as $menu) {
            $this->count++;
            $this->prevMenuLevel = $menu->page_level;
            $this->menuString .= ' <li class="' . ((count($menu->childrens) > 0) ? ' has-sitemap-submenu ' : '') .
                    ((count($menu->childrens) > 0) ? (($menu->page_level < 1) ? '' : ' sitemap-sub-li ') : '') .
                    '" data-level="' . $menu->page_level . '" data-id="' . $menu->page_id . '">' .
                    '<a href="' . (( $menu->page_nav_link == 2) ? '#' : asset($lang . '/' . $menu->page_slug)) . '" >' . (($lang == 'en') ? $menu->page_name : $menu->page_name_arabic);
            $this->level = $menu->page_level;
            if (count($menu->childrens) > 0) {
                if ($menu->page_level < 1) {
                    $this->menuString .= '</a>';
                } else {
                    $this->menuString .= '</a>';
                }
                $this->get_sitemap($menu->childrens, $this->level, $lang);
            } else {
                $this->menuString .= '</a>';
            }
            $this->menuString .= ' </li>';
        }
        $this->menuString .= ' </ul>';

        return $this->menuString;
    }



}

function get_menu_helper($data, $type = 'option', $level = 0, $selected = null, $lang = 'en', $curMenu = null, $ulClass = 'nav-menu') {
    $menus = new MyHelper($lang);
    return $menus->get_tree_menu($data, $type, $level, $selected, $lang, $curMenu, $ulClass);
}


function get_sub_menu_helper($data, $level = 0, $selected = null, $lang = null) {
    $menus = new MyHelper($lang);
    return $menus->get_sub_tree_menu($data, $level, $selected, $lang);
}

function get_sub_menu_helper_new($data, $curMenu = '', $selected = null, $lang = null) {
    $menus = new MyHelper($lang);
    return $menus->get_sub_tree_menu_new($data, $curMenu, $selected, $lang);
}

function get_page_listing_tree_helper($data, $baseURL) {
    $menus = new MyHelper();
    return $menus->get_page_tree_flat_list($data, $baseURL);
}

function get_sitemap_helper($data, $level, $lang) {
    $menus = new MyHelper();
    return $menus->get_sitemap($data, $level, $lang);
}




function pr($arr) {
    print_r($arr);
}

function pre($arr) {
	if(Config::get('app.debug')){
		echo "<pre>";
		print_r($arr);
		exit();
	}
}

function disp_field($lang, $field) {
    return ($lang == 'en') ? $field : $field . "_arabic";
}

function replace_relative_urls($baseURL, $str) { //Only use under live domain
    $result = preg_replace('/(\.\.\/)*\1/', $baseURL, $str);
    return $result;
}



function limitText($text, $limit = 65) {

    if (strlen($text) < $limit) {
        return $text;
    }
    $stringCut = substr($text, 0, $limit);
    $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
    return $string;
}

function adjust_title_with_br($title, $lang, $removeThe = true) {
    if ($lang == 'en' && $removeThe == true) {
        $title = trim(str_replace('the', '', strtolower($title)));
    }
    $title = str_replace('|', '<br/>', $title);
    return $title;
}

function adjust_title_without_pipe($title, $lang, $removeThe = true) {
    if ($lang == 'en' && $removeThe == true) {
        $title = trim(str_replace('the', '', strtolower($title)));
    }
    $title = str_replace('|', '', $title);
    return $title;
}

function isFrontendUserLoggedIn() {
    //pre(Auth::user());
    if (Auth::user() && @Auth::user()->is_backend_user == 2) {
        return true;
    }
    return false;
}

function highlight_text($text, $keyword) {
    return preg_replace("~\p{L}*?" . preg_quote($keyword) . "\p{L}*~ui", "<span class='highlight'><b>$0</b></span>", $text);
}

function getTranslatedMonthNames(){
	$translatedMonth=[];
	$short = $full = '';
	for($month=1;$month<=12;$month++){
		$full.= (empty($full)) ? Lang::get('months.'.$month) : ','.Lang::get('months.'.$month);
		$short.= (empty($short)) ? Lang::get('months.'.$month.'_short') : ','.Lang::get('months.'.$month.'_short');
	}
	$translatedMonth['full'] = explode(',',$full);
	$translatedMonth['short'] = explode(',',$short);
	
	// pre($translatedMonth);
	return $translatedMonth;
}

function getPlUploadControlWithoutLabel($controlName, $allowedMimes=['jpg','jpeg','png'], $uploadType=null, $btnLabel='Select File', $validationMsg , $required = false){
   
  
   
    $controlHTML = '<div class = "noLabelFU uploadControlWrapper">'.
        '<input type = "file" class = "form-control uploaderProfile" data-allowed="'.(implode(",", $allowedMimes)).'" data-type="'.$uploadType.'" title = "'.$validationMsg.'" id = "'.$controlName.'_file" name = "'.$controlName.'_file" '.(($required==true)?" required ":'').' />'.
        '<div class = "choose">'.
            '<div class = "choose-btn">'.$btnLabel.'</div>'.
            '<div class = "choose-file uploadFileName"></div>'.
            '<div class = "uploadPercentage"></div>'.
            '<div class = "uploadProgressWrapper">'.
            '<div class = "uploadProgress" ></div>'.
        '</div>'.
    '</div>'.
    '<input class = "filename" type="hidden" id="'.$controlName.'" value="" name="'.$controlName.'" placeholder="">'.
    '<input class = "original_name" type="hidden" id="'.$controlName.'_tmp" value="" name="'.$controlName.'_tmp" placeholder="">'.
    '</div>';
    return $controlHTML;
}

function getPlUploadControl($label, $controlName, $allowedMimes=['jpg','jpeg','png'], $uploadType=null, $btnLabel='Select File', $validationMsg, $required = false, $oldFileName="",$postType,$width='',$height=''){
    $imagePreview = '';
    $postBasePath = 'storage/app/public/post/';
    if(!empty($oldFileName) && File::exists($postBasePath.$oldFileName) && $uploadType=="image"){
        $imagePreview = '<div class="uploadPreview"><div class="upImgWrapper"><span class="delUploadImage" data-name="'.$oldFileName.'"><i class="fa fa-times-circle"></i></span><img src="'.asset($postBasePath.$oldFileName).'" class="uploadPreview"/></div><div class="clearfix"></div></div>';
    }else{
        if(!empty($oldFileName) && File::exists($postBasePath.$oldFileName)){
        $imagePreview = '<div class="uploadPreview"><div class="upImgWrapper"><span class="delUploadImage" data-name="'.$oldFileName.'"><i class="fa fa-times-circle"></i></span><a target="_blank" href="'.asset($postBasePath.$oldFileName).'" class="uploadPreview">'.$oldFileName.'</a></div><div class="clearfix"></div></div>';
       } 
    }
   
    if (empty($allowedMimes)) {
        $allowedMimes = ['jpg', 'jpeg', 'png'];
    }
	$requiredText=($required)?'<em class = "red">*</em>':'';
	
    $controlHTML = '<label class = "fl-start">'.$label.$requiredText.$imagePreview.'</label>'.
    '<div class = "uploadControlWrapper input_parent">'.
        '<input type = "file" class = "form-control uploader" data-width="'.$width.'" data-height="'.$height.'" data-slug="'.$postType.'" data-allowed="'.(implode(",", $allowedMimes)).'" data-type="'.$uploadType.'" title = "'.$validationMsg.'" id = "'.$controlName.'_file" name = "'.$controlName.'_file" '.(($required==true && empty($oldFileName))?" required ":'').' />'.
        '<div class = "choose">'.
            '<div class = "choose-btn">'.$btnLabel.'</div>'.
            '<div class = "choose-file uploadFileName"></div>'.
            '<div class = "uploadPercentage"></div>'.
            '<div class = "uploadProgressWrapper">'.
            '<div class = "uploadProgress" ></div>'.
        '</div>'.
    '</div>'.
    '<input class = "filename" type="hidden" id="'.$controlName.'" value="'.((!empty($oldFileName))?$oldFileName:'').'" name="meta[text]['.$controlName.']" placeholder="">'.
    '<input class = "original_name" type="hidden" id="'.$controlName.'_tmp" value="" name="'.$controlName.'_tmp" placeholder="">'.
    '</div>';
    return $controlHTML;
}



function getPLSingleUplolad($label, $controlName, $allowedMimes=['jpg','jpeg','png'], $uploadType=null, $btnLabel='Select File', $validationMsg, $required = false, $oldFileName="",$postType,$width='',$height=''){
    $imagePreview = '';
    $postBasePath = 'storage/app/public/post/';
    if(!empty($oldFileName) && File::exists($postBasePath.$oldFileName) && $uploadType=="image"){
        $imagePreview = '<div class="uploadPreview"><div class="upImgWrapper"><span class="delUploadImage" data-name="'.$oldFileName.'"><i class="fa fa-times-circle"></i></span><img src="'.asset($postBasePath.$oldFileName).'" class="uploadPreview"/></div><div class="clearfix"></div></div>';
    }else{
        if(!empty($oldFileName) && File::exists($postBasePath.$oldFileName)){
        $imagePreview = '<div class="uploadPreview"><div class="upImgWrapper"><span class="delUploadImage" data-name="'.$oldFileName.'"><i class="fa fa-times-circle"></i></span><a target="_blank" href="'.asset($postBasePath.$oldFileName).'" class="uploadPreview">'.$oldFileName.'</a></div><div class="clearfix"></div></div>';
       } 
    }
   
    if (empty($allowedMimes)) {
        $allowedMimes = ['jpg', 'jpeg', 'png'];
    }
	$requiredText=($required)?'<em class = "red">*</em>':'';
	
    $controlHTML = '<label class = "fl-start">'.$label.$requiredText.$imagePreview.'</label>'.
    '<div class = "uploadControlWrapper input_parent">'.
        '<input type = "file" class = "form-control uploader" data-width="'.$width.'" data-height="'.$height.'" data-slug="'.$postType.'" data-allowed="'.(implode(",", $allowedMimes)).'" data-type="'.$uploadType.'" title = "'.$validationMsg.'" id = "'.$controlName.'_file" name = "'.$controlName.'_file" '.(($required==true && empty($oldFileName))?" required ":'').' />'.
        '<div class = "choose">'.
            '<div class = "choose-btn">'.$btnLabel.'</div>'.
            '<div class = "choose-file uploadFileName"></div>'.
            '<div class = "uploadPercentage"></div>'.
            '<div class = "uploadProgressWrapper">'.
            '<div class = "uploadProgress" ></div>'.
        '</div>'.
    '</div>'.
    '<input class = "filename" type="hidden" id="'.$controlName.'" value="'.((!empty($oldFileName))?$oldFileName:'').'" name="'.$controlName.'" placeholder="">'.
    '<input class = "original_name" type="hidden" id="'.$controlName.'_tmp" value="" name="'.$controlName.'_tmp" placeholder="">'.
    '</div>';
    return $controlHTML;
}






function getResourceAttachmentPlUploadControl($label, $controlName, $allowedMimes=['jpg','jpeg','png'], $uploadType=null, $btnLabel='Select File', $validationMsg, $required = false, $oldFileName="",$resourceID=null){
    $imagePreview = '';

    if(!empty($oldFileName) && File::exists('storage/app/post/uploads/'.$oldFileName) && $uploadType=="image"){
        $imagePreview = '<div class="uploadPreview"><div class="upImgWrapper"><span class="delUploadImage" data-name="'.$oldFileName.'"><i class="fa fa-times-circle"></i></span><img src="'.asset('storage/app/post/uploads/'.$oldFileName).'" class="uploadPreview"/></div><div class="clearfix"></div></div>';
    }else{
        if(!empty($oldFileName) && File::exists('storage/app/post/uploads/'.$oldFileName)){
        $imagePreview = '<div class="uploadPreview"><div class="upImgWrapper"><span class="delUploadImage" data-name="'.$oldFileName.'"><i class="fa fa-times-circle"></i></span><a target="_blank" href="'.asset('storage/app/post/uploads/'.$oldFileName).'" class="uploadPreview">'.$oldFileName.'</a></div><div class="clearfix"></div></div>';
       } 
    }
   
    if (empty($allowedMimes)) {
        $allowedMimes = ['jpg', 'jpeg', 'png'];
    }
    $controlHTML = '<label class = "fl-start">'.$label.'<em class = "mandatory">*</em></label>'.$imagePreview.
    '<div class = "uploadControlWrapper input_parent">'.
        '<input type = "file" class = "form-control custom_uploader" data-allowed="'.(implode(",", $allowedMimes)).'" data-type="'.$uploadType.'" title = "'.$validationMsg.'" data-id="'.$resourceID.'" id = "'.$controlName.'_file" name = "'.$controlName.'_file" />'.
        '<div class = "choose">'.
            '<div class = "choose-btn">'.$btnLabel.'</div>'.
            '<div class = "choose-file uploadFileName"></div>'.
            '<div class = "uploadPercentage"></div>'.
            '<div class = "uploadProgressWrapper">'.
            '<div class = "uploadProgress" ></div>'.
        '</div>'.
    '</div>'.
    '</div>';
    return $controlHTML;
}

 function getYoutubeVideoID($url){

    
       $videoID='';
       if (preg_match('/youtube\.com\/watch\?v=([^\&\?\/]+)/', $url, $id)) {
               $videoID = $id[1];
          } else if (preg_match('/youtube\.com\/embed\/([^\&\?\/]+)/', $url, $id)) {
              $videoID = $id[1];
          } else if (preg_match('/youtube\.com\/v\/([^\&\?\/]+)/', $url, $id)) {
                 $videoID = $id[1];
          } else if (preg_match('/youtu\.be\/([^\&\?\/]+)/', $url, $id)) {
              $videoID = $id[1];
          }
          else if (preg_match('/youtube\.com\/verify_age\?next_url=\/watch%3Fv%3D([^\&\?\/]+)/', $url, $id)) {
             $videoID = $id[1];
          }
        return $videoID;
}


function printTextValue($lang,$obj,$prop){
   $returnVal = '';
   
   if(is_object($obj)){
   
       if($lang=='ar'){
           $tmp = isset($obj->{$prop.'_ar'});
           if($tmp){
               $returnVal =  $obj->{$prop.'_ar'};               
           }elseif(isset($obj->{$prop.'_arabic'})){
               $returnVal =  $obj->{$prop.'_arabic'};               
           }
       }else{
           $returnVal = (isset($obj->{$prop}))?$obj->{$prop}:'';
       }
   }elseif(is_array($obj)){
       if($lang=='ar'){
           if(array_key_exists($prop.'_ar', $obj)){
               $returnVal =  $obj[$prop.'_ar'];               
           }elseif(array_key_exists($prop.'_arabic', $obj)){
               $returnVal =  $obj[$prop.'_arabic'];               
           }
       }else{
           $returnVal = (array_key_exists($prop,$obj))?$obj[$prop]:'';
       }
   }
       
   return $returnVal;    
}

function printMetaValue($lang,$obj,$prop){
   $returnVal = '';
   
    
   if(is_object($obj)){
   
       if($lang=='ar'){
           $fieldName = $prop.'_ar';
           if($obj->hasMeta($fieldName)){
                $returnVal = $obj->getMeta($fieldName);
           }else{
                $fieldName = $prop.'_arabic';
                if($obj->hasMeta($fieldName)){
                    $returnVal =  $obj->getMeta($fieldName);
                }
           }
       }else{
          
           $returnVal = $obj->getMeta($prop);
       }
   }elseif(is_array($obj)){
       if($lang=='ar'){
           if(array_key_exists($prop.'_ar', $obj)){
               $returnVal =  $obj[$prop.'_ar'];               
           }elseif(array_key_exists($prop.'_arabic', $obj)){
               $returnVal =  $obj[$prop.'_arabic'];               
           }
       }else{
           $returnVal = (array_key_exists($prop,$obj))?$obj[$prop]:'';
       }
   }
       
   return $returnVal;    
}

function is_rtl( $string ) {
    $rtl_chars_pattern = '/[\x{0590}-\x{05ff}\x{0600}-\x{06ff}]/u';
    return preg_match($rtl_chars_pattern, $string);
}

function display_post_type($postType){
	return ucwords(str_replace('_',' ',$postType));		
}

function dateWithLang($obj,$prop){

       $returnVal=$date="";
       if(is_object($obj)){
        $returnVal = (isset($obj->{$prop}))?$obj->{$prop}:'';
       }elseif(is_array($obj)){
          $returnVal = (isset($obj[$prop]))?$obj[$prop]:'';
       }

       if(!empty($returnVal)){

                            
          $date='<span>'.date('d ',strtotime($returnVal))."</span><span>".Lang::get("messages.".date('M',strtotime($returnVal)))." ".date('Y',strtotime($returnVal)).'</span>';

       }
	   
       return $date;
}

function printDateDay($obj,$prop){

       $returnVal="";
       if(is_object($obj)){
        $returnVal = (isset($obj->{$prop}))?$obj->{$prop}:'';
       }elseif(is_array($obj)){
          $returnVal = (isset($obj[$prop]))?$obj[$prop]:'';
       }
        return date('d ',strtotime($returnVal));

}

function printDateMonthYear($obj,$prop){

       $returnVal="";
       if(is_object($obj)){
        $returnVal = (isset($obj->{$prop}))?$obj->{$prop}:'';
       }elseif(is_array($obj)){
          $returnVal = (isset($obj[$prop]))?$obj[$prop]:'';
       }
        return Lang::get("messages.".date('M',strtotime($returnVal)))." ".date('Y',strtotime($returnVal));

}

function displaySplitDate($returnVal,$d){      
       if(!empty($returnVal)){         
          $date=date($d,strtotime($returnVal));
			if($d=='M'){
				$date=Lang::get("messages.".date('M',strtotime($returnVal)));			
			}
       }	   
       return $date;
}

function displayDateTime($dateTime){
     $dateTimeTemp =  DateTime::createFromFormat('Y-m-d H:i:s', $dateTime);
     if(!$dateTimeTemp) return $dateTime;
     
     if($dateTimeTemp->format('H:i:s') == "00:00:00"){
        return $dateTimeTemp->format('Y-m-d');
    } 
    return $dateTimeTemp->format('Y-m-d h:i A'); 
}

function eventDateTime($obj,$prop){
	   $dateTime="";
       if(is_object($obj)){
        $dateTime = (isset($obj->{$prop}))?$obj->{$prop}:'';
       }elseif(is_array($obj)){
          $dateTime = (isset($obj[$prop]))?$obj[$prop]:'';
       }
   
	
     $dateTimeTemp =  DateTime::createFromFormat('Y-m-d H:i:s.000000', $dateTime);
     if(!$dateTimeTemp) return $dateTime;
     
      
	
    return $dateTimeTemp->format('m/d/Y H:i'); 
}


function eventStartEndDateTime($obj,$prop1, $prop2){
	   $startDateTime="";
       $endDateTime="";
       if(is_object($obj)){
            $startDateTime = (isset($obj->{$prop1}))?$obj->{$prop1}:'';
       }elseif(is_array($obj)){
            $startDateTime = (isset($obj[$prop1]))?$obj[$prop1]:'';
       }
    
        
       if(is_object($obj)){
            $endDateTime = (isset($obj->{$prop2}))?$obj->{$prop2}:'';
       }elseif(is_array($obj)){
            $endDateTime = (isset($obj[$prop2]))?$obj[$prop2]:'';
       }
	
    
     $dateTimeStart =  DateTime::createFromFormat('Y-m-d H:i:s', $startDateTime);
     $dateTimeEnd =  DateTime::createFromFormat('Y-m-d H:i:s', $endDateTime);
     
      if(!$dateTimeStart || !$dateTimeEnd) return $startDateTime.' - '.$endDateTime;
     
     if($dateTimeStart->format('Y-m-d') == $dateTimeEnd->format('Y-m-d')){
        return '<span class="datetimeWrapper"><span class="datePartSpan">'.$dateTimeStart->format('d.m.Y'). ' </span><span class="timePartSpan">'.$dateTimeStart->format('H:i').' - '.$dateTimeEnd->format('H:i').'</span></span>'; 
     }
     
    return '<span class="datetimeWrapper"><span class="datePartSpan">'.$dateTimeStart->format('d.m.Y').' </span><span class="timePartSpan">'.$dateTimeStart->format('H:i').'</span></span>-<span class="datetimeWrapper"><span class="datePartSpan">'.$dateTimeStart->format('d.m.Y').'</span><span class="timePartSpan">'.$dateTimeEnd->format('H:i').'</span></span>';   
	
}


function getPaginationSerial($obj){
    //pre($obj->perpage());
    return ($obj->currentpage()-1)* $obj->perpage()+1;
}

function getContributorImageURL($imageName=null){
    $imageURL = asset('assets/frontend/images/user-avatar.svg');
    if(!empty($imageName) && File::exists(asset('storage/app/user/'.$imageName))){
        $image = asset('storage/app/user/'.$imageName);
    }

    return $imageURL;
}

function getAppConfig($label){
    return \Config::get('constants.'.$label);
}

function getFileSize($bytes){
    if ($bytes >= 1073741824){
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
    }elseif ($bytes >= 1048576){
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
    }elseif ($bytes >= 1024)
        {
            $bytes = number_format($bytes / 1024, 2) . ' KB';
        }
        elseif ($bytes > 1)
        {
            $bytes = $bytes . ' bytes';
        }
        elseif ($bytes == 1)
        {
            $bytes = $bytes . ' byte';
        }
        else
        {
            $bytes = '0 bytes';
        }

        return $bytes;
}

function getFrontendAsset($path,$root=false){
    return ($root)?asset('assets/frontend/'.$path):asset('assets/frontend/dist/'.$path);
}

function getStorageAsset($path){
    return asset('public/storage/uploads/'.$path);
}

function adminPrefix(){
    return \Config::get('app.admin_prefix').'/';
}

function get_admin_menu_active_class($currentURI, $slugArr) {

    $className = '';
    $listArr = $slugArr;
    if (!is_array($listArr)) {
        $listArr = array();
    }
    $URLParts = explode("/", $currentURI);
    if (!empty($URLParts)) {
        foreach ($URLParts as $Uparts) {
            if (in_array($Uparts, $listArr)) {
                $className = 'active';
            }
        }
    }

    if (in_array('seo', $URLParts)) {
        return null;
    }
    // pre($URLParts);
    return $className;
}

function getHumanReadbleFormat($date){
	$instance = $date->diff(new DateTime(date('Y-m-d H:i:s')));
	$returnText = '';
	if($instance->y >0){
		$returnText = $instance->y.' '.Lang::get('messages.years');
	}
	else if($instance->m >0){
		$returnText = $instance->m.' '.Lang::get('messages.months');
	}
	else if($instance->d >0){
		$returnText = $instance->d.' '.Lang::get('messages.days');
	}
	else if($instance->h >0){
		$returnText = $instance->h.' '.Lang::get('messages.hours');
	}
	else if($instance->i >0){
		$returnText = $instance->i.' '.Lang::get('messages.minutes');
	}
	else if($instance->s >=0){
		$returnText = $instance->s.' '.Lang::get('messages.seconds');
	}
	return $returnText;
}

function frontAsset($fileName){
    return asset('assets/frontend/dist/'.$fileName);
}

function lang($str){
    return Lang::get('messages.'.$str);
}

function getPostObjectById($postId,$postCollection){
    $obj = null;
    foreach($postCollection as $post){
        if($post->post_id == $postId){
            $obj = $post;
            break;
        }
    }
    return $obj;
}

function getCategoryWisePosts($postsCollections,$fieldName){
    
	$splitedArray=[];
    foreach($postsCollections as $post){
       if(!empty($post->getData($fieldName))){
           $splitedArray[$post->getData($fieldName)][]=$post;
       }
	}
	return $splitedArray;
}

function getGalleryItemsByType($galCollection,$type){
	$filterArray=[];
    foreach($galCollection as $galItem){
          if($galItem->gallery_image_type == 1){
            $filterArray[] = $galItem;
          }
	}
	return $filterArray;
}

function youtubeImage($videoID){
	return "//img.youtube.com/vi/".$videoID."/sddefault.jpg";
}

function youtubeEmbedUrl($url){
	
	    $videoID='';
       if (preg_match('/youtube\.com\/watch\?v=([^\&\?\/]+)/', $url, $id)) {
               $videoID = $id[1];
          } else if (preg_match('/youtube\.com\/embed\/([^\&\?\/]+)/', $url, $id)) {
              $videoID = $id[1];
          } else if (preg_match('/youtube\.com\/v\/([^\&\?\/]+)/', $url, $id)) {
                 $videoID = $id[1];
          } else if (preg_match('/youtu\.be\/([^\&\?\/]+)/', $url, $id)) {
              $videoID = $id[1];
          }
          else if (preg_match('/youtube\.com\/verify_age\?next_url=\/watch%3Fv%3D([^\&\?\/]+)/', $url, $id)) {
             $videoID = $id[1];
          }
		  
	return "//www.youtube.com/embed/".$videoID."&autoplay=1&rel=0&controls=1&showinfo=1";
}

function youtubeEmbedUrlFromID($videoID){		  
	return "//www.youtube.com/embed/".$videoID."&autoplay=1&rel=0&controls=1&showinfo=1";
}
?>
