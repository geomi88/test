<?php

function get_time_slot_array($startTime , $endTime , $slotDuration){ //$slotDuration in minutes
    $slotDuration = (int) $slotDuration;
    $totalTimeSlots = array();
    $interval = 'PT'.$slotDuration.'M';
    $period = new \DatePeriod(  new \DateTime($startTime),  new \DateInterval($interval), new \DateTime($endTime) );
    foreach ($period as $time) {
        $totalTimeSlots[$time->format("H:i")] = $time->format("h:i A");
    }

    return $totalTimeSlots;
}
    
function pr($arr) {
    print_r($arr);
}

function get_user_profile_image($farmUser){
	
	$image_url = htmlAsset('images/person01.jpg');
	
	if(!isset($farmUser->owner)) return $image_url;
	/*if(file_exists('storage/uploads/user/'.$farmUser->owner->user_avatar)){
		$image_url = asset('storage/uploads/user/'.$farmUser->owner->user_avatar);
	}*/
	
	return $image_url;
	
}

function pre($arr) {
	if(Config::get('app.debug')){
		echo "<pre>";
		print_r($arr);
		exit();
	}
}


function replace_relative_urls($baseURL, $str) { //Only use under live domain
    $result = preg_replace('/(\.\.\/)*\1/', $baseURL, $str);
    return $result;
}



function limitText($text, $limit = 65) {
    if (strlen($text) < $limit) {
        return $text;
    }
    $stringCut = substr($text, 0, $limit);
    $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
    return $string;
}


function highlight_text($text, $keyword) {
    return preg_replace("~\p{L}*?" . preg_quote($keyword) . "\p{L}*~ui", "<span class='highlight'><b>$0</b></span>", $text);
}

function getTranslatedMonthNames(){
	$translatedMonth=[];
	$short = $full = '';
	for($month=1;$month<=12;$month++){
		$full.= (empty($full)) ? Lang::get('months.'.$month) : ','.Lang::get('months.'.$month);
		$short.= (empty($short)) ? Lang::get('months.'.$month.'_short') : ','.Lang::get('months.'.$month.'_short');
	}
	$translatedMonth['full'] = explode(',',$full);
	$translatedMonth['short'] = explode(',',$short);
	
	
	return $translatedMonth;
}

function getPlUploadControlWithoutLabel($controlName, $allowedMimes=['jpg','jpeg','png'], $uploadType=null, $btnLabel='Select File', $validationMsg , $required = false){
   
    $controlHTML = '<div class = "noLabelFU uploadControlWrapper">'.
        '<input type = "file" class = "form-control uploaderProfile" data-allowed="'.(implode(",", $allowedMimes)).'" data-type="'.$uploadType.'" title = "'.$validationMsg.'" id = "'.$controlName.'_file" name = "'.$controlName.'_file" '.(($required==true)?" required ":'').' />'.
        '<div class = "choose">'.
            '<div class = "choose-btn">'.$btnLabel.'</div>'.
            '<div class = "choose-file uploadFileName"></div>'.
            '<div class = "uploadPercentage"></div>'.
            '<div class = "uploadProgressWrapper">'.
            '<div class = "uploadProgress" ></div>'.
        '</div>'.
    '</div>'.
    '<input class = "filename" type="hidden" id="'.$controlName.'" value="" name="'.$controlName.'" placeholder="">'.
    '<input class = "original_name" type="hidden" id="'.$controlName.'_tmp" value="" name="'.$controlName.'_tmp" placeholder="">'.
    '</div>';
    return $controlHTML;
}

function getPlUploadControl($label, $controlName, $allowedMimes=['jpg','jpeg','png'], $uploadType=null, $btnLabel='Select File', $validationMsg, $required = false, $oldFileName="",$postType){
    $imagePreview = '';
    $postBasePath = 'storage/app/public/post/';
    if(!empty($oldFileName) && File::exists($postBasePath.$oldFileName) && $uploadType=="image"){
        $imagePreview = '<div class="uploadPreview"><div class="upImgWrapper"><span class="delUploadImage" data-name="'.$oldFileName.'"><i class="fa fa-times-circle"></i></span><img src="'.asset($postBasePath.$oldFileName).'" class="uploadPreview"/></div><div class="clearfix"></div></div>';
    }else{
        if(!empty($oldFileName) && File::exists($postBasePath.$oldFileName)){
        $imagePreview = '<div class="uploadPreview"><div class="upImgWrapper"><span class="delUploadImage" data-name="'.$oldFileName.'"><i class="fa fa-times-circle"></i></span><a target="_blank" href="'.asset($postBasePath.$oldFileName).'" class="uploadPreview">'.$oldFileName.'</a></div><div class="clearfix"></div></div>';
       } 
    }
   
    if (empty($allowedMimes)) {
        $allowedMimes = ['jpg', 'jpeg', 'png'];
    }
    $controlHTML = '<label class = "fl-start">'.$label.'<em class = "mandatory">*</em></label>'.$imagePreview.
    '<div class = "uploadControlWrapper input_parent">'.
        '<input type = "file" class = "form-control uploader" data-slug="'.$postType.'" data-allowed="'.(implode(",", $allowedMimes)).'" data-type="'.$uploadType.'" title = "'.$validationMsg.'" id = "'.$controlName.'_file" name = "'.$controlName.'_file" '.(($required==true)?" required ":'').' />'.
        '<div class = "choose">'.
            '<div class = "choose-btn">'.$btnLabel.'</div>'.
            '<div class = "choose-file uploadFileName"></div>'.
            '<div class = "uploadPercentage"></div>'.
            '<div class = "uploadProgressWrapper">'.
            '<div class = "uploadProgress" ></div>'.
        '</div>'.
    '</div>'.
    '<input class = "filename" type="hidden" id="'.$controlName.'" value="'.((!empty($oldFileName))?$oldFileName:'').'" name="meta[text]['.$controlName.']" placeholder="">'.
    '<input class = "original_name" type="hidden" id="'.$controlName.'_tmp" value="" name="'.$controlName.'_tmp" placeholder="">'.
    '</div>';
    return $controlHTML;
}


 function getYoutubeVideoID($url){
    
    $videoID = false;
    if (preg_match('/youtube\.com\/watch\?v=([^\&\?\/]+)/', $url, $id)) {
        $videoID = $id[1];
    } else if (preg_match('/youtube\.com\/watch\?.*&v=([^\&\?\/]+)/', $url, $id)) {
        $mediaID = $id[1];
    } else if (preg_match('/youtube\.com\/embed\/([^\&\?\/]+)/', $url, $id)) {
        $videoID = $id[1];
    } else if (preg_match('/youtube\.com\/v\/([^\&\?\/]+)/', $url, $id)) {
        $videoID = $id[1];
    } else if (preg_match('/youtu\.be\/([^\&\?\/]+)/', $url, $id)) {
        $videoID = $id[1];
    } else if (preg_match('/youtube\.com\/verify_age\?next_url=\/watch%3Fv%3D([^\&\?\/]+)/', $url, $id)) {
        $videoID = $id[1];
    }
    return $videoID;
}



function is_rtl( $string ) {
    $rtl_chars_pattern = '/[\x{0590}-\x{05ff}\x{0600}-\x{06ff}]/u';
    return preg_match($rtl_chars_pattern, $string);
}

function dateWithLang($obj,$prop){

       $returnVal=$date="";
       if(is_object($obj)){
        $returnVal = (isset($obj->{$prop}))?$obj->{$prop}:'';
       }elseif(is_array($obj)){
          $returnVal = (isset($obj[$prop]))?$obj[$prop]:'';
       }

       if(!empty($returnVal)){

                            
          $date='<span>'.date('d ',strtotime($returnVal))."</span><span>".Lang::get("messages.".date('M',strtotime($returnVal)))." ".date('Y',strtotime($returnVal)).'</span>';

       }
	   
       return $date;
}

function printDateDay($obj,$prop){

       $returnVal="";
       if(is_object($obj)){
        $returnVal = (isset($obj->{$prop}))?$obj->{$prop}:'';
       }elseif(is_array($obj)){
          $returnVal = (isset($obj[$prop]))?$obj[$prop]:'';
       }
        return date('d ',strtotime($returnVal));

}

function printDateMonthYear($obj,$prop){

       $returnVal="";
       if(is_object($obj)){
        $returnVal = (isset($obj->{$prop}))?$obj->{$prop}:'';
       }elseif(is_array($obj)){
          $returnVal = (isset($obj[$prop]))?$obj[$prop]:'';
       }
        return Lang::get("messages.".date('M',strtotime($returnVal)))." ".date('Y',strtotime($returnVal));

}

function displaySplitDate($returnVal,$d){      
       if(!empty($returnVal)){         
          $date=date($d,strtotime($returnVal));
			if($d=='M'){
				$date=Lang::get("messages.".date('M',strtotime($returnVal)));			
			}
       }	   
       return $date;
}

function displayDateTime($dateTime){
     $dateTimeTemp =  DateTime::createFromFormat('Y-m-d H:i:s', $dateTime);
     if(!$dateTimeTemp) return $dateTime;
     
     if($dateTimeTemp->format('H:i:s') == "00:00:00"){
        return $dateTimeTemp->format('Y-m-d');
    } 
    return $dateTimeTemp->format('Y-m-d h:i A'); 
}


function getPaginationSerial($obj){
    if(!isset($obj)) return 1;
    try{
        return ($obj->currentpage()-1)* $obj->perpage()+1;
    }catch(\Exception $ex){
        return 1;
    }
}


function getAppConfig($label){
    return \Config::get('constants.'.$label);
}

function getFileSize($bytes){
    if ($bytes >= 1073741824){
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
    }elseif ($bytes >= 1048576){
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
    }elseif ($bytes >= 1024)
        {
            $bytes = number_format($bytes / 1024, 2) . ' KB';
        }
        elseif ($bytes > 1)
        {
            $bytes = $bytes . ' bytes';
        }
        elseif ($bytes == 1)
        {
            $bytes = $bytes . ' byte';
        }
        else
        {
            $bytes = '0 bytes';
        }

        return $bytes;
}

function getFrontendAsset($path,$root=false){
    return ($root)?asset('assets/frontend/'.$path):asset('assets/frontend/dist/'.$path);
}

function getStorageAsset($path){
    return asset('public/storage/uploads/'.$path);
}

function adminPrefix(){
    return \Config::get('app.admin_prefix').'/';
}

function ap($path){
    return \Config::get('app.admin_prefix').'/'.$path;
}

function apa($path,$queryString = false){
	$url = asset(\Config::get('app.admin_prefix').'/'.$path);
	if($queryString){
		$qs = request()->query(); /* DONOT USE request()->all() , Will load post data too */
		if (count($qs)){

			foreach($qs as $key => $value){
				$qs[$key] = sprintf('%s=%s',$key, urlencode($value));
			}
			$url = sprintf('%s?%s', $url, implode('&', $qs));
		}
	}
    return $url;
}

function get_admin_menu_active_class($currentURI, $slugArr) {

    $className = '';
    $listArr = $slugArr;
    if (!is_array($listArr)) {
        $listArr = [$slugArr];
    }
    $URLParts = explode("/", $currentURI);
    if (!empty($URLParts)) {
        foreach ($URLParts as $Uparts) {
            if (in_array($Uparts, $listArr)) {
                $className = 'active';
            }
        }
    }

    if (in_array('seo', $URLParts)) {
        return null;
    }
    // pre($URLParts);
    return $className;
}

function getHumanReadbleFormat($date){
	$instance = $date->diff(new DateTime(date('Y-m-d H:i:s')));
	$returnText = '';
	if($instance->y >0){
		$returnText = $instance->y.' '.Lang::get('messages.years');
	}
	else if($instance->m >0){
		$returnText = $instance->m.' '.Lang::get('messages.months');
	}
	else if($instance->d >0){
		$returnText = $instance->d.' '.Lang::get('messages.days');
	}
	else if($instance->h >0){
		$returnText = $instance->h.' '.Lang::get('messages.hours');
	}
	else if($instance->i >0){
		$returnText = $instance->i.' '.Lang::get('messages.minutes');
	}
	else if($instance->s >=0){
		$returnText = $instance->s.' '.Lang::get('messages.seconds');
	}
	return $returnText;
}

function htmlAsset($fileName){
    return asset('assets/frontend/'.$fileName);
}

function lang($str){
    return Lang::get('messages.'.$str);
}

function getCategoryWisePosts($postsCollections,$fieldName){
    
	$splitedArray=[];
    foreach($postsCollections as $post){
       if(!empty($post->getData($fieldName))){
           $splitedArray[$post->getData($fieldName)][]=$post;
       }
	}
	return $splitedArray;
}

function getGalleryItemsByType($galCollection,$type){
	$filterArray=[];
    foreach($galCollection as $galItem){
          if($galItem->gallery_image_type == 1){
            $filterArray[] = $galItem;
          }
	}
	return $filterArray;
}
function youtubeImage($videoID){
	return "//img.youtube.com/vi/".$videoID."/sddefault.jpg";
}
function youtubeEmbedUrl($videoID){
	return "//www.youtube.com/embed/".$videoID."&autoplay=1&rel=0&controls=1&showinfo=1";
}

function getAgeFromDob($userDob){
    //Create a DateTime object using the user's date of birth.
    $dob = new \DateTime($userDob);
     
    //We need to compare the user's date of birth with today's date.
    $now = new \DateTime();
     
    //Calculate the time difference between the two dates.
    $difference = $now->diff($dob);
     
    //Get the difference in years, as we are looking for the user's age.
    return $difference->y;
}

function getDaysFromInterval($fromDate, $toDate, $resultFormat ='Y-m-d'){
    $res = array();    
    try{
        $intervalDays = new \DatePeriod(
         new \DateTime($fromDate),
         new \DateInterval('P1D'),
         new \DateTime($toDate)
        );
        
        $fromDate = \DateTime::createFromFormat($resultFormat, $fromDate);
        if(!empty($fromDate)){
            $res[] = $fromDate->format($resultFormat);
        }
        
        foreach($intervalDays as $day){
         $res[] =  $day->format($resultFormat);
        }
       
        $lastDate = \DateTime::createFromFormat($resultFormat, $toDate);

        if(!empty($lastDate)){
            $res[] = $lastDate->format($resultFormat);
        }
         
    }catch(\Exception $ex){
        return false;
    }
    return $res;


}

function _age($fomart='m/d/Y',$date) {
    $birthDate =date($format,strtotime($date));
    //explode the date to get month, day and year
    $birthDate =
            explode("/",
            $birthDate);
    //get age from date or birthdate
   return $age =
            (date("md",
                    date("U",
                            mktime(0,
                                    0,
                                    0,
                                    $birthDate[0],
                                    $birthDate[1],
                                    $birthDate[2]))) >
            date("md")
            ? ((date("Y") -
            $birthDate[2]) -
            1)
            : (date("Y") -
            $birthDate[2]));
}

/*
 The below function return day name and day of week as key
*/
function generateWeekDays($startDay='Sunday'){
    $timestamp = strtotime('next '.$startDay);
    $days = array();
    for ($i = 0; $i < 7; $i++) {
        $dayName = strftime('%A', $timestamp);
        $days[date('w',$timestamp)] = $dayName;
        $timestamp = strtotime('+1 day', $timestamp);
    }
   return $days;
}

function getAdminStatusIcon($status,$link=''){
	$link = ($link) ? ' href="'.$link.'"' : '';
    $iconStr = '<a '.$link.'><i class="fa fa-check-circle"></i></a>';
    if($status ==2){
        $iconStr = '<a '.$link.'><i class="fa fa-times-circle"></i></a>';
    }else if($status == 3){
		 $iconStr = '<a '.$link.'><i class="fas fa-clock"></i></a>';
	}
    return $iconStr;
}

function getAdminActionIcons($buttons,$postType,$item){
	$str = '';
    if($buttons['edit'] || $buttons['delete'] ){
		$str.='<td class="manage">';
			$str.='<ul>';
			if($buttons['edit'] ){
				$str.='<li>';
					$str.='<a href="'.route('post_edit',[$postType,$item->post_id]).'"  title="edit"><i class="far fa-edit"></i></a>';
				$str.='</li>';
			}
			if($buttons['delete'] ){
				$str.='<li>';
					$str.='<a class="deleteRecord" href="'.route('post_delete',[$postType,$item->post_id]).'"  title="delete" ><i class="fa fa-trash"></i></a>';
				$str.='</li>';
			}
			$str.='</ul>';
		$str.='</td>';
	}
	return $str;
}

function displayAdminUploadedThumb($fieldVal,$path){
    
    if(empty($fieldVal)) return '';
    
    return '<div class="admin-upload-thumb"><img src="'.asset($path.'/'.$fieldVal).'"/></div>';
    
}

function is_between_times($startTime, $endTime, $timeToCheck){
    return $timeToCheck->greaterThanOrEqualTo($startTime) && $timeToCheck->lessThan($endTime);
}

function urlWithQueryStr($path = null, $secure = null)
{
    $url = app('url')->to($path, $secure);
	$qs = request()->all();
    if (count($qs)){

        foreach($qs as $key => $value){
            $qs[$key] = sprintf('%s=%s',$key, urlencode($value));
        }
        $url = sprintf('%s?%s', $url, implode('&', $qs));
    }
    return $url;
}

function isFrontendUserLoggedIn(){
	if(Auth::user() && @Auth::user()->is_backend_user == 2){
		return true;
	}
	return false;
}
function adjust_title_with_br($title,$lang,$removeThe=true){
	if($lang=='en' && $removeThe == true){
		$title = trim(str_replace('the','',strtolower($title)));
	}
	$title = str_replace('|','<br/>',$title);
	return $title;
}

function adjust_title_without_pipe($title,$lang,$removeThe=true){
	if($lang=='en' && $removeThe == true){
		$title = trim(str_replace('the','',strtolower($title)));
	}
	$title = str_replace('|','',$title);
	return $title;
}
function get_months_duration($startTime , $endTime){
    $to = \Carbon\Carbon::createFromFormat('Y-m-d', $startTime);
    $from = \Carbon\Carbon::createFromFormat('Y-m-d', $endTime);
    return $diff_in_months = $to->diffInMonths($from);
}
function date_convert($date){
    return $date = date("j F Y", strtotime($date));
}
function get_profile_image($user_image){
	
	$image_url = htmlAsset('images/person01.jpg');
    if(File::exists(storage_path('app/public/uploads/user/small/'.$user_image)) && !empty($user_image)){
		$image_url = asset('storage/uploads/user/small/'.$user_image);
	}
	
	return $image_url;
	
}
function get_profile_large_image($user_image){
	
	$image_url = htmlAsset('images/person01.jpg');
    if(File::exists(storage_path('app/public/uploads/user/large/'.$user_image)) && !empty($user_image)){
		$image_url = asset('storage/uploads/user/large/'.$user_image);
	}
	
	return $image_url;
	
}
function get_farm_image($farm_image){
        
    if(File::exists(storage_path('app/public/uploads/farm/image/small/'.$farm_image)) && !empty($farm_image)){
		$image_url = asset('storage/uploads/farm/image/small/'.$farm_image);	
    }
    else {
        $image_url = htmlAsset('images/farm_default.jpg');
    }
		
	return $image_url;
	
}
function get_farm_large_image($farm_image){
		
    if(File::exists(storage_path('app/public/uploads/farm/image/large/'.$farm_image)) && !empty($farm_image)){
		$image_url = asset('storage/uploads/farm/image/large/'.$farm_image);	
    }
    else {
        $image_url = htmlAsset('images/farm_default_large.jpg');
    }	
	return $image_url;
	
}
function get_crop_image($crop_image){
		
	$image_url = asset('storage/uploads/agriculture/icon/'.$crop_image);
	return $image_url;
	
}
function toAcre($area_val,$area_unit){
	
	$acre = 0;
	if($area_unit == 'M2')
	{
		$acre = $area_val * 0.000247105;
	}
	if($area_unit == 'Feet')
	{
		$acre = $area_val * 0.00002295684;
	}
    //$acre = number_format((float)$acre, 1, '.', '');
    $acre = round($acre,4);
	if($area_unit == 'Acre')
	{
		$acre = $area_val;
	}
	
	
	return $acre.' acre';
}
?>