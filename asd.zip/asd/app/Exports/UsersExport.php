<?php

namespace App\Exports;

use App\User;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class UsersExport implements FromView
{
	protected $request;
	
	public function __construct($request){
		$this->request = $request;
	}
    public function view(): View
    {
		$type = $this->request->input('type');
		$isZip = $this->request->input('zip');
		
		$userTmp = User::filter();
		if(!empty($this->request->input('registrationID'))){
			$userTmp->where('id',$this->request->input('registrationID'));
		}
		
		$user = $userTmp->get();
		$template = ($type == 'excel') ? 'admin.registrations.exports.excel_export' : 'admin.registrations.exports.pdf_export';
        return view($template, ['users' => $user]);
    }
	
	private function _getViewTemplate(){
		switch(){
			case 'pdf':
			break;
		}
		
	}
}
