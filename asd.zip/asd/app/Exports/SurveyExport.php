<?php
namespace App\Exports;

use App\Models\Admodels\SurveyUserModel;
use App\Models\Admodels\SurveyMasterModel;
use Maatwebsite\Excel\Concerns\RegistersEventListeners;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\BeforeExport;
use Maatwebsite\Excel\Events\AfterSheet;
use \App\ExcelHelper;

class SurveyExport implements FromArray, WithEvents
{
	use RegistersEventListeners;
	private $request;
	private $surveySlug;
	public function __construct($request,$surveySlug){
		$this->request = $request;
		$this->surveySlug = $surveySlug;
	}
	
	public function registerEvents(): array{
        return [
            AfterSheet::class    => function(AfterSheet $event) {
                $event->sheet->setOrientation(\PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_LANDSCAPE);

                /* $event->sheet->styleCells(
                    'B2:G8',
                    [
                        'borders' => [
                            'outline' => [
                                'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK,
                                'color' => ['argb' => 'FFFF0000'],
                            ],
                        ]
                    ]
                ); */
				
				$event->sheet->mergeCells('A1:AD1');
				$event->sheet->getStyle('A1')->applyFromArray(
					['font' => [
						'bold' => true,
						'size' => 18
						],
					]
				);
            },
        ];
    }
	
	public function array(): array
    {	

		$excelHelper  = new ExcelHelper;
       
		$survey = SurveyMasterModel::orderBy('sm_id','asc')
						->where('sm_slug','=',$this->surveySlug)
						->first();
						
		$users = SurveyUserModel::orderBy('created_at','desc')
					->whereHas('surveyDetails',function($q) use($survey){ 
						$q->where('sm_id','=',$survey->sm_id);
					})->get();
		
		$title = $survey->sm_title.( ($survey->sm_description) ? $survey->sm_description : '' );
		$excelHelper->setExcelHeader([$title]);
		$headers = [
				-2 => '#',
				-1 => 'Name',
				0 => 'Email',
			];
			
		/* EXcel headers are created dynamically, the sort order order here is important*/
		$questions = $survey->questions()->orderBy('sqm_id','asc')->get();
		foreach($questions as $question){
			$headers[$question->sqm_id] = $question->sqm_question_en;
		}

		$slNo = 1;
		foreach($users as $user){
			$singleUsrArr = null;
			foreach($headers as $key=>$val){
				$singleUsrArr[$key] = '-';
			}
			
			$singleUsrArr[-2]= $slNo++;
			$userAnswers = $user->userSurvey()->orderBy('sua_question_id','asc')->get();
			if(!empty($user->userDetails->email)){
				$singleUsrArr[-1] = $user->userDetails->name;
				$singleUsrArr[0] = $user->userDetails->email;
			}else{
				$singleUsrArr[-1]= '-';
				$singleUsrArr[0]= $user->su_email;

			}

			foreach($userAnswers as $record){
		
				if(@$record->answer->show_textbox_if_selected) {
					$singleUsrArr[$record->sua_question_id]=$record->sua_answer_text ;
				}else{
					$data = (empty($record->answer->sa_answer)) ? $record->sua_answer_text : $record->answer->sa_answer ;
					$singleUsrArr[$record->sua_question_id]= $data;
				}
			}
			
			ksort($singleUsrArr);
			$excelHelper->setExcelData($singleUsrArr);
		}
		
		$excelHelper->setExcelHeader($headers);
		return $excelHelper->getExcelHeadersAndData();
    }
}