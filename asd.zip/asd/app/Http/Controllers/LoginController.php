<?php

namespace App\Http\Controllers;

use App\Http\Controllers\FrontendBaseController;
use App\User as User;
use Auth;
use Input;
use Config;
use Illuminate\Http\Request;

class LoginController extends FrontendBaseController {
	
    public function __construct(Request $request){
		// pre('asd');
		 parent::__construct($request);
	}

	public function index(Request $request){
		$this->data['message']='';
		if(Input::get('user_email')){
			$inputs = [
				'user_email'=>Input::get('user_email'),
				'password'=>Input::get('password'),
			];
			$rules = [
				'user_email' => 'required',
				'password' => 'required',
			];
			
			$messages = [
				'user_email.required' => trans('messages.email_required'),
				'password.required' => trans('messages.password_required'),
			];
			
			$validator = \Validator::make($inputs,$rules,$messages);
			if($validator->fails()){
                $request->flash();
				$errors = '<ul class="alert alert-danger">';
				$messages = $validator->messages()->all();
				foreach($messages as $message){
					$errors .= '<li>'.$message.'</li>';
				}
				$errors .= '</ul>';
				$response_data['userMessage'] = $errors;
                $response_data['status'] = false;
                
			}else{
			
				$credentials = array('user_email' => Input::get('user_email'), 'password' => Input::get('password'),'user_status'=>1);

				if(Auth::attempt($credentials)){
					if(Auth::user()->user_email_confirmed != 1){
						$response_data['userMessage'] = trans('messages.email_not_verified');
                    	$response_data['status'] = false;
						return Response($response_data);
					}
                     User::where('id','=',Auth::user()->id)
                     ->update(['last_logged_in'=>\Carbon\Carbon::now()->toDateTimeString()]); 
                     $lang = $this->data['lang'];
					 $response_data['status'] = true;
                     $response_data['redirectURL'] = url($lang."/home");
				}else{
                    $response_data['userMessage'] = trans('messages.invalid_login');
                    $response_data['status'] = false;
				}
				
			}
            return Response($response_data);
		}
		
	}
	
	public function logout(){
        $lang = $this->data['lang'];
	 	Auth::logout();
		\Session::flush();
		return redirect()->to($lang.'/');
	}
    
    public function signin(Request $request){
		return view('frontend.user.login',$this->data);
	}

	
}
