<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\Base\AdminBaseController;
use Validator, Input, Redirect, Auth, Config, DB;
use Illuminate\Support\Facades\Gate;
use App\User as User;
use Illuminate\Http\Request;
use File;
use View;
use App\Models\FarmModel;
use App\Models\FarmSubscriptionModel;


class FarmSubscriptionController extends AdminBaseController
{

    protected $roleName;
    public function __construct(Request $request)
    {

        parent::__construct($request);
        $this->roleNames = ['Super Admin', 'Farm subscription Manager'];
    }

    private function checkPermission($name)
    {
        return ($this->userObj->can($name)) ? true : false;
    }


    public function index()
    {
        $query = FarmSubscriptionModel::orderBy('fs_created_at','desc');
        $name = Input::get('name');
        
        if(!empty($name)){
            $query->whereHas('getFarmDetails',function($q) use($name) {
                return $q->where('farm_master.fm_title','LIKE', "%$name%");                                  
            });
        }

        //$this->data['subscriptionList'] = FarmSubscriptionModel::orderBy('fs_created_at', 'desc')->paginate(20);
        $this->data['subscriptionList'] = $query->paginate(20)->appends(Input::except('page'));
        return View::make('admin.farm_subscription.index', $this->data);
    }

    public function view($id, Request $request)
    {

        if (empty($id)) {
            return redirect()->to(Config::get('app.admin_prefix') . '/farm_subscriptions');
        }
        $this->data['messages']    = '';

        $this->data['subscriptionDetails'] = FarmSubscriptionModel::findorfail($id);

        return View::make('admin.farm_subscription.view', $this->data);
    }
}
