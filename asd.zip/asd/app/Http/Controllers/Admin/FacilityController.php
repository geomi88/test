<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\Base\AdminBaseController;
use Validator, Input, Redirect,Auth,Config,DB;
use Illuminate\Support\Facades\Gate;
use App\User as User;
use Illuminate\Http\Request;
use File;
use View;
use App\Models\FacilityModel;
use App\Models\CategoryModel;

class FacilityController extends AdminBaseController {
	
	protected $roleName;
	public function __construct(Request $request){

		parent::__construct($request);
		$this->roleNames = ['Super Admin','Facility Manager'];
	}
	
	private function checkPermission($name){
		return ($this->userObj->can($name)) ? true : false;
	}

	
	public function index(){
		// pre($this->data);
		/* if( !$this->userObj->hasAnyRole($this->roleNames) ){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		} */
		
		$this->data['facilityList']= FacilityModel::orderBy('facility_title','asc')->paginate(20);
		
		return View::make('admin.facility.list',$this->data);		 
	}
	
	public function create(Request $request){	
		
		
		/*if(!$this->checkPermission('Create Country')){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		}*/
		
		$this->data['messages']='';
		// pre($request->all());
		if($request->input('savebtnsubmit')){
				

				$insertData = array();
				$insertData = array(
								'facility_title'=>$request->input('facility_title'),
								'facility_exceprt'=>$request->input('facility_excerpt'),
								'facility_description'=>$request->input('facility_description'),
								'facility_created_by'=> Auth::user()->id,
								'facility_updated_by'=> Auth::user()->id,
								'facility_status'=>$request->input('facility_status')		
								);
								
				$imageFile = $request->file('facility_image');

				if($imageFile){
					$filePath = 'public/uploads/facility/image/';
					list($fileName, $fileNameWithPath) = $this->store_file('facility_image', 'public/uploads/facility/image/');
					$insertData['facility_image'] = $fileName;
				}

				$iconFile = $request->file('facility_icon');

				if($iconFile){
					$filePath = 'public/uploads/facility/icon/';
					list($fileName, $fileNameWithPath) = $this->store_file('facility_icon', 'public/uploads/facility/icon/');
					$insertData['facility_icon'] = $fileName;
				}

				$newfacility = FacilityModel::create($insertData);
				
				if(empty($newfacility)){
					return redirect()->to(apa('facility_manager'))->with('errorMessage','Cannot save to database');
				}

				$this->data['userMessage'] =$this->custom_message('Facility added Successfully','success');		
		}
		
		
		return View::make('admin.facility.create',$this->data);			 
	}

	public function update($id, Request $request){	 
	
		/*
		if(!$this->checkPermission('Edit Country')){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		}*/
		
		
		if(empty($id)) { return redirect()->to(Config::get('app.admin_prefix').'/facility_manager');}		
		$this->data['messages']	='';
		if($request->input('updatebtnsubmit')){		
				$updateData = array();
				$updateData = array(
								//'facility_category_id'=>$request->input('facility_category_id'),
								//'facility_type_id'=>$request->input('facility_type_id'),
								'facility_title'=>$request->input('facility_title'),
								'facility_exceprt'=>$request->input('facility_excerpt'),
								'facility_description'=>$request->input('facility_description'),
								'facility_created_by'=> Auth::user()->id,
								'facility_updated_by'=> Auth::user()->id,
								'facility_status'=>$request->input('facility_status')		
								);
								
				$imageFile = $request->file('facility_image');
				
				if($imageFile){
					$filePath = 'public/uploads/facility/image/';
					list($fileName, $fileNameWithPath) = $this->store_file('facility_image', 'public/uploads/facility/image/');
					$updateData['facility_image'] = $fileName;
				}
				
				$iconFile = $request->file('facility_icon');
				
				if($iconFile){
					$filePath = 'public/uploads/facility/icon/';
					list($fileName, $fileNameWithPath) = $this->store_file('facility_icon', 'public/uploads/facility/icon/');
					$updateData['facility_icon'] = $fileName;
				}
				// pre($updateData);

				$facility = FacilityModel::where('facility_id','=',$id)->update($updateData);
				$this->data['userMessage'] = $this->custom_message('Facility updated successfully','success');		
			}
		
	 $this->data['facilityDetails'] = FacilityModel::findorfail($id);
	 
	 return View::make('admin.facility.edit',$this->data);			 
  }

	public function changestatus($statusID,$currentStatus){
		
		if(!$this->checkPermission('Edit Country')){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		}
		
		
		$currentStatus = ($currentStatus==0)?1:0;
		 $currentStatusdatas = array("country_status"=>$currentStatus);
		 DB::table('country')->where('country_id', '=',$statusID)->update($currentStatusdatas);	
		return redirect()->to(Config::get('app.admin_prefix').'/country')->with('userMessage','Status changed');
	}
	
	public function delete($deleteID){	 
		
		/*if(!$this->checkPermission('Delete Country')){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		}
		
		
		if( !$this->userObj->hasRole($this->roleName) ){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		}*/
		
		if(empty($deleteID)) { return redirect()->to(Config::get('app.admin_prefix').'/country');}
		 DB::table('country')->where('country_id', '=',$deleteID)->delete();	
		 $this->data['messages'] = $this->custom_message('Deleted Successfully','success');
		 return redirect()->to(Config::get('app.admin_prefix').'/country')->with('flash_error','deleted');
	 }	 
	
	


}