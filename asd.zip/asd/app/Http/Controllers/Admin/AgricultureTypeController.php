<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\Base\AdminBaseController;
use Validator, Input, Redirect, Auth, Config, DB;
use Illuminate\Support\Facades\Gate;
use App\User as User;
use Illuminate\Http\Request;
use File;
use View;
use App\Models\AgricultureTypeModel;

class AgricultureTypeController extends AdminBaseController
{

	protected $roleName;
	public function __construct(Request $request)
	{

		parent::__construct($request);
		$this->roleNames = ['Super Admin', 'Agriculture Type Manager'];
	}

	private function checkPermission($name)
	{
		return ($this->userObj->can($name)) ? true : false;
	}
	private function _set_post_validations($request){
		
		$this->rules =  [
			'agriculture_type_title'=>'required',
			'agriculture_type_status'=>'required',
		];
		
		$this->messages = [
			'agriculture_type_title.required'=>'Title is required',
            'agriculture_type_status.required'=>'Status is required',
		];
		
		$slugRules = [];
		$slugMessages = [];
		
		
		$this->rules = array_merge($this->rules, $slugRules);
		$this->messages = array_merge($this->rules, $slugMessages);
		
		return (!empty($this->messages)) ? $this->validate($request,$this->rules,$this->messages) : $this->validate($request,$this->rules);
	}

	public function index()
	{
		// pre($this->data);
		/* if( !$this->userObj->hasAnyRole($this->roleNames) ){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		} */

		$this->data['agriTypeList'] = AgricultureTypeModel::orderBy('agriculture_type_title', 'asc')->paginate(20);

		return View::make('admin.agriculture_type.list', $this->data);
	}

	public function create(Request $request)
	{


		/*if(!$this->checkPermission('Create Country')){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		}*/

		$this->data['messages'] = '';
		if ($request->input('savebtnsubmit')) {

			$this->_set_post_validations($request);

			$insertData = array();
			$insertData = array(
				'agriculture_type_title' => $request->input('agriculture_type_title'),
				'agriculture_type_created_by' => Auth::user()->id,
				'agriculture_type_updated_by' => Auth::user()->id,
				'agriculture_type_status' => $request->input('agriculture_type_status')
			);

			
			$newType = AgricultureTypeModel::create($insertData);

			if (empty($newType)) {
				return redirect()->to(apa('agriculture_type'))->with('errorMessage', 'Cannot save to database');
			}

			$this->data['userMessage'] = $this->custom_message('Agriculture Type added Successfully', 'success');
		}


		return View::make('admin.agriculture_type.create', $this->data);
	}

	public function update($id, Request $request)
	{

		/*
		if(!$this->checkPermission('Edit Country')){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		}*/


		if (empty($id)) {
			return redirect()->to(Config::get('app.admin_prefix') . '/agriculture_type');
		}
		$this->data['messages']	= '';
		if ($request->input('updatebtnsubmit')) {
			$this->_set_post_validations($request);

			$updateData = array();
			$updateData = array(
				'agriculture_type_title' => $request->input('agriculture_type_title'),
				'agriculture_type_created_by' => Auth::user()->id,
				'agriculture_type_updated_by' => Auth::user()->id,
				'agriculture_type_status' => $request->input('agriculture_type_status')
			);
			
			$agri_type = AgricultureTypeModel::where('agriculture_type_id', '=', $id)->update($updateData);
			$this->data['userMessage'] = $this->custom_message('Agriculture Type updated successfully', 'success');
		}

		$this->data['agriTypeDetails'] = AgricultureTypeModel::findorfail($id);

		return View::make('admin.agriculture_type.edit', $this->data);
	}

	public function changestatus($statusID, $currentStatus)
	{

		if (!$this->checkPermission('Edit Agriculture Type')) {
			return Redirect(route('admin_dashboard'))->with('userMessage', 'Invalid Permission');
		}


		$currentStatus = ($currentStatus == 0) ? 1 : 0;
		$currentStatusdatas = array("agriculture_type_status" => $currentStatus);
		DB::table('agriculture_types')->where('agriculture_type_id', '=', $statusID)->update($currentStatusdatas);
		return redirect()->to(Config::get('app.admin_prefix') . '/agriculture_type')->with('userMessage', 'Status changed');
	}

	public function delete($deleteID)
	{

		/*if (!$this->checkPermission('Delete Agriculture Type')) {
			return Redirect(route('admin_dashboard'))->with('userMessage', 'Invalid Permission');
		}


		if (!$this->userObj->hasRole($this->roleName)) {
			return Redirect(route('admin_dashboard'))->with('userMessage', 'Invalid Permission');
		}*/

		if (empty($deleteID)) {
			return redirect()->to(Config::get('app.admin_prefix') . '/agriculture_type');
		}
		DB::table('agriculture_types')->where('agriculture_type_id', '=', $deleteID)->delete();
		$this->data['messages'] = $this->custom_message('Deleted Successfully', 'success');
		return redirect()->to(Config::get('app.admin_prefix') . '/agriculture_type')->with('flash_error', 'deleted');
	}
}
