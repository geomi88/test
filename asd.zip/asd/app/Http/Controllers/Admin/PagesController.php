<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\Base\AdminBaseController;
use Validator, Input, Redirect,Auth,Config,DB;
use Illuminate\Support\Facades\Gate;
use App\User as User;
use Illuminate\Http\Request;
use App\Models\Admodels\PageModel;
use App\Models\Admodels\ObjectiveModel;
use App\Models\Admodels\InitiativeModel;
use File;


class PagesController extends AdminBaseController {

	private $pageSlug;
  public $tree = array();

	public function __construct(Request $request){

		 parent::__construct($request);

	}
	
	public function GeneratePassword($length, $characters){
		$output='';
		$strLen = strlen($characters)-1;

		for($i=0;$i<$length;$i++){
		$output .= $characters[rand(0,$strLen)];
		}
		return $output;
	}
	
	public function index(){
		
		
		$pageList = PageModel::getMenus();
		//pre($pageList);

		$allPages = $this->buildTree($pageList);
        
		$this->data['pageTreeAdmin'] = $allPages;
		//pre($pageList);
		return view('admin.pages.list',$this->data);
	}

	private function get_unique_page_slug($pageSlug,$id=false){
		$this->pageSlug = $pageSlug;
		// pre('asd');
		$tempRes = DB::Table('pages')
				   ->where(DB::Raw('TRIM(page_slug)'),'=',trim($this->pageSlug));
			if(!empty($id)){
				$tempRes =	$tempRes->where('page_id','!=',$id);
			}
			$tempRes	= $tempRes->first();
			// pre($tempRes);
		if(!empty($tempRes)){
			$ttt = explode('-',strtolower($tempRes->page_slug));
			$newSlugCount = (int)end($ttt)+1;
			if($newSlugCount<2){
				$ttt[count($ttt)] = $newSlugCount;
			}else{
				$ttt[count($ttt)-1] = $newSlugCount;
			}
			$this->pageSlug = implode("-",$ttt);

			$this->get_unique_page_slug($this->pageSlug);
		}

		//return "Return ".$this->pageSlug."<br/>";;
		return $this->pageSlug;
	}



	public function create(Request $request){
		

		// If the page is created by an Author or Reviewer, then do the following steps
		// a) DO NOT SAVE THE PAGE CONTENTS TO PAGES table
		// b) SAVE PAGE CONTENT TO PAGE_HISTORY TABLE WITH STATUS 1 FOR AUTHOR AND  STATUS  2 FOR REVIEWER
		// c) IF A REVIEWER LOGS IN, PULL ALL THE PAGES FROM PAGE HISTORY TABLE WITH STATUS  1
		// d) IF A PUBLISHER LOGS IN, PULL ALL THE PAGES FROM PAGE HISTORY TABLE WITH STATUS  2
		// e) WHEN A PUBLISHER PUBLISHES THE PAGE COPY THE CONTENTS FROM PAGE HISTORY TABLE TO PAGES TABLE AND MAKE STATUS IN
		//    PAGE HISTORY TABLE AS PUBLISHED
		// f)
			// pre($_POST);
		// $this->data['messages']='';
		// pre($request->all());
		// echo $request->isMethod('createbtnsubmit');
		// exit();
		if( $request->input('createbtnsubmit') && $request->isMethod('post') ){
			// pre($request->all());
			$this->validate($request, [
											'page_name' => 'required',
											'page_type' => 'required',
											'page_priority' => 'required',
										]);

			$page_large_desc = str_replace("../../../","",$request->input('page_large_desc'));
			$page_large_desc_arabic = str_replace("../../../","",$request->input('page_large_desc_arabic'));
			// $page_large_desc2 = str_replace("../../../","",$request->input('page_large_desc2'));
			// $page_large_desc2_arabic = str_replace("../../../","",$request->input('page_large_desc2_arabic'));
			// pre($request->all());
			$arr = array(
						  'page_is_main_navigation' =>$request->input('is_main_navigation'),
						  'page_parent_id' =>$request->input('page_parent_id'),
						  'page_name' =>$request->input('page_name'),
						  'page_name_arabic' =>$request->input('page_name_arabic'),
						  'page_subtitle' =>$request->input('page_subtitle'),
						  'page_subtitle_arabic' =>$request->input('page_subtitle_arabic'),
						  'page_short_desc' =>$request->input('page_short_desc'),
						  'page_short_desc_arabic' =>$request->input('page_short_desc_arabic'),
						  'page_large_desc' =>$page_large_desc,
						  'page_large_desc_arabic' =>$page_large_desc_arabic,
						  'page_custom_content' =>$request->input('page_custom_content'),
						  'page_custom_content_arabic' =>$request->input('page_custom_content_arabic'),
						  'page_seo_title' =>$request->input('page_seo_title'),
						  'page_meta_title' =>$request->input('page_meta_title'),
						  'page_meta_description' =>$request->input('page_meta_description'),
						  'page_meta_keyword' =>$request->input('page_meta_keyword'),
						  'page_seo_title_arabic' =>$request->input('page_seo_title_arabic'),
						  'page_meta_title_arabic' =>$request->input('page_meta_title_arabic'),
						  'page_meta_description_arabic' =>$request->input('page_meta_description_arabic'),
						  'page_meta_keyword_arabic' =>$request->input('page_meta_keyword_arabic'),
						  'page_youtube_url' =>$request->input('page_youtube_url'),
						  'page_type' =>$request->input('page_type'),
						  'page_priority' =>$request->input('page_priority'),
						   'page_icon_mobile' =>$request->input('page_icon_mobile'),
						  'page_is_hide_mobile' =>$request->input('is_hide_mobile'),
						  'page_created_by'=>Auth::user()->id,
						  'page_updated_by'=>Auth::user()->id,
						  'page_status'=>$request->input('page_status')
			          	);


					
					$arr['page_slug'] = $this->get_unique_page_slug(trim(strtolower(str_slug($request->input('page_name')))));

					//Check for footer link
					if ($request->input('is_footer_link') == 2) {
							$arr['page_is_footer_link'] = 2;
					}else{
							$arr['page_is_footer_link'] = 1;
					}
                    
                    if ($request->input('page_inject_collection') == 1) {
							$arr['page_inject_collection'] = 1;
					}else{
							$arr['page_inject_collection'] = 2;
					}

					/* if ($request->input('page_nav_link') == 2) {
						$arr['page_nav_link'] = 2;
					}else{
						$arr['page_nav_link'] = 1;
					}  */
					// pre($arr);


					$bannerImage = $request->file('page_banner');
					
					if($bannerImage){
						
						$width = 1920;
						$height = 1064;
					
						$filePath = 'uploads/pages/banners';
						list($fileName, $fileNameWithPath) = $this->store_file('page_banner', 'uploads/pages/banners');
						
						$this->resize_image($fileName,$filePath,array('recommended'=> array('height' => $height,'width'=> $width), 'small'=>array('height' => 720,'width'=> 163)));
						$arr['page_banner']= ($fileName)?$fileName:null;
					}
					

					$bannerImage = $request->file('page_banner_small');
					if($bannerImage){
						$filePath = 'public/uploads/pages/banners';
						list($fileName, $fileNameWithPath) = $this->store_file('page_banner_small', 'public/uploads/pages/banners');
						$this->resize_image($fileName,$filePath,array('recommended'=> array('height' => 378,'width'=> 224), 'small'=>array('height' => 189,'width'=> 112)));
						$arr['page_banner_small']= ($fileName)?$fileName:null;
					}
					
					$bannerImage = $request->file('page_banner_medium');
					if($bannerImage){
						$filePath = 'public/uploads/pages/banners';
						list($fileName, $fileNameWithPath) = $this->store_file('page_banner_medium', 'public/uploads/pages/banners');
						$this->resize_image($fileName,$filePath,array('recommended'=> array('height' => 578,'width'=> 612), 'small'=>array('height' => 289,'width'=> 306)));
						$arr['page_banner_medium']= ($fileName)?$fileName:null;
					}
                    $page_menu_icon = $request->file('page_menu_icon');
					if($page_menu_icon){
						$filePath = 'public/uploads/pages/menu_icon';
						list($fileName, $fileNameWithPath) = $this->store_file('page_banner_medium', 'public/uploads/pages/menu_icon');
						$arr['page_menu_icon']= ($fileName)?$fileName:null;
					}

					//Calculate current menu page level
					$parentID = $request->input('page_parent_id');
					$menuLevel = 	Pagemodel::find($parentID);
					if(!empty($menuLevel)){
						$arr['page_level'] = $menuLevel->page_level + 1;
					}
					
					

					$newPageID = Pagemodel::create($arr);
					
					return back()->with('success','Page details saved successfully.');
			}


		$pageList = Pagemodel::orderBy('page_parent_id','asc')->get();
		$allPages = $this->buildTree($pageList);
		$this->data['pageTreeAdminSelect'] = $allPages;
		return view('admin.pages.add',$this->data);
	}

	public function update($editSlug, Request $request){

  		
		if(empty($editSlug)) { return redirect()->to(Config::get('app.admin_prefix').'/pages');}

		$newSlug = $editSlug;

		$this->data['pageDetails'] = Pagemodel::where('page_slug','=',$editSlug)->first();

		if(empty($this->data['pageDetails'])){
			$this->data['messages']	='Invalid page request';
			return redirect()->to(Config::get('app.admin_prefix').'/pages');
		}
		$this->data['messages']	='';
		$this->data['validationErrors'] = false;
		if($request->input('updatebtnsubmit') || $request->input('updatebtnsubmit1')){
			
			$page_large_desc = str_replace("../../../","",$request->input('page_large_desc'));
			$page_large_desc_arabic = str_replace("../../../","",$request->input('page_large_desc_arabic'));

			$arr = array(
						  'page_is_main_navigation' => $request->input('is_main_navigation'),
						  'page_parent_id' =>$request->input('page_parent_id'),
						  'page_name' =>$request->input('page_name'),
						  'page_name_arabic' =>$request->input('page_name_arabic'),
						  'page_subtitle' =>$request->input('page_subtitle'),
						  'page_subtitle_arabic' =>$request->input('page_subtitle_arabic'),
						  'page_short_desc' =>$request->input('page_short_desc'),
						  'page_short_desc_arabic' =>$request->input('page_short_desc_arabic'),
						  'page_large_desc' =>$page_large_desc,
						  'page_large_desc_arabic' =>$page_large_desc_arabic,
						  'page_custom_content' =>$request->input('page_custom_content'),
						  'page_custom_content_arabic' =>$request->input('page_custom_content_arabic'),
						  'page_seo_title' =>$request->input('page_seo_title'),
						  'page_meta_title' =>$request->input('page_meta_title'),
						  'page_meta_description' =>$request->input('page_meta_description'),
						  'page_meta_keyword' =>$request->input('page_meta_keyword'),
						  'page_seo_title_arabic' =>$request->input('page_seo_title_arabic'),
						  'page_meta_title_arabic' =>$request->input('page_meta_title_arabic'),
						  'page_meta_description_arabic' =>$request->input('page_meta_description_arabic'),
						  'page_meta_keyword_arabic' =>$request->input('page_meta_keyword_arabic'),
						  'page_type' =>$request->input('page_type'),
						  'page_icon_mobile' =>$request->input('page_icon_mobile'),
						  'page_is_hide_mobile' =>$request->input('is_hide_mobile'),
						  'page_priority' =>$request->input('page_priority'),
						  'page_created_by'=>Auth::user()->id,
						  'page_updated_by'=>Auth::user()->id,
						  'page_status'=>$request->input('page_status'),
		          	);

				
					$YTurl = $request->input('page_youtube_url');	
					if (!empty($YTurl)) {
						$arr['page_youtube_url'] = $request->input('page_youtube_url');
						$YTid = $this->get_youtube_id($arr['page_youtube_url']);
						if(!empty($YTid)){
							$arr['page_youtube_id'] = $YTid;
						}
					}
                    
                    if ($request->input('page_inject_collection') == 1) {
							$arr['page_inject_collection'] = 1;
					}else{
							$arr['page_inject_collection'] = 2;
					}
                    
					if ($request->input('page_nav_link') == 2) {
							$arr['page_nav_link'] = 2;
					}else{
							$arr['page_nav_link'] = 1;
					} 
					
					
					$bannerImage = $request->file('page_banner');
					if($bannerImage){
						$tempSlug = $this->data['pageDetails']->page_slug;
						$width = 1920;
						$height = 1064;
					
						$filePath = 'uploads/pages/banners';
						list($fileName, $fileNameWithPath) = $this->store_file('page_banner', 'uploads/pages/banners');
						
						$this->resize_image($fileName,$filePath,array('recommended'=> array('height' => $height,'width'=> $width)));
						$arr['page_banner']= ($fileName)?$fileName:null;
					}
					
					

					$bannerImage = $request->file('page_banner_small');
					if($bannerImage){
						$tempSlug = $this->data['pageDetails']->page_slug;
						$width = 578;
						$height = 712;
						$filePath = 'uploads/pages/banners';
						list($fileName, $fileNameWithPath) = $this->store_file('page_banner_small', 'uploads/pages/banners');
						$this->resize_image($fileName,$filePath,array('recommended'=> array('height' => $height,'width'=> $width)));
						$arr['page_banner_small']= ($fileName)?$fileName:null;
					}
					
					$bannerImage = $request->file('page_banner_medium');
					if($bannerImage){
						$filePath = 'public/uploads/pages/banners';
						list($fileName, $fileNameWithPath) = $this->store_file('page_banner_medium', 'public/uploads/pages/banners');
						$this->resize_image($fileName,$filePath,array('recommended'=> array('height' => 537,'width'=> 552), 'small'=>array('height' => 269,'width'=> 276)));
						$arr['page_banner_medium']= ($fileName)?$fileName:null;
					}
					$page_menu_icon = $request->file('page_menu_icon');
					if($page_menu_icon){
						$filePath = 'public/uploads/pages/menu_icon';
						list($fileName, $fileNameWithPath) = $this->store_file('page_banner_medium', 'public/uploads/pages/menu_icon');
						$arr['page_menu_icon']= ($fileName)?$fileName:null;
					}


					
					//Calculate current menu page level
					$parentID = $request->input('page_parent_id');
					$menuLevel = 	Pagemodel::find($parentID);
					if(!empty($menuLevel)){
						$arr['page_level'] = $menuLevel->page_level + 1;
					}


					$menuLevel = 	Pagemodel::where('page_id', '=',$request->input('page_parent_id'))->first();

					if(!empty($menuLevel)){
							$arr['page_level'] = $menuLevel->page_level + 1;
					}else{
							$arr['page_level'] = 0;
					}
					// pre($arr);
					if($request->input('page_parent_id') == $this->data['pageDetails']->page_id ){ // Dont allow to save this page as its parent
						$this->data['messages'] = $this->custom_message('Invalid Operation. Cannot set same page as it\'s parent','error');
					}else{//update data
						Pagemodel::where('page_slug', $editSlug)->update($arr);
						$this->data['messages'] = $this->custom_message('Page content updated successfully','success');
					}
		}

		$this->data['pageDetails'] = Pagemodel::where('page_slug','=',$newSlug)->first();

	    if(empty($this->data['pageDetails'])){
			 return redirect()->to(Config::get('app.admin_prefix').'/pages')->with('error','Page not found');
	    }
		
		if(!empty($request->input('redirect'))){
			return \Redirect(asset(Config::get('app.admin_prefix').'/'.$request->input('redirect')));
		}
		
		
		$pageList = Pagemodel::orderBy('page_parent_id','asc')->get();
		$allPages = $this->buildTree($pageList);
		$this->data['pageTreeAdminSelect'] = $allPages;
		return view('admin.pages.edit',$this->data);
	}

	public function changestatus($statusID,$currentStatus){
		
		 $currentStatus = ($currentStatus==0)?1:0;
		 $currentStatusdatas = array("page_status"=>$currentStatus);
		 Pagemodel::where('page_id', '=',$statusID)->update($currentStatusdatas);
		 return redirect()->to(Config::get('app.admin_prefix').'/pages');
	}

	public function delete($deleteID){
		
		 if(empty($deleteID)) { return redirect()->to(Config::get('app.admin_prefix').'/pages'); }
		$details = Pagemodel::where('page_id', '=',$deleteID)->first();
		if(empty($details)){
			 return redirect()->to(Config::get('app.admin_prefix').'/pages');
		}
		$childPages =  Pagemodel::where('page_parent_id', '=',$deleteID)->first();
		if(count($childPages)>0){
				Pagemodel::where('page_parent_id', '=',$deleteID)->update(array('page_parent_id'=>$details->page_parent_id));
		}
		Pagemodel::where('page_id', '=',$deleteID)->delete();
		$this->data['messages'] = $this->custom_message('Deleted successfully','success');
		return redirect()->to(Config::get('app.admin_prefix').'/pages')->with('flash_error','deleted');
	 }


	 public function delete_file($pageID,$type){
		$pageDetails = 	DB::table('pages')
						->where('page_id','=',$pageID)
						->first();
		$arr = array();
		$pageBannerBase = 'storage/app/uploads/pages/banners/';
		switch($type){

			case 1:
				if(\File::exists($pageBannerBase.$pageDetails->page_banner)){
					\File::delete($pageBannerBase.$pageDetails->page_banner);
					\File::delete($pageBannerBase.'small/'.$pageDetails->page_banner);
					\File::delete($pageBannerBase.'recommended/'.$pageDetails->page_banner);
				}
				$arr['page_banner'] = null;
			break;
			case 2:
				if(\File::exists($pageBannerBase.$pageDetails->page_banner_small)){
					\File::delete($pageBannerBase.$pageDetails->page_banner_small);
					\File::delete($pageBannerBase.'small/'.$pageDetails->page_banner_small);
					\File::delete($pageBannerBase.'/recommended/'.$pageDetails->page_banner_small);
				}
				$arr['page_banner_small'] = null;
			break;
			case 3:
				if(\File::exists($pageBannerBase.$pageDetails->page_banner_medium)){
					\File::delete($pageBannerBase.$pageDetails->page_banner_medium);
					\File::delete($pageBannerBase.'small/'.$pageDetails->page_banner_medium);
					\File::delete($pageBannerBase.'recommended/'.$pageDetails->page_banner_medium);
				}
				$arr['page_banner_medium'] = null;
			break;
		}
			
		DB::table('pages')->where('page_id', '=',$pageID)->update($arr);
		return redirect()->to(Config::get('app.admin_prefix').'/pages/update/'.$pageDetails->page_slug)->with('userMessage',$this->custom_message('File deleted successfully.','success'));
	 }

public function update_home_section($slug,$editID, Request $request){

  		
		if(empty($editID)) { return redirect()->to(Config::get('app.admin_prefix').'/pages');}
		
		switch($editID){
			case 1:
				$name="Ministors Quote";
				$this->data['title']=true;
				$this->data['short']=true;
				$this->data['large']=false;
				$this->data['image']=true;
				$this->data['imageWidth']=550;
				$this->data['imageHeight']=625;
			break;
			  
			case 2:
				$name="about";
				$this->data['title']=true;
				$this->data['short']=true;
				$this->data['large']=false;
				$this->data['image']=false;
				$this->data['imageWidth']=550;
				$this->data['imageHeight']=625;
			break;
			 case 3:
				$name="Mission";
				$this->data['title']=true;
				$this->data['short']=true;
				$this->data['large']=true;
				$this->data['image']=true;
				$this->data['imageWidth']=705;
				$this->data['imageHeight']=623;
			break;  
			 case 4:
				$name="Team";
				$this->data['title']=false;
				$this->data['short']=false;
				$this->data['large']=true;
				$this->data['image']=false;
				$this->data['imageWidth']='';
				$this->data['imageHeight']='';
			break; 
			 case 5:
				$name="About Logo";
				$this->data['title']=true;
				$this->data['short']=false;
				$this->data['large']=false;
				$this->data['image']=true;
				$this->data['imageWidth']='';
				$this->data['imageHeight']='';
			break; 
			case 6:
				$name="what is it";
				$this->data['title']=true;
				$this->data['short']=true;
				$this->data['large']=false;
				$this->data['image']=true;
				$svg=true;
				$this->data['imageWidth']='';
				$this->data['imageHeight']='';
			break;  
			case 7:
				$name="who can apply";
				$this->data['title']=true;
				$this->data['short']=true;
				$this->data['large']=false;
				$this->data['image']=false;
				$svg=false;
				$this->data['imageWidth']='';
				$this->data['imageHeight']='';
			break;  
			case 8:
				$name="why do u need to apply";
				$this->data['title']=true;
				$this->data['short']=true;
				$this->data['large']=false;
				$this->data['image']=false;
				$svg=false;
				$this->data['imageWidth']='';
				$this->data['imageHeight']='';
			break;  
			case 9:
				$name="benifits";
				$this->data['title']=true;
				$this->data['short']=true;
				$this->data['large']=false;
				$this->data['image']=true;
				$svg=true;
				$this->data['imageWidth']='';
				$this->data['imageHeight']='';
			break;  
			case 11:
				$name="strategic team";
				$this->data['title']=false;
				$this->data['short']=false;
				$this->data['large']=true;
				$this->data['image']=false;
				$svg=true;
				$this->data['imageWidth']=705;
				$this->data['imageHeight']=623;
			break; 
                case 12:
				$name="";
				$this->data['title']=true;
				$this->data['short']=true;
				$this->data['large']=false;
				$this->data['image']=true;
				$svg=true;
				$this->data['imageWidth']=705;
				$this->data['imageHeight']=623;
			break;  
			
		}

		$this->data['ps_slug'] =$slug;

		$this->data['pageDetails'] =DB::table('page_section')->where('ps_id','=',$editID)->first();

		if(empty($this->data['pageDetails'])){
			$this->data['messages']	='Invalid page request';
			return redirect()->to(Config::get('app.admin_prefix').'/pages');
		}
		$this->data['messages']	='';
		$this->data['validationErrors'] = false;
		if($request->input('updatebtnsubmit') || $request->input('updatebtnsubmit1')){
			
			$ps_title = str_replace("../../../","",$request->input('ps_title'));
			$ps_title_ar = str_replace("../../../","",$request->input('ps_title_ar'));
			
			$ps_short_desc = str_replace("../../../","",$request->input('ps_short_desc'));
			$ps_short_desc_ar = str_replace("../../../","",$request->input('ps_short_desc_ar'));
			
			$ps_large_desc= str_replace("../../../","",$request->input('ps_large_desc'));
			$ps_large_desc_ar = str_replace("../../../","",$request->input('ps_large_desc_ar'));

			$arr = array(
						
						  
						 
						  'ps_title' =>$ps_title,
						  'ps_title_ar' =>$ps_title_ar,
						  'ps_short_desc' =>$ps_short_desc,
						  'ps_short_desc_ar' =>$ps_short_desc_ar,
						  'ps_large_desc' =>$ps_large_desc,
						  'ps_large_desc_ar' =>$ps_large_desc_ar,
						  
						 
		          	);

				
					
					
					
					$bannerImage = $request->file('ps_image');
					if($bannerImage){
					
					
						$width = $this->data['imageWidth'];
						$height = $this->data['imageHeight'];
					
						$filePath = 'uploads/pages/section';
						list($fileName, $fileNameWithPath) = $this->store_file('ps_image', 'uploads/pages/section');
						if(empty($svg)){
							$this->resize_image($fileName,$filePath,array('recommended'=> array('height' => $height,'width'=> $width)));
						}
						$arr['ps_image']= ($fileName)?$fileName:null;
						
					
						
					}
					
					

					

					DB::table('page_section')->where('ps_id', '=',$editID)->update($arr);
				$this->data['messages'] = $this->custom_message('Page content updated successfully','success');
					
					
		}

		$this->data['pageDetails'] =DB::table('page_section')->where('ps_id','=',$editID)->first();

	    if(empty($this->data['pageDetails'])){
			 return redirect()->to(Config::get('app.admin_prefix').'/pages')->with('error','Page not found');
	    }
		
		
		return view('admin.pages.edit_home_section',$this->data);
	}
}
