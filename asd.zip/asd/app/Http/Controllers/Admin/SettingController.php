<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Admin\Base\AdminBaseController;
use Illuminate\Support\Facades\Redirect;
use App\Models\SettingModel;
use Illuminate\Http\Request;
use App\User as User;
use Auth;
use Input;
use Config;
use Session,
    DB,
    View;

class SettingController extends AdminBaseController {

	protected $roleName;
	
    public function __construct(Request $request){

		 parent::__construct($request);
		$this->roleName = 'Super Admin';
    }
	
	private function checkPermission($name){
		return ($this->userObj->can($name)) ? true : false;
	}

    public function index(Request $request) {
		

        if( !$this->userObj->hasRole($this->roleName) ){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		}

        $this->data['messages'] =
                '';
        if ($request->input('updatebtnsubmit')) {

            /* $this->validate($request, [
              'sitename' => 'required',
              'enquiry_send_email' => 'required',
              'site_meta_title' => 'required',
              ]); */

            // pre($request->all());
            $this->datasupdate =
                    $request->input('setting');
            $this->datasupdate['sitename'] =
                    $request->input('sitename');
            $this->datasupdate['enquiry_send_email'] =
                    trim($request->input('enquiry_send_email'));
            $this->datasupdate['site_meta_title'] =
                    $request->input('site_meta_title');

            $file =
                    $request->file('sitelogo_english');
            if ($file) {
                list($fileName, $fileNameWithPath) =
                        $this->store_file('sitelogo_english',
                        'public/uploads/logo');
                $this->datasupdate['sitelogo_english'] =
                        $fileName;
            }

            $file1 =
                    $request->file('sitelogo_arabic');
            if ($file1) {
                list($fileName, $fileNameWithPath) =
                        $this->store_file('sitelogo_arabic',
                        'public/uploads/logo');
                $this->datasupdate['sitelogo_arabic'] =
                        $fileName;
            }

            $file2 =
                    $request->file('sublogo_english');
            if ($file2) {
                list($fileName, $fileNameWithPath) =
                        $this->store_file('sublogo_english',
                        'public/uploads/logo');
                $this->datasupdate['sublogo_english'] =
                        $fileName;
            }

            $file3 =
                    $request->file('sublogo_arabic');
            if ($file3) {
                list($fileName, $fileNameWithPath) =
                        $this->store_file('sublogo_arabic',
                        'public/uploads/logo');
                $this->datasupdate['sublogo_arabic'] =
                        $fileName;
            }

            $file6 =
                    $request->file('location_map');
            if ($file6) {
                list($fileName, $fileNameWithPath) =
                        $this->store_file('location_map',
                        'public/uploads/location-map');
                $this->datasupdate['location_map'] =
                        $fileName;
                $this->datasupdate['location_map_file_ext'] =
                        $file6->getClientOriginalExtension();
            }

            $this->datasupdate['registeration_expiry_date'] =
                    date('Y-m-d',
                    strtotime($request->input('registeration_expiry_date')));



            SettingModel::find(1)->update($this->datasupdate);
            $this->data['messages'] =
                    $this->custom_message('Updated Successfully',
                    'success');
        }
        $this->data['rssetting'] =
                SettingModel::find(1);
        return view('admin.setting.edit',
                $this->data);
    }

    public function privacy_policy(Request $request) {

        if ($request->input('updatebtnsubmit')) {
            $data =
                    array(
                        'pp_content' => $request->input('pp_content'),
                        'pp_content_arabic' => $request->input('pp_content_arabic'),
                        'pp_status' => $request->input('pp_status'),
            );
            DB::table('privacy_policy')->where('pp_id',
                    '=',
                    1)->update($data);
        }
        $this->data['privacy'] =
                DB::table('privacy_policy')->where('pp_id',
                        '=',
                        1)->first();

        // dd($this->data);
        return view('admin.setting.privacy_policy',
                $this->data);
    }

    public function terms_and_conditions(Request $request) {
        // echo "DDdsf"; exit();
        /* if(!$this->check_user_privileges()){
          $message = $this->custom_message('Insufficient privileges. You are not authorized to access this page.','error');
          Session::flash('userMessage', $message);
          return redirect()->to(Config::get('app.admin_prefix').'/dashboard');
          } */

        if ($request->input('updatebtnsubmit')) {
            $data =
                    array(
                        'pp_content' => $request->input('pp_content'),
                        'pp_content_arabic' => $request->input('pp_content_arabic'),
                        'pp_status' => $request->input('pp_status'),
            );
            DB::table('privacy_policy')->where('pp_id',
                    '=',
                    2)->update($data);
        }
        $this->data['privacy'] =
                DB::table('privacy_policy')->where('pp_id',
                        '=',
                        2)->first();
        return view('admin.setting.terms_and_conditions',
                $this->data);
    }

    public function delete_file($type) {
        $settings =
                DB::table('setting')->where('id',
                        '=',
                        1)->first();
        $datasupdate =
                array();
        switch ($type) {
            case 1:

                if (File::exists('assets/uploads/news_page_banner/' . $settings->news_page_banner)) {
                    File::delete('assets/uploads/news_page_banner/' . $settings->news_page_banner);
                    File::delete('assets/uploads/news_page_banner/' . $settings->news_page_banner);
                    File::delete('assets/uploads/news_page_banner/' . $settings->news_page_banner);
                }
                $datasupdate['news_page_banner'] =
                        null;
                break;

            case 2:
                if (File::exists('assets/uploads/location-map/' . $settings->location_map)) {
                    File::delete('assets/uploads/location-map/' . $settings->location_map);
                }
                $datasupdate['location_map'] =
                        null;
                break;

            case 3:

                if (File::exists('assets/uploads/banner/' . $settings->banner_image)) {
                    File::delete('assets/uploads/banner/' . $settings->banner_image);
                    File::delete('assets/uploads/banner/' . $settings->banner_image);
                    File::delete('assets/uploads/banner/' . $settings->banner_image);
                }
                $datasupdate['banner_image'] =
                        null;
                break;
        }
        if (!empty($datasupdate)) {
            SettingModel::find(1)->update($datasupdate);
        }
        return redirect()->to(Config::get('app.admin_prefix') . '/setting')->with('userMessage',
                        $this->custom_message('Image deleted successfully.',
                                'success'));
    }

    public function post_category(Request $request) {
        if ($request->input('action') =="delete") {

            $delete =$request->input('id');
            $flag =DB::table('post_category')->where('category_id',$delete)->delete();
            if ($flag) {
                $message ='<div class="alert alert-success">Deleted Successfully</div>';
            } else {
                $message ='<div class="alert alert-danger">Error occured while deleting data</div>';
            }
            $request->session()->flash('messages',$message);
        }
        if ($request->input('addbtnsubmit')) {
            $data =array(
                        'category_en' => $request->input('type_en'),
                        'category_ar' => $request->input('type_ar'),
            );
            $data['category_slug'] = str_slug($data['category_en']);
            DB::table('post_category')->insert($data);
            $message ='<div class="alert alert-success">Add Successfully</div>';

            $request->session()->flash('messages',$message);
        }
        if ($request->input('updatebtnsubmit')) {
            // pre($request->all());
            $id =$request->input('category_id');
            $data =array(
                        'category_en' => $request->input('type_en'),
                        'category_ar' => $request->input('type_ar'),
            );
            $data['category_slug'] = str_slug($data['category_en']);
            
            DB::table('post_category')->where('category_id',$id)->update($data);

            $message ='<div class="alert alert-success">Update Successfully</div>';

            $request->session()->flash('messages',
                    $message);
        }

        $this->data['post_category'] =DB::table('post_category')->get();


        return view('admin.setting.post_category',$this->data);
    }

    public function post_type(Request $request) {
        if ($request->input('action') ==
                "delete") {

            $delete =
                    $request->input('id');
            $flag =
                    DB::table('post_type')->where('type_id',
                            $delete)->delete();
            if ($flag) {
                $message =
                        '<div class="alert alert-success">Deleted Successfully</div>';
            } else {
                $message =
                        '<div class="alert alert-danger">Error occured while deleting data</div>';
            }
            $request->session()->flash('messages',
                    $message);
        }
        if ($request->input('addbtnsubmit')) {
            $data =
                    array(
                        'type_en' => $request->input('type_en'),
                        'type_ar' => $request->input('type_ar'),
            );
            $data['post_slug'] = str_slug($data['type_en']);
            DB::table('post_type')->insert($data);
            $message =
                    '<div class="alert alert-success">Add Successfully</div>';

            $request->session()->flash('messages',
                    $message);
        }
        if ($request->input('updatebtnsubmit')) {
            $id =
                    $request->input('type_id');
            $data =
                    array(
                        'type_en' => $request->input('type_en'),
                        'type_ar' => $request->input('type_ar'),
            );
            $data['post_slug'] = str_slug($data['type_en']);
            DB::table('post_type')->where('type_id',
                    $id)->update($data);

            $message =
                    '<div class="alert alert-success">Update Successfully</div>';

            $request->session()->flash('messages',
                    $message);
        }

        $this->data['post_type'] =
                DB::table('post_type')->get();


        return view('admin.setting.post_type',
                $this->data);
    }

    public function watch_type(Request $request) {
        if ($request->input('action') ==
                "delete") {

            $delete =
                    $request->input('id');
            $flag =
                    DB::table('video_post_type')->where('type_id',
                            $delete)->delete();
            if ($flag) {
                $message =
                        '<div class="alert alert-success">Deleted Successfully</div>';
            } else {
                $message =
                        '<div class="alert alert-danger">Error occured while deleting data</div>';
            }
            $request->session()->flash('messages',
                    $message);
        }
        if ($request->input('addbtnsubmit')) {
            $data =
                    array(
                        'type_en' => $request->input('type_en'),
                        'type_ar' => $request->input('type_ar'),
            );
            $flag =
                    DB::table('video_post_type')->insert($data);

            $message =
                    '<div class="alert alert-success">Add Successfully</div>';

            $request->session()->flash('messages',
                    $message);
        }
        if ($request->input('updatebtnsubmit')) {
            $id =
                    $request->input('type_id');
            $data =
                    array(
                        'type_en' => $request->input('type_en'),
                        'type_ar' => $request->input('type_ar'),
            );

            $flag =
                    DB::table('post_type')->where('type_id',
                            $id)->update($data);

            $message =
                    '<div class="alert alert-success">Update Successfully</div>';

            $request->session()->flash('messages',
                    $message);
        }

        $this->data['post_type'] =
                DB::table('video_post_type')->get();


        return view('admin.setting.watch_type',
                $this->data);
    }
    public function initiatives_category(Request $request) {
        if ($request->input('action') =="delete") {

            $delete =$request->input('id');
            $flag =DB::table('initiatives_category')->where('category_id',$delete)->delete();
            if ($flag) {
                $message ='<div class="alert alert-success">Deleted Successfully</div>';
            } else {
                $message ='<div class="alert alert-danger">Error occured while deleting data</div>';
            }
            $request->session()->flash('messages',$message);
        }
        if ($request->input('addbtnsubmit')) {
            $data =array(
                        'category_en' => $request->input('type_en'),
                        'category_ar' => $request->input('type_ar'),
            );
            $data['category_slug'] = str_slug($data['category_en']);
            DB::table('initiatives_category')->insert($data);
            $message ='<div class="alert alert-success">Add Successfully</div>';

            $request->session()->flash('messages',$message);
        }
        if ($request->input('updatebtnsubmit')) {
            // pre($request->all());
            $id =$request->input('category_id');
            $data =array(
                        'category_en' => $request->input('type_en'),
                        'category_ar' => $request->input('type_ar'),
            );
            $data['category_slug'] = str_slug($data['category_en']);
            
            DB::table('initiatives_category')->where('category_id',$id)->update($data);

            $message ='<div class="alert alert-success">Update Successfully</div>';

            $request->session()->flash('messages',
                    $message);
        }

        $this->data['initiatives_category'] =DB::table('initiatives_category')->get();


        return view('admin.setting.initiatives_category',$this->data);
    }

}
