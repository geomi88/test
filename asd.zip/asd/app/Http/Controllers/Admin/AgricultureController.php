<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\Base\AdminBaseController;
use Validator, Input, Redirect,Auth,Config,DB;
use Illuminate\Support\Facades\Gate;
use App\User as User;
use Illuminate\Http\Request;
use File;
use View;
use App\Models\AgricultureModel;
use App\Models\CategoryModel;
use App\Models\AgricultureTypeModel;


class AgricultureController extends AdminBaseController {
	
	protected $roleName;
	public function __construct(Request $request){

		parent::__construct($request);
		$this->roleNames = ['Super Admin','Agriculture Manager'];
	}
	
	private function checkPermission($name){
		return ($this->userObj->can($name)) ? true : false;
	}

	
	public function index(){
		// pre($this->data);
		/* if( !$this->userObj->hasAnyRole($this->roleNames) ){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		} */
		
		$this->data['agricultureList']= AgricultureModel::orderBy('agriculture_title','asc')->paginate(20);
		
		return View::make('admin.agriculture.list',$this->data);		 
	}
	
	public function create(Request $request){	
		
		
		/*if(!$this->checkPermission('Create Country')){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		}*/
		
		$this->data['messages']='';
		// pre($request->all());
		if($request->input('savebtnsubmit')){
				

				$insertData = array();
				$insertData = array(
								'agriculture_category_id'=>$request->input('agriculture_category_id'),
								'agriculture_type_id'=>$request->input('agriculture_type_id'),
								'agriculture_title'=>$request->input('agriculture_title'),
								'agriculture_cultivate_min_duration'=>$request->input('agriculture_cultivate_min_duration'),
								'agriculture_cultivate_max_duration'=>$request->input('agriculture_cultivate_max_duration'),
								'agriculture_excerpt'=>$request->input('agriculture_excerpt'),
								'agriculture_description'=>$request->input('agriculture_description'),
								'agriculture_created_by'=> Auth::user()->id,
								'agriculture_updated_by'=> Auth::user()->id,
								'agriculture_status'=>$request->input('agriculture_status')		
								);
								
				$imageFile = $request->file('agriculture_image');

				if($imageFile){
					$filePath = 'public/uploads/agriculture/image/';
					list($fileName, $fileNameWithPath) = $this->store_file('agriculture_image', 'public/uploads/agriculture/image/');
					$insertData['agriculture_image'] = $fileName;
				}

				$iconFile = $request->file('agriculture_icon');

				if($iconFile){
					$filePath = 'public/uploads/agriculture/icon/';
					list($fileName, $fileNameWithPath) = $this->store_file('agriculture_icon', 'public/uploads/agriculture/icon/');
					$insertData['agriculture_icon'] = $fileName;
				}

				// $insertData['agriculture_uuid'] = 

				$newAgriculture = AgricultureModel::create($insertData);
				
				if(empty($newAgriculture)){
					return redirect()->to(apa('agriculture_manager'))->with('errorMessage','Cannot save to database');
				}

				$this->data['userMessage'] =$this->custom_message('Agriculture Added Successfully','success');		
		}
		
		$this->data['categoryList'] = CategoryModel::active()->get();
        $this->data['agricultureTypeList'] = AgricultureTypeModel::active()->get();
		 return View::make('admin.agriculture.create',$this->data);			 
	}

	public function update($id, Request $request){	 
	
		/*
		if(!$this->checkPermission('Edit Country')){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		}*/
		
		
		if(empty($id)) { return redirect()->to(Config::get('app.admin_prefix').'/agriculture_manager');}		
		$this->data['messages']	='';
		if($request->input('updatebtnsubmit')){		
				$updateData = array();
				$updateData = array(
								'agriculture_category_id'=>$request->input('agriculture_category_id'),
								'agriculture_type_id'=>$request->input('agriculture_type_id'),
								'agriculture_title'=>$request->input('agriculture_title'),
								'agriculture_cultivate_min_duration'=>$request->input('agriculture_cultivate_min_duration'),
								'agriculture_cultivate_max_duration'=>$request->input('agriculture_cultivate_max_duration'),
								'agriculture_excerpt'=>$request->input('agriculture_excerpt'),
								'agriculture_description'=>$request->input('agriculture_description'),
								'agriculture_created_by'=> Auth::user()->id,
								'agriculture_updated_by'=> Auth::user()->id,
								'agriculture_status'=>$request->input('agriculture_status')		
								);
								
				$imageFile = $request->file('agriculture_image');
				
				if($imageFile){
					$filePath = 'public/uploads/agriculture/image/';
					list($fileName, $fileNameWithPath) = $this->store_file('agriculture_image', 'public/uploads/agriculture/image/');
					$updateData['agriculture_image'] = $fileName;
				}
				
				$iconFile = $request->file('agriculture_icon');
				
				if($iconFile){
					$filePath = 'public/uploads/agriculture/icon/';
					list($fileName, $fileNameWithPath) = $this->store_file('agriculture_icon', 'public/uploads/agriculture/icon/');
					$updateData['agriculture_icon'] = $fileName;
				}
				// pre($updateData);

				$newAgriculture = AgricultureModel::where('agriculture_id','=',$id)->update($updateData);
				$this->data['userMessage'] = $this->custom_message('Agriculture updated successfully','success');		
			}
		
	 $this->data['agricultureDetails'] = AgricultureModel::findorfail($id);
	 $this->data['categoryList'] = CategoryModel::active()->get();
     $this->data['agricultureTypeList'] = AgricultureTypeModel::active()->get();
	 return View::make('admin.agriculture.edit',$this->data);			 
  }

	public function changestatus($id,Request $request){
		
		/* if(!$this->checkPermission('Edit Country')){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		} */
		
		$agriculture = AgricultureModel::where('agriculture_id', '=',$id)->first();
		if(empty($agriculture)){
			return redirect()->to(apa('agriculture_manager'))->with('userMessage','Invalid request');
		}
		$currentStatus = ($agriculture->agriculture_status==1)?2:1;
		$newStatusData = array("agriculture_status"=>$currentStatus);
		AgricultureModel::where('agriculture_id', '=',$id)->update($newStatusData);	
		return redirect()->to(apa('agriculture_manager'))->with('userMessage','Status changed');
	}
	
	public function delete($id){	 
	
		/* if( !$this->userObj->hasRole($this->roleName) ){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		} */

		$agriculture = AgricultureModel::where('agriculture_id', '=',$id)->first();
		if(empty($agriculture)){
			return redirect()->to(apa('agriculture_manager'))->with('userMessage','Invalid request');
		}

		$newStatusData = array("agriculture_status"=>3);
		AgricultureModel::where('agriculture_id', '=',$id)->update($newStatusData);	
		return redirect()->to(apa('agriculture_manager'))->with('userMessage','Agriculture deleted');
	 }	 
	
	


}