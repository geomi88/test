<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\Base\AdminBaseController;
use Validator, Input, Redirect,Auth,Config,DB;
use Illuminate\Support\Facades\Gate;
use App\User as User;
use Illuminate\Http\Request;
use File;
use View;
use App\Models\FarmModel;
use App\Models\CategoryModel;
use App\Models\CountryModel;
use App\Models\AgricultureModel;
use App\Models\FacilityModel;
use App\Models\SoilModel;
use App\Models\IrrigationModel;
use App\Models\AgricultureTypeModel;

class FarmController extends AdminBaseController {
	
	protected $roleName;
	public function __construct(Request $request){

		parent::__construct($request);
		$this->roleNames = ['Super Admin','Farm Manager'];
	}
	
	private function checkPermission($name){
		return ($this->userObj->can($name)) ? true : false;
	}

	private function _set_post_validations($request){
		
		$this->rules =  [
			'fm_title'=>'required',
			'farm_categories'=>'required',
			'fm_status'=>'required',
		];
		
		$this->messages = [
			'fm_title.required'=>'Title is required',
            'farm_categories.required'=>'Select atleast one category',
            'fm_status.required'=>'Status is required',
		];
		
		$slugRules = [];
		$slugMessages = [];
		
		
		$this->rules = array_merge($this->rules, $slugRules);
		$this->messages = array_merge($this->rules, $slugMessages);
		
		return (!empty($this->messages)) ? $this->validate($request,$this->rules,$this->messages) : $this->validate($request,$this->rules);
	}
	public function index(){
		// pre($this->data);
		/* if( !$this->userObj->hasAnyRole($this->roleNames) ){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		} */
		$query = FarmModel::orderBy('fm_created_at','desc');
		$name = Input::get('name');
		$query->when($name, function ($q) use ($name) {
			return $q->where('fm_title','LIKE', "%$name%");
		});
		
		$status = Input::get('status');
		$query->when($status, function ($q) use ($status) {
			return $q->where('fm_status', $status);
		});

		//$this->data['farmList']= FarmModel::orderBy('fm_created_at','desc')->paginate(20);
		$this->data['farmList'] = $query->paginate(20)->appends(Input::except('page'));

		return View::make('admin.farm.list',$this->data);		 
	}
	
	public function create(Request $request){	
		
		
		/*if(!$this->checkPermission('Create Country')){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		}*/
		
		$this->data['messages']='';
		// pre($request->all());
		if($request->input('savebtnsubmit')){
				
                $this->_set_post_validations($request);
				$uuid = (string) \Uuid::generate(5,microtime(), \Uuid::NS_DNS);
				$request->request->add(['uuid' => $uuid]);


				/*if((!empty($request->input('fm_country_id')) || !empty($request->input('fm_state_name')) || !empty($request->input('fm_city')) || !empty($request->input('fm_zipcode'))))
                {
                    $country_details = CountryModel::find($request->input('fm_country_id'));

                    $address = $request->input('fm_city').','.$request->input('fm_state_name').','.$country_details->country_name.','.$request->input('fm_zipcode');
                    $curl = curl_init();

                    curl_setopt($curl, CURLOPT_URL, 'https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyD7dxAhKeEHs4QpOPhGqOSwl2NFfW9rqtk&address=' . rawurlencode($address));

                    curl_setopt ($curl, CURLOPT_RETURNTRANSFER, 1);

                    $json = curl_exec($curl);
                    
                    $co_ordinates = json_decode($json);
                    
                    $fm_latitude = $co_ordinates->results[0]->geometry->location->lat;
					$fm_longitude = $co_ordinates->results[0]->geometry->location->lng;
					$request->request->add(['fm_latitude' => $fm_latitude]);
					$request->request->add(['fm_longitude' => $fm_longitude]);
                }*/
				$fm_latitude = $request->input('fm_latitude');
				$fm_longitude = $request->input('fm_longitude');
				$request->request->add(['farm_status' => $request->input('fm_status')]);
				$insertData = array();
				$insertData = array(	
								'fm_uuid' => $uuid,
								'fm_code' => FarmModel::max('fm_code')+1,							
								'fm_title'=>$request->input('fm_title'),
                                'fm_country_id'=>$request->input('fm_country_id'),
                                'fm_state_name'=>$request->input('fm_state_name'),
                                'fm_city'=>$request->input('fm_city'),
                                'fm_zipcode'=>$request->input('fm_zipcode'),
                                'fm_area'=>$request->input('fm_area'),
                                'fm_area_unit'=>$request->input('fm_area_unit'),
                                'fm_plots_no'=>$request->input('fm_plots_no'),
								'fm_area_unit'=>$request->input('fm_area_unit'),
								'fm_latitude'=>$fm_latitude,
								'fm_longitude'=>$fm_longitude,
								/*'farm_cultivate_min_duration'=>$request->input('farm_cultivate_min_duration'),
								'farm_cultivate_max_duration'=>$request->input('farm_cultivate_max_duration'),*/
                                'fm_soil_id'=>$request->input('fm_soil_id'),
                                'fm_irrigation_id'=>$request->input('fm_irrigation_id'),
                                'fm_agriculture_type_id'=>$request->input('fm_agriculture_type_id'),
								'fm_farm_highlights'=>$request->input('fm_farm_highlights'),
								'fm_about_farm'=>$request->input('fm_about_farm'),
								'fm_start_date'=>$request->input('available_start_date'),
								'fm_end_date'=>$request->input('available_end_date'),
								'fm_price'=>$request->input('fm_price'),
								'fm_policies'=>$request->input('fm_policies'),
								'fm_created_by'=> Auth::user()->id,
								'fm_updated_by'=> Auth::user()->id,
								'fm_owner_id'=> Auth::user()->id,
								'fm_status'=>$request->input('fm_status')		
								);
								
				$imageFile = $request->file('fm_main_image');

				if($imageFile){
					$filePath = 'public/uploads/farm/image/';
					list($fileName, $fileNameWithPath) = $this->store_file('fm_main_image', 'public/uploads/farm/image/');
					$insertData['fm_main_image'] = $fileName;

					$largeWidth='1200';
                    $largeHeight= '900';
                    $smallWidth= '600';
                    $smallHeight= '450';
                    $this->resize_image($fileName,$filePath,array('large'=> array('height' =>$largeHeight,'width'=> $largeWidth), 'small'=>array('height' => $smallHeight,'width'=> $smallWidth)),true);
				}

				$iconFile = $request->file('fm_main_icon');

				if($iconFile){
					$filePath = 'public/uploads/farm/icon/';
					list($fileName, $fileNameWithPath) = $this->store_file('fm_main_icon', 'public/uploads/farm/icon/');
					$insertData['fm_main_icon'] = $fileName;
				}
                
                $plotFile = $request->file('fm_plot_map');

				if($plotFile){
					$filePath = 'public/uploads/farm/plot/';
					list($fileName, $fileNameWithPath) = $this->store_file('fm_plot_map', 'public/uploads/farm/plot/');
					$insertData['fm_plot_map'] = $fileName;
				}
                
                $weatherFile = $request->file('fm_weather_report');

				if($weatherFile){
					$filePath = 'public/uploads/farm/weather_report/';
					list($fileName, $fileNameWithPath) = $this->store_file('fm_weather_report', 'public/uploads/farm/weather_report/');
					$insertData['fm_weather_report'] = $fileName;
				}
                
                $soilFile = $request->file('fm_soil_report');

				if($soilFile){
					$filePath = 'public/uploads/farm/soil_report/';
					list($fileName, $fileNameWithPath) = $this->store_file('fm_soil_report', 'public/uploads/farm/soil_report/');
					$insertData['fm_soil_report'] = $fileName;
				}
                
                $annualFile = $request->file('fm_annual_report');

				if($plotFile){
					$filePath = 'public/uploads/farm/annual_report/';
					list($fileName, $fileNameWithPath) = $this->store_file('fm_annual_report', 'public/uploads/farm/annual_report/');
					$insertData['fm_annual_report'] = $fileName;
				}

				$newFarm = FarmModel::create($insertData);
                
                if(!empty($request->input('farm_categories')))
                {
                       $newFarm->categories()->sync($request->input('farm_categories'));
                }
                
                if(!empty($request->input('farm_agricultures')))
                {
                       $newFarm->crops()->sync($request->input('farm_agricultures'));
                }
                
                if(!empty($request->input('farm_facilities')))
                {
                       $newFarm->facilities()->sync($request->input('farm_facilities'));
                }
				
                $galleryImages = Input::get('gallaryImages');
				$updateGalleryImages = array('gallery_farm_id'=>$newFarm->fm_id);
				
				if(!empty($galleryImages)){
					DB::table('gallery_images')->whereIn('gallery_id',$galleryImages)->update($updateGalleryImages);
				}
                
				if(empty($newFarm)){
					return redirect()->to(apa('farm_manager'))->with('errorMessage','Cannot save to database');
				}
				app('App\Http\Controllers\API\ElasticSearchController')->add_farm_admin($request); 
				$this->data['userMessage'] =$this->custom_message('Farm Added Successfully','success');		
		}
		
		$this->data['categoryList'] = CategoryModel::active()->get();
        $this->data['countryList'] = CountryModel::active()->get();
        $this->data['agricultureList'] = AgricultureModel::active()->get();
        $this->data['facilityList'] = FacilityModel::active()->get();
        $this->data['soilList'] = SoilModel::active()->get();
        $this->data['irrigationList'] = IrrigationModel::active()->get();
        $this->data['agricultureTypeList'] = AgricultureTypeModel::active()->get();
        $this->data['farm_id'] = '';
        
		return View::make('admin.farm.create',$this->data);			 
	}

	public function update($id, Request $request){	 
	
		/*
		if(!$this->checkPermission('Edit Country')){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		}*/
		
		
		if(empty($id)) { return redirect()->to(Config::get('app.admin_prefix').'/farm_manager');}		
		$this->data['messages']	='';
		if($request->input('updatebtnsubmit')){		
				$this->_set_post_validations($request);
				
				/*if((!empty($request->input('fm_country_id')) || !empty($request->input('fm_state_name')) || !empty($request->input('fm_city')) || !empty($request->input('fm_zipcode'))))
                {
                    $country_details = CountryModel::find($request->input('fm_country_id'));

                    $address = $request->input('fm_city').','.$request->input('fm_state_name').','.$country_details->country_name.','.$request->input('fm_zipcode');
                    $curl = curl_init();

                    curl_setopt($curl, CURLOPT_URL, 'https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyD7dxAhKeEHs4QpOPhGqOSwl2NFfW9rqtk&address=' . rawurlencode($address));

                    curl_setopt ($curl, CURLOPT_RETURNTRANSFER, 1);

                    $json = curl_exec($curl);
                    
                    $co_ordinates = json_decode($json);
                    
                    $fm_latitude = $co_ordinates->results[0]->geometry->location->lat;
					$fm_longitude = $co_ordinates->results[0]->geometry->location->lng;
					$request->request->add(['fm_latitude' => $fm_latitude]);
					$request->request->add(['fm_longitude' => $fm_longitude]);
                }*/
				$fm_latitude = $request->input('fm_latitude');
				$fm_longitude = $request->input('fm_longitude');
				$request->request->add(['farm_status' => $request->input('fm_status')]);
				$updateData = array();
				$updateData = array(
								'fm_title'=>$request->input('fm_title'),
                                'fm_country_id'=>$request->input('fm_country_id'),
                                'fm_state_name'=>$request->input('fm_state_name'),
                                'fm_city'=>$request->input('fm_city'),
                                'fm_zipcode'=>$request->input('fm_zipcode'),
                                'fm_area'=>$request->input('fm_area'),
                                'fm_area_unit'=>$request->input('fm_area_unit'),
								'fm_plots_no'=>$request->input('fm_plots_no'),
								'fm_latitude'=>$fm_latitude,
								'fm_longitude'=>$fm_longitude,
								/*'farm_cultivate_min_duration'=>$request->input('farm_cultivate_min_duration'),
								'farm_cultivate_max_duration'=>$request->input('farm_cultivate_max_duration'),*/
                                'fm_soil_id'=>$request->input('fm_soil_id'),
                                'fm_irrigation_id'=>$request->input('fm_irrigation_id'),
                                'fm_agriculture_type_id'=>$request->input('fm_agriculture_type_id'),
								'fm_farm_highlights'=>$request->input('fm_farm_highlights'),
								'fm_about_farm'=>$request->input('fm_about_farm'),
								'fm_start_date'=>$request->input('available_start_date'),
								'fm_end_date'=>$request->input('available_end_date'),
								'fm_price'=>$request->input('fm_price'),
								'fm_policies'=>$request->input('fm_policies'),
								//'fm_updated_by'=> Auth::user()->id,
								'fm_updated_by'=> Auth::user()->id,
								//'fm_owner_id'=> Auth::user()->id,
								'fm_status'=>$request->input('fm_status')		
								);
								
				$imageFile = $request->file('fm_main_image');

				if($imageFile){
					$filePath = 'public/uploads/farm/image/';
					list($fileName, $fileNameWithPath) = $this->store_file('fm_main_image', 'public/uploads/farm/image/');
					$updateData['fm_main_image'] = $fileName;


					$largeWidth='1200';
                    $largeHeight= '900';
                    $smallWidth= '600';
                    $smallHeight= '450';
                    $this->resize_image($fileName,$filePath,array('large'=> array('height' =>$largeHeight,'width'=> $largeWidth), 'small'=>array('height' => $smallHeight,'width'=> $smallWidth)),true);

				}

				$iconFile = $request->file('fm_main_icon');

				if($iconFile){
					$filePath = 'public/uploads/farm/icon/';
					list($fileName, $fileNameWithPath) = $this->store_file('fm_main_icon', 'public/uploads/farm/icon/');
					$updateData['fm_main_icon'] = $fileName;
				}
                
                $plotFile = $request->file('fm_plot_map');

				if($plotFile){
					$filePath = 'public/uploads/farm/plot/';
					list($fileName, $fileNameWithPath) = $this->store_file('fm_plot_map', 'public/uploads/farm/plot/');
					$updateData['fm_plot_map'] = $fileName;
				}
                
                $weatherFile = $request->file('fm_weather_report');

				if($weatherFile){
					$filePath = 'public/uploads/farm/weather_report/';
					list($fileName, $fileNameWithPath) = $this->store_file('fm_weather_report', 'public/uploads/farm/weather_report/');
					$updateData['fm_weather_report'] = $fileName;
				}
                
                $soilFile = $request->file('fm_soil_report');

				if($soilFile){
					$filePath = 'public/uploads/farm/soil_report/';
					list($fileName, $fileNameWithPath) = $this->store_file('fm_soil_report', 'public/uploads/farm/soil_report/');
					$updateData['fm_soil_report'] = $fileName;
				}
                
                $annualFile = $request->file('fm_annual_report');

				if($plotFile){
					$filePath = 'public/uploads/farm/annual_report/';
					list($fileName, $fileNameWithPath) = $this->store_file('fm_annual_report', 'public/uploads/farm/annual_report/');
					$updateData['fm_annual_report'] = $fileName;
				}
                $farmObj = FarmModel::where('fm_id','=',$id)->first();
				$newFarm = FarmModel::where('fm_id','=',$id)->update($updateData);
                $request->request->add(['uuid' => $farmObj->fm_uuid]);
                if(!empty($request->input('farm_categories')))
                {
                       $farmObj->categories()->sync($request->input('farm_categories'));
                }
                
                if(!empty($request->input('farm_agricultures')))
                {
                       $farmObj->crops()->sync($request->input('farm_agricultures'));
                }
                
                if(!empty($request->input('farm_facilities')))
                {
                       $farmObj->facilities()->sync($request->input('farm_facilities'));
                }
				
                $galleryImages = Input::get('gallaryImages');
				$updateGalleryImages = array('gallery_farm_id'=>$farmObj->fm_id);
				if(!empty($galleryImages)){
					DB::table('gallery_images')->whereIn('gallery_id',$galleryImages)->update($updateGalleryImages);
				}
                
                app('App\Http\Controllers\API\ElasticSearchController')->edit_farm_admin($request);
				$this->data['userMessage'] = $this->custom_message('Farm updated successfully','success');		
			}
		
	 $this->data['farmDetails'] = FarmModel::findorfail($id);
	 $this->data['categoryList'] = CategoryModel::active()->get();
     $this->data['countryList'] = CountryModel::active()->get();
     $this->data['agricultureList'] = AgricultureModel::active()->get();
     $this->data['facilityList'] = FacilityModel::active()->get();
     $this->data['soilList'] = SoilModel::active()->get();
     $this->data['irrigationList'] = IrrigationModel::active()->get();
     $this->data['agricultureTypeList'] = AgricultureTypeModel::active()->get();
     $this->data['farm_id'] = $id;
	 return View::make('admin.farm.edit',$this->data);			 
  }

	public function changestatus($statusID,$currentStatus){
		
		/* if(!$this->checkPermission('Edit Farm')){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		} */
		
		
		$currentStatus = ($currentStatus==1)?2:1;
		$currentStatusdatas = array("fm_status"=>$currentStatus);
		DB::table('farm_master')->where('fm_id', '=',$statusID)->update($currentStatusdatas);	

		$farm_details = FarmModel::find($statusID);

		app('App\Http\Controllers\API\ElasticSearchController')->change_farm_status($farm_details->fm_uuid,$currentStatus);
		$this->data['userMessage'] = $this->custom_message('Status changed','success');
		return redirect()->to(Config::get('app.admin_prefix').'/farm_manager')->with('userMessage',$this->data['userMessage']);
	}
	
	public function delete($deleteID){	 
		
		// if(!$this->checkPermission('Delete Farm')){
		// 	return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		// }
		
		
		// if( !$this->userObj->hasRole($this->roleName) ){
		// 	return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		// }
		
		if(empty($deleteID)) { return redirect()->to(Config::get('app.admin_prefix').'/farm_manager');}
		 DB::table('farm_master')->where('fm_id', '=',$deleteID)->delete();	
		 $this->data['messages'] = $this->custom_message('Deleted Successfully','success');
		 return redirect()->to(Config::get('app.admin_prefix').'/farm_manager')->with('flash_error','deleted');
	 }	 
	
	


}