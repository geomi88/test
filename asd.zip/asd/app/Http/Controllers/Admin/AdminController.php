<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\Base\AdminBaseController;
use Validator, Input, Redirect, Auth, Config, DB;
use Illuminate\Support\Facades\Gate;
use App\User as User;
use Illuminate\Http\Request;
use File;
use View;
use App\Models\FarmModel;
use App\Models\FarmSubscriptionModel;
use Hash;


class AdminController extends AdminBaseController
{

    protected $roleName;
    public function __construct(Request $request)
    {

        parent::__construct($request);
        $this->roleNames = ['Super Admin', 'Change Password Manager'];
    }

    private function checkPermission($name)
    {
        return ($this->userObj->can($name)) ? true : false;
    }


    public function change_password(Request $request)
    {
        if ($request->input('_token')) {

            $userDetails = Auth::user();
            $inputs = $request->all();
            $rules = [
                'new_password' => 'required',
                'confirm_password' =>  'required',
                'current_password' => ['required', function ($attribute, $value, $fail) use ($userDetails) {
                    if (!\Hash::check($value, $userDetails->password)) {
                        return $fail(__('The current password is incorrect.'));
                    }
                }],
            ];

            $messages = [
                'current_password.required' => 'Current Password is required',
                'new_password.required' => 'Password is required',
                'confirm_password.required' => 'Confirm Password is required',

            ];
            $validator = \Validator::make($inputs, $rules, $messages);
            $userMessage = false;

            if ($validator->fails()) {
                $request->flash();
                $userMessage = '<ul style="list-style:none" class="alert alert-danger">';
                $messages = $validator->messages();
                foreach ($messages->all() as $message) {
                    $userMessage .= '<li>' . $message . '</li>';
                }
                $userMessage .= '</ul>';
                $this->data['userMessage'] = $userMessage;
                $this->data['status'] = false;
            } else {
                $userDetails->password = Hash::make($request->input('new_password'));

                $userDetails->save();

                $this->data['userMessage'] = $this->custom_message('Password changed Successfully', 'success');

            }
        }
        return View::make('admin.admin.change_password', $this->data);
    }

    
}
