<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\Base\AdminBaseController;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use App\Models\Admodels\CmsModel;
use App\Models\Admodels\PageModel;
use App\Models\Admodels\PostModel;
use App\Models\Admodels\NewsFeedTmp;


use Input;
use Config;
use DB;
use Validator;
use Session;
use Carbon\Carbon;
use File;
use App\Models\Admodels\PostMetaModel;

class PostCollectionController extends AdminBaseController {
	
	protected $postType;
	//protected $postDateFormat = 'd/m/Y';
	protected $postDateFormat = 'm/d/Y';
	
	private $inputs = [];
	private $rules = [];
	private $messages = [];
	private $myValidator = [];
	private $validatorErrorMsgs;
	private $slugText = 'Post';
	
	protected $roleName;
	protected $module;
	public function __construct(Request $request){
		
		parent::__construct($request);
		
		if($this->requestSlug){  
			
			$this->_set_post_basic_settings($this->requestSlug, $request);           
		}
		$slug = ucwords(str_replace(['_','-'],' ',$this->requestSlug)).' Manager';
		
		$this->module = ucwords(str_replace(['_','-'],' ',$this->requestSlug));
		$this->roleNames = ['Super Admin',$slug];
		
	}
	
	private function checkPermission($name){
		return (\Auth::user()->can($name)) ? true : false;
	}
	
	private function _set_post_validations($slug, $request){
		
		$this->rules =  [
			'post.title'=>'required',
			'post.title_arabic'=>'required',
			'post.status'=>'required',
		];
		
		$this->messages = [
			'post.title.required'=>'Title is required',
			'post.title_arabic.required'=>'Arabic Title is required',
			'post.status.required'=>'Status is required'
		];
		
		$slugRules = [];
		$slugMessages = [];
		
		switch($slug){
			
			case 'events':               
			$this->postDateFormat = 'm/d/Y H:i';
			break;
			
		}
		
		$this->rules = array_merge($this->rules, $slugRules);
		$this->messages = array_merge($this->rules, $slugMessages);
		
		return (!empty($this->messages)) ? $this->validate($request,$this->rules,$this->messages) : $this->validate($request,$this->rules);
	}
	
	
	private function _set_post_basic_settings($slug, $request){
		
		if(empty($slug)) return false;
		
		$this->data['postType'] = $slug;
		$this->data['hasGallery'] = false;
		
		
		switch($slug){
			case 'banner':
				$this->buttons = ['add'=>false,'edit'=>true,'delete'=>false,'status'=>true];
				$this->hasTextEditor = true;
			break;
			case 'book_a_tour':
			case 'the_invite':
				$this->buttons = ['add'=>false,'edit'=>true,'delete'=>false,'status'=>true];
				$this->hasTextEditor = true;
			break;
			case 'start_timeline':
				$this->buttons = ['add'=>true,'edit'=>true,'delete'=>true,'status'=>true];
				$this->hasTextEditor = true;
			break;
			case 'the_hub':
			case 'the_start':
			case 'the_x':
				$this->buttons = ['add'=>false,'edit'=>true,'delete'=>false,'status'=>true];
				$this->hasTextEditor = true;
				$this->hasPluploader = true;
			break;
			case 'the_youth':
				$this->buttons = ['add'=>false,'edit'=>true,'delete'=>false,'status'=>true];
				$this->hasTextEditor = true;
				$this->hasPluploader = true;
			break;
			case 'about':
				$this->buttons = ['add'=>true,'edit'=>true,'delete'=>false,'status'=>true];
			break;
			// case 
			
			
		}
	
		$this->data['buttons'] = $this->buttons;
		$this->data['hasPluploader'] = $this->hasPluploader;
		$this->data['hasTextEditor'] = $this->hasTextEditor;
		
	}
	
	private function _set_file_upload_settings($slug, $request){
		if(empty($slug)) return false;
		switch($slug){
			case 'the_hub':
				$this->imageDimensions[$slug] =    [
					['width'=>650,'height'=>646,'folder'=>'large'],
					['width'=>200,'height'=>199,'folder'=>'small']
				];
			break;
			
			case 'the_x':
				$this->imageDimensions[$slug] =    [
					['width'=>815,'height'=>710,'folder'=>'large'],
					['width'=>200,'height'=>199,'folder'=>'small']
				];
			break;
			
			case 'the_youth': 
				$this->imageDimensions[$slug] =    [
					['width'=>900,'height'=>614,'folder'=>'large'],
					['width'=>400,'height'=>125,'folder'=>'small']
				];
			break;
			
			case 'the_partner':
				$this->imageDimensions[$slug] =    [
					['width'=>200,'height'=>120,'folder'=>'large'],
					['width'=>100,'height'=>60,'folder'=>'small']
				];
			break;
		}
	}
	
	
	
	
	
	
	public function index($slug, Request $request){
		
		$orderBy = [];
		$orderByMeta = [];
		$searchReq = ['post'=>$request->post,'meta'=>$request->meta];
		
		switch($slug){
			case 'news':
			$orderByMeta = ['publish_date'=>'DESC', 'post_priority'=>'ASC'];
			break;
			case 'events':
			$orderByMeta = ['event_from_date'=>'DESC'];
			break;
			default:
			$orderBy = ['post_priority'=>'ASC'];
			break;
		}
		
		$postItems = PostModel::where('post_type','=',$slug);
		
		if(!empty($orderBy)){
			foreach($orderBy as $field=>$sort){
				$postItems = $postItems->orderBy($field,$sort);
			}
		}
		
		if(!empty($orderByMeta)){
			foreach($orderByMeta as $field=>$sort){
				$postItems = $postItems->OrderByMeta($field,$sort);
			}
		}
		
		$postItems = $postItems->paginate(10);
		$this->data['post_items'] = $postItems;
		
		
		if(!view()->exists('admin.'.$slug.'.list')){
			return View('admin.error.errorpage',$this->data);
		}
		
		
		
		return View('admin.'.$slug.'.list',$this->data);
		
	}
	
	public function create($slug, Request $request){
		
		
		/* if(!$this->checkPermission('Create '.$this->module)){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		} */
		$this->data['hasPluploader'] = $this->hasPluploader;
		$this->data['hasTextEditor'] = $this->hasTextEditor;
		$this->data['hasPluploader'] = true;
		$this->data['feedDetails']='';
		if($request->input('btnsubmit')){
			
			$userInputs = $request->all();
			$this->_set_post_validations($this->requestSlug, $request);
			$this->_set_file_upload_settings($this->requestSlug, $request);
			
			try{
				
				$postData = $this->_get_post_data($request);
				$postMetaData = $this->_get_post_meta_data($request);
				
				DB::beginTransaction();
				$postData = $this->_get_post_data($request);
				$newPost = PostModel::create($postData);
				if(!empty($postMetaData)){
					$newPost->syncMeta($postMetaData);
				}
				$galleryImages = Input::get('gallaryImages');
				$galleryVideolink = Input::get('shows_link');
				$updateGalleryImages = array('gallery_post_id'=>$newPost->post_id);
				
				if(!empty($galleryImages)){
					DB::table('gallery_images')->whereIn('gallery_id',$galleryImages)->update($updateGalleryImages);
				}
				if(!empty($galleryVideolink)){
					foreach($galleryVideolink as $url){
						$videoID=$this->get_youtube_id($url);							
						if(!empty($videoID)){
							$insertVideos[] = array(					
							'gallery_post_id'=>$newPost->post_id,
							'gallery_image_name'=>$videoID,
							'gallery_image_title'=>$url,
							'gallery_image_type'=>2,
							'gallery_image_date'=>date('Y-m-d H:i:s'),
							);
						}
						
					}
					
					if(!empty($insertVideos)){
						DB::table('gallery_images')->insert($insertVideos);
					} 
				}
				
				$tags = $request->input('post_tags');                    
				$finalTags = [];
				if(!empty($tags)){
					$tags = array_map('trim', explode(',', $tags));
					foreach($tags as $tag){
						if(!empty($tag)){
							$finalTags[] = $tag;
						}
					}
					$newPost->tag($finalTags);
				}
				DB::commit();
				
				$this->data['userMessage'] = $this->custom_message($this->slugText.' saved successfully.','success');
				}catch(\Exception $e){
				
				$request->flash();
				DB::rollback();
				$message =  '<div class="alert alert-danger">Error occured while saving data.Error : '.$e->getMessage().'</div>';
				if($e->getCode() == 23000){
					$message =  '<div class="alert alert-danger">Title already exist, Please enter a different title</div>';
				}
				$this->data['userMessage'] = $message;
			}
		}
		
		
		if(!view()->exists('admin.'.$slug.'.add')){
			return View('admin.error.errorpage',$this->data);
		}
		
		switch($slug){
			case 'partner':
			$this->data['partnerCategory'] = PostModel::where('post_type','=','partner_category')->get();
			break;
		}
		
		if($slug=='gallery'){
			$this->data['hasGallery'] = true;
		}
		
		return View('admin.'.$slug.'.add',$this->data);
		
	}
	
	private function _getCarbonObject($dateStr,$sourceFormat){
		
		
		$dateObj = Carbon::createFromFormat($sourceFormat, $dateStr);
		
		if(!$dateObj) return false;
		return $dateObj;
	}
	
	public function is_rtl( $string ) {
		$rtl_chars_pattern = '/[\x{0590}-\x{05ff}\x{0600}-\x{06ff}]/u';
		return preg_match($rtl_chars_pattern, $string);
	}
	
	public function edit($slug, $editId, Request $request){
		
		/* if(!$this->checkPermission('Edit '.$this->module)){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		} */
		$this->data['hasPluploader'] = $this->hasPluploader;
		$this->data['hasTextEditor'] = $this->hasTextEditor;
		
		if($request->input('updatebtnsubmit')){
			$userInputs = $request->all();
			$this->_set_post_validations($this->requestSlug, $request);
			$this->_set_file_upload_settings($this->requestSlug, $request);
			
			try{
				
				$postData = $this->_get_post_data($request);
				
				$postMetaData = $this->_get_post_meta_data($request);

				DB::beginTransaction();
				$postData = $this->_get_post_data($request);
				$postDetails = PostModel::findorfail($editId);
				
				
				$galleryImages = Input::get('gallaryImages');
				$galleryVideolink = Input::get('shows_link');
				$updateGalleryImages = array('gallery_post_id'=>$postDetails->post_id);
				if(!empty($galleryImages)){
					DB::table('gallery_images')->whereIn('gallery_id',$galleryImages)->update($updateGalleryImages);
				}
				if(!empty($galleryVideolink)){
					foreach($galleryVideolink as $url){
						
						$videoID=$this->get_youtube_id($url);
						
						if(!empty($videoID)){
							$insertVideos[] = array(					
							'gallery_post_id'=>$postDetails->post_id,
							'gallery_image_name'=>$videoID,
							'gallery_image_title'=>$url,
							'gallery_image_type'=>2,
							'gallery_image_date'=>date('Y-m-d H:i:s'),
							);
						}
						
					}
					
					if(!empty($insertVideos)){
						DB::table('gallery_images')->insert($insertVideos);
					} 
				}
				
				foreach($postData as $key=>$val){
					$postDetails->{$key} = $val;
				}
				
				$postDetails->save();
				
				if(!empty($postMetaData)){
					$postDetails->syncMeta($postMetaData);
				}
				
				$tags = $request->input('post_tags');                    
				$finalTags = [];
				if(!empty($tags)){
					$tags = array_map('trim', explode(',', $tags));
					foreach($tags as $tag){
						if(!empty($tag)){
							$finalTags[] = $tag;
						}
					}
					$postDetails->tag($finalTags);
				}
				
				DB::commit();
				
				$this->data['userMessage'] = $this->custom_message($this->slugText.' saved successfully.','success');
				}catch(\Exception $e){
				$request->flash();
				DB::rollback();
				$message =  '<div class="alert alert-danger">Error occured while saving data.</div>';
				if($e->getCode() == 23000){
					$message =  '<div class="alert alert-danger">Title already exist, Please enter a different title</div>';
				}
				$this->data['userMessage'] = $message;
			}
		}
		
		
		if(!view()->exists('admin.'.$slug.'.edit')){
			return View('admin.error.errorpage',$this->data);
		}
		switch($slug){
			case 'contribute':
				$contribute = Postmodel::where('post_type','=','contribute')->first();
				$editId = $contribute->post_id;
			break;
			case 'partner':
				$this->data['partnerCategory'] = PostModel::where('post_type','=','partner_category')->get();
			break;
			case 'agenda_session':
				$this->data['speakerList'] = PostModel::where('post_type','=','speakers')->get();
				$this->data['sessionDays'] = PostModel::where('post_type','=','agenda_day')->get();
			break;
		}
		$this->data['postDetails'] = Postmodel::find($editId);
		
		if(empty($this->data['postDetails'])){
			return redirect()->to(adminPrefix().'post_collection/'.$slug)->with('userMessage','Invalid Request.');
		}
		
		
		if($slug=='gallery'){
			$this->data['hasGallery'] = true;
		}
		return View('admin.'.$slug.'.edit',$this->data);
	}
	
	
	
	public function changestatus($slug,$postID,$currentStatus, Request $request){
		/*if(!$this->checkPermission('Edit '.$this->module)){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		}*/
		$currentStatus = ($currentStatus==1)?2:1;
		$currentStatusdatas = array('post_status'=>$currentStatus);
		PostModel::where('post_id', '=',$postID)->update($currentStatusdatas);
		$message = '<div class="alert alert-success">Status changed successfully</div>';
		
		return redirect()->to(adminPrefix().'post_collection/'.$slug)->with('userMessage',$message);
	}
	
	
	
	public function fileupload(Request $request){
		
		$this->_set_file_upload_settings($request->input('slug'),$request);
		if(!$request->file('file')) {
			return response()->json(array('status'=>false,'message'=>'Invalid Request'));
		}
		
		$file = $request->file('file');
		$slug = $request->input('slug');
		$type = $request->input('controlName');
		if(!empty($this->imageDimensions[$slug]) && $type=="image"){            
			$fileName = $this->resize_and_crop_image('file','public/post/',$this->imageDimensions[$slug]);
			return response()->json(array('status'=>true,'uploadDetails'=>['fileName'=>$fileName]));
			}else{
			list($fileName,$filePath) = $this->store_file('file','public/post/');
			return response()->json(array('status'=>true,'uploadDetails'=>['fileName'=>$fileName]));
		}
		
		return response()->json(array('status'=>false,'message'=>'Invalid Request'));
	}
	
	public function general_filedelete($fileName , Request $request){
		
		return parent::deleteFile($fileName,$request);
	}
	
	public function general_filedownload($fileName , Request $request){
		
		return parent::downloadFile($fileName,$request);
	}
	
	
	public function delete($slug, $id, Request $request){  
		
		/* if(!$this->checkPermission('Delete '.$this->module)){
			return Redirect(route('admin_dashboard'))->with('userMessage','Invalid Permission') ;
		} */
		
		//Restrict Banner Deletion
		if(in_array($slug,['banner'])){
			return redirect()->to(adminPrefix().'dashboard')->with('userMessage','Invalid Request.');
		}
		
		
		$post = PostModel::find($id);
		// pre($post);
		$message = $this->custom_message('Error deleting '.$slug,'error');
		if(!empty($post)){
			try{
				DB::beginTransaction();
				if($slug == 'gallery'){
					$galleryData = DB::table('gallery_images')
					->where('gallery_image_type','=',1)
					->where('gallery_post_id','=',$post->post_id)
					->get();
					foreach($galleryData as $galImage){
						if(!empty($galImage->gallery_image_name) && File::exists('storage/app/public/uploads/gallery/'.$galImage->gallery_image_name) ){
							
							File::delete('storage/app/public/uploads/gallery/'.$galImage->gallery_image_name);
							File::delete('storage/app/public/uploads/gallery/thumb/'.$galImage->gallery_image_name);
							File::delete('storage/app/public/uploads/gallery/small/'.$galImage->gallery_image_name);
							File::delete('storage/app/public/uploads/gallery/large/'.$galImage->gallery_image_name);
							
						}
					}
				}
				// pre($galleryData);
				$post->delete();
				DB::commit();
				$message = $this->custom_message($this->slugText.' deleted Successfully','success');
				}catch(\Exception $e){
				DB::rollback();
				$message = $this->custom_message('Error deleting '.$this->slugText,'error');
			}
			// pre(adminPrefix().'post_collection/'.$slug);
			return redirect()->to(adminPrefix().'post_collection/'.$slug)->with('userMessage',$message);
		}
		return redirect()->to(adminPrefix().'post_collection/'.$slug)->with('userMessage',$message);
	}
	
	public function getSubCategory( Request $request){  
		$id=$request->id;
		if(!empty($id)){
			$Where =[
			'rawQuery'=>' AND category_id = ? ',
			'args'=>[$id]
			]; 
		}
		
		$subcategoryList=CmsModel::getPostListWithDetailByPostSlug('product_sub_category',$Where);
		
		
		
		$html='<select name="meta[text][prod_sub_category_id]"  class="form-control">';
		$html .='<option value=" ">Select</option>';
		foreach($subcategoryList as $sub){
			$html .='<option value="'.$sub->post_id.'">'.$sub->post_title.'</option>';
		}
		$html .='</select>';
		
		
		
		return response()->json(array('status'=>true,'subHtml'=>$html));
		
		
		
	}
	
	public function view_feed_news($postID,Request $request){
		
		$postDetails = PostModel::find($postID);
		if(empty($postDetails)){
			return redirect()->to(adminPrefix().'post_collection/news-feed')->with('userMessage',$this->custom_message('Invalid Request. No details found!','error'));
		}
		
		$feedObj = \Feeds::make($postDetails->getMeta('news_feed_url'));
		
		$insertData=[];
		foreach($feedObj->get_items() as $item){
			if($this->is_rtl($item->get_title()) == 0){
				$tmp['nfp_title'] = $item->get_title();
				$tmp['nfp_description'] = $item->get_description();
				}else{
				$tmp['nfp_title_arabic'] = $item->get_title();
				$tmp['nfp_description_arabic'] = $item->get_description();
			}
			$tmp['nfp_link'] = $item->get_permalink();
			$tmp['nfp_publish_date'] = $item->get_date('Y-m-d H:i:s');
			$tmp['nfp_is_arabic'] = $this->is_rtl($item->get_title());
			
			$insertData[] = $tmp;
			
		}
		
		NewsFeedTmp::truncate();
		NewsFeedTmp::insert($insertData);
		
		
		$this->data['feedDetails'] = NewsFeedTmp::all();
		
		return view('admin.news-feed.feed_news_list',$this->data);
	}
	
	public function get_youtube_id($url){
		
		$videoID = false;
		if (preg_match('/youtube\.com\/watch\?v=([^\&\?\/]+)/', $url, $id)) {
			$videoID = $id[1];
			} else if (preg_match('/youtube\.com\/watch\?.*&v=([^\&\?\/]+)/', $url, $id)) {
			$videoID = $id[1];
			} else if (preg_match('/youtube\.com\/embed\/([^\&\?\/]+)/', $url, $id)) {
			$videoID = $id[1];
			} else if (preg_match('/youtube\.com\/v\/([^\&\?\/]+)/', $url, $id)) {
			$videoID = $id[1];
			} else if (preg_match('/youtu\.be\/([^\&\?\/]+)/', $url, $id)) {
			$videoID = $id[1];
			}else if (preg_match('/youtube\.com\/verify_age\?next_url=\/watch%3Fv%3D([^\&\?\/]+)/', $url, $id)) {
			$videoID = $id[1];
		}
		
		return $videoID;
	}
	
}	