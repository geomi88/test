<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\Base\AdminBaseController;

use Illuminate\Support\Facades\Redirect;
use Input;
use Config;
use DB;

use Validator;
use Session;
use Carbon\Carbon;
use File;
use Auth;
use Storage;

use App\User as User;
use App\Models\CountryModel;
use App\Models\Admodels\HubModel;
use App\Models\Admodels\HubWorkingModel;
use App\Models\Admodels\EmirateModel;
use App\Models\Admodels\SpaceModel;
use Symfony\Component\HttpFoundation\Request;
use \Cviebrock\EloquentSluggable\Services\SlugService;




class HubController extends AdminBaseController {
	
	public function __construct(Request $request){
		parent::__construct($request);
        $this->data['pageTitle'] = 'Hub Manager';
	}
    
    public function index(Request $request){
        
        $this->data['emirateList'] = EmirateModel::get();
        $tmp = HubModel::orderBy('hub_title','asc');
		if(!empty($request->input('hubName'))){
				$tmp->where('hub_title','LIKE','%'.$request->input('hubName').'%');
				$tmp->orWhere('hub_title_arabic','LIKE','%'.$request->input('hubName').'%');
		}
		if(!empty($request->input('emirateId'))){
				$tmp->where('hub_emirate_id','=',$request->input('emirateId'));
				
		} 
		if(!empty($request->input('hub_status'))){
				$tmp->where('hub_status','=',$request->input('hub_status'));
				
		} 
		$this->data['hubList']=$tmp->paginate(5);
		
        return view('admin.hub-manager.list',$this->data);
    }

    public function add(Request $request){

        if($request->input('_token')){

            $inputs =   [
                            'hub_title' => $request->input('hub_title'),
                            'hub_title_arabic' => $request->input('hub_title_arabic'),
                            'hub_address1' => $request->input('hub_address1'),
                            'hub_address1_arabic' => $request->input('hub_address1_arabic'),
                            'hub_address2' => $request->input('hub_address2'),
							 'hub_main_image' => $request->file('hub_main_image'),
                            'hub_address2_arabic' => $request->input('hub_address2_arabic'),
                            // 'hub_working_from' => $request->input('hub_working_from'),
                            // 'hub_working_to' => $request->input('hub_working_to'),
                            'hub_misc_desc' => $request->input('hub_misc_desc'),
                            'hub_misc_desc_arabic' => $request->input('hub_misc_desc_arabic'),
                            'hub_phone' => $request->input('hub_phone'),
                            'hub_mobile' => $request->input('hub_mobile'),
                            'hub_priority' => $request->input('hub_priority'),
                            'hub_status' => $request->input('hub_status'),
                        ];
			
			$rules = [
                        'hub_title' =>'required',
                        'hub_title_arabic' => 'required',
						'hub_main_image' => 'required|mimes:jpg,jpeg,png,bmp',
                        'hub_priority' => 'required',
                        'hub_status' => 'required',
                    ];
				
			$messages = [
				'hub_title.required' => 'Name/Title of hub is required',
				'hub_title_arabic.required' => 'Arabic Name/Title of hub is required',
				'hub_main_image.required' => 'Hub Image is required',
				'hub_status.required' => 'Status of hub is required',
			];
			
			$validator = \Validator::make($inputs,$rules,$messages);
			if($validator->fails()){
                
                $this->data['userMessage'] =  $this->custom_message($validator,'error');
                \Input::flash();
                $request->flash();

            }else{
                $data = [
                    'hub_emirate_id' => $request->input('hub_emirate'),
                    'hub_title' => $request->input('hub_title'),
                    'hub_title_arabic' => $request->input('hub_title_arabic'),
                    'hub_address1' => $request->input('hub_address1'),
                    'hub_address1_arabic' => $request->input('hub_address1_arabic'),
                    'hub_address2' => $request->input('hub_address2'),
                    'hub_address2_arabic' => $request->input('hub_address2_arabic'),
                    'hub_misc_desc' => $request->input('hub_misc_desc'),
                    'hub_misc_desc_arabic' => $request->input('hub_misc_desc_arabic'),
					'hub_map_embedd_code' => $request->input('hub_map_embedd_code'),
					'hub_video_url' => $request->input('hub_video_url'),
                    'hub_phone' => $request->input('hub_phone'),
                    'hub_mobile' => $request->input('hub_mobile'),
                    'hub_created_by' => \Auth::user()->id,
                    'hub_updated_by' => \Auth::user()->id,
                    'hub_priority' => $request->input('hub_priority'),
                    'hub_status' => $request->input('hub_status'),
                ];
                
				if(!empty($inputs['hub_main_image'])){
					$destinationPath = 'public/uploads/hub/';
					$dimensions = [
						['folder'=>'recommended','width'=>400,'height'=>400],
						['folder'=>'small','width'=>100,'height'=>100]
					];
					$fileName = $this->resize_and_crop_image('hub_main_image',$destinationPath,$dimensions,$hubDetails->hub_main_image);
					$data['hub_main_image'] = $fileName;
				}
                try{
                    DB::beginTransaction();
                        $newhub = HubModel::create($data);
                        $hubWorkingDays = $request->input('workingday');
                        $hubWorkingDayOfWeek = $request->input('dayofweek');
                        
                        $startTimeArr = $request->input('hub_working_from');
                        $endTimeArr = $request->input('hub_working_to');
                        
                        if(!empty($hubWorkingDays)){
                            $workingData = [];
                            foreach($hubWorkingDays as $key=>$workingDay){   
                                $workingData[] =    [
                                                        'hwm_hub_id'=> $newhub->hub_id,
                                                        'hwm_dayname'=> $workingDay,
                                                        'hwm_dayofweek'=>$hubWorkingDayOfWeek[$key],
                                                        'hwm_start_time'=>$startTimeArr[$key],
                                                        'hwm_end_time'=>$endTimeArr[$key],
                                                        'hwm_created_by'=>Auth::user()->id,
                                                        'hwm_updated_by'=>Auth::user()->id,
                                                    ]; 
                            }
                            

                            HubWorkingModel::insert($workingData);
                        }
                    DB::commit();
                    $request->flush();
                    $this->data['userMessage'] = $this->custom_message('Hub details saved successfully.','success');
                }catch(\Exception $ex){
                    DB::rollBack();
                    $request->flash();
                    $this->data['userMessage'] = $this->custom_message('Cannot Save Data. '.$ex->getMessage(),'error');
                }                
            }
            
            
        }

        
        $this->data['pageTitle'] = 'Add New Hub';
        $this->data['emirateList'] = EmirateModel::get();
        return view('admin.hub-manager.add',$this->data);
    }

    public function edit($id, Request $request){
        
        $hubDetails = HubModel::find($id);
        if(empty($hubDetails)){
            return redirect()->to(apa('hub-manager'))->with('userMessage', $this->custom_message('Invalid request. No such record found','error'));
        }
        if($request->input('_token')){
            

            $inputs =   [
                            'hub_title' => $request->input('hub_title'),
                            'hub_title_arabic' => $request->input('hub_title_arabic'),
                            'hub_main_image' => $request->file('hub_main_image'),
                            'hub_address1' => $request->input('hub_address1'),
                            'hub_address2' => $request->input('hub_address2'),
                            'hub_working_from' => $request->input('hub_working_from'),
                            'hub_working_to' => $request->input('hub_working_to'),
                            'hub_misc_desc' => $request->input('hub_misc_desc'),
                            'hub_video_url' => $request->input('hub_video_url'),
                            'hub_map_embedd_code' => $request->input('hub_map_embedd_code'),
                            'hub_phone' => $request->input('hub_phone'),
                            'hub_mobile' => $request->input('hub_mobile'),
                            'hub_created_by' => \Auth::user()->id,
                            'hub_updated_by' => \Auth::user()->id,
                            'hub_priority' => $request->input('hub_priority'),
                            'hub_status' => $request->input('hub_status'),
                        ];
			
			$rules = [
                        'hub_title' =>'required',
                        'hub_title_arabic' => 'required',
                        'hub_priority' => 'required',
                        'hub_status' => 'required',
                    ];
			if(!empty($Inputs['hub_main_image'])){
				$rules['hub_main_image'] = 'required|mimes:jpg,jpeg,png,bmp';
			}	
			$messages = [
				'hub_title.required' => 'Name/Title of hub is required',
				'hub_title_arabic.required' => 'Arabic Name/Title of hub is required',
				'hub_main_image.required' => 'Hub Image is required',
				'hub_status.required' => 'Status of hub is required',
			];
            
			$validator = \Validator::make($inputs,$rules,$messages);
			if($validator->fails()){
                $this->data['userMessage'] =  $this->custom_message($validator,'error');
                \Input::flash();
                $request->flash();
                
            }else{
				
				
                $data = [
                    'hub_emirate_id' => $request->input('hub_emirate'),
                    'hub_title' => $request->input('hub_title'),
                    'hub_title_arabic' => $request->input('hub_title_arabic'),
                    'hub_address1' => $request->input('hub_address1'),
                    'hub_address1_arabic' => $request->input('hub_address1_arabic'),
                    'hub_address2' => $request->input('hub_address2'),
                    'hub_address2_arabic' => $request->input('hub_address2_arabic'),
                    'hub_misc_desc' => $request->input('hub_misc_desc'),
                    'hub_misc_desc_arabic' => $request->input('hub_misc_desc_arabic'),
					'hub_video_url' => $request->input('hub_video_url'),
					'hub_map_embedd_code' => $request->input('hub_map_embedd_code'),
                    'hub_phone' => $request->input('hub_phone'),
                    'hub_mobile' => $request->input('hub_mobile'),
                    'hub_created_by' => \Auth::user()->id,
                    'hub_updated_by' => \Auth::user()->id,
                    'hub_priority' => $request->input('hub_priority'),
                    'hub_status' => $request->input('hub_status'),
                ];
				
				if(!empty($inputs['hub_main_image'])){
					$destinationPath = 'public/uploads/hub/';
					$dimensions = [
						['folder'=>'recommended','width'=>400,'height'=>400],
						['folder'=>'small','width'=>100,'height'=>100]
					];
					$fileName = $this->resize_and_crop_image('hub_main_image',$destinationPath,$dimensions,$hubDetails->hub_main_image);
					$data['hub_main_image'] = $fileName;
				}
				
                try{
                    DB::beginTransaction();
                        $updatedHub = HubModel::where('hub_id','=',$hubDetails->hub_id)->update($data);
                        // pre($updatedHub);
                        $hubWorkingDays = $request->input('workingday');
                        $hubWorkingDayOfWeek = $request->input('dayofweek');
                        
                        $startTimeArr = $request->input('hub_working_from');
                        $endTimeArr = $request->input('hub_working_to');
                        
                        if(!empty($hubWorkingDays)){
                            $workingData = [];
                            foreach($hubWorkingDays as $key=>$workingDay){   
                                $workingData[] =    [
                                                        'hwm_hub_id'=> $hubDetails->hub_id,
                                                        'hwm_dayname'=> $workingDay,
                                                        'hwm_dayofweek'=>$hubWorkingDayOfWeek[$key],
                                                        'hwm_start_time'=>$startTimeArr[$key],
                                                        'hwm_end_time'=>$endTimeArr[$key],
                                                        'hwm_created_by'=>Auth::user()->id,
                                                        'hwm_updated_by'=>Auth::user()->id,
                                                    ]; 
                            }
                            
                            HubWorkingModel::where('hwm_hub_id','=',$hubDetails->hub_id)->delete();
                            HubWorkingModel::insert($workingData);
                        }
                    DB::commit();
                    $request->flush();
                    DB::commit();
                    
                    $this->data['userMessage'] = $this->custom_message('Hub updated successfully','success');
                }catch(\Exception $ex){
                    DB::rollBack();
                    $request->flash();
                    $this->data['userMessage'] = $this->custom_message('Cannot Save Data'.$ex->getMessage(),'error');
                }
            }
            
            
        }
        
        $this->data['hubDetails'] = HubModel::find($id);
        $this->data['emirateList'] = EmirateModel::get();
        
        return view('admin.hub-manager.edit',$this->data);
    }

    public function changestatus($id,Request $request){
        $hubInfo = HubModel::find($id);
        if(empty($hubInfo)){
            return redirect()->to(apa('hub-manager'))->with('userMessage', $this->custom_message('Invalid request. No such record found','error'));
        }

        $newStatus = ($hubInfo->hub_status==2)?1:2;
        $hubInfo->hub_status = $newStatus;
        $hubInfo->save();
      
       // pre(apa('/hub-manager'));
		return redirect()->to(apa('hub-manager?'.implode('&',\Input::all())))->with('userMessage', $this->custom_message('Status changed successfully','success'));
    } 



    public function delete($resourceID, Request $request){
        if(empty($resourceID)){
            return redirect()->to(apa('hub-manager'))->with('userMessage', $this->custom_message('Invalid request. No such record found','error'));
        }
        $resourceDetails = ResourceManagerModel::find($resourceID);
        if(empty($resourceDetails)){
            return redirect()->to(apa('hub-manager'))->with('userMessage', $this->custom_message('Invalid request. No such record found','error'));
        }
        $resourceDetails->delete();        
        return redirect()->to(apa('hub-manager'))->with('userMessage', $this->custom_message('Resource delete permanently.','success'));
    }
	
	
	
}