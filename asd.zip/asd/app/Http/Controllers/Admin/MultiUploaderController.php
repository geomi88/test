<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\Base\AdminBaseController;

use Illuminate\Support\Facades\Redirect;
use App\User as User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Auth;
use Input;
use Config;
use DB;
use Validator;
use Session;
use File;

class MultiUploaderController extends AdminBaseController {
	
	private $module;
	private $dimensions;
	private $hasImage = false;
	private $image_column_name = false;
	private $resizeImage = true;
	
    public function __construct(Request $request){
		parent::__construct($request);
        $this->data['pageTitle'] = 'Upload Manager';
	}

	public function file_upload(Request $request){
		$resize = 0;
		if($request->hasFile('file')){
				$path = 'public/uploads/cms/'.$request->module.'/multi_image_gallery';
				if($request->width && $request->height){
					//$uploadPath = 'storage/app/public/uploads/cms/'.$request->module.'/multi_image_gallery/';
					$dimensions = [
							[
							'width'=>$request->width,
							'height'=>$request->height,
							'folder'=>$request->folder,
							]
					];
					$fileName = $this->resize_and_crop_image('file',$path ,$dimensions ,null);
					$resize = 1;
				}else{
					//$fileName = $this->resize_and_crop_image('file','assets/uploads/image_gallery/',array(array('width'=> 150,'height'=>115,'folder'=>'thumb'),array('width'=>343,'height'=>262,'folder'=>'medium'),array('width'=> 800,'height'=>600,'folder'=>'large')),null);
					$fileName = $this->store_file('file',$path)[0];
				}
				$id=0;
				if(!empty($fileName)){
					$insertDatas = array(
										'gallery_category_slug' => $request->slug,
										'gallery_image_name' =>$fileName,
										'gallery_image_type' =>1,
										'gallery_image_date' =>date('Y-m-d H:i:s'),
										'gallery_image_status' =>1,
										'gallery_priority' =>1,
										'gallery_resize' =>$resize,
										'gallery_uploaded_user' =>\Auth::user()->id,
									);
					//pre($insertDatas);
					$id = DB::table('gallery_images')->insertGetId($insertDatas);
				}
				$data = DB::table('gallery_images AS GI ')
						  // -> select(DB::raw('GI.*,CI.category_name'))
						  // ->join('category_master AS CI','CI.category_id','=','GI.gallery_cat_id')
						  ->where('gallery_image_type','=',1)
						  ->where('gallery_id','=',$id)
						  ->first();
				// echo json_encode(array('status'=>true,'fileName'=>$data->gallery_image_name,'id'=>$data->gallery_id,'category_name'=>$data->category_name));
				echo json_encode(array('uploadDetails'=>array('status'=>true,'fileName'=>$data->gallery_image_name,'id'=>$data->gallery_id)));
				exit();
		}
	}

	
	/* BELOW METHOD IS ONLY USED IN ADD EVENT POPUP FORM ONLY*/ 
	public function fileUpload(Request $request){
		$resize = 0;
		if($request->hasFile('file')){
				$path = 'uploads/team/recommended';

				$fileName = $this->store_file('file',$path)[0];
				
				if(empty($fileName)){
					return \Response::json(array('status'=>false,'response'=>'File Cannot be uploaded. Some error occured'));
				}
			$data['fileName'] = $fileName;
			return \Response::json(array('status'=>true,'uploadDetails'=>$data));
		}
	}

	

	public function get_old_files(Request $request){
		// $circleID = Input::get('circleID');
		$slug = $request->slug;
		$oldFiles = array();
	
			$oldFiles	= DB::table('gallery_images AS GI')
						  // -> select(DB::raw('GI.*,YC.yc_name'))
						 
						  ->where('gallery_image_type','=',1)
						  ->where('gallery_category_slug','=',$slug)
						  // ->where('gallery_circle_id','=',$circleID)
						  // ->orderBy(DB::raw('GC.gc_id'),'DESC')
						  ->orderBy(DB::raw('GI.gallery_id'),'DESC')
						  ->get();
	
	  
	   echo json_encode(array('status'=>true, 'gallery'=>$oldFiles));
	   exit();
	}

	public function delete_gallery_image($id, Request $request){
		$imageDetail = 	DB::table('gallery_images')
						   ->where('gallery_id','=',$id)
						   ->first();
		if(!empty($imageDetail)){
		   $path = 'storage/app/public/uploads/cms/'.$imageDetail->gallery_category_slug.'/multi_image_gallery';
			   if(!empty($imageDetail->gallery_image_name) && File::exists($path.'/'.$imageDetail->gallery_image_name) ){

				   File::delete($path.'/'.$imageDetail->gallery_image_name);
				   File::delete($path.'/thumb/'.$imageDetail->gallery_image_name);
				   File::delete($path.'/small/'.$imageDetail->gallery_image_name);
				   File::delete($path.'/large/'.$imageDetail->gallery_image_name);

			   }
			   DB::table('gallery_images')->where('gallery_id', '=', $id)->delete();
			   // DB::table('gallery_category')->where('gc_id', '=',$id)->delete();
		   // }
		}
		if($request->ajax()){
		   echo json_encode(array('status'=>true,'Message'=>'File Deleted'));
		}else{
			return Redirect::to(Config::get('app.admin_prefix').'/image-gallery')->with('userMessage',$this->custom_message('Album deleted successfully.','success'));
		}
   }



	
}
