<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Cookie;
use App\Models\Admodels\CountryModel;
use App\Models\Admodels\PostModel;
use App\Models\Admodels\EventModel;

use App\Models\Admodels\MenuManagerModel;
use Illuminate\Support\Facades\View;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Validation\Validator;
use CustomCalendar\Calendar;


use App\Models\Admodels\HubModel;
use App\Models\Admodels\SpaceModel;


use Auth;
use App\User as User;
use Lang;
use Image;
use DB;
use Input;
use File;

class AjaxController extends FrontendBaseController {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
			if(!$request->ajax()){
				return redirect()->to(route('home',\App::getLocale()));
			}
			return $next($request);
        });
    }

	public function getEventDetails(Request $request){

		$eventID = $request->input('event');
		$response = ['status'=> false, 'data' =>null ];
		if(!empty($eventID)){
			$event = EventModel::where('event_id','=',$eventID)->first();
			if(!empty($event)){
				$title = $event->getData('event_title');
				$descr = $event->getData('event_large_desc');
				$response = ['status'=> true, 'data' =>['title'=>$title,'description'=>$descr] ];
			}
		}
		return response()->json($response);
	}
   
    public function get_all_hub_data(Request $request){
			
		$hubList = HubModel::active()->get();
		
		$allHubsAndSpaces = []; 
		foreach($hubList as $hub){
			$temp = [
				'hubId'=>$hub->hub_id,
				'hubSlug'=>$hub->hub_slug,
				'hubTitle'=>$hub->getData('hub_title'),
				'hubImage'=>$hub->getData('hub_main_image'),
			];
			// pre($hub->spaces->count());
			foreach($hub->spaces as $space){
				if($space->space_status == 1){
					$temp['spaces'][] = [
											'spaceId'=>	$space->space_id,
											'spaceTitle'=>	$space->getData('space_title'),
											'spaceType'=>	($space->space_type==1)?'space':(($space->space_type==2)?'meeting':'none'),
											'spaceMaxSeats'=> $space->space_max_seats,
											'spaceImage'=> $space->space_image,
											'spaceDesc'=> $space->getData('space_description'),
										];
					
				}
			}
			$allHubsAndSpaces[] = $temp;
			
		}
		return response()->json(['status'=>true,'data'=>$allHubsAndSpaces]);
	}
	
	public function get_spaces(Request $request){
		$hubSlug = $request->input('slug');
		$hubDetails = HubModel::where('hub_slug','=',$hubSlug)->first();
		if(!empty($hubDetails)){
            return response()->json(['status'=>false,'message'=>lang('invalid_request')]);
        }		
		$spaceList = SpaceModel::active()->ByHubId($hubDetails->hub_id)->get();
		return response()->json(['status'=>true,'spaceList'=>$spaceList,'hub'=>$hubDetails]);
	}
	
	public function getHubSpaceSlides(Request $request){

		$hubSlug = $request->input('hub');
		$data = [];
		$response = ['status'=> false, 'data' =>$data ];
		if(!empty($hubSlug)){
			$hub = HubModel::where('hub_slug','=',$hubSlug)->first();
			
			if(!empty($hub)){
				if(!empty($hub) && $hub->spaces->count() > 0 ){ 
					foreach($hub->spaces as $key => $space){ 
						$data['spaces'][$space->space_id]['title'] = $space->getData('space_title');
						$data['spaces'][$space->space_id]['description'] = $space->getData('space_description');
						$data['spaces'][$space->space_id]['id'] = $space->getData('space_id');
						$data['spaces'][$space->space_id]['slides']['listItems'] = View::make('frontend.partials.home.spaces.spaces_li',['hub'=>$hub,'space'=>$space,'key'=>$key])->render();
						$data['spaces'][$space->space_id]['slides']['thumbsItems'] = View::make('frontend.partials.home.spaces.spaces_thumb',['space'=>$space,'key'=>$key])->render();
						$data['spaces'][$space->space_id]['slides']['largeItems'] = View::make('frontend.partials.home.spaces.spaces_large',['space'=>$space,'key'=>$key])->render();
					}	
				}
				$data['hub'][$hub->hub_id]['title'] = trans('messages.youthhub').' '.$hub->getData('hub_title');
				$response = ['status'=> true, 'data' =>$data ];
				
			}
		}
		return response()->json($response);
	}
   
	public function getHubDetails(Request $request){

		$hubSlug = $request->input('hub');
		$data = [];
		$response = ['status'=> false, 'data' =>$data ];
		if(!empty($hubSlug)){
			$hub = HubModel::where('hub_slug','=',$hubSlug)->first();
			if(!empty($hub)){
				if(!empty($hub) && $hub->spaces->count() > 0 ){ 
					foreach($hub->spaces as $key => $space){ 
						
					}	
				}
				$data['hub'][$hub->hub_id]['title'] = trans('messages.youthhub').' '.$hub->getData('hub_title');
				$response = ['status'=> true, 'data' =>$data ];
				
			}
		}
		return response()->json($response);
	}
   
}
