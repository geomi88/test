<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use \DrewM\MailChimp\MailChimp;
use Cookie;

use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Auth;
use App\User as User;
use DB, Mail;
use Hash;
use File;
use Illuminate\Support\Facades\Storage;
use Session;
use Lang;

use DateTime;
use Carbon\Carbon as Carbon;
use Illuminate\Support\Facades\Log;
use Alert;

use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Models\FarmModel;
use App\Models\CountryModel;
use App\Models\FarmSubscriptionModel;
use App\Models\FarmRatingModel;
use App\Models\UserNotificationModel;

use Illuminate\Pagination\Paginator;

class UserController extends FrontendBaseController
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    protected $user;

    protected $userActionData;

    public function __construct()
    {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            $this->user = Auth::user();
            return $next($request);
        });
    }


    public function register($lang, Request $request)
    {

        if ($request->input('_token')) {

            $inputs = $request->all();
            $rules = [
                'name' => 'required',
                'user_email' =>  'required|unique:users',
                'phone' => 'required',
                'password' => 'required|min:8',
            ];

            $messages = [
                'name.required' => trans('messages.name_required'),
                'user_email.required' => trans('messages.email_required'),
                'phone.required' => trans('messages.phone_required'),
                'password.required' => trans('messages.password_required'),

            ];
            $validator = \Validator::make($inputs, $rules, $messages);
            $userMessage = false;

            if ($validator->fails()) {
                $request->flash();
                $userMessage = '<ul style="list-style:none" class="alert alert-danger">';
                $messages = $validator->messages();
                foreach ($messages->all() as $message) {
                    $userMessage .= '<li>' . $message . '</li>';
                }
                $userMessage .= '</ul>';
                $response_data['userMessage'] = $userMessage;
                $response_data['status'] = false;
                return Response($response_data);
                // pre($userMessage);
            } else {
                DB::beginTransaction();

                try{
                    $regAuthCode= \Hash::make($request->input('user_email').microtime());
                    $user = new User;
                    $user->user_full_name = $request->input('name');
                    $user->user_email = $request->input('user_email');
                    $user->user_phone_number = $request->input('phone');

                    $user->password = \Hash::make($request->input('password'));
                    $user->user_validate_code = $regAuthCode;
                    $user->user_code = User::max('user_code')+1;
                    $user->save();
                    

                    /** Email Confirmation mail */
                    
                    $confirmationLink = asset('/confirm-email?code='.$regAuthCode);
                            
                    $data = array(
                        'user_name' => $request->input('name'),
                        'confirmationLink'=>$confirmationLink,
                    );

                    $emailTemplate='frontend.email_template.autoreply_register_en';
                    $email = $request->input('user_email');
                   
                   
					Mail::send($emailTemplate,$data,function($message) use ( $email ){
						$message->to($email)
						->subject(trans('messages.farmsGate_registration'));
					});
                    /** */
                    DB::commit();
                    //Auth::loginUsingId($user->id);
                    $response_data['userMessage'] = trans('messages.registration_success');
                    $response_data['status'] = true;
                    $response_data['redirectURL'] = url($lang . "/home");
                    return Response($response_data);
                }catch(\Exception $e){
                    DB::rollBack();
                    $response_data['userMessage'] = trans('messages.some_issue');
                    $response_data['status'] = false;
                    return Response($response_data);
                }
            }
        }
        return view('frontend.index', $this->data);
    }
    public function dashboard($lang, Request $request)
    {
        try{
            $farmList = FarmModel::where('fm_owner_id', '=', Auth::user()->id)->orderby('fm_created_at','DESC')->get();
            $this->data['farmList'] = $farmList;
            return view('frontend.user.dashboard', $this->data);
        }
        catch(\Exception $e){            
            $data = $this->catch_message();
			return  redirect($this->data['lang'].'/home')->with('userMessage',$data);
        }
    }

    public function favoriteFarms($lang, Request $request)
    {
        try{
            $farmList = Auth::user()->favFarms()->whereHas('getFarmDetails')->get();
            $this->data['farmList'] = $farmList;
            return view('frontend.user.favorites', $this->data);
        }
        catch(\Exception $e){            
            $data = $this->catch_message();
			return  redirect($this->data['lang'].'/home')->with('userMessage',$data);
        }
    }

    public function settings($lang, Request $request)
    {
        try{
            $userDetails = Auth::user();
            $this->data['countryList'] = CountryModel::active()->get();
            $this->data['userDetails'] = $userDetails;
            if ($request->input('_token')) {
                $inputs = $request->all();
                $rules = [
                    'full_name' => 'required',
                    'u_phone' =>  'required',
                ];

                $messages = [
                    'full_name.required' => trans('messages.name_required'),
                    'u_phone.required' => trans('messages.phone_required'),
                ];
                $validator = \Validator::make($inputs, $rules, $messages);
                $userMessage = false;

                if ($validator->fails()) {
                    $request->flash();
                    $userMessage = '<ul style="list-style:none" class="alert alert-danger">';
                    $messages = $validator->messages();
                    foreach ($messages->all() as $message) {
                        $userMessage .= '<li>' . $message . '</li>';
                    }
                    $userMessage .= '</ul>';
                    $response_data['userMessage'] = $userMessage;
                    $response_data['status'] = false;
                    return Response($response_data);
                    // pre($userMessage);
                } else {
                    $userDetails->user_full_name = $request->input('full_name');
                    $userDetails->user_phone_number = $request->input('u_phone');
                    $userDetails->user_nationality = $request->input('country_id');
                    $userDetails->user_description = $request->input('describe');
                    $userDetails->user_address = $request->input('address');
                    $avatar = $request->file('avatar');
                    if ($avatar) {
                        $filePath = 'public/uploads/user/';
                        list($fileName, $fileNameWithPath) = $this->store_file('avatar', $filePath);

                        $largeWidth = '400';
                        $largeHeight = '400';
                        $smallWidth = '150';
                        $smallHeight = '150';
                        $this->resize_image($fileName, $filePath, array('large' => array('height' => $largeHeight, 'width' => $largeWidth), 'small' => array('height' => $smallHeight, 'width' => $smallWidth)), true);


                        $userDetails->user_avatar = $fileName;
                    }
                    $userDetails->save();

                    $data['status'] = true;
                    $data['redirectURL'] = true;
                    return Response($data);
                }
            }

            return view('frontend.user.settings', $this->data);
        }
        catch(\Exception $e){            
            $data = $this->catch_message();
			return  redirect($this->data['lang'].'/home')->with('userMessage',$data);
        }
    }

    public function farmSubscriptions($lang, Request $request)
    {
        try{
            $farmList = Auth::user()->subscribedFarms()->orderBy('fs_created_at','desc')->whereHas('getFarmDetails')->get();
            $this->data['farmList'] = $farmList;
            return view('frontend.user.farm_subscriptions', $this->data);
        }
        catch(\Exception $e){            
            $data = $this->catch_message();
			return  redirect($this->data['lang'].'/home')->with('userMessage',$data);
        }
    }

    public function change_password($lang, Request $request)
    {
        try{
            if ($request->input('_token')) {

                $userDetails = Auth::user();
                $inputs = $request->all();
                $rules = [
                    'new_pwd' => 'required',
                    'confirm_pwd' =>  'required',
                    'current_pwd' => ['required', function ($attribute, $value, $fail) use ($userDetails) {
                        if (!\Hash::check($value, $userDetails->password)) {
                            return $fail(__(trans('messages.current_password_incorrect')));
                        }
                    }],
                ];

                $messages = [
                    'current_pwd.required' => trans('messages.current_password_required'),
                    'new_pwd.required' => trans('messages.password_required'),
                    'confirm_pwd.required' => trans('messages.confirm_password_required'),

                ];
                $validator = \Validator::make($inputs, $rules, $messages);
                $userMessage = false;

                if ($validator->fails()) {
                    $request->flash();
                    $userMessage = '<ul style="list-style:none" class="alert alert-danger">';
                    $messages = $validator->messages();
                    foreach ($messages->all() as $message) {
                        $userMessage .= '<li>' . $message . '</li>';
                    }
                    $userMessage .= '</ul>';
                    $response_data['userMessage'] = $userMessage;
                    $response_data['status'] = false;
                    return Response($response_data);
                    // pre($userMessage);
                } else {
                    $userDetails->password = Hash::make($request->input('new_pwd'));

                    $userDetails->save();

                    $data['status'] = true;
                    $data['redirectURL'] = true;
                    return Response($data);
                }
            }

            return view('frontend.user.change_password', $this->data);
        }catch(\Exception $e){            
            $data = $this->catch_message();
            return  redirect($this->data['lang'].'/home')->with('userMessage',$data);
        }    
    }

    public function ownedFarmSubscriptions($lang, Request $request)
    {   
        try{    
            $farmSubscriptions =FarmSubscriptionModel::orderBy('fs_created_at','desc')
                                                    ->whereHas('getOwnedFarmDetails')
                                                    ->get();   
            $this->data['farmSubscriptions'] = $farmSubscriptions ;                                 
            return view('frontend.user.owned_farm_subscriptions', $this->data);
        }catch(\Exception $e){            
            $data = $this->catch_message();
            return  redirect($this->data['lang'].'/home')->with('userMessage',$data);
        }
    }

    public function reviews($lang, Request $request)
    {   
        try{    
            $reviews_for_user =FarmRatingModel::orderBy('fr_created_at','desc')
                                                    ->whereHas('getOwnedFarmDetails')
                                                    ->get();        

            $reviews_by_user = Auth::user()->reviewedFarms()->whereHas('getFarmDetails')->get();

            $this->data['reviews_for_user'] = $reviews_for_user ;
            $this->data['reviews_by_user'] = $reviews_by_user ;                                 
            return view('frontend.user.reviews', $this->data);
        }catch(\Exception $e){            
            $data = $this->catch_message();
            return  redirect($this->data['lang'].'/home')->with('userMessage',$data);
        }
    }

    public function notifications($lang, Request $request)
    {   
        try{    
            $notifications = UserNotificationModel::active()->where('un_to_user_id',Auth::user()->id)->where('un_status',1)->orderBy('un_created_at','desc')->get();
            UserNotificationModel::where('un_to_user_id',Auth::user()->id)->update(['un_read_status' =>1]);

            $this->data['notifications'] = $notifications ;
            return view('frontend.user.notifications', $this->data);
        }catch(\Exception $e){            
            $data = $this->catch_message();
            return  redirect($this->data['lang'].'/home')->with('userMessage',$data);
        }
    }

    public function confirm_email(Request $request){
		$code = $request->input('code');	
		if(empty($code)){


            $userMessage = "Invalid Request";
            $data['userMessage'] = $userMessage;
            $data['flag'] = 'error';
            $data['show_staus'] = 'show_';
            $data['show_modal'] = true;
			return redirect($this->data['lang'].'/home')->with('userMessage',$data);
		}
        
        $userDetails = User::where('user_validate_code','=',$code)->first();
		
		if(empty($userDetails)){
            $userMessage = "Account Not Found";
            $data['userMessage'] = $userMessage;
            $data['flag'] = 'error';
            $data['show_staus'] = 'show_';
            $data['show_modal'] = true;
			return  redirect($this->data['lang'].'/home')->with('userMessage',$data);
		}
		
		$dataToUpdate = ['user_email_confirmed'=>1,'user_validate_code'=>null];
		
		try{
			User::where('user_validate_code','=',$code)->update($dataToUpdate);
            $userMessage = "Verified Successfully";
            Auth::loginUsingId($userDetails->id);
		}catch(\Exception $e){
		
			$userMessage = 'Error';
		}
		$lang = $this->data['lang'];
		return \Redirect($lang . "/home")->with('userMessage',$userMessage);
		
    }
    
    /*public function forgot_password($lang,Request $request){

		if($request->input('_token')){
			$inputs = [
				'reset-email' => $request->input('reset-email'),
			];
			$rules = [
				'reset-email' =>'required|email',
			];
			$messages = [
				'reset-email.required' => trans('messages.email_required'),
				'reset-email.email' => trans('messages.invalid_email_address'),
			];
			
			$validator = \Validator::make($inputs,$rules,$messages);
			
			if($validator->fails()){
				$userMessage = '<ul style="list-style:none" class="alert alert-danger">';
                $messages = $validator->messages();
                foreach ($messages->all() as $message) {
                    $userMessage .= '<li>' . $message . '</li>';
                }
                $userMessage .= '</ul>';
                $response_data['userMessage'] = $userMessage;
                $response_data['status'] = false;
                return Response($response_data);
			}else{
				$email = $request->input('reset-email');
				$user = User::where('user_email','=',$email)->where('user_status',1)->first();
				$userMessages = 'You will receive a new password in your mail.';
				if($user){

                    $random_pwd = str_random(8);
					$user->password = Hash::make($random_pwd);
					$user->save();
                    $data['name'] = $user->user_full_name;
                    $data['new_pwd'] = $random_pwd;
					$emailTemplate = 'frontend.email_template.forgot_password_'.$lang;
					Mail::send($emailTemplate,$data,function($message) use ( $user ){
							$message->to($user->user_email)
							->subject(trans('messages.forgot_password_msg'));
                    });
                    $response_data['userMessage'] = trans('messages.receive_new_password_in_mail');
                    $response_data['status'] = true;
                    return Response($response_data);
				}else{
					$response_data['userMessage'] = "<b>".trans('messages.invalid_credentials')."</b>";
                    $response_data['status'] = false;
                    return Response($response_data);
				}
				
			}
		}
		return View('frontend.index',$this->data);
		
    }*/
    
    public function delete_notification($id, Request $request)
    {       
        UserNotificationModel::where('un_id',$id)->update(['un_status' =>2]);
        $lang = $this->data['lang'];
        return redirect()->to($lang.'/user/notifications');
    }

    public function forgot_password($lang,Request $request){

		if($request->input('_token')){
			$inputs = [
				'reset-email' => $request->input('reset-email'),
			];
			$rules = [
				'reset-email' =>'required|email',
			];
			$messages = [
				'reset-email.required' => trans('messages.email_required'),
				'reset-email.email' => trans('messages.invalid_email_address'),
			];
			
			$validator = \Validator::make($inputs,$rules,$messages);
			
			if($validator->fails()){
				$userMessage = '<ul style="list-style:none" class="alert alert-danger">';
                $messages = $validator->messages();
                foreach ($messages->all() as $message) {
                    $userMessage .= '<li>' . $message . '</li>';
                }
                $userMessage .= '</ul>';
                $response_data['userMessage'] = $userMessage;
                $response_data['status'] = false;
                return Response($response_data);
			}else{
                try{
                    $email = $request->input('reset-email');
                    $user = User::where('user_email','=',$email)->where('user_status',1)->first();
                    //$userMessages = 'You will receive a new password in your mail.';
                    if($user){
                        $validateCode = \Hash::make($email.microtime());
                        User::where('user_email','=',$email)->update(array('pwd_forgot_code'=>$validateCode));

                        
                        $data['name'] = $user->user_full_name;
                        $data['resetUrl'] = asset('/en/password-reset?resetCode='.$validateCode);
                        $emailTemplate = 'frontend.email_template.password_reset_email_'.$lang;
                        Mail::send($emailTemplate,$data,function($message) use ( $user ){
                                $message->to($user->user_email)
                                ->subject(trans('messages.forgot_password_msg'));
                        });
                        $response_data['userMessage'] = trans('messages.password_change_request_in_mail');
                        $response_data['status'] = true;
                        return Response($response_data);
                    }else{
                        $response_data['userMessage'] = "<b>".trans('messages.invalid_credentials')."</b>";
                        $response_data['status'] = false;
                        return Response($response_data);
                    }
                }
                catch(\Exception $e){
                    $response_data['userMessage'] = trans('messages.some_issue');
                    $response_data['status'] = false;
                    return Response($response_data);
                }
			}
		}
		return View('frontend.index',$this->data);
		
    }

    public function password_reset($lang,Request $request){
        $code = $request->input('resetCode');
		if(empty($code) ){
			return  redirect($this->data['lang'])->with('message','Invalid Request');
		}
        $userDetails = User::where('pwd_forgot_code','=',$code)->first();
	
		if(empty($userDetails)){
			return  redirect($this->data['lang'])->with('userMessage','Invalid Request');
		}

		$this->data['userDetails'] = $userDetails;
        $this->data['resetCode'] = $code;
        $this->data['lang'] = $lang;
		if($request->input('password')){

			$validator = \Validator::make($request->all(), [
				'password' => 'required',
			],
			[
				'password.required'=>trans('messages.password_required'),
			]
			);
			if ($validator->fails()) {
				$userMessage = '<ul style="list-style:none" class="alert alert-danger">';
                $messages = $validator->messages();
                foreach ($messages->all() as $message) {
                    $userMessage .= '<li>' . $message . '</li>';
                }
                $userMessage .= '</ul>';
                $response_data['userMessage'] = $userMessage;
                $response_data['status'] = false;
                return Response($response_data);
			}
			else{
				$password = $request->input('password');
				$passwordhash = \Hash::make($password);
				$newValidateCode = '';
				
				$dataToUpdate = array('password'=>$passwordhash,'pwd_forgot_code'=>$newValidateCode);
				User::where('id','=',$userDetails->id)
					->update($dataToUpdate);
								
                $response_data['userMessage'] = 'Password changed succesfully.Login with your new password.';
                $response_data['status'] = true;
                $response_data['redirectURL'] = url($lang . "/home");
                return Response($response_data);
				
					
			}
		}
		
		return view('frontend.user.reset_password',$this->data);
	}
}
