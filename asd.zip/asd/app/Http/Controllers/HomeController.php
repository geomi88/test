<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Cookie;
use App\Models\CountryModel;
use App\Models\Admodels\PostModel;
use App\Models\Admodels\EventModel;
use App\Models\Admodels\HubModel;
use App\Models\Admodels\MenuManagerModel;
use Illuminate\Support\Facades\View;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Validation\Validator;
use CustomCalendar\Calendar;
use App\Models\CategoryModel;
use App\Models\FarmModel;

use Auth;
use App\User as User;
use Lang;
use Image;
use DB;
use Input;
use File;

class HomeController extends FrontendBaseController {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
          
            $this->user = Auth::user();
            return $next($request);
        });
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request) {
		// pre(Auth::user());
		// Auth::logout();
		// \Session::flush();
		//pre((string) \Uuid::generate(5,microtime(), \Uuid::NS_DNS));
		$lang= $this->data['lang'];
		$this->data['bodyClass'] = 'home__page __index';

        $this->data['isHomePage'] = true;
        $this->data['pageTitle'] .= 'Home';
        $this->data['homePage'] = true;
        $this->data['current_menu'] = 'home';
        $this->data['current_page_slug'] = 'home';
        $this->data['current_parent_menu'] = 'home';
        $this->data['topParentAlias'] = 'home';
		$request->session()->put('search_keyword', '');
        $this->data['categoryList'] = CategoryModel::active()->get();

        $query = FarmModel::active();
        
        if(Auth::user()){
            $query->where('farm_master.fm_owner_id','!=',Auth::user()->id);
        }
        if(isset($_COOKIE['near_latitude']) && isset($_COOKIE['near_longitude'])){
            $near_latitude = $_COOKIE['near_latitude'];         
            $near_longitude = $_COOKIE['near_longitude'];
            $query->when($near_latitude, function ($q) use ($near_latitude,$near_longitude) {
                return $q->orderByRaw(
                    '(3959 * acos(cos(radians(' . floatval($near_latitude) . ')) * cos(radians(fm_latitude)) * cos(radians(fm_longitude) - radians(' . floatval($near_longitude) . ')) + sin(radians(' . intval($near_latitude) . ')) * sin(radians(fm_latitude)))) ASC'
                );
            });
        }
        

        $query->groupby('farm_master.fm_id');
        $this->data['farmList'] = $query->limit(6)->get();

        //$this->data['farmList'] = FarmModel::active()->limit(6)->get();
		
		return view('frontend.index',$this->data);
    }

    public function setlanguage($lang, Request $request) {

        if (!empty($lang)) {
            \Session::put('lang', $lang);
        }

        $redirectURL = request()->input('redirect_url');

		if(strpos($redirectURL,$request->getSchemeAndHttpHost()) !== 0){
			$redirectURL=null;
		}

        if ($this->data['websiteSettings']->disable_arabic == 2) {
            // \Session::put('lang', 'en');
            if (!empty($redirectURL)) {
                // $ll = \Session::get('lang');
                $redirectURL = str_replace('/ar/', '/en/', $redirectURL);
                return redirect()->to($redirectURL)->with('homeMessage', $this->custom_message('Arabic version will be coming soon.', 'success'));
                ;
            }
            return redirect()->to('/')->with('homeMessage', $this->custom_message('Arabic version will be coming soon.', 'success'));

        }

        if (!empty($redirectURL)) {

            if ($lang == 'ar') {
				 $redirectURL = str_replace(asset('/en'), asset('/ar/'), $redirectURL);

            } else {
				 $redirectURL = str_replace(asset('/ar/'), asset('/en/'), $redirectURL);

            }

            return redirect()->to($redirectURL);
        }

        return redirect()->to('/' . $lang);
    }

    public function page_not_found() {

        $this->data['bodyClass'] = ' inner__page domLoaded';
        return view('errors.404', $this->data);
    }

    public function service_not_available() {
        $this->data['bodyClass'] = ' inner__page domLoaded';
        return view('errors.503', $this->data);
    }
    
    public function how_it_works($lang) {
        
        return view('frontend.how_it_works',$this->data);
    }

}
