<?php
namespace App\Http\Controllers\API;

use App\User;

use App\Http\Controllers\FrontendBaseController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Cookie;
use File;
use DB;
use Lang;	
use Elasticsearch;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use App\Models\CategoryModel;
use App\Models\CountryModel;
use App\Models\AgricultureModel;
use App\Models\FacilityModel;
use App\Models\SoilModel;
use App\Models\IrrigationModel;
use App\Models\AgricultureTypeModel;
use Auth;


class ElasticSearchController extends FrontendBaseController {
		
		const INDEX_NAME = 'farmsgate_new';
		public $index_n = 'farmsgate_elastic_set';
		
		private function _getParams($indexName,$id){
			$params = [
				'index' => $indexName,
				//'id'    => '456',
				'body' => [
					'settings' => [ 
						'number_of_shards' => 1,
						'number_of_replicas' => 1,
						'analysis' => [ 
							'filter' => [
								'stemmer' => [
									'type' => 'stemmer',
									'language' => 'english',
								],
								'autocompleteFilter' => [
									'type' => 'shingle',
									'min_shingle_size' => 2,
									'max_shingle_size' => 4
								],
								'stopwords' => [
									'type' => 'stop',
									'stopwords' => ['_english_']
								]
							],
							'analyzer' => [
								'autocomplete' => [
									'type' => 'custom',
									'tokenizer' => 'standard',
									'filter' => ['lowercase', 'autocompleteFilter'],
									'char_filter' => ['html_strip']
								],
								'didYouMean' => [
									'type' => 'custom',
									'tokenizer' => 'standard',
									'filter' => ['lowercase'],
									'char_filter' => ['html_strip']
								],
								'default' => [
									'type' => 'custom',
									'tokenizer' => 'standard',
									'filter' => ['lowercase', 'stopwords','stemmer'],
									'char_filter' => ['html_strip']
								],
							]
						]
					],
					'mappings' => [ 
						'_source' => [
							'enabled' => true
						],
						'properties' => [
							'id' => [
								'type' => 'keyword'
							],
							'title' => [
								'type' => 'text',
								'analyzer' => 'autocomplete',
								'copy_to' => 'my_suggester'
							],
							'image' => [
								'type' => 'text'
							],
							'slug' => [
								'type' => 'text'
							],
							'farm_type' => [
								'type' => 'nested',
								'properties' => [
									'name' => [
										'type' => 'text',																		
										'copy_to' => 'my_suggester',
										'analyzer' => 'autocomplete',
									]																		
								],
								
							],
							'country' => [
								'type' => 'text',
								'analyzer' => 'autocomplete',
								'copy_to' => 'my_suggester'
							],
							'country_code' => [
								'type' => 'keyword'
							],
							'state' => [
								'type' => 'text',
								'analyzer' => 'autocomplete',
								'copy_to' => 'my_suggester'
							],
							'city' => [
								'type' => 'text',
								'analyzer' => 'autocomplete',
								'copy_to' => 'my_suggester'
							],
							'zip_code' => [
								'type' => 'text'
							],
							'geographic_coordinate' => [
								'type' => 'geo_point'
							],
							'total_area_in_acre' => [
								'type' => 'long'
							],
							'plot_count' => [
								'type' => 'integer'
							],
							'crops' => [
								'type' => 'nested',
								'include_in_parent' => true,
								'properties' => [
									'name' => [
										'type' => 'text',
										'copy_to' => 'my_suggester',
										'analyzer' => 'autocomplete',									
									],
									'farming_type' => [
										'type' => 'text',
										'copy_to' => 'my_suggester',
										'analyzer' => 'autocomplete',									
									],
									'season' => [
										'type' => 'text',
										'copy_to' => 'my_suggester',
										'analyzer' => 'autocomplete',									
									],
									'min_duration' => [
										'type' => 'integer',
									],
									'price_per_month' => [
										'type' => 'long',
									]								
								]
							],
							'facilities' => [
								'type' => 'nested',
								'include_in_parent' => true,
								'properties' => [
									'name' => [
										'type' => 'text',
										'copy_to' => 'my_suggester',
										'analyzer' => 'autocomplete',
									]								
								]
							],
							'area_unit' => [
								'type' => 'text'
							],
							'soil' => [
								'type' => 'text',
								'analyzer' => 'autocomplete',
								'copy_to' => 'my_suggester'
							],
							'irrigation' => [
								'type' => 'text',
								'analyzer' => 'autocomplete',
								'copy_to' => 'my_suggester'
							],
							'agriculture_type' => [
								'type' => 'text',
								'analyzer' => 'autocomplete',
								'copy_to' => 'my_suggester'
							],
							'weather_report' => [
								'type' => 'text',
								'analyzer' => 'autocomplete',
							],
							'soil_report' => [
								'type' => 'text',
								'analyzer' => 'autocomplete',
							],
							'annual_report' => [
								'type' => 'text',
								'analyzer' => 'autocomplete',
							],
							'highlights' => [
								'type' => 'nested',
								'properties' => [
									'name' => [
										'type' => 'text',
										'copy_to' => 'my_suggester',
										'analyzer' => 'autocomplete',
									]								
								]
							],
							'about' => [
								'type' => 'text',
								'analyzer' => 'autocomplete',
								'copy_to' => 'my_suggester'
							],
							'description' => [
								'type' => 'text',
								'analyzer' => 'autocomplete',
								'copy_to' => 'my_suggester'
							],
							'owner_code' => [
								'type' => 'keyword'
							],
							'owner_id' => [
								'type' => 'integer'
							],
							'owner_name' => [
								'type' => 'text',
								'copy_to' => 'my_suggester',
								'analyzer' => 'autocomplete',
							],
							'owner_image' => [
								'type' => 'text'
							],
							'available_from' => [
								'type' => 'date'
							],
							'available_to' => [
								'type' => 'date'
							],
							'farm_status' => [
								'type' => 'keyword'
							],
							'created_at' => [
								'type' => 'date',
								'format' => "yyyy-MM-dd HH:mm:ss||yyyy-MM-dd HH:mm:ss.SSS||yyyy-MM-dd'T'HH:mm:ssZZ",					
							],
							'updated_at' => [
								'type' => 'date',
								'format' => "yyyy-MM-dd HH:mm:ss||yyyy-MM-dd HH:mm:ss.SSS||yyyy-MM-dd'T'HH:mm:ssZZ",					
							],
							'my_suggester' => [
								'type' => 'completion',
								'analyzer' => 'simple',
								'preserve_separators' => 1,
								'preserve_position_increments' => 1,
								'max_input_length' => 50,
								'contexts' => [
									'name' => 'farm_status',
									'type' => 'category',
									'path' => 'farm_status'
								]	
							]
						]
					]
				]
			];
			
			return $params;
		}
		
		//THis function is like creating a database 
        public function create_index(Request $request){
			$indexName = $request->input('ind');
			$id = $request->input('id');
			
			if(empty($indexName)){
				return response()->json(['status'=>false,'message'=>'Index name is missing']);
			}
			
			$logger = new Logger('elastic_manager');
			$logger->pushHandler(new StreamHandler('/var/www/farmsgate/storage/logs/elasticsearch_manager.log', Logger::WARNING));

           
			try{
				
				$client =  Elasticsearch\ClientBuilder::create()
							->setLogger($logger)  
							->setHosts(["127.0.0.1:9200"])
							->setRetries(0)
							->build();
							
				/* $params = [
					'index' => $indexName
				]; */
				
				$params = $this->_getParams($indexName,$id);
				
				//pre($params);
				// Create the index
				$response = $client->indices()->create($params);
				
				//$logger->info('New index created:',$indexName.'###'.$response);
				//pre($response);
				return response()->json($response);
				
			}catch(\Exception $ex){
				//$logger->error('Index creation failed'.$ex->getMessage());
				pre(($ex->getMessage()));
				// pre('Exception occured'.json_decode($ex->getMessage()));
			}
			
        }
		
		//THis function is like deleting a database 
        public function delete_index(Request $request){
			$indexName = $request->input('ind');
			
			if(empty($indexName)){
				return response()->json(['status'=>false,'message'=>'Index name is missing']);
			}
			
			$logger = new Logger('elastic_manager');
			$logger->pushHandler(new StreamHandler('/var/www/farmsgate/storage/logs/elasticsearch_manager.log', Logger::WARNING));

           
			try{
				
				$client =  Elasticsearch\ClientBuilder::create()
							->setLogger($logger)  
							->setHosts(["127.0.0.1:9200"])
							->setRetries(0)
							->build();
							
				$params = [
					'index' => $indexName
				];

				// Create the index
				$response = $client->indices()->delete($params);
				// pre($response);
				$logger->info('New index deleted:',$indexName.'###'.$response);
				return response()->json($response);
				
			}catch(\Exception $ex){
				$logger->error('Index creation failed'.$ex->getMessage());
				// pre(json_decode($ex->getMessage()));
				// pre('Exception occured'.json_decode($ex->getMessage()));
			}
			
        }
							
		
		//THis function is to create a document
        public function get_index_setting(Request $request){
			$indexName = $request->input('ind');
			
			if(empty($indexName)){
				return response()->json(['status'=>false,'message'=>'Index name is missing']);
			}
			
			$logger = new Logger('elastic_manager');
			$logger->pushHandler(new StreamHandler('/var/www/farmsgate/storage/logs/elasticsearch_manager.log', Logger::WARNING));

           
			try{
				
				$client =  Elasticsearch\ClientBuilder::create()
							->setLogger($logger)  
							->setHosts(["127.0.0.1:9200"])
							->setRetries(0)
							->build();
							
				$params = [
					'index' => $indexName
				];

				// Create the index
				$response = $client->indices()->getSettings($params);
				pre($response);
				$logger->info('index settings:',$indexName.'###'.$response);
				return response()->json($response);
				
			}catch(\Exception $ex){
				$logger->error('Index creation failed'.$ex->getMessage());
				pre(json_decode($ex->getMessage()));
				// pre('Exception occured'.json_decode($ex->getMessage()));
			}
			
        }

		
		public function list_farms($search_key = null){
			$query = [
				/*'multi_match' => [
					'query' => $search_key,
					/*'fields' => ['title','farm_type.name','soil','country','country_code','state','city','zip_code','crops.name','facilities.name',
								'soil','irrigation','agriculture_type','about','description','owner_code','owner_name'],*/
					/*'type' => 'best_fields',
					"fuzziness" => "AUTO",
					"tie_breaker" => 0.6			
				],*/
				'bool' => [
					'must' =>[
								[
								'multi_match' => [
									'query' => $search_key,
									'type' => 'best_fields',
									"fuzziness" => "AUTO",
									"tie_breaker" => 0.6			
									],
								],
							/*[
								'nested'=>[
									'path'=>'crops',
									'query'=>[
										'bool'=>[
											'must'=>[
												'match'=>[
													'crops.name'=>'Potato',
												],
											],
										],
									],
								],
							],	*/	
																	
					],
					'filter'=>[
						'term'=>[
							'farm_status' => 1
						],
					],
					
				],
			];
			$params = [
				'index' => $this->index_n,
				'size' => 10000,				
				'body' => [
					//'min_score' => 2,
					'query' => $query,
					"sort"=>[
						["_score"=>"desc"]
					],

				]
				//'id'=>'e2d9d3f7-4540-5a0d-b2ff-ff5cd9dfbad4'
				//'id'=>'PCDsrZTwReatODv0SITtwA'
			];
			try{
				$logger = new Logger('elastic_manager');
				$logger->pushHandler(new StreamHandler('/var/www/farmsgate/storage/logs/elasticsearch_manager.log', Logger::WARNING));
				
				$client =  Elasticsearch\ClientBuilder::create()
							->setLogger($logger)  
							->setHosts(["127.0.0.1:9200"])
							->setRetries(0)
							->build();
							
				$response = $client->search($params);


				$farmsArray = [];
				// If there are any farm that match given search text "hits" fill their id's in array
				if($response['hits']['total'] > 0) {
					foreach ($response['hits']['hits'] as $hit) {
						$farmsArray[] = $hit['_id'];
					}
				}

				//pre(json_encode($response));
				//pre($farmsArray);
				return $farmsArray;
			}catch(\Exception $ex){
				$logger->error('Document creation failed'.$ex->getMessage());
				pre($ex->getMessage());
				// pre('Exception occured'.json_decode($ex->getMessage()));
			}

		}
		
		public function get_mappings(Request $request){
			$params = ['index' => $this->index_n];
			
			$logger = new Logger('elastic_manager');
			$logger->pushHandler(new StreamHandler('/var/www/farmsgate/storage/logs/elasticsearch_manager.log', Logger::WARNING));
			$client =  Elasticsearch\ClientBuilder::create()
							->setLogger($logger)  
							->setHosts(["127.0.0.1:9200"])
							->setRetries(0)
							->build();
			$response = $client->indices()->getMapping($params);
			pre($response);
		}
		
		public function add_farm(Request $request){
			// $indexName = $request->input('ind');
			$data = $request->all();


			$cat_array = array();
			if(!empty($data['farm_categories'])){
				foreach($data['farm_categories'] as $cat_id)
					{
						$cat_details = CategoryModel::find($cat_id);
						$cat_row['name'] = $cat_details->category_title;
						array_push($cat_array,$cat_row);
					}
					//$cat_array = json_encode($cat_array);	
			}
			$country = '';
			$country_code = '';
			if(!empty($data['country_id'])){
				$country_details = CountryModel::find($data['country_id']);
				$country = $country_details->country_name;
				$country_code = $country_details->iso;
			}

			$crop_array = array();
			if(!empty($data['crops_list'])){
				$crops_list = json_decode($data['crops_list']);
				foreach($crops_list as $crop)
				{
					$crop_details = AgricultureModel::find($crop->crop_id);
					$crop_row['name'] = $crop_details->agriculture_title;
					$crop_row['min_duration'] = $crop->crop_min_duration;
					$crop_row['price_per_month'] = 0;
					$crop_row['farming_type'] = $crop->crop_farm_type;
					$crop_row['season'] = $crop->crop_season;
					array_push($crop_array,$crop_row);
				}
				//$crop_array = json_encode($crop_array);
			}

			$facility_array = array();
			if(!empty($data['farm_facilities'])){				
				foreach($data['farm_facilities'] as $facility_id)
				{
					$facility_details = FacilityModel::find($facility_id);
					$facility_row['name'] = $facility_details->facility_title;
					array_push($facility_array,$facility_row);
				}
				//$facility_array = json_encode($facility_array);
			}
			$soil = '';
			if(!empty($data['soil_id'])){
				$soil_details = SoilModel::find($data['soil_id']);
				$soil = $soil_details->soil_title;
			}
			$irrigation = '';
			if(!empty($data['irrigation_id'])){
				$irrigation_details = IrrigationModel::find($data['irrigation_id']);
				$irrigation = $irrigation_details->irrigation_title;
			}

			$agriculture_type = '';
			if(!empty($data['agriculture_type_id'])){
				$agr_type_details = AgricultureTypeModel::find($data['agriculture_type_id']);
				$agriculture_type = $agr_type_details->agriculture_type_title;
			}
			//pre($data);
			
			$add_data = [
				//'index'=>'farmsgate_new',
				'index'=>$this->index_n,
				'id' => $data['uuid'],
				'body'  => [
						'doc' => [
								
							'title' => $data['farm_name'],
							'image' => $data['plot_map_image'],
							'slug' => $data['farm_name'],
							'farm_type' => $cat_array,		
							'country' => $country,
							'country_code' => $country_code,
							'state' => $data['state'],
							'city' => $data['city'],
							'zip_code' => $data['zip'],
							/*'geographic_coordinate' => [
								'lat' => $data['farm_latitude'], 
								'lon' => $data['farm_longitude']
							],*/
							'total_area_in_acre' => $data['total_area'],
							'plot_count' => $data['plots'],
							'crops' => $crop_array,
							'facilities' => $facility_array,
							'area_unit' => $data['area_unit'],
							'soil' => $soil,
							'irrigation' => $irrigation,
							'agriculture_type' => $agriculture_type,
							'weather_report' => '',
							'soil_report' => '',
							'annual_report' => '',							
							'about' => $data['farm_about'],
							'description' => $data['farm_policies'],
							'owner_code' => Auth::user()->user_code,
							'owner_name' => Auth::user()->user_full_name,
							'owner_image' => '',
							'available_from' => $data['available_start_date'],
							'available_to' => $data['available_end_date'],
							'owner_id' => Auth::user()->id,
							'farm_status' => $data['farm_status'],
						]
				]
			];
			if($data['farm_latitude']!='' && $data['farm_longitude']!=''){
				$add_data['body']['doc']['geographic_coordinate']['lat'] = $data['farm_latitude'];
				$add_data['body']['doc']['geographic_coordinate']['lon'] = $data['farm_longitude'];
			}
			
			//pre($data);
			//$data = json_encode($data);
			try{
				$logger = new Logger('elastic_manager');
				$logger->pushHandler(new StreamHandler('/var/www/farmsgate/storage/logs/elasticsearch_manager.log', Logger::WARNING));
			
				$client =  Elasticsearch\ClientBuilder::create()
							->setLogger($logger)  
							->setHosts(["127.0.0.1:9200"])
							->setRetries(0)
							->build();
							
								
				$params = $add_data;				

				// Create the index
				//$response = $client->indices()->create($params);
				$response = $client->update($params);
				//$response = $client->index($params);
				
				//$logger->info('New document created:',$indexName.'###'.$response);
				//pre($response);
				return response()->json($response);
				
			}catch(\Exception $ex){
				//$logger->error('Document creation failed'.$ex->getMessage());
				pre($ex->getMessage());
				// pre('Exception occured'.json_decode($ex->getMessage()));
			}
				
		}

		public function add_farm_index($uuid){
			
			$data = [
				'index'=>$this->index_n,
				'id' => $uuid,
				'body'  => [						
				]
			];
			
			try{
				$logger = new Logger('elastic_manager');
				$logger->pushHandler(new StreamHandler('/var/www/farmsgate/storage/logs/elasticsearch_manager.log', Logger::WARNING));
			
				$client =  Elasticsearch\ClientBuilder::create()
							->setLogger($logger)  
							->setHosts(["127.0.0.1:9200"])
							->setRetries(0)
							->build();
							
								
				$params = $data;				

				// Create the index
				//$response = $client->indices()->create($params);
				$response = $client->index($params);
				
				//$logger->info('New document created:',$indexName.'###'.$response);
				//pre($response);
				return response()->json($response);
				
			}catch(\Exception $ex){
				//$logger->error('Document creation failed'.$ex->getMessage());
				pre($ex->getMessage());
				// pre('Exception occured'.json_decode($ex->getMessage()));
			}
				
		}


		public function auto_complete(Request $request){
			$search_key = $request->input('search_key');
			if(empty($search_key))
			{
				$search_key = '';
			}
			$params = [
					'index' => $this->index_n,		
					'body' => [					
						"suggest" => [
							"autocomplete" => [
								"prefix" => $search_key,
								
								"completion" => [
									"field" => "my_suggester",
									"skip_duplicates" => true,
									"contexts" => [
										"farm_status" => 1
									],
									"fuzzy" => [
									"fuzziness" => "AUTO"	
								]
							]
						]
					]												
				]
			];
			try{
				$logger = new Logger('elastic_manager');
				$logger->pushHandler(new StreamHandler('/var/www/farmsgate/storage/logs/elasticsearch_manager.log', Logger::WARNING));
				
				$client =  Elasticsearch\ClientBuilder::create()
							->setLogger($logger)  
							->setHosts(["127.0.0.1:9200"])
							->setRetries(0)
							->build();
							
				$response = $client->search($params);
				return(json_encode($response));
			}catch(\Exception $ex){
				$logger->error('Failed'.$ex->getMessage());
				return($ex->getMessage());
			}

		}




		public function add_farm_admin(Request $request){
			// $indexName = $request->input('ind');
			$data = $request->all();


			$cat_array = array();
			if(!empty($data['farm_categories'])){
				foreach($data['farm_categories'] as $cat_id)
					{
						$cat_details = CategoryModel::find($cat_id);
						$cat_row['name'] = $cat_details->category_title;
						array_push($cat_array,$cat_row);
					}
					//$cat_array = json_encode($cat_array);	
			}
			$country = '';
			$country_code = '';
			if(!empty($data['fm_country_id'])){
				$country_details = CountryModel::find($data['fm_country_id']);
				$country = $country_details->country_name;
				$country_code = $country_details->iso;
			}

			$crop_array = array();
			if(!empty($data['farm_agricultures'])){
				$crops_list = $data['farm_agricultures'];
				foreach($crops_list as $crop_id)
				{
					$crop_details = AgricultureModel::find($crop_id);
					$crop_row['name'] = $crop_details->agriculture_title;
					$crop_row['min_duration'] = '';
					$crop_row['price_per_month'] = 0;
					$crop_row['farming_type'] = '';
					$crop_row['season'] ='';
					array_push($crop_array,$crop_row);
				}
				//$crop_array = json_encode($crop_array);
			}

			$facility_array = array();
			if(!empty($data['farm_facilities'])){				
				foreach($data['farm_facilities'] as $facility_id)
				{
					$facility_details = FacilityModel::find($facility_id);
					$facility_row['name'] = $facility_details->facility_title;
					array_push($facility_array,$facility_row);
				}
				//$facility_array = json_encode($facility_array);
			}
			if(!empty($data['fm_soil_id'])){
				$soil_details = SoilModel::find($data['fm_soil_id']);
				$soil = $soil_details->soil_title;
			}

			if(!empty($data['fm_irrigation_id'])){
				$irrigation_details = IrrigationModel::find($data['fm_irrigation_id']);
				$irrigation = $irrigation_details->irrigation_title;
			}

			if(!empty($data['fm_agriculture_type_id'])){
				$agr_type_details = AgricultureTypeModel::find($data['fm_agriculture_type_id']);
				$agriculture_type = $agr_type_details->agriculture_type_title;
			}
			//pre($data);
			$fm_latitude = 0.0;
			$fm_longitude = 0.0;
			if(!empty($data['fm_latitude'])){
				$fm_latitude = $data['fm_latitude'];
			}
			if(!empty($data['fm_longitude'])){
				$fm_longitude = $data['fm_longitude'];
			}
			$data = [
				'index'=>$this->index_n,
				'id' => $data['uuid'],
				'body'  => [
								
							'title' => $data['fm_title'],
							'image' => '',
							'slug' => $data['fm_title'],
							'farm_type' => $cat_array,		
							'country' => $country,
							'country_code' => $country_code,
							'state' => $data['fm_state_name'],
							'city' => $data['fm_city'],
							'zip_code' => $data['fm_zipcode'],
							'geographic_coordinate' => [
								'lat' => $fm_latitude, 
								'lon' => $fm_longitude
							],
							'total_area_in_acre' => $data['fm_area'],
							'plot_count' => $data['fm_plots_no'],
							'crops' => $crop_array,
							'facilities' => $facility_array,
							'area_unit' => $data['fm_area_unit'],
							'soil' => $soil,
							'irrigation' => $irrigation,
							'agriculture_type' => $agriculture_type,
							'weather_report' => '',
							'soil_report' => '',
							'annual_report' => '',							
							'about' => $data['fm_about_farm'],
							'description' => '',
							'owner_code' => Auth::user()->user_code,
							'owner_name' => Auth::user()->user_full_name,
							'owner_image' => '',
							'available_from' => $data['available_start_date'],
							'available_to' => $data['available_end_date'],
							'owner_id' => Auth::user()->id,
							'farm_status' => $data['farm_status'],					
				]
			];
			//pre($data);
			//$data = json_encode($data);
			try{
				$logger = new Logger('elastic_manager');
				$logger->pushHandler(new StreamHandler('/var/www/farmsgate/storage/logs/elasticsearch_manager.log', Logger::WARNING));
			
				$client =  Elasticsearch\ClientBuilder::create()
							->setLogger($logger)  
							->setHosts(["127.0.0.1:9200"])
							->setRetries(0)
							->build();
							
								
				$params = $data;				

				// Create the index
				//$response = $client->indices()->create($params);
				$response = $client->index($params);
				
				//$logger->info('New document created:',$indexName.'###'.$response);
				//pre($response);
				return response()->json($response);
				
			}catch(\Exception $ex){
				//$logger->error('Document creation failed'.$ex->getMessage());
				pre($ex->getMessage());
				// pre('Exception occured'.json_decode($ex->getMessage()));
			}
				
		}

		public function edit_farm_admin(Request $request){
			$data = $request->all();

			$cat_array = array();
			if(!empty($data['farm_categories'])){
				foreach($data['farm_categories'] as $cat_id)
					{
						$cat_details = CategoryModel::find($cat_id);
						$cat_row['name'] = $cat_details->category_title;
						array_push($cat_array,$cat_row);
					}
			}
			$country = '';
			$country_code = '';
			if(!empty($data['fm_country_id'])){
				$country_details = CountryModel::find($data['fm_country_id']);
				$country = $country_details->country_name;
				$country_code = $country_details->iso;
			}

			$crop_array = array();
			if(!empty($data['farm_agricultures'])){
				$crops_list = $data['farm_agricultures'];
				foreach($crops_list as $crop_id)
				{
					$crop_details = AgricultureModel::find($crop_id);
					$crop_row['name'] = $crop_details->agriculture_title;
					$crop_row['min_duration'] = '';
					$crop_row['price_per_month'] = 0;
					$crop_row['farming_type'] = '';
					$crop_row['season'] ='';
					array_push($crop_array,$crop_row);
				}
			}

			$facility_array = array();
			if(!empty($data['farm_facilities'])){				
				foreach($data['farm_facilities'] as $facility_id)
				{
					$facility_details = FacilityModel::find($facility_id);
					$facility_row['name'] = $facility_details->facility_title;
					array_push($facility_array,$facility_row);
				}
			}
			if(!empty($data['fm_soil_id'])){
				$soil_details = SoilModel::find($data['fm_soil_id']);
				$soil = $soil_details->soil_title;
			}

			if(!empty($data['fm_irrigation_id'])){
				$irrigation_details = IrrigationModel::find($data['fm_irrigation_id']);
				$irrigation = $irrigation_details->irrigation_title;
			}

			if(!empty($data['fm_agriculture_type_id'])){
				$agr_type_details = AgricultureTypeModel::find($data['fm_agriculture_type_id']);
				$agriculture_type = $agr_type_details->agriculture_type_title;
			}
			$fm_latitude = 0.0;
			$fm_longitude = 0.0;
			if(!empty($data['fm_latitude'])){
				$fm_latitude = $data['fm_latitude'];
			}
			if(!empty($data['fm_longitude'])){
				$fm_longitude = $data['fm_longitude'];
			}
			$data = [
				'index'=>$this->index_n,
				'id' => $data['uuid'],
				'body'  => [
					'doc' => [	
							'title' => $data['fm_title'],
							'image' => '',
							'slug' => $data['fm_title'],
							'farm_type' => $cat_array,		
							'country' => $country,
							'country_code' => $country_code,
							'state' => $data['fm_state_name'],
							'city' => $data['fm_city'],
							'zip_code' => $data['fm_zipcode'],
							'geographic_coordinate' => [
								'lat' => $fm_latitude, 
								'lon' => $fm_longitude
							],
							'total_area_in_acre' => $data['fm_area'],
							'plot_count' => $data['fm_plots_no'],
							'crops' => $crop_array,
							'facilities' => $facility_array,
							'area_unit' => $data['fm_area_unit'],
							'soil' => $soil,
							'irrigation' => $irrigation,
							'agriculture_type' => $agriculture_type,
							'weather_report' => '',
							'soil_report' => '',
							'annual_report' => '',							
							'about' => $data['fm_about_farm'],
							'description' => '',
							//'owner_code' => Auth::user()->user_code,
							//'owner_name' => Auth::user()->user_full_name,
							//'owner_image' => '',
							'available_from' => $data['available_start_date'],
							'available_to' => $data['available_end_date'],	
							'farm_status' => $data['farm_status'],
					]				
				]
			];
			try{
				$logger = new Logger('elastic_manager');
				$logger->pushHandler(new StreamHandler('/var/www/farmsgate/storage/logs/elasticsearch_manager.log', Logger::WARNING));
			
				$client =  Elasticsearch\ClientBuilder::create()
							->setLogger($logger)  
							->setHosts(["127.0.0.1:9200"])
							->setRetries(0)
							->build();
							
								
				$params = $data;				

				// Create the index
				//$response = $client->indices()->create($params);
				$response = $client->update($params);
				
				return response()->json($response);
				
			}catch(\Exception $ex){
				//$logger->error('Document creation failed'.$ex->getMessage());
				pre($ex->getMessage());
				// pre('Exception occured'.json_decode($ex->getMessage()));
			}
				
		}

		public function change_farm_status($uuid,$currentStatus){
			$add_data = [
				'index'=>$this->index_n,
				'id' => $uuid,
				'body'  => [
						'doc' => [															
							'farm_status' => $currentStatus,
						]
				]
			];
						
			try{
				$logger = new Logger('elastic_manager');
				$logger->pushHandler(new StreamHandler('/var/www/farmsgate/storage/logs/elasticsearch_manager.log', Logger::WARNING));
			
				$client =  Elasticsearch\ClientBuilder::create()
							->setLogger($logger)  
							->setHosts(["127.0.0.1:9200"])
							->setRetries(0)
							->build();
							
								
				$params = $add_data;				

				$response = $client->update($params);
				
				return response()->json($response);
				
			}catch(\Exception $ex){
				pre($ex->getMessage());
			}
				
		}
}