<?php
namespace App\Http\Controllers\API;

use App\User;

use App\Http\Controllers\FrontendBaseController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Cookie;
use File;
use DB;
use Lang;

class APIController extends FrontendBaseController {

        public function test(){
            $arr = User::get()->toArray();
            return response()->json($arr);
        }
}