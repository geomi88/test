<?php
namespace App\Http\Controllers\API;

use App\User;

use App\Http\Controllers\FrontendBaseController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Cookie;
use File;
use DB;
use Lang;	
use Elasticsearch;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;


class SearchController extends FrontendBaseController {

        public function index(Request $request){
			
			$logger = new Logger('elastic');
			$logger->pushHandler(new StreamHandler('/var/www/farmsgate/storage/logs/elasticsearch.log', Logger::WARNING));

            // die('asd');
			try{
				$client = Elasticsearch\ClientBuilder::create()
				->setLogger($logger)  
				->setHosts(["127.0.0.1:9200"])
				->setRetries(0)
				->build();
				$params = [
					'index' => 'test',
					'id'    => 1
				];
				$response = $client->get($params);
				// echo $response;
				// exit();     
				
				// pre(json_decode($response));
			}catch(\Exception $ex){
				pre('Exception occured'.$ex->getMessage());
			}
			
        }
}