<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use Cookie;
use App\Models\CountryModel;
use App\Models\Admodels\PostModel;
use App\Models\Admodels\EventModel;
use App\Models\Admodels\HubModel;
use App\Models\Admodels\MenuManagerModel;
use Illuminate\Support\Facades\View;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Validation\Validator;
use CustomCalendar\Calendar;

use Auth;
use App\User as User;
use Lang;
use Image;
use DB;
use Input;
use File;
use App\Models\FarmModel;
use App\Models\CategoryModel;
use App\Models\AgricultureModel;
use App\Models\FacilityModel;
use App\Models\SoilModel;
use App\Models\IrrigationModel;
use App\Models\AgricultureTypeModel;
use App\Models\FarmCrops;
use App\Models\Admodels\GalleryModel;
use App\Models\FarmSubscriptionCropModel;
use App\Models\FarmSubscriptionModel;
use App\Models\FarmRatingModel;
use App\Models\UserFarmBookmarkModel;
use App\Models\FarmAvailabilityNotificationModel;
use App\Models\UserNotificationModel;
use Mail;

class FarmController extends ApiBaseController {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
          
            $this->user = Auth::user();
            return $next($request);
        });
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */


    public function add($uuid='',Request $request) {
        
		if(empty($uuid)){
           $uuid = (string) \Uuid::generate(5,microtime(), \Uuid::NS_DNS);
           return redirect()->to('farm-signup/' . $uuid);
        }
		
		
            if($request->ajax()){
              $data = $request->all();
                            
              $farmDetails = FarmModel::firstOrCreate (array('fm_uuid' => $data['uuid']));  
              $farmDetails->fm_title = $data['farm_name'];
              $farmDetails->fm_country_id = $data['country_id'];
              $farmDetails->fm_state_name = $data['state'];
              $farmDetails->fm_city = $data['city'];
              $farmDetails->fm_zipcode = $data['zip'];
              $farmDetails->fm_area = $data['total_area'];
              $farmDetails->fm_area_unit = $data['area_unit'];
              $farmDetails->fm_plots_no = $data['plots'];
              $farmDetails->fm_soil_id = $data['soil_id'];
              $farmDetails->fm_irrigation_id = $data['irrigation_id'];
              $farmDetails->fm_agriculture_type_id = $data['agriculture_type_id'];
              $farmDetails->fm_farm_highlights = $data['farm_highlights'];
              $farmDetails->fm_about_farm = $data['farm_about'];
              $farmDetails->fm_house_description = $data['farm_house_description'];
              $farmDetails->fm_start_date = $data['available_start_date'];
              $farmDetails->fm_end_date = $data['available_end_date'];
              $farmDetails->fm_created_by = 1;
              $farmDetails->fm_updated_by = 1;
              $farmDetails->fm_status = 2;
                                                                                          
                /*$plotFile = $request->file('plot_map');

				if($plotFile){
					$filePath = 'public/uploads/farm/plot/';
					list($fileName, $fileNameWithPath) = $this->store_file('fm_plot_map', $filePath);
					$farmDetails->fm_plot_map = $fileName;
				}*/
                /*$weatherFile = $request->file('weather_report');

				if($weatherFile){
					$filePath = 'public/uploads/farm/weather_report/';
					list($fileName, $fileNameWithPath) = $this->store_file('weather_report', $filePath);
					$farmDetails->fm_weather_report = $fileName;
				}*/
                
                $farmDetails->fm_plot_map = $data['plot_map_image'];
                $farmDetails->fm_weather_report = $data['weather_report_image'];
                $farmDetails->fm_soil_report = $data['soil_report_image'];
                $farmDetails->fm_annual_report = $data['annual_report_image'];
                $farmDetails->fm_latitude = $data['farm_latitude'];
                $farmDetails->fm_longitude = $data['farm_longitude'];
                $farmDetails->fm_price = $data['farm_price'];
                $farmDetails->fm_main_image = $data['farm_main_image'];
                
                /*if((!empty($data['country_id']) || !empty($data['state']) || !empty($data['city']) || !empty($data['zip']))
                  )
                {
                    $country_details = CountryModel::find($data['country_id']);

                    $address = $data['city'].','.$data['state'].','.$country_details->country_name.','.$data['zip'];
                    $curl = curl_init();

                    curl_setopt($curl, CURLOPT_URL, 'https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyD7dxAhKeEHs4QpOPhGqOSwl2NFfW9rqtk&address=' . rawurlencode($address));

                    curl_setopt ($curl, CURLOPT_RETURNTRANSFER, 1);

                    $json = curl_exec($curl);
                    
                    $co_ordinates = json_decode($json);
                    
                    $farmDetails->fm_latitude = $co_ordinates->results[0]->geometry->location->lat;
                    $farmDetails->fm_longitude = $co_ordinates->results[0]->geometry->location->lng;
                }*/
                    
                    
                $farmDetails->save();
                
                if(!empty($data['farm_categories'])){
                    $farmDetails->categories()->sync($data['farm_categories']);
                }
                                
                if(!empty($data['farm_facilities'])){
                    $farmDetails->facilities()->sync($data['farm_facilities']);
                }
                
                
                $crops_list = json_decode($data['crops_list']);
                foreach($crops_list as $crop)
                {
                    $farm_crops_obj = FarmCrops::firstOrCreate (array('farm_id' => $farmDetails->fm_id,'agriculture_id' => $crop->crop_id));
                    /*$crop_data['farm_id'] = $farmDetails->fm_id;
                    $crop_data['agriculture_id'] = $crop->crop_id;
                    $crop_data['fc_min_duration'] = $crop->crop_min_duration;
                    $crop_data['fc_season'] = $crop->crop_season;
                    $crop_data['fc_farm_type'] = $crop->crop_farm_type;
                    $crop_data['fc_price'] = $crop->crop_price;
                    
                    FarmCrops::create($crop_data);*/
                    $farm_crops_obj->farm_id = $farmDetails->fm_id;
                    $farm_crops_obj->agriculture_id = $crop->crop_id;
                    $farm_crops_obj->fc_min_duration = $crop->crop_min_duration;
                    $farm_crops_obj->fc_season = $crop->crop_season;
                    $farm_crops_obj->fc_farm_type = $crop->crop_farm_type;
                    $farm_crops_obj->fc_price = $crop->crop_price;
                    $farm_crops_obj->save();
                    
                }
                
                $gallery_list = json_decode($data['gallery_list']);
                foreach($gallery_list as $gallery)
                {
                    
                    
                    $insertDatas = array(
										'gallery_farm_id' => $farmDetails->fm_id,
										'gallery_image_name' => $gallery->gal_img,
										'gallery_image_type' => 1,
										'gallery_image_date' => date('Y-m-d H:i:s'),
										'gallery_image_status' => 1
									);
					DB::table('gallery_images')->insertGetId($insertDatas);
                }
                
              $arr = array('status' => true);
              return Response()->json($arr);
            }
      
        $lang= $this->data['lang'];
        $this->data['categoryList'] = CategoryModel::active()->get();
        $this->data['countryList'] = CountryModel::active()->get();
        $this->data['agricultureList'] = AgricultureModel::active()->get();
        $this->data['facilityList'] = FacilityModel::active()->get();
        $this->data['soilList'] = SoilModel::active()->get();
        $this->data['irrigationList'] = IrrigationModel::active()->get();
        $this->data['agricultureTypeList'] = AgricultureTypeModel::active()->get();
        $this->data['uuid'] = $uuid;
		// pre('asd');
		return view('frontend.farm.add',$this->data);
    }

    public function search(Request $request) {
        $this->data['isSearchPage'] = true;
        $search_location = [];
        $search_price = [];
        $search_crop = [];
        $search_facility = [];
        
        $search_key = Input::get('search_key');
        $ft = Input::get('ft');
        $request->session()->put('search_keyword', $search_key);
        
        $search_location = (is_array(Input::get('search_location')))?Input::get('search_location'):[];
        $search_price = (is_array(Input::get('search_price')))?Input::get('search_price'):[];
        $search_crop = (is_array(Input::get('search_crop')))?Input::get('search_crop'):[];
        $search_facility = (is_array(Input::get('search_facility')))?Input::get('search_facility'):[];

        //$request->flashOnly('search_key');
        $request->flash();

        $query = FarmModel::active();
             /*if(!empty($search_key)){
                 $query->leftJoin('country', 'country.country_id', '=', 'farm_master.fm_country_id');
                 $query->leftJoin('farm_crops', 'farm_crops.farm_id', '=', 'farm_master.fm_id');
                 $query->leftJoin('agriculture_master', 'agriculture_master.agriculture_id', '=', 'farm_crops.agriculture_id');
                 $query->where(function ($q) use ($search_key) {
                     $q = $q->where('fm_title', 'LIKE', "%$search_key%")
                            ->orWhere('country.country_name','LIKE', "%$search_key%")
                            ->orWhere('farm_master.fm_state_name','LIKE', "%$search_key%")
                            ->orWhere('farm_master.fm_city','LIKE', "%$search_key%")
                            ->orWhere('agriculture_master.agriculture_title','LIKE', "%$search_key%");
                    return $q;
                });
             }*/


           /* if(!empty($search_key)){
                $query->whereHas('crops',function($q) use($search_key) {
                    return $q->orWhere('agriculture_master.agriculture_title','LIKE', "%$search_key%");                                  
                });
            }*/
            if(!empty($search_key)){
                $farms_array = app('App\Http\Controllers\API\ElasticSearchController')->list_farms($search_key);
                if(is_array($farms_array)){
                    $query->whereIn('fm_uuid', $farms_array);
                }
            }


            if(!empty($ft)){
            $query->whereHas('categories',function($q) use($ft) {               
                return $q->where('category_master.category_slug', $ft);                              
            });
            }
            
            $query->when($search_location, function ($q) use ($search_location) {
                return $q->whereIn('fm_state_name', $search_location);
            });
            
            $query->when($search_price, function ($q) use ($search_price) {
                return $q->where('fm_price', $search_price);
            });
            
            if(!empty($search_crop)){
            $query->whereHas('crops',function($q) use($search_crop) {
               
                return $q->whereIn('agriculture_master.agriculture_id', $search_crop);
                              
            });
            }
            
            if(!empty($search_facility))
            {
            $query->whereHas('facilities',function($q) use($search_facility) {
               
                return $q->whereIn('facility_master.facility_id', $search_facility);
                              
            });
            }
            if(!empty($farms_array)){
                $farm_uuids = '';
                foreach($farms_array as $farm_uuid)
                {
                    $farm_uuids = $farm_uuids."'".$farm_uuid."',";
                }
                $farm_uuids = rtrim($farm_uuids,",");
                //$farm_uuids = implode(",",$farms_array);
                $query->orderbyRaw("FIELD(fm_uuid,$farm_uuids)");
            }
            if(!empty(Input::get('near_latitude')) && !empty(Input::get('near_longitude')))
            {
                $near_latitude = Input::get('near_latitude');
                $near_longitude = Input::get('near_longitude');
                $query->when($near_latitude, function ($q) use ($near_latitude,$near_longitude) {
                    return $q->orderByRaw(
                        '(3959 * acos(cos(radians(' . floatval($near_latitude) . ')) * cos(radians(fm_latitude)) * cos(radians(fm_longitude) - radians(' . floatval($near_longitude) . ')) + sin(radians(' . intval($near_latitude) . ')) * sin(radians(fm_latitude)))) ASC'
                    );
                });
            }
            $query->groupby('farm_master.fm_id');
            //$query->get();
            //echo $query->toSql();die();
            $all_farms = $query->get();

        $paginate_count = 6;
        $iPad = stripos($request->header('User-Agent'),"iPad");
        if($iPad){
            $paginate_count = 9;
        }
        $farms = $query->paginate($paginate_count);
        
        $map_array = array();
        
        foreach($farms as $farm)
        {
            $row['fm_title'] = $farm->fm_title;
            $row['fm_owner_id'] = $farm->fm_owner_id;
            $row['fm_slug'] = $farm->fm_slug;
            $row['fm_latitude'] = $farm->fm_latitude;
            $row['fm_longitude'] = $farm->fm_longitude;
            $row['fm_area'] = $farm->fm_area;
            $row['fm_area_unit'] = $farm->fm_area_unit;
            $row['fm_state_name'] = $farm->fm_state_name;
            
            
            
            $row['fm_price'] = $farm->fm_price;
            $row['fm_main_image'] = get_farm_image($farm->fm_main_image);
            $row['profile_image'] = get_profile_image($farm->owner->user_avatar);
            $row['profile_name'] = $farm->owner->user_full_name;
            $farm->fm_main_image = get_farm_image($farm->fm_main_image);
            $farm->owner_name= $farm->owner->user_full_name;
            $farm->owner_avatar= get_profile_image($farm->owner->user_avatar);
            $crops = $farm->crops;
            $crop_row = array();
            foreach($crops as $crop)
            {                
                $crop_row[$crop->agriculture_title] =  asset('storage/uploads/agriculture/icon/'.$crop->agriculture_icon);
                $crop->agriculture_image = asset('storage/uploads/agriculture/icon/'.$crop->agriculture_icon);
            }
            
            $row['crops'] = $crop_row;
            
            /*if($farm->fm_state_name != '' || $farm->fm_state_name != null)
            {
                
                if(empty(array_search($farm->fm_state_name, $states)))
                {
                    $state_row['fm_id'] = $farm->fm_id;
                    $state_row['fm_state_name'] = $farm->fm_state_name;
                    array_push($states,$state_row);
                }
            }*/
            array_push($map_array,$row);
        }
        
        
        
        $querystringArray = Input::only(['search_key','search_location','search_price','search_crop','search_facility']);
        $farms->appends($querystringArray);
        
        
        $states = array();        
        foreach ($all_farms->unique('fm_state_name') as $state){
            if(!empty($state->fm_state_name) && $state->fm_state_name!=null){
            $state_row['fm_id'] = $state->fm_id;
            $state_row['fm_state_name'] = $state->fm_state_name;
            $state_row['checked'] = '';
            if(in_array($state->fm_state_name,$search_location))
            {
                $state_row['checked'] = "checked";
            }
            array_push($states,$state_row);
            }
        }
        
        $prices = array();
        foreach ($all_farms->unique('fm_price') as $price){
            if(!empty($price->fm_price) && $price->fm_price!=null){
            $price_row['fm_id'] = $price->fm_id;
            $price_row['fm_price'] = $price->fm_price;
            $price_row['checked'] = '';
            if(in_array($price->fm_price,$search_price))
            {
                $price_row['checked'] = "checked";
            }
            array_push($prices,$price_row);
            }
        }
        
        $crops=[]; 
        $temp_crops = array();                
        foreach($all_farms as $farm){
           foreach ($farm->crops->unique('agriculture_id') as $crop){
               if(!empty($crop->agriculture_title)){
                   
                      if(!in_array($crop->agriculture_id,$temp_crops)) {
                       $crop_row['agriculture_id'] = $crop->agriculture_id;
                       $crop_row['agriculture_title'] = $crop->agriculture_title;
                       $crop_row['checked'] = '';
                        if(in_array($crop->agriculture_id,$search_crop))
                            {
                                $crop_row['checked'] = "checked";
                            }
                       array_push($crops,$crop_row);
                       $temp_crops[] = $crop->agriculture_id;
                   }
               }                      
           }

          }  
        
        $facilities=[]; 
        $temp_facilities = array();                
        foreach($all_farms as $farm){
           foreach ($farm->facilities->unique('facility_id') as $facility){
               if(!empty($facility->facility_title)){
                   
                      if(!in_array($facility->facility_id,$temp_facilities)) {
                       $facility_row['facility_id'] = $facility->facility_id;
                       $facility_row['facility_title'] = $facility->facility_title;
                       $facility_row['checked'] = '';
                        if(in_array($facility->facility_id,$search_facility))
                            {
                                $facility_row['checked'] = "checked";
                            }
                       array_push($facilities,$facility_row);
                       $temp_facilities[] = $facility->facility_id;
                   }
               }                      
           }

        }
        
        $user_data['profile_image'] = htmlAsset('images/person01.jpg');

        $data['search_key'] = $search_key;
        $data['ft'] = $ft;
        $data['farms'] = $farms;
        $data['user_data'] = $user_data;
        $data['map_array'] = $map_array;
        $data['states'] = $states;
        $data['prices'] = $prices;
        $data['crops'] = $crops;
        $data['facilities'] = $facilities;
        return Response($data);
    }
    public function subscribe(Request $request) {
        try{
            $inputs = [
                'plots_no' => $request->input('plots_no'),
                'subs_duration' => $request->input('subs_duration'),
                'farm_type' => $request->input('farm_type'),
                'start_date' => $request->input('start_date'),
                'subs_crop' => $request->input('subs_crop'),
            ];
            $rules = [
                'plots_no' =>'required',
                'subs_duration' =>'required',
                'farm_type' =>'required',
                'start_date' =>'required',
                'subs_crop' => 'min:1',
            ];
            $messages = [
                'plots_no.required' => trans('messages.plots_no_required'),
                'subs_duration.required' => trans('messages.subs_duration_required'),
                'farm_type.required' => trans('messages.farm_type_required'),
                'start_date.required' => trans('messages.start_date_required'),
                'subs_crop.min' => trans('messages.atleast_one_crop_required'),
            ];
            
            $validator = \Validator::make($inputs,$rules,$messages);
            
            if($validator->fails()){
                $userMessage = '<ul style="list-style:none" class="alert alert-danger">';
                $messages = $validator->messages();
                foreach ($messages->all() as $message) {
                    $userMessage .= '<li>' . $message . '</li>';
                }
                $userMessage .= '</ul>';
                $response_data['userMessage'] = $userMessage;
                $response_data['status'] = false;
                return Response($response_data);
            }else{
                
                $farmDetails = FarmModel::where('fm_id','=',Input::get('farm_id'))->first();

                //$subscription_details = FarmSubscriptionModel::select(DB::raw('sum(fs_number_of_plots) as booked_plots_no'))->where('fs_start_date','>=',$farmDetails->fm_start_date)->where('fs_farm_id','=',Input::get('farm_id'))->first();
                $subscription_details = FarmSubscriptionModel::select(DB::raw('sum(fs_number_of_plots) as booked_plots_no'))->whereRaw("DATE_ADD(fs_start_date, INTERVAL fs_duration_months MONTH) >= NOW()")->where('fs_farm_id','=',$farmDetails->fm_id)->first();
                $plots_available = $farmDetails->fm_plots_no - $subscription_details->booked_plots_no;
                if($plots_available < 1){

                    $response_data['userMessage'] = trans('messages.farm_not_available_to_subscribe');
                    $response_data['status'] = false;
                    $response_data['redirectURL'] = true;
                    return Response($response_data);
                }
                if($plots_available < Input::get('plots_no')){

                    $response_data['userMessage'] = trans('messages.plot_count_not_available_to_subscribe');
                    $response_data['status'] = false;
                    $response_data['redirectURL'] = true;
                    return Response($response_data);
                }

                DB::beginTransaction();
                $subs_crop = (is_array(Input::get('subs_crop')))?Input::get('subs_crop'):[];
                    
                $subscription = new FarmSubscriptionModel;
                $subscription->fs_user_id = Auth::user()->id;
                $subscription->fs_farm_id = Input::get('farm_id');
                $subscription->fs_number_of_plots = Input::get('plots_no');
                $subscription->fs_duration_months = Input::get('subs_duration');
                $subscription->fs_total_amount = Input::get('total_price');
                $subscription->fs_farm_type = Input::get('farm_type');
                $subscription->fs_start_date = Input::get('start_date');
                
                $subscription->fs_change_loc_status = Input::get('change_loc_status');
                $subscription->fs_delivery_full_name = Input::get('delivery_full_name');
                $subscription->fs_ph_no = Input::get('delivery_ph_no');
                $subscription->fs_delivery_address = Input::get('delivery_address');
                $subscription->fs_delivery_city = Input::get('delivery_city');
                $subscription->fs_delivery_country_id = Input::get('delivery_country_id');
                $subscription->fs_delivery_zip = Input::get('delivery_zip');
                if( Input::get('home_delivery') == 1) {
                    $subscription->fs_home_delivery = 1;
                }

                $subscription->fs_created_by = Auth::user()->id;
                $subscription->fs_updated_by = Auth::user()->id;
                $subscription->save();
                
                $subscription->crops()->sync($subs_crop);

                $farmDetails = FarmModel::where('fm_id',Input::get('farm_id'))->first();
                $to_user_id = $farmDetails->fm_owner_id;

                $un_model = new UserNotificationModel;
                $un_model->un_to_user_id = $to_user_id;
                $un_model->un_from_user_id = Auth::user()->id;
                $un_model->un_farm_id = Input::get('farm_id');
                $un_model->un_type = 1;
                $un_model->save();


                $data['status']=true;
                $data['redirectURL'] = true;
                DB::commit();
            }
            return Response($data);
        }catch(\Exception $e){
            DB::rollBack();            
            $response_data['userMessage'] = trans('messages.some_issue');
            $response_data['status'] = false;
            $response_data['redirectURL'] = true;
            return Response($response_data);
        }
    }
    
    public function addreview(Request $request) {
                        
        /*$rating = new FarmRatingModel;
        $rating->fr_user_id = Auth::user()->id;
        $rating->fr_farm_id = Input::get('farm_id');
        $rating->fr_comment = Input::get('comment');
        $rating->fr_rating = Input::get('rating');
        
        $rating->save(); */
        
        
        $rating = FarmRatingModel::updateOrCreate(
            ['fr_user_id' => Auth::user()->id, 'fr_farm_id' => Input::get('farm_id')],
            ['fr_comment' => Input::get('comment'), 'fr_rating' => Input::get('rating')]
        );

        $farmDetails = FarmModel::where('fm_id',Input::get('farm_id'))->first();
        $to_user_id = $farmDetails->fm_owner_id;

        $un_model = new UserNotificationModel;
        $un_model->un_to_user_id = $to_user_id;
        $un_model->un_from_user_id = Auth::user()->id;
        $un_model->un_farm_id = Input::get('farm_id');
        $un_model->un_type = 3;
        $un_model->save();

        $data['status']=true;   
        $data['redirectURL'] = true;   
        return Response($data);
    }
    
    public function addfav(Request $request) {
        
        $user_id = Auth::user()->id;
        $farm_id = Input::get('farm_id');
        $result = UserFarmBookmarkModel::where('ufb_user_id', $user_id)->where('ufb_farm_id', $farm_id)->first();
        
        $farmDetails = FarmModel::where('fm_id', $farm_id)->first();
        $to_user_id = $farmDetails->fm_owner_id;

        if(!empty($result)){
            $result->delete();
            UserNotificationModel::where(['un_from_user_id'=>$user_id,'un_to_user_id'=>$to_user_id,'un_farm_id'=>$farm_id,'un_type'=>2])->update(['un_status'=>2]);
        }
        else{
            $favorite = new UserFarmBookmarkModel;
            $favorite->ufb_user_id = $user_id;
            $favorite->ufb_farm_id = $farm_id;        
            $favorite->save();

            $un_model = new UserNotificationModel;
            $un_model->un_to_user_id = $to_user_id;
            $un_model->un_from_user_id = $user_id;
            $un_model->un_farm_id = $farm_id;
            $un_model->un_type = 2;
            $un_model->save();
        }        
        $data['status']=true;   
        return Response($data);
    }
    
    public function reviews(Request $request) {
        
        $farm_id = Input::get('farm_id');
        $reviews = FarmRatingModel::where('fr_farm_id', $farm_id)->orderby('fr_created_at','DESC')->paginate(4);
        
        foreach($reviews as $review)
        {            
            $review->reviewer_name = $review->owner->user_full_name;
            $review->reviewer_avatar = get_profile_image($review->owner->user_avatar);
            $review->created_at = date_convert($review->fr_created_at);
            //$review->fr_created_at = date_convert($review->fr_created_at);
            $review->fr_rating = number_format($review->fr_rating, 1, '.', '');
        }
        $data['status']=true;            
        $data['reviews']=$reviews;
        return Response($data);
    }

    public function availability_notify(Request $request) {
                        
        $fan_model = new FarmAvailabilityNotificationModel;
        $fan_model->fan_user_id = Auth::user()->id;
        $fan_model->fan_farm_id = Input::get('farm_id');
        
        $fan_model->save();
        $data['status']=true;   
        $data['redirectURL'] = true;   
        return Response($data);
    }

    public function sendSubscriptionOverMail(Request $request) {
        

        $subscriptions = FarmSubscriptionModel::whereRaw('NOW() > DATE_ADD(fs_start_date, INTERVAL fs_duration_months MONTH)')
                        ->where('fs_over_mail_status',0)
                        ->get();
        //pre($subscriptions);
        foreach($subscriptions as $subscription){
            $review_code = \Hash::make(microtime());
            $user_id = $subscription->fs_user_id;
            $farm_id = $subscription->fs_farm_id;
            $Link = asset("en/addreview/$user_id/$review_code");
                
            $farm_details = FarmModel::find($farm_id);
            
            $user_details = User::find($user_id);
            $email = $user_details->user_email;

            $data = array(
                'farm_name' => $farm_details->fm_title,
                'user_name' => $user_details->user_full_name,
                'Link'=>$Link,
            );

            $emailTemplate='frontend.email_template.subscription_over';

            
        
        
            Mail::send($emailTemplate,$data,function($message) use ( $email ){
                $message->to($email)
                ->subject('FarmsGate Subscription Over');
            });
            if(!Mail::failures()){
                $subscription->fs_over_mail_status = 1;
                $subscription->fs_review_code = $review_code;
                $subscription->save();
            }
            //pre(Mail::failures());
        }
    }

    public function get_plots_number(Request $request) {

        $farm_id = Input::get('plot_farm_id');
        $selected_date = Input::get('selected_date');
        $farmDetails = FarmModel::where('fm_id','=',$farm_id)->first();
        $plots_available = 0;
        if($farmDetails->fm_plots_no){
            $plots_available = $farmDetails->fm_plots_no;
        }
               
        $subscription_details = FarmSubscriptionModel::select(DB::raw('sum(fs_number_of_plots) as booked_plots_no'))->whereRaw("DATE_ADD(fs_start_date, INTERVAL fs_duration_months MONTH) > '$selected_date'")->where('fs_farm_id','=',$farmDetails->fm_id)->first();
        $plots_available = $plots_available - $subscription_details->booked_plots_no;
        
        $data['status']=true;   
        $data['date_plot_no'] = $plots_available;
        return Response($data);
    }

    public function sendFarmAvailableNotification(Request $request) {
                
        $fan_notifications = FarmAvailabilityNotificationModel::where('fan_status',0)->get();
        foreach($fan_notifications as $fan_notification){

            $user_id = $fan_notification->fan_user_id;
            $farm_id = $fan_notification->fan_farm_id;

            $farmDetails = FarmModel::find($farm_id);

            $plots_available = 0;
            if(date('Y-m-d') > $farmDetails->fm_end_date ){
                $plots_available = 0;
            }
            else{
                if($farmDetails->fm_plots_no > 0){
                    $subscription_details = FarmSubscriptionModel::select(DB::raw('sum(fs_number_of_plots) as booked_plots_no'))->whereRaw("DATE_ADD(fs_start_date, INTERVAL fs_duration_months MONTH) >= NOW()")->where('fs_farm_id','=',$farmDetails->fm_id)->first();
                    $plots_available = $farmDetails->fm_plots_no - $subscription_details->booked_plots_no;
                }
            }
            
            
            if($plots_available > 0){
                $Link = asset("en/farm-notify/$user_id/$farmDetails->fm_slug");                            
            
                $user_details = User::find($user_id);
                $email = $user_details->user_email;

                $data = array(
                    'farm_name' => $farmDetails->fm_title,
                    'user_name' => $user_details->user_full_name,
                    'Link'=>$Link,
                );

                $emailTemplate='frontend.email_template.farm_availablity_notification';
                                
                Mail::send($emailTemplate,$data,function($message) use ( $email ){
                    $message->to($email)
                    ->subject('Farm Availability');
                });
                if(!Mail::failures()){
                    $fan_notification->fan_status = 1;
                    $fan_notification->save();
                }
            }
            
        }
    }

    public function disablefarm(Request $request) {
        
        $farm_id = Input::get('farm_id');
        $disable_status = Input::get('disable_status');
        $farmDetails = FarmModel::where('fm_id', $farm_id)->update(array('fm_disable_status'=>$disable_status));        
        $data['status']=true;   
        return Response($data);

    }

    public function downloadfile($type,$farm_id) {
        $farm_details = FarmModel::find($farm_id);
        if($type == 'weather'){
            $file_path = 'storage/uploads/farm/weather_report/'.$farm_details->fm_weather_report;
        }
        if($type == 'soil'){
            $file_path = 'storage/uploads/farm/soil_report/'.$farm_details->fm_soil_report;
        }
        if($type == 'annual'){
            $file_path = 'storage/uploads/farm/annual_report/'.$farm_details->fm_annual_report;
        }                    
        return \Response::download($file_path);
    }
}
