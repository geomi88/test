<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use \DrewM\MailChimp\MailChimp;
use Cookie;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Auth;
use App\User as User;
use DB,Mail;
use Hash;
use File;
use Illuminate\Support\Facades\Storage;
use Session;
use Lang;

use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Models\Admodels\CountryModel;

use DateTime;
use Carbon\Carbon as Carbon;
use Illuminate\Support\Facades\Log;
use ChannelLog as CustomLog;
use Alert;
use Socialite;



class SocialAuthGoogleController extends FrontendBaseController {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    protected $user;
    
    protected $userActionData;

    public function __construct() {
        parent::__construct();
        
        $this->middleware(function ($request, $next) {
            $this->user = Auth::user();
            return $next($request);
        });
    }
	
    public function redirect($lang='en',Request $request){
        return Socialite::driver('google')->redirect();
    }

    private function getCountryId($iso2Code){
        if(empty($iso2Code)) return null;
        $country = CountryModel::where('iso','=',strtoupper($iso2Code))->first();
        if(empty($country)) return null;
        return $country->country_id;
    }
    
    private function save_profile_image($url){
        try{
            $filename = md5(microtime()).'.jpg';
            \Image::make($url)->save(storage_path('app/public/uploads/user/'.$filename));
            \Image::make($url)->save(storage_path('app/public/uploads/user/small/'.$filename));
            \Image::make($url)->save(storage_path('app/public/uploads/user/large/'.$filename));
            return $filename;
        }catch(\Exception $ex){

		}
        return null;        
    }
    
    private function sendRegEmail($lang, $mailData){
        
        \Mail::send('frontend.email_template.autoreply_register_'.$lang, $mailData, function($message) use ($mailData) {
            $message->to($mailData['email'])->subject(Lang::get('messages.reg_email_message'));
        });
    }
    
    public function callback($lang='en',Request $request){
        //try {
            
            $googleUser = Socialite::driver('google')->user();
            $existUser = User::where('user_email',$googleUser->email)->first();
            if($existUser) {
                Auth::loginUsingId($existUser->id);
            }else {
                    
                    $profilePic = $this->save_profile_image($googleUser->avatar_original); 

                    $userPass = rand(10000,99999);  
                    
                    //$memberRole = Role::where('name','=','Website Member')->first();
                    
                    $user = new User;
                    
                    $user->user_first_name = $googleUser->user['given_name'];
                    
                    $user->user_gender = isset($googleUser->user['gender']) ? $googleUser->user['gender'] : '';
                    
                    $user->user_full_name = $googleUser->name;
                    
                    $user->username = $googleUser->email;
                    
                    $user->user_email = $googleUser->email;
                    
                    $user->user_google_id = $googleUser->id;
                    
                    $user->user_google_link = isset($googleUser->user['url']) ? $googleUser->user['url']  : '';
                    
                    
                    $user->user_avatar = $profilePic;
                    
                    $user->password = \Hash::make($userPass);
                    $user->user_code = User::max('user_code')+1;
                    $user->save(); 
                    
                    //$user->assignRole($memberRole);
                    
                    //$user->original_password = $userPass;
                    //$mailData = $user->toArray(); 
                    /*try{    
                        $this->sendRegEmail($lang, $mailData);                
                    }catch(\Exception $ex){
                        CustomLog::log('reg_email_error',print_r($request->input('email').'::'.$ex->getMessage(),true));
                    }   */ 
                                   
                    Auth::loginUsingId($user->id);
                    session(['tempPass'=>$userPass]);
                    session(['socialSignup'=> true]);
                    
                }
                
                return redirect()->to($lang.'/home')->with('userMessage',Lang::get('messages.registration_welcome_message'));
            /*} 
        catch (\Exception $e) {

            //CustomLog::log('linkedin_error',print_r($e->getMessage(),true));
            return redirect()->to($lang.'/register')->with('userMessage',Lang::get('messages.google_signup_error'));
        }*/
    }
    
    
		
}
