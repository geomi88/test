<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Cookie;
use App\Models\CountryModel;
use App\Models\Admodels\PostModel;
use App\Models\Admodels\EventModel;
use App\Models\Admodels\HubModel;
use App\Models\Admodels\MenuManagerModel;
use Illuminate\Support\Facades\View;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Validation\Validator;
use CustomCalendar\Calendar;

use Auth;
use App\User as User;
use Lang;
use Image;
use DB;
use Input;
use File;
use App\Models\FarmModel;
use App\Models\CategoryModel;
use App\Models\AgricultureModel;
use App\Models\FacilityModel;
use App\Models\SoilModel;
use App\Models\IrrigationModel;
use App\Models\AgricultureTypeModel;
use App\Models\FarmCrops;
use App\Models\GalleryModel;
use App\Models\UserFarmBookmarkModel;
use App\Models\FarmRatingModel;
use App\Models\FarmSubscriptionModel;

use App\Http\Controllers\API\ElasticSearchController as ES;

class FarmController extends FrontendBaseController {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
          
            $this->user = Auth::user();
            return $next($request);
        });
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */


    public function add($lang,$uuid='',Request $request) {
        $lang= $this->data['lang'];
        if(empty($uuid))
        {
           $uuid = (string) \Uuid::generate(5,microtime(), \Uuid::NS_DNS);

           /**ElasticSearch */
           app('App\Http\Controllers\API\ElasticSearchController')->add_farm_index($uuid); 

           return redirect()->to("$lang/farm-signup/" . $uuid);
        }
        else
        {
            if($request->ajax()){
              $data = $request->all();
              $farm_check = FarmModel::where('fm_uuid', $data['uuid'])->first();
              $farmDetails = FarmModel::firstOrCreate (array('fm_uuid' => $data['uuid']));  
              
              
              if(!$farm_check)
              {
                $farmDetails->fm_code = FarmModel::max('fm_code')+1;

                if($data['farm_name'] == '')
                {
                    $farmDetails->fm_slug = FarmModel::max('fm_code')+1;
                }
                
              }
			  
              $farmDetails->fm_title = $data['farm_name'];
              $farmDetails->fm_country_id = $data['country_id'];
              $farmDetails->fm_owner_id = Auth::user()->id;
              $farmDetails->fm_state_name = $data['state'];
              $farmDetails->fm_city = $data['city'];
              $farmDetails->fm_zipcode = $data['zip'];
              $farmDetails->fm_area = $data['total_area'];
              $farmDetails->fm_area_unit = $data['area_unit'];
              $farmDetails->fm_plots_no = $data['plots'];
              $farmDetails->fm_soil_id = $data['soil_id'];
              $farmDetails->fm_irrigation_id = $data['irrigation_id'];
              $farmDetails->fm_agriculture_type_id = $data['agriculture_type_id'];
              $farmDetails->fm_farm_highlights = $data['farm_highlights'];
              $farmDetails->fm_about_farm = $data['farm_about'];
              //$farmDetails->fm_house_description = $data['farm_house_description'];
              $farmDetails->fm_policies = $data['farm_policies'];
              $farmDetails->fm_start_date = $data['available_start_date'];
              $farmDetails->fm_end_date = $data['available_end_date'];
              $farmDetails->fm_created_by = Auth::user()->id;
              $farmDetails->fm_updated_by = Auth::user()->id;
              $farmDetails->fm_status = $data['farm_status'];
                                                                                          
                /*$plotFile = $request->file('plot_map');

				if($plotFile){
					$filePath = 'public/uploads/farm/plot/';
					list($fileName, $fileNameWithPath) = $this->store_file('fm_plot_map', $filePath);
					$farmDetails->fm_plot_map = $fileName;
				}*/
                /*$weatherFile = $request->file('weather_report');

				if($weatherFile){
					$filePath = 'public/uploads/farm/weather_report/';
					list($fileName, $fileNameWithPath) = $this->store_file('weather_report', $filePath);
					$farmDetails->fm_weather_report = $fileName;
				}*/
                if(!empty($data['plot_map_image']))
                {
                    $farmDetails->fm_plot_map = $data['plot_map_image'];
                }
                if(!empty($data['weather_report_image']))
                {
                    $farmDetails->fm_weather_report = $data['weather_report_image'];
                }
                if(!empty($data['soil_report_image']))
                {
                    $farmDetails->fm_soil_report = $data['soil_report_image'];
                }
                if(!empty($data['annual_report_image']))
                {
                    $farmDetails->fm_annual_report = $data['annual_report_image'];
                }
                
                $farmDetails->fm_latitude = $data['farm_latitude'];
                $farmDetails->fm_longitude = $data['farm_longitude'];
                $farmDetails->fm_price = $data['farm_price'];
                if(!empty($data['farm_main_image']))
                {
                    $farmDetails->fm_main_image = $data['farm_main_image'];
                }
                
                /*if((!empty($data['country_id']) || !empty($data['state']) || !empty($data['city']) || !empty($data['zip']))
                  )
                {
                    $country_details = CountryModel::find($data['country_id']);

                    $address = $data['city'].','.$data['state'].','.$country_details->country_name.','.$data['zip'];
                    $curl = curl_init();

                    curl_setopt($curl, CURLOPT_URL, 'https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyD7dxAhKeEHs4QpOPhGqOSwl2NFfW9rqtk&address=' . rawurlencode($address));

                    curl_setopt ($curl, CURLOPT_RETURNTRANSFER, 1);

                    $json = curl_exec($curl);
                    
                    $co_ordinates = json_decode($json);
                    
                    $farmDetails->fm_latitude = $co_ordinates->results[0]->geometry->location->lat;
                    $farmDetails->fm_longitude = $co_ordinates->results[0]->geometry->location->lng;
                }*/
                    
                    
                $farmDetails->save();
                
                $farm_categories_arr = [];
                if(!empty($data['farm_categories']))
                {
                    $farm_categories_arr = $data['farm_categories'];
                }
                $farmDetails->categories()->sync($farm_categories_arr);
                
                $farm_facilities_arr = [];                
                if(!empty($data['farm_facilities']))
                {
                    $farm_facilities_arr = $data['farm_facilities'];                    
                }
                $farmDetails->facilities()->sync($farm_facilities_arr);
                
                $crops_list = json_decode($data['crops_list']);
                FarmCrops::where('farm_id',$farmDetails->fm_id)->delete();
                foreach($crops_list as $crop)
                {
                    $farm_crops_obj = FarmCrops::firstOrCreate (array('farm_id' => $farmDetails->fm_id,'agriculture_id' => $crop->crop_id));
                    /*$crop_data['farm_id'] = $farmDetails->fm_id;
                    $crop_data['agriculture_id'] = $crop->crop_id;
                    $crop_data['fc_min_duration'] = $crop->crop_min_duration;
                    $crop_data['fc_season'] = $crop->crop_season;
                    $crop_data['fc_farm_type'] = $crop->crop_farm_type;
                    $crop_data['fc_price'] = $crop->crop_price;
                    
                    FarmCrops::create($crop_data);*/
                    $farm_crops_obj->farm_id = $farmDetails->fm_id;
                    $farm_crops_obj->agriculture_id = $crop->crop_id;
                    $farm_crops_obj->fc_min_duration = $crop->crop_min_duration;
                    $farm_crops_obj->fc_season = $crop->crop_season;
                    $farm_crops_obj->fc_farm_type = $crop->crop_farm_type;
                    $farm_crops_obj->save();
                }
                
                $gallery_list = json_decode($data['gallery_list']);
                GalleryModel::where('gallery_farm_id',$farmDetails->fm_id)->delete();
                foreach($gallery_list as $gallery)
                {
                    $gallery_obj = GalleryModel::firstOrCreate (array('gallery_farm_id' => $farmDetails->fm_id,'gallery_image_name' => $gallery->gal_img));
                    $gallery_obj->gallery_farm_id = $farmDetails->fm_id;
                    $gallery_obj->gallery_image_name = $gallery->gal_img;
                    $gallery_obj->gallery_image_type = 1;
                    $gallery_obj->gallery_image_date = date('Y-m-d H:i:s');
                    $gallery_obj->gallery_image_status = 1;
                    $gallery_obj->save();
                    /*$insertDatas = array(
										'gallery_farm_id' => $farmDetails->fm_id,
										'gallery_image_name' => $gallery->gal_img,
										'gallery_image_type' => 1,
										'gallery_image_date' => date('Y-m-d H:i:s'),
										'gallery_image_status' => 1
									);
					DB::table('gallery_images')->insertGetId($insertDatas);*/
                }
               /**ElasticSearch */
              app('App\Http\Controllers\API\ElasticSearchController')->add_farm($request); 
              if($request->ajax()){  
				$arr = array('status' => true);
				return Response()->json($arr);
			  }
              $this->data['userMessage'] = lang('farm_added_successfully');
              
              
            }
        }

        
        //ES->add_farm($request);

        $lang= $this->data['lang'];
        $this->data['categoryList'] = CategoryModel::active()->get();
        $this->data['countryList'] = CountryModel::active()->get();
        $this->data['agricultureList'] = AgricultureModel::active()->get();
        $this->data['facilityList'] = FacilityModel::active()->get();
        $this->data['soilList'] = SoilModel::active()->get();
        $this->data['irrigationList'] = IrrigationModel::active()->get();
        $this->data['agricultureTypeList'] = AgricultureTypeModel::active()->get();
        $this->data['uuid'] = $uuid;
		$this->data['farmDetails'] = FarmModel::where('fm_uuid' ,'=', $uuid)->first();
		// pre($this->data['farmDetails']);
		return view('frontend.farm.add',$this->data);
    }

    public function search(Request $request) {
        $this->data['isSearchPage'] = true;
        
        $search_key = Input::get('search_key');
        $search_location = Input::get('search_location');
        $search_price = Input::get('search_price');
        $search_crop = Input::get('search_crop');
        $search_facility = Input::get('search_facility');
        //$request->flashOnly('search_key');
        $request->flash();

        $query = FarmModel::active();                
             $query->when($search_key, function ($q) use ($search_key) {
                return $q->where('fm_title', 'LIKE', "%$search_key%");
            });
            $query->when($search_location, function ($q) use ($search_location) {
                return $q->whereIn('fm_state_name', $search_location);
            });
            $query->when($search_price, function ($q) use ($search_price) {
                return $q->where('fm_price', $search_price);
            });
            if(!empty($search_crop))
            {
            $query->whereHas('crops',function($q) use($search_crop) {
               
                return $q->whereIn('agriculture_master.agriculture_id', $search_crop);
                              
            });
            }
            if(!empty($search_facility))
            {
            $query->whereHas('facilities',function($q) use($search_facility) {
               
                return $q->whereIn('facility_master.facility_id', $search_facility);
                              
            });
            }
            $query->get();
        
        $farms = $query->paginate(6);
        
        $map_array = array();
        foreach($farms as $farm)
        {
            $row['fm_title'] = $farm->fm_title;
            $row['fm_latitude'] = $farm->fm_latitude;
            $row['fm_longitude'] = $farm->fm_longitude;
            $row['fm_area'] = $farm->fm_area;
            $row['fm_area_unit'] = $farm->fm_area_unit;
            $row['fm_state_name'] = $farm->fm_state_name;
            $row['fm_price'] = $farm->fm_price;
            $row['fm_main_image'] = asset('storage/uploads/farm/image/'.$farm->fm_main_image);
            $crops = $farm->crops;
            foreach($crops as $crop)
            {                
                $crop_row[$crop->agriculture_title] =  asset('storage/uploads/agriculture/icon/'.$crop->agriculture_icon);
            }
            $row['crops'] = $crop_row;
            array_push($map_array,$row);
        }
        $querystringArray = Input::only(['search_key','search_location','search_price','search_crop','search_facility']);
        $farms->appends($querystringArray);
        
        $this->data['search_key'] = $search_key;
        $this->data['farms'] = $farms;
        $this->data['map_array'] = $map_array;
        return view('frontend.farm.search',$this->data);
    }
    
    public function ajax_search(Request $request) {
        $this->data['isSearchPage'] = true;
        $this->data['search_key'] = Input::get('search_key');
        $this->data['ft'] = Input::get('ft');
        $request->session()->put('search_keyword', Input::get('search_key'));
        return view('frontend.farm.ajax_search',$this->data);
    }
	
	public function farm_details($lang, $slug, Request $request){
		// pre($slug);	
        // $slug = $
        try{
            $farmDetails = FarmModel::where('fm_slug','=',$slug)->first();
            if(empty($farmDetails)){
                return redirect()->to($lang)->with('errorMessage',lang('invalid_request'));
            }
            $farmDetails->isFav = 0;
            if(Auth::user()){
                $check_fav = UserFarmBookmarkModel::where('ufb_user_id', Auth::user()->id)->where('ufb_farm_id', $farmDetails->fm_id)->first();   
            
                if(!empty($check_fav)){
                    $farmDetails->isFav = 1;
                }
            }
            
            $farmDetails->plots_available = 0;
            if($farmDetails->fm_plots_no > 0)
            {
                //$subscription_details = FarmSubscriptionModel::select(DB::raw('sum(fs_number_of_plots) as booked_plots_no'))->where('fs_start_date','>=',$farmDetails->fm_start_date)->where('fs_farm_id','=',$farmDetails->fm_id)->first();
                $subscription_details = FarmSubscriptionModel::select(DB::raw('sum(fs_number_of_plots) as booked_plots_no'))->whereRaw("DATE_ADD(fs_start_date, INTERVAL fs_duration_months MONTH) >= NOW()")->where('fs_farm_id','=',$farmDetails->fm_id)->first();
                $farmDetails->plots_available = $farmDetails->fm_plots_no - $subscription_details->booked_plots_no;
            }
            if(date('Y-m-d') > $farmDetails->fm_end_date ){
                $farmDetails->plots_available = 0;
            }
            elseif($farmDetails->fm_status == 0 || $farmDetails->fm_disable_status == 1){
                $farmDetails->plots_available = 0;
            }
            $reviews = FarmRatingModel::where('fr_farm_id','=',$farmDetails->fm_id)->paginate(4);
            
            $this->data['farmDetails'] = $farmDetails;
            $this->data['reviews'] = $reviews;
            return view('frontend.farm.details',$this->data);
        }catch(\Exception $e){            
            $data = $this->catch_message();
            return  redirect($this->data['lang'].'/home')->with('userMessage',$data);
        }
		
		
	}
    public function owner_profile($lang, $id, Request $request){
		try{
            $userDetails = User::where('id','=',$id)->first();            
            
            $farms = FarmModel::active()->where('fm_owner_id','=',$id)->get();
            
            $this->data['userDetails'] = $userDetails;
            $this->data['farms'] = $farms;
            return view('frontend.farm.owner_profile',$this->data);
        }catch(\Exception $e){            
            $data = $this->catch_message();
            return  redirect($this->data['lang'].'/home')->with('userMessage',$data);
        }
		
    }
    

    public function edit($lang,$uuid='',Request $request) {
        try{
            $lang= $this->data['lang'];
            $this->data['categoryList'] = CategoryModel::active()->get();
            $this->data['countryList'] = CountryModel::active()->get();
            $this->data['agricultureList'] = AgricultureModel::active()->get();
            $this->data['facilityList'] = FacilityModel::active()->get();
            $this->data['soilList'] = SoilModel::active()->get();
            $this->data['irrigationList'] = IrrigationModel::active()->get();
            $this->data['agricultureTypeList'] = AgricultureTypeModel::active()->get();
            $this->data['uuid'] = $uuid;
            $this->data['farmDetails'] = FarmModel::where('fm_uuid' ,'=', $uuid)->first();
            
            return view('frontend.farm.edit',$this->data);
        }catch(\Exception $e){            
            $data = $this->catch_message();
            return  redirect($this->data['lang'].'/home')->with('userMessage',$data);
        }
    }

    public function addreview($lang,$user_id,$review_code,Request $request) {
        try{
            Auth::loginUsingId($user_id);
            if(Auth::user()){            
                $this->data['unread_notifications'] = Auth::user()->unreadNotifications()->count();       
            }
            $subs_details = FarmSubscriptionModel::where('fs_review_code','=',$review_code)->where('fs_user_id','=',$user_id)->first();
            $farmDetails = FarmModel::where('fm_id','=',$subs_details->fs_farm_id)->first();
            $this->data['farmDetails'] = $farmDetails;
            return view('frontend.farm.addreview',$this->data);
        }catch(\Exception $e){            
            $data = $this->catch_message();
            return  redirect($this->data['lang'].'/home')->with('userMessage',$data);
        }
    }
    public function farm_notify($lang, $user_id, $farm_slug){
		try{
            Auth::loginUsingId($user_id);
            return  redirect($this->data['lang']."/farm/$farm_slug");
        }catch(\Exception $e){            
            $data = $this->catch_message();
            return  redirect($this->data['lang'].'/home')->with('userMessage',$data);
        }
		
    }
}
