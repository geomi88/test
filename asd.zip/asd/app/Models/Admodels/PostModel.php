<?php
namespace App\Models\Admodels;

use DB;
use Illuminate\Database\Eloquent\Model;
use App\Models\Extension\BaseAppModel;
use Cviebrock\EloquentSluggable\Sluggable;
use \Venturecraft\Revisionable\RevisionableTrait;
// use Plank\Metable\Metable;
use App\Traits\PGSMetable;
use App\Traits\DataTrait;


class PostModel extends Model {

		/**
		 * The database table used by the model.
		 *
		 * @var string
		 */
        use RevisionableTrait;
        use Sluggable;
        use \Conner\Tagging\Taggable;
        // use Metable;
        use PGSMetable,DataTrait;
        
		protected $table = 'posts';

        protected $primaryKey = 'post_id';
        
        protected $with = ['meta'];
        
        protected $revisionEnabled = true;
        protected $revisionCreationsEnabled = true;
        protected $historyLimit = 50;
       // protected $revisionCleanup = true; //Remove old revisions (works only when used with $historyLimit)
      

		protected $fillable =  [ 
                                    'post_slug',
                                    'post_type',
                                    'post_category_id',
                                    'post_title',
                                    'post_title_arabic',
                                    'post_image',
                                    'post_image_arabic',
                                    'post_priority',
                                    'post_set_as_banner',
                                    'post_created_by',
                                    'post_updated_by',                                    
                                    'post_status'
                                ];

        const CREATED_AT = 'post_created_at';

        const UPDATED_AT = 'post_updated_at';
        
        public function sluggable(){
            return [
                'post_slug' => [
                    'source' => 'removeTags'
                ]
            ];
        }
		
		public function getRemoveTagsAttribute() {
			return strip_tags($this->post_title);
		}
        public static function boot(){
            parent::boot();
        }
		
		function isActive(){
			return ($this->post_status == 1);
		}
        
       /*  public function gallery(){
			return $this->hasMany('\App\Models\Admodels\GalleryModel','gallery_post_id','post_id');
		}
        
        public function youtubeGallery(){
			return $this->hasMany('\App\Models\Admodels\GalleryModel','gallery_post_id','post_id')->where('gallery_image_type','=',2);
		} */

        




}