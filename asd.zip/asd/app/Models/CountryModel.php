<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use DB;
use \App\Traits\DataTrait;
class CountryModel extends Model {
	use DataTrait;
		/**
		 * The database table used by the model.
		 *
		 * @var string
		 */

		protected $table = 'country';

		protected $primaryKey = 'country_id';



		protected $fillable = ['country_name','iso','name','country_name_arabic','iso3','numcode','phonecode','country_status'];
		//protected $fillable = ['test'];

		 const CREATED_AT = 'country_created_at';

		 const UPDATED_AT = 'country_updated_at';
         
         public function scopeActive($query){
            return $query->where('country_status', 1);
        }

        public function scopeInActive($query){
            return $query->where('country_status', 2);
        }








}