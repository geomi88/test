<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;
use DB;


class AgricultureTypeModel extends Model {

    use Sluggable;
    
	use SoftDeletes;

    protected $table = 'agriculture_types';
	
	protected $primaryKey = 'agriculture_type_id';
	
	protected $dates = ['deleted_at'];

    protected $fillable = [
        'agriculture_type_title',
        'agriculture_type_slug',
        'agriculture_type_status'
    ];

    const CREATED_AT = 'agriculture_type_created_at'; 

    const UPDATED_AT = 'agriculture_type_updated_at';
    
    public function sluggable(){
        return [
            'agriculture_type_slug' => [
                'source' => 'agriculture_type_title'
            ]
        ];
    }

    public function scopeActive($query){
        return $query->where('agriculture_type_status', 1);
    }

    public function scopeInActive($query){
        return $query->where('agriculture_type_status', 2);
    }

}