<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;
use DB;


class FacilityModel extends Model {

    use Sluggable;
	
	use SoftDeletes;
    
    protected $table = 'facility_master';
	
	protected $primaryKey = 'facility_id';
	
	protected $dates = ['deleted_at'];	

	
    protected $with = [];

    protected $fillable = [
        'facility_title',
        'facility_slug',
        'facility_image',
        'facility_icon',
        'facility_exceprt',
        'facility_description',
        'facility_created_at',
        'facility_updated_at',
        'facility_created_by',
        'facility_updated_by',
        'facility_status'
    ];

    const CREATED_AT = 'facility_created_at'; 

    const UPDATED_AT = 'facility_updated_at';
    
    public function sluggable(){
        return [
            'facility_slug' => [
                'source' => 'facility_title'
            ]
        ];
    }

    public function scopeActive($query){
        return $query->where('facility_status', 1);
    }

    public function scopeInActive($query){
        return $query->where('facility_status', 2);
    }

}