<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use DB;


class FarmSubscriptionCropModel extends Model {

 

    protected $table = 'farm_subscription_crops';
	
	protected $primaryKey = 'fsc_id';

	
    protected $with = [];

    protected $fillable = [
        'fsc_subscription_id',
        'fsc_crop_id'
    ];
	
	public $timestamps = false;
	
	
    public function single_crop()
    {
        return $this->hasOne('App\Models\AgricultureModel','agriculture_id','fsc_crop_id');
    }
    

}