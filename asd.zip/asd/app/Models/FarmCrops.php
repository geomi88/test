<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;


class FarmCrops extends Model {


    protected $table = 'farm_crops';
	
	protected $primaryKey = 'farm_crops_id';

	
    protected $with = [];

    protected $fillable = [
       'farm_id',
       'agriculture_id',
       'fc_min_duration',
       'fc_season',
       'fc_farm_type',
       'fc_price'
    ];

    const CREATED_AT = 'created_at'; 

    const UPDATED_AT = 'updated_at';
	
	
	public function single_crop(){
        return $this->hasOne('App\Models\AgricultureModel','agriculture_id','agriculture_id');
    }

}