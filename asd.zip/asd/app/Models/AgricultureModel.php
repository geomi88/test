<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;

use DB;


class AgricultureModel extends Model {

    use Sluggable;
	
	use SoftDeletes;


    protected $table = 'agriculture_master';
	
	protected $primaryKey = 'agriculture_id';

	protected $dates = ['deleted_at'];
	
    protected $with = [];

    protected $fillable = [
        'agriculture_uuid',
        'agriculture_category_id',
        'agriculture_type_id',
        'agriculture_title',
        'agriculture_slug',
        'agriculture_image',
        'agriculture_icon',
        'agriculture_cultivate_min_duration',
        'agriculture_cultivate_max_duration',
        'agriculture_excerpt',
        'agriculture_description',
        'agriculture_created_at',
        'agriculture_updated_at',
        'agriculture_created_by',
        'agriculture_updated_by',
        'agriculture_status'
    ];

    const CREATED_AT = 'agriculture_created_at'; 

    const UPDATED_AT = 'agriculture_updated_at';
    
    public function sluggable(){
        return [
            'agriculture_slug' => [
                'source' => 'agriculture_title'
            ]
        ];
    }

    public function scopeActive($query){
        return $query->where('agriculture_status', 1);
    }

    public function scopeInActive($query){
        return $query->where('agriculture_status', 2);
    }

    public function Category(){
		return $this->belongsTo('App\Models\CategoryModel','agriculture_category_id','category_id');
	}
    
    public function AgricultureType(){
		return $this->belongsTo('App\Models\AgricultureTypeModel','agriculture_type_id','agriculture_type_id');
	}

}