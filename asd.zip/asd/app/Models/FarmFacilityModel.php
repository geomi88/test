<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use DB;


class FarmFacilityModel extends Model {

 

    protected $table = 'farm_facilities';
	
	protected $primaryKey = 'farm_facilities_id';

	
    protected $with = [];

    protected $fillable = [
        'farm_id',
        'facility_id'
    ];

    const CREATED_AT = 'created_at'; 

    const UPDATED_AT = 'updated_at';
    
	
    public function single_facility()
    {
        return $this->hasOne('App\Models\FacilityModel','facility_id','facility_id');
    }
    

}