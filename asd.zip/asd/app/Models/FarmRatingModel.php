<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use Auth;

class FarmRatingModel extends Model {

    

    protected $table = 'farm_ratings';
	
	protected $primaryKey = 'fr_id';

	
    protected $with = [];

    protected $fillable = [
        'fr_comment',
        'fr_user_id',
        'fr_farm_id',
        'fr_rating',
        'fr_status'
    ];

    const CREATED_AT = 'fr_created_at'; 

    const UPDATED_AT = 'fr_updated_at';
    
    

    public function scopeActive($query){
        return $query->where('fr_status', 1);
    }

    public function scopeInActive($query){
        return $query->where('fr_status', 2);
    }

    public function owner(){
        return $this->belongsTo('App\User','fr_user_id','id');
    }

    public function getOwnedFarmDetails()
    {
        return $this->belongsTo('App\Models\FarmModel', 'fr_farm_id', 'fm_id')->where('fm_owner_id',Auth::user()->id);
    }

    public function getFarmDetails()
    {
        return $this->belongsTo('App\Models\FarmModel', 'fr_farm_id', 'fm_id');
    }
}