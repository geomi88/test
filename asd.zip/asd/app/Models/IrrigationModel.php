<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;
use DB;


class IrrigationModel extends Model {

    use Sluggable;
    
	use SoftDeletes;
	
    protected $table = 'irrigations';
	
	protected $primaryKey = 'irrigation_id';
	
	
	protected $dates = ['deleted_at'];

    protected $fillable = [
        'irrigation_title',
        'irrigation_slug',
        'irrigation_status'
    ];

    const CREATED_AT = 'irrigation_created_at'; 

    const UPDATED_AT = 'irrigation_updated_at';
    
    public function sluggable(){
        return [
            'irrigation_slug' => [
                'source' => 'irrigation_title'
            ]
        ];
    }

    public function scopeActive($query){
        return $query->where('irrigation_status', 1);
    }

    public function scopeInActive($query){
        return $query->where('irrigation_status', 2);
    }

}