<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use DB;


class FarmModel extends Model
{

    use Sluggable;

    protected $table = 'farm_master';

    protected $primaryKey = 'fm_id';


    protected $with = [];

    protected $fillable = [
        'fm_uuid',
        'fm_code',
        'fm_title',
        'fm_price',
        'fm_slug',
        'fm_owner_id',
        'fm_main_image',
        'fm_country_id',
        'fm_state_name',
        'fm_city',
        'fm_zipcode',
        'fm_latitude',
        'fm_longitude',
        'fm_type',
        'fm_area',
        'fm_area_unit',
        'fm_plots_no',
        'fm_plot_map',
        'fm_soil_id',
        'fm_irrigation_id',
        'fm_agriculture_type_id',
        'fm_weather_report',
        'fm_soil_report',
        'fm_annual_report',
        'fm_farm_highlights',
        'fm_about_farm',
        'fm_created_at',
        'fm_updated_at',
        'fm_created_by',
        'fm_updated_by',
        'fm_status',
        'fm_house_description',
        'fm_policies',
        'fm_start_date',
        'fm_end_date',
        'fm_disable_status'
    ];

    const CREATED_AT = 'fm_created_at';

    const UPDATED_AT = 'fm_updated_at';

    public function sluggable()
    {
        return [
            'fm_slug' => [
                'source' => 'fm_title'
            ]
        ];
    }

    public function scopeActive($query)
    {
        return $query->where('fm_status', 1)->where('fm_disable_status', 0);
    }

    public function scopeInActive($query)
    {
        return $query->where('fm_status', 2);
    }

    public function gallery()
    {
        return $this->hasMany('App\Models\GalleryModel', 'gallery_farm_id', 'fm_id');
    }
    public function reviews()
    {
        return $this->hasMany('App\Models\FarmRatingModel', 'fr_farm_id', 'fm_id');
    }

    public function categories()
    {
        return $this->belongsToMany('App\Models\CategoryModel', 'farm_categories', 'farm_id', 'category_id');
    }

    public function country()
    {
        return $this->belongsTo('App\Models\CountryModel', 'fm_country_id', 'country_id');
    }

    public function owner()
    {
        return $this->belongsTo('App\User', 'fm_owner_id', 'id');
    }

    public function crops()
    {
        return $this->belongsToMany('App\Models\AgricultureModel', 'farm_crops', 'farm_id', 'agriculture_id')->withPivot('fc_min_duration', 'fc_season', 'fc_farm_type');
        // return $this->hasMany('App\Models\FarmCrops','farm_id','fm_id');

    }

    public function facilities()
    {
        //return $this->hasMany('App\Models\FarmFacilityModel','farm_id','fm_id');
        return $this->belongsToMany('App\Models\FacilityModel', 'farm_facilities', 'farm_id', 'facility_id');
    }

    public function subscriptions()
    {
        return $this->hasMany('App\Models\FarmSubscriptionModel', 'fs_farm_id', 'fm_id');
    }
}
