<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;


class UserFarmBookmarkModel extends Model {

    

    protected $table = 'user_farm_bookmarks';
	
	protected $primaryKey = 'ufb_id';

	
    protected $with = [];

    protected $fillable = [
        'ufb_id',
        'ufb_user_id',
        'ufb_farm_id',
        'ufb_created_at'
    ];

    const CREATED_AT = 'ufb_created_at'; 

    const UPDATED_AT = 'ufb_updated_at';
    
    /*public function crops(){
		return $this->hasMany('App\Models\Admodels\HubWorkingModel','hwm_hub_id','hub_id');
	}*/
    public function farm()
    {
        return $this->belongsTo('App\Models\FarmModel','ufb_farm_id','fm_id');
    }
   public function getFarmDetails()
    {
        return $this->belongsTo('App\Models\FarmModel','ufb_farm_id','fm_id')->where('fm_status',1);
    }
   
	
	public function user(){
        return $this->belongsTo('App\User','ufb_user_id','id');
    }
    
}