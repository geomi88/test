<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;
use DB;


class SoilModel extends Model {

    use Sluggable;
    
	use SoftDeletes;

    protected $table = 'soils';
	
	protected $primaryKey = 'soil_id';
	
	protected $dates = ['deleted_at'];

    protected $fillable = [
        'soil_title',
        'soil_slug',
        'soil_status'
    ];

    const CREATED_AT = 'soil_created_at'; 

    const UPDATED_AT = 'soil_updated_at';
    
    public function sluggable(){
        return [
            'soil_slug' => [
                'source' => 'soil_title'
            ]
        ];
    }

    public function scopeActive($query){
        return $query->where('soil_status', 1);
    }

    public function scopeInActive($query){
        return $query->where('soil_status', 2);
    }

}