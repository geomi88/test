<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;


class FarmAvailabilityNotificationModel extends Model {

    

    protected $table = 'farm_availability_notifications';
	
	protected $primaryKey = 'fan_id';

	
    protected $with = [];

    protected $fillable = [
        'fan_id',
        'fan_user_id',
        'fan_farm_id',
    ];

    const CREATED_AT = 'fan_created_at'; 

    const UPDATED_AT = 'fan_updated_at';
    
    public function farm()
    {
        return $this->belongsTo('App\Models\FarmModel','fan_farm_id','fm_id');
    }
   public function getFarmDetails()
    {
        return $this->belongsTo('App\Models\FarmModel','fan_farm_id','fm_id')->where('fm_status',1);
    }
   	
	public function user(){
        return $this->belongsTo('App\User','fan_user_id','id');
    }
    
}