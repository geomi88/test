<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use DB;
use Auth;

class FarmSubscriptionModel extends Model
{



    protected $table = 'farm_subscription';

    protected $primaryKey = 'fs_id';


    protected $with = [];

    protected $fillable = [
        'fs_user_id',
        'fs_farm_id',
        'fs_duration_months',
        'fs_number_of_plots',
        'fs_total_amount',
        'fs_start_month',
        'fs_created_by',
        'fs_updated_by',
        'fs_review_code'
    ];

    const CREATED_AT = 'fs_created_at';

    const UPDATED_AT = 'fs_updated_at';


    public function subscribed_crops()
    {
        return $this->hasMany('App\Models\FarmSubscriptionCropModel', 'fsc_subscription_id', 'fs_id');
    }
    public function crops()
    {
        return $this->belongsToMany('App\Models\CategoryModel', 'farm_subscription_crops', 'fsc_subscription_id', 'fsc_crop_id');
    }

    public function getFarmDetails()
    {
        return $this->belongsTo('App\Models\FarmModel', 'fs_farm_id', 'fm_id');
    }
    public function getOwnedFarmDetails()
    {
        return $this->belongsTo('App\Models\FarmModel', 'fs_farm_id', 'fm_id')->where('fm_owner_id',Auth::user()->id);
    }

    public function subscriber_details()
    {
        return $this->belongsTo('App\User', 'fs_user_id', 'id');
    }

    public function deliveryCountry(){
        return $this->hasOne('App\Models\CountryModel','country_id','fs_delivery_country_id');
    }
}
