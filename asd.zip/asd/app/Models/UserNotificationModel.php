<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use Auth;

class UserNotificationModel extends Model {
    
    protected $table = 'user_notifications';
	
	protected $primaryKey = 'un_id';

	
    protected $with = [];

    protected $fillable = [
        'un_user_id',
        'un_farm_id',
        'un_type',
        'un_read_status'
    ];

    const CREATED_AT = 'un_created_at'; 

    const UPDATED_AT = 'un_updated_at';


    public function scopeActive($query){
        return $query->where('un_status', 1);
    }

    public function scopeInActive($query){
        return $query->where('un_status', 2);
    }

    public function unread($query){
        return $query->where('un_read_status', 0);
    }

    public function fromuserDetails(){
        return $this->belongsTo('App\User', 'un_from_user_id', 'id');
    }

    public function touserDetails(){
        return $this->belongsTo('App\User', 'un_to_user_id', 'id');
    }

    public function farmDetails(){
        return $this->belongsTo('App\Models\FarmModel', 'un_farm_id', 'fm_id');
    }
    
}